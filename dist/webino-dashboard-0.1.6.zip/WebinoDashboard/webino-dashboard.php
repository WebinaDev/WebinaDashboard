<?php
/**
 * Plugin Name:       Webino Dashboard
 * Plugin URI:        https://webina.dev
 * Description:       Standalone customer dashboard at /dashboard (SPA), separate from wp-admin.
 * Version:           0.1.6
 * Author:            Webina
 * Author URI:        https://webina.dev
 * Text Domain:       webino-dashboard
 * Domain Path:       /languages
 * Requires at least: 6.1
 * Requires PHP:      7.4
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WEBINO_DASHBOARD_VERSION', '0.1.6' );
define( 'WEBINO_DASHBOARD_FILE', __FILE__ );
define( 'WEBINO_DASHBOARD_DIR', plugin_dir_path( __FILE__ ) );
define( 'WEBINO_DASHBOARD_URL', plugin_dir_url( __FILE__ ) );
define( 'WEBINO_DASHBOARD_BASENAME', plugin_basename( __FILE__ ) );

require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-i18n.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-install.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-license.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-wfcp-loader.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-modules.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-taxonomies.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rest-base.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rest.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rest-crud.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rest-wfcp.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-bots-loader.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-bots-rest-context.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rest-bots.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-rewrite.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-assets.php';
require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-plugin.php';

/**
 * Begins execution of the plugin.
 *
 * @return Webino_Dashboard_Plugin
 */
function webino_dashboard() {
	return Webino_Dashboard_Plugin::instance();
}

webino_dashboard();

Webino_Dashboard_License::instance();
Webino_Dashboard_WFCP_Loader::init();
Webino_Dashboard_REST_WFCP::init();
Webino_Dashboard_Bots_Loader::init();
Webino_Dashboard_REST_Bots::init();
