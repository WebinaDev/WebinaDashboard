<?php
/**
 * Minimal document shell for the React dashboard (no theme layout).
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wd_uid         = get_current_user_id();
$wd_ui_theme    = $wd_uid ? (string) get_user_meta( $wd_uid, 'webino_dashboard_theme', true ) : '';
$wd_ui_accent   = $wd_uid ? (string) get_user_meta( $wd_uid, 'webino_dashboard_accent', true ) : '';
$wd_ui_theme    = $wd_ui_theme ? $wd_ui_theme : 'system';
$wd_ui_accent   = $wd_ui_accent ? $wd_ui_accent : 'default';
$wd_accents_ok  = array( 'default', 'red', 'rose', 'orange', 'green', 'blue', 'yellow', 'violet' );
if ( 'amber' === $wd_ui_accent ) {
	$wd_ui_accent = 'orange';
}
if ( ! in_array( $wd_ui_accent, $wd_accents_ok, true ) ) {
	$wd_ui_accent = 'default';
}
$wd_html_class = ( 'dark' === $wd_ui_theme ) ? 'dark' : '';

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo esc_attr( $wd_html_class ); ?>" data-accent="<?php echo esc_attr( $wd_ui_accent ); ?>">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo esc_attr( get_bloginfo( 'description', 'display' ) ?: __( 'Store dashboard', 'webino-dashboard' ) ); ?>">
	<title><?php echo esc_html( get_bloginfo( 'name' ) . ' — ' . __( 'Dashboard', 'webino-dashboard' ) ); ?></title>
	<link rel="preconnect" href="<?php echo esc_url( rest_url() ); ?>" crossorigin />
	<script>
	(function () {
		try {
			var stored = localStorage.getItem('wd-theme');
			var theme = stored || <?php echo wp_json_encode( $wd_ui_theme ); ?>;
			var dark =
				theme === 'dark' ||
				(theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
			document.documentElement.classList.toggle('dark', dark);
			document.documentElement.setAttribute('data-accent', <?php echo wp_json_encode( $wd_ui_accent ); ?>);
		} catch (e) {}
	})();
	</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'webino-dashboard-body' ); ?>>
<?php
if ( class_exists( 'Webino_Dashboard_Assets' ) ) {
	Webino_Dashboard_Assets::render_build_missing_notice();
}
?>
<div id="root"></div>
<script>
if (typeof window.freeShippingData === 'undefined') {
	window.freeShippingData = {
		total: 0,
		threshold: 0,
		remaining: 0,
		progress: 0,
	};
}
</script>
<?php wp_footer(); ?>
</body>
</html>
