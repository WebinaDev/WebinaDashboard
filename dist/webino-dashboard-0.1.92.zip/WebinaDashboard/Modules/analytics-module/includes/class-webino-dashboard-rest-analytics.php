<?php
/**
 * REST API for native analytics.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Analytics REST routes.
 */
final class Webino_Dashboard_REST_Analytics {

	const NS = 'webino-dashboard/v1';

	/** Analytics read endpoint cache (seconds). */
	const CACHE_TTL = 90;

	/** Shorter cache for online visitors (seconds). */
	const CACHE_TTL_ONLINE = 15;

	const CACHE_PREFIX = 'webino_analytics_rest_';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/analytics/hit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'hit' ),
				'permission_callback' => '__return_true',
			)
		);

		$admin = array(
			'permission_callback' => array( __CLASS__, 'perm_admin' ),
		);

		register_rest_route(
			self::NS,
			'/analytics/overview',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'overview' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/visitors',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'visitors' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/pages',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'pages' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/referrals',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'referrals' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/geo',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'geo' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/devices',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'devices' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/online',
			array_merge(
				$admin,
				array(
					'methods'  => 'GET',
					'callback' => array( __CLASS__, 'online' ),
				)
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_settings' ),
					'permission_callback' => array( __CLASS__, 'perm_settings' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'save_settings' ),
					'permission_callback' => array( __CLASS__, 'perm_settings' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/purge-cache',
			array_merge(
				$admin,
				array(
					'methods'  => 'POST',
					'callback' => array( __CLASS__, 'purge_cache' ),
				)
			)
		);
	}

	/**
	 * @return bool
	 */
	public static function perm_admin() {
		if ( ! Webino_Dashboard_Analytics::is_module_active() ) {
			return false;
		}
		return Webino_Dashboard_Rest_Base::can_view_analytics();
	}

	/**
	 * @return bool
	 */
	public static function perm_settings() {
		return Webino_Dashboard_Rest_Base::can( 'manage_options' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function hit( WP_REST_Request $request ) {
		$settings = Webino_Dashboard_Analytics::get_settings();
		$token    = (string) $request->get_param( 'token' );
		if ( '' === $token ) {
			$token = (string) $request->get_header( 'X-Webino-Analytics-Token' );
		}
		if ( ! hash_equals( (string) $settings['hit_token'], $token ) ) {
			return new WP_Error( 'forbidden', __( 'Invalid token.', 'webino-dashboard' ), array( 'status' => 403 ) );
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}

		$result = Webino_Dashboard_Analytics_Tracker::record( $body );
		if ( is_wp_error( $result ) ) {
			$code = (int) ( $result->get_error_data()['status'] ?? 400 );
			if ( 200 === $code ) {
				return new WP_REST_Response( array( 'ok' => true, 'skipped' => true ) );
			}
			return $result;
		}

		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @return void
	 */
	private static function ensure_ready() {
		Webino_Dashboard_Analytics_Db::ensure_tables();
	}

	/**
	 * @param string            $endpoint Endpoint slug.
	 * @param WP_REST_Request   $request  Request.
	 * @param callable():array  $builder  Payload builder.
	 * @return WP_REST_Response
	 */
	private static function cached_response( $endpoint, WP_REST_Request $request, callable $builder, $ttl = null ) {
		$key    = self::cache_key( $endpoint, $request );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return new WP_REST_Response( $cached );
		}
		$data      = $builder();
		$cache_ttl = null !== $ttl ? max( 5, (int) $ttl ) : self::CACHE_TTL;
		if ( is_array( $data ) ) {
			set_transient( $key, $data, $cache_ttl );
		}
		return new WP_REST_Response( $data );
	}

	/**
	 * @param string          $endpoint Endpoint slug.
	 * @param WP_REST_Request $request  Request.
	 * @return string
	 */
	private static function cache_key( $endpoint, WP_REST_Request $request ) {
		$parts = array( $endpoint );
		foreach ( array( 'from', 'to', 'days', 'page', 'per_page', 'search', 'dim' ) as $param ) {
			$val = $request->get_param( $param );
			if ( null !== $val && '' !== $val ) {
				$parts[] = $param . '=' . (string) $val;
			}
		}
		return self::CACHE_PREFIX . md5( implode( '|', $parts ) );
	}

	/**
	 * @return void
	 */
	private static function flush_read_cache() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::CACHE_PREFIX ) . '%',
				$wpdb->esc_like( '_transient_timeout_' . self::CACHE_PREFIX ) . '%'
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function overview( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'overview',
			$request,
			function () use ( $request ) {
				$range = self::parse_range( $request );
				$data  = Webino_Dashboard_Analytics_Query::overview( $range['from'], $range['to'] );
				return array_merge( $range, $data );
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function visitors( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'visitors',
			$request,
			function () use ( $request ) {
				$range = self::parse_range( $request );
				return array(
					'from'         => $range['from'],
					'to'           => $range['to'],
					'top_visitors' => Webino_Dashboard_Analytics_Query::top_visitors( $range['from'], $range['to'] ),
					'online'       => Webino_Dashboard_Analytics_Query::online_visitors(),
					'series'       => Webino_Dashboard_Analytics_Query::overview( $range['from'], $range['to'] )['series'],
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function pages( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'pages',
			$request,
			function () use ( $request ) {
				$range  = self::parse_range( $request );
				$page   = max( 1, (int) $request->get_param( 'page' ) );
				$pp     = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ) );
				if ( ! $request->get_param( 'per_page' ) ) {
					$pp = 20;
				}
				$search = (string) $request->get_param( 'search' );
				$data   = Webino_Dashboard_Analytics_Query::top_pages( $range['from'], $range['to'], $page, $pp, $search );
				return array_merge(
					$range,
					array(
						'page'     => $page,
						'per_page' => $pp,
						'items'    => $data['items'],
						'total'    => $data['total'],
					)
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function referrals( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'referrals',
			$request,
			function () use ( $request ) {
				$range = self::parse_range( $request );
				return array_merge( $range, Webino_Dashboard_Analytics_Query::referrers( $range['from'], $range['to'] ) );
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function geo( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'geo',
			$request,
			function () use ( $request ) {
				$range = self::parse_range( $request );
				$dim   = sanitize_key( (string) $request->get_param( 'dim' ) );
				return array_merge(
					$range,
					array(
						'dim'   => $dim ? $dim : 'country',
						'items' => Webino_Dashboard_Analytics_Query::geo( $range['from'], $range['to'], $dim ),
					)
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function devices( WP_REST_Request $request ) {
		self::ensure_ready();
		return self::cached_response(
			'devices',
			$request,
			function () use ( $request ) {
				$range = self::parse_range( $request );
				$dim   = sanitize_key( (string) $request->get_param( 'dim' ) );
				return array_merge(
					$range,
					array(
						'dim'   => $dim ? $dim : 'browser',
						'items' => Webino_Dashboard_Analytics_Query::devices( $range['from'], $range['to'], $dim ),
					)
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function online( WP_REST_Request $request = null ) {
		self::ensure_ready();
		$req = $request instanceof WP_REST_Request ? $request : new WP_REST_Request( 'GET' );
		return self::cached_response(
			'online',
			$req,
			static function () {
				return array(
					'count'    => Webino_Dashboard_Analytics_Query::online_count(),
					'visitors' => Webino_Dashboard_Analytics_Query::online_visitors(),
				);
			},
			self::CACHE_TTL_ONLINE
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function get_settings() {
		$s = Webino_Dashboard_Analytics::get_settings();
		unset( $s['hit_token'], $s['daily_salt'] );
		$roles = array_keys( get_editable_roles() );
		return new WP_REST_Response(
			array(
				'settings'       => $s,
				'editable_roles' => $roles,
				'source'         => Webino_Dashboard_Analytics::data_source(),
				'wp_statistics'  => class_exists( 'Webino_Dashboard_Analytics_Wp_Statistics', false )
					&& Webino_Dashboard_Analytics_Wp_Statistics::is_active(),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function save_settings( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}
		$payload = isset( $body['settings'] ) && is_array( $body['settings'] ) ? $body['settings'] : $body;
		$next    = Webino_Dashboard_Analytics::sanitize_settings( $payload );
		update_option( Webino_Dashboard_Analytics::OPTION_SETTINGS, $next, false );
		if ( ! empty( $next['bypass_adblocker'] ) ) {
			Webino_Dashboard_Analytics::ensure_bypass_tracker_file();
		}
		return self::get_settings();
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function purge_cache() {
		self::ensure_ready();
		self::flush_read_cache();
		$days = Webino_Dashboard_Analytics_Cron::rebuild_all();
		Webino_Dashboard_Analytics_Cron::purge_old_events();
		return new WP_REST_Response(
			array(
				'ok'            => true,
				'days_rebuilt'  => $days,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return array{from: string, to: string, from_ts: int, to_ts: int}
	 */
	private static function parse_range( WP_REST_Request $request ) {
		$from_ts = (int) $request->get_param( 'from' );
		$to_ts   = (int) $request->get_param( 'to' );
		if ( ! $to_ts ) {
			$to_ts = time();
		}
		if ( ! $from_ts ) {
			$days    = max( 1, min( 365, (int) $request->get_param( 'days' ) ) );
			$from_ts = $to_ts - ( $days ? $days : 30 ) * DAY_IN_SECONDS;
		}
		$range = Webino_Dashboard_Analytics_Query::date_range( $from_ts, $to_ts );
		return array(
			'from'    => $range['from'],
			'to'      => $range['to'],
			'from_ts' => $from_ts,
			'to_ts'   => $to_ts,
		);
	}
}
