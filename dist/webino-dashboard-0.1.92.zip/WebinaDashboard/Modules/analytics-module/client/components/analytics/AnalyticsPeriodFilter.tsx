import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'

import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export type AnalyticsPeriodDays = 7 | 30 | 90

type AnalyticsPeriodFilterProps = {
  days: AnalyticsPeriodDays
  onChange: (days: AnalyticsPeriodDays) => void
}

export function AnalyticsPeriodFilter({ days, onChange }: AnalyticsPeriodFilterProps) {
  const { t } = useTranslation()
  return (
    <div className="mb-4 space-y-2">
      <Label>{t('analytics.period')}</Label>
      <Select value={String(days)} onValueChange={(v) => onChange(Number(v) as AnalyticsPeriodDays)}>
        <SelectTrigger className="w-[min(100%,220px)]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="7">{t('analytics.period7')}</SelectItem>
          <SelectItem value="30">{t('analytics.period30')}</SelectItem>
          <SelectItem value="90">{t('analytics.period90')}</SelectItem>
        </SelectContent>
      </Select>
    </div>
  )
}

/**
 * Stable from/to for React Query keys — Date.now() each render caused infinite loading.
 */
export function useAnalyticsPeriod(defaultDays: AnalyticsPeriodDays = 30) {
  const [days, setDays] = useState<AnalyticsPeriodDays>(defaultDays)
  // Snapshot once per mount so query keys stay stable across re-renders.
  const [anchorTo] = useState(() => Math.floor(Date.now() / 1000))

  const { from, to } = useMemo(() => {
    const toTs = anchorTo
    const fromTs = toTs - days * 86400
    return { from: fromTs, to: toTs }
  }, [days, anchorTo])

  return { days, setDays, from, to }
}
