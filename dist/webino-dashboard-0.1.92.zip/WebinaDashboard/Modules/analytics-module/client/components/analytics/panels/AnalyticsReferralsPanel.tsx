import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { AnalyticsDataTable } from '@module-analytics/components/analytics/AnalyticsDataTable'
import { AnalyticsPanelQueryGate } from '@module-analytics/components/analytics/AnalyticsPanelQueryGate'
import { AnalyticsPeriodFilter, useAnalyticsPeriod } from '@module-analytics/components/analytics/AnalyticsPeriodFilter'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { translateEnum } from '@/lib/enumLabels'
import { apiFetch } from '@/lib/api'
import { formatNumber } from '@/lib/formatNumber'

type ReferralsData = {
  categories: Array<{ category: string; visits: number }>
  sources: Array<{ source: string; category: string; visits: number }>
}

export function AnalyticsReferralsPanel() {
  const { t, i18n } = useTranslation()
  const { days, setDays, from, to } = useAnalyticsPeriod(30)

  const q = useQuery({
    queryKey: ['analytics', 'referrals', from, to],
    queryFn: () => apiFetch<ReferralsData>(`analytics/referrals?from=${from}&to=${to}`),
    retry: false,
  })
  useQueryErrorToast(q)

  return (
    <div className="space-y-4">
      <AnalyticsPeriodFilter days={days} onChange={setDays} />
      <AnalyticsPanelQueryGate query={q} variant="table" skeletonRows={6} skeletonColumns={2}>
        <div className="space-y-4">
        <AnalyticsDataTable
          columns={[
            { key: 'category', label: t('analytics.col.category') },
            { key: 'visits', label: t('analytics.col.visits') },
          ]}
          rows={(q.data?.categories ?? []).map((c) => ({
            category: translateEnum(t, 'analytics.ref', c.category),
            visits: formatNumber(c.visits, i18n.language),
          }))}
          empty={t('analytics.empty')}
        />
        <AnalyticsDataTable
          columns={[
            { key: 'source', label: t('analytics.col.source') },
            { key: 'category', label: t('analytics.col.category') },
            { key: 'visits', label: t('analytics.col.visits') },
          ]}
          rows={(q.data?.sources ?? []).map((s) => ({
            source: s.source,
            category: translateEnum(t, 'analytics.ref', s.category),
            visits: formatNumber(s.visits, i18n.language),
          }))}
          empty={t('analytics.empty')}
        />
        </div>
      </AnalyticsPanelQueryGate>
    </div>
  )
}
