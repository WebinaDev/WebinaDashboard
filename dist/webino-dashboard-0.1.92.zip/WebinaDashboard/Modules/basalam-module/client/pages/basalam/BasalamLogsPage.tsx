import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { JobsTable, LogRows, PhaseCoverageCards, type JobLike } from '@/components/data/DumpUi'
import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamLogsPage() {
  const { t } = useTranslation()
  const jobsQ = useQuery({
    queryKey: ['basalam', 'jobs', 'all'],
    queryFn: () => apiFetch<{ jobs: JobLike[] }>('basalam/jobs'),
    refetchInterval: 8000,
  })
  const logsQ = useQuery({
    queryKey: ['basalam', 'logs'],
    queryFn: () => apiFetch<{ hint?: string; logs: Record<string, unknown>[] }>('basalam/logs'),
  })
  const covQ = useQuery({
    queryKey: ['basalam', 'coverage'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/coverage/endpoints'),
  })

  return (
    <PageShell title={t('basalam.logsTitle')} description={t('basalam.logsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.coverage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <PhaseCoverageCards data={covQ.data} emptyLabel={t('common.empty')} />
        </CardContent>
      </Card>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.recentJobs')}</CardTitle>
        </CardHeader>
        <CardContent>
          <JobsTable
            jobs={jobsQ.data?.jobs ?? []}
            emptyLabel={t('common.empty')}
            typeLabel={t('basalam.col.type')}
            statusLabel={t('basalam.col.status')}
            errorLabel={t('basalam.col.error')}
          />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.logsTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          {logsQ.data?.hint ? <p className="text-muted-foreground mb-2 text-sm">{logsQ.data.hint}</p> : null}
          <LogRows items={logsQ.data?.logs ?? []} emptyLabel={t('common.empty')} />
        </CardContent>
      </Card>
    </PageShell>
  )
}
