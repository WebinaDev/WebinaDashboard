import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamCategoriesPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [wooId, setWooId] = useState('')
  const [wooName, setWooName] = useState('')
  const [bslName, setBslName] = useState('')
  const [l1, setL1] = useState('')
  const [l2, setL2] = useState('')
  const [l3, setL3] = useState('')

  const mapsQ = useQuery({
    queryKey: ['basalam', 'mappings'],
    queryFn: () => apiFetch<{ mappings: Array<Record<string, unknown>> }>('basalam/categories/mappings'),
  })

  const save = useMutation({
    mutationFn: () =>
      apiFetch('basalam/categories/mappings', {
        method: 'POST',
        body: JSON.stringify({
          woo_category_id: Number(wooId) || 0,
          woo_category_name: wooName,
          basalam_category_level1: Number(l1) || null,
          basalam_category_level2: Number(l2) || null,
          basalam_category_level3: Number(l3) || null,
          basalam_category_name: bslName,
        }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.mappingSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'mappings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const del = useMutation({
    mutationFn: (id: number) =>
      apiFetch('basalam/categories/mappings/delete', {
        method: 'POST',
        body: JSON.stringify({ id }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.mappingDeleted'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'mappings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <PageShell title={t('basalam.categoriesTitle')} description={t('basalam.categoriesSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.addMapping')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-2 md:grid-cols-3">
          <Input placeholder="Woo category ID" value={wooId} onChange={(e) => setWooId(e.target.value)} />
          <Input placeholder="Woo name" value={wooName} onChange={(e) => setWooName(e.target.value)} />
          <Input placeholder="Basalam name" value={bslName} onChange={(e) => setBslName(e.target.value)} />
          <Input placeholder="Level 1" value={l1} onChange={(e) => setL1(e.target.value)} />
          <Input placeholder="Level 2" value={l2} onChange={(e) => setL2(e.target.value)} />
          <Input placeholder="Level 3" value={l3} onChange={(e) => setL3(e.target.value)} />
          <Button onClick={() => save.mutate()}>{t('basalam.saveMapping')}</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.mappings')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {(mapsQ.data?.mappings ?? []).map((row) => (
            <div key={String(row.id)} className="flex items-center justify-between gap-2 border-b py-2 text-sm">
              <span>
                #{String(row.woo_category_id)} {String(row.woo_category_name)} → {String(row.basalam_category_name)}
              </span>
              <Button size="sm" variant="destructive" onClick={() => del.mutate(Number(row.id))}>
                {t('basalam.delete')}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </PageShell>
  )
}
