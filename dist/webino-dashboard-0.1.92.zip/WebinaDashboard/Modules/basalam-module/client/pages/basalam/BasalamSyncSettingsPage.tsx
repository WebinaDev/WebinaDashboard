import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamSyncSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [draft, setDraft] = useState<Record<string, unknown>>({})
  const [gatewaySecret, setGatewaySecret] = useState('')

  const settingsQ = useQuery({
    queryKey: ['basalam', 'settings'],
    queryFn: () =>
      apiFetch<{ settings: Record<string, unknown>; connected?: boolean }>('basalam/settings'),
  })

  const gatewayQ = useQuery({
    queryKey: ['basalam', 'gateway'],
    queryFn: () =>
      apiFetch<{
        gateway_secret_set?: boolean
        sandbox?: boolean
        sandbox_token?: string
      }>('basalam/gateway/settings'),
  })

  useEffect(() => {
    if (settingsQ.data?.settings) {
      setDraft(settingsQ.data.settings)
    }
  }, [settingsQ.data])

  const save = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('basalam/settings', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: async () => {
      toast.success(t('basalam.settingsSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'settings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const saveGateway = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('basalam/gateway/settings', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: async () => {
      toast.success(t('basalam.settingsSaved'))
      setGatewaySecret('')
      await qc.invalidateQueries({ queryKey: ['basalam', 'gateway'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const s = draft
  const setField = (key: string, value: unknown) => setDraft((prev) => ({ ...prev, [key]: value }))

  const toggles: Array<{ key: string; label: string }> = [
    { key: 'sync_status_product', label: t('basalam.syncProducts') },
    { key: 'sync_status_order', label: t('basalam.syncOrders') },
    { key: 'auto_confirm_order', label: t('basalam.autoConfirm') },
    { key: 'developer_mode', label: t('basalam.developerMode') },
  ]

  return (
    <PageShell title={t('basalam.settingsTitle')} description={t('basalam.settingsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncToggles')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {toggles.map((item) => (
            <Button
              key={item.key}
              variant={s[item.key] ? 'default' : 'outline'}
              onClick={() => setField(item.key, !s[item.key])}
            >
              {item.label}
            </Button>
          ))}
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncFields')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.defaultWeight')}</span>
            <Input
              type="number"
              value={String(s.default_weight ?? '')}
              onChange={(e) => setField('default_weight', Number(e.target.value) || 0)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.defaultPackageWeight')}</span>
            <Input
              type="number"
              value={String(s.default_package_weight ?? '')}
              onChange={(e) => setField('default_package_weight', Number(e.target.value) || 0)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.defaultPreparation')}</span>
            <Input
              type="number"
              value={String(s.default_preparation ?? '')}
              onChange={(e) => setField('default_preparation', Number(e.target.value) || 0)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.tasksPerMinute')}</span>
            <Input
              type="number"
              value={String(s.tasks_per_minute ?? '')}
              onChange={(e) => setField('tasks_per_minute', Number(e.target.value) || 0)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.priceChange')}</span>
            <Input
              type="number"
              value={String(s.price_change_value ?? '')}
              onChange={(e) => setField('price_change_value', Number(e.target.value) || 0)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.productPrefix')}</span>
            <Input
              value={String(s.product_prefix_title ?? '')}
              onChange={(e) => setField('product_prefix_title', e.target.value)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.productSuffix')}</span>
            <Input
              value={String(s.product_suffix_title ?? '')}
              onChange={(e) => setField('product_suffix_title', e.target.value)}
            />
          </label>
          <label className="space-y-1 text-sm">
            <span>{t('basalam.field.safeStock')}</span>
            <Input
              type="number"
              value={String(s.safe_stock ?? '')}
              onChange={(e) => setField('safe_stock', Number(e.target.value) || 0)}
            />
          </label>
          <div className="md:col-span-2">
            <Button onClick={() => save.mutate(draft)} disabled={save.isPending}>
              {t('basalam.saveSettings')}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.paymentsTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm md:col-span-2">
            <span>{t('basalam.gatewaySecret')}</span>
            <Input
              type="password"
              placeholder={gatewayQ.data?.gateway_secret_set ? '***' : ''}
              value={gatewaySecret}
              onChange={(e) => setGatewaySecret(e.target.value)}
              autoComplete="off"
            />
          </label>
          <Button
            variant={gatewayQ.data?.sandbox ? 'default' : 'outline'}
            onClick={() =>
              saveGateway.mutate({
                gateway_sandbox: !gatewayQ.data?.sandbox,
                ...(gatewaySecret ? { gateway_secret: gatewaySecret } : {}),
              })
            }
          >
            {t('basalam.gatewaySandbox')}
          </Button>
          <Button
            onClick={() =>
              saveGateway.mutate({
                ...(gatewaySecret ? { gateway_secret: gatewaySecret } : {}),
                gateway_sandbox: !!gatewayQ.data?.sandbox,
              })
            }
          >
            {t('basalam.saveGateway')}
          </Button>
        </CardContent>
      </Card>
    </PageShell>
  )
}
