import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamTicketsPage() {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['basalam', 'tickets'],
    queryFn: () => apiFetch<{ tickets: unknown[]; hint?: string }>('basalam/tickets'),
  })

  const tickets = Array.isArray(q.data?.tickets) ? q.data.tickets : []

  return (
    <PageShell title={t('basalam.ticketsTitle')} description={t('basalam.ticketsSubtitle')}>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.ticketsTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {tickets.length === 0 ? (
            <p className="text-muted-foreground text-sm">{q.data?.hint ?? t('basalam.ticketsHint')}</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {tickets.map((item, idx) => {
                const row = item as Record<string, unknown>
                const id = String(row.id ?? row.ticket_id ?? idx)
                const title = String(row.title ?? row.subject ?? id)
                let status = '—'
                if (typeof row.status === 'string') {
                  status = row.status
                } else if (row.status && typeof row.status === 'object') {
                  const st = row.status as { slug?: string; name?: string }
                  status = String(st.slug || st.name || '—')
                }
                return (
                  <li key={id} className="flex items-center justify-between gap-2 border-b py-2">
                    <span>
                      #{id} · {title}
                    </span>
                    <span className="text-muted-foreground text-xs">{status}</span>
                  </li>
                )
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </PageShell>
  )
}
