# Basalam Coverage Contract (WooSalam 1.10.8 parity)

Status legend: `implemented`, `queued`, `pending`.

## Engine

Independent dual ports:

- WebinaConnector: `includes/api/basalam/engine` (`WncBasalam`)
- WebinaDashboard: `Modules/basalam-module/engine` (`WebinoBasalam`)

## Domain mapping

- Auth / Hamsalam OAuth SSO — `implemented`
- Product create / update / bulk / archive / restore / connect — `implemented`
- Uploadio media — `implemented`
- Category mapping + detection — `implemented`
- Order webhook + poll + vendor actions — `implemented`
- Job manager (7 types + discount) — `implemented`
- Finance / tickets / onboarding — `implemented` (WP-Admin + Dashboard REST/UI)
- Legacy payment gateway / wallet stubs — quarantined (not WooSalam)

## Hosts

- openapi.basalam.com
- core.basalam.com
- order-processing.basalam.com
- uploadio.basalam.com
- categorydetection.basalam.com
- api.hamsalam.ir
- accounting.basalam.com / identity.basalam.com
