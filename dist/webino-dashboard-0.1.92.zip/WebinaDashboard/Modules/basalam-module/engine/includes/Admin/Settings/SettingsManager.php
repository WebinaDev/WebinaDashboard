<?php

namespace WebinoBasalam\Admin\Settings;

use WebinoBasalam\Services\SystemResourceMonitor;

defined('ABSPATH') || exit;

class SettingsManager
{
    public static function getSettings($setting = null)
    {
        $settings = (array) get_option('webino_basalam_sync_settings', SettingsConfig::getDefaultSettings());

        if ($setting == null || !array_key_exists($setting, $settings)) {
            $defaultSettings = SettingsConfig::getDefaultSettings();

            foreach ($defaultSettings as $key => $value) {
                if (!array_key_exists($key, $settings)) {
                    $settings[$key] = $value;
                }
            }

            update_option('webino_basalam_sync_settings', $settings);
        }

        if ($setting === null) return $settings;

        return $settings[$setting] ?? null;
    }

    public static function updateSettings($data)
    {
        $settings = self::sanitizeSettings($data);
        update_option('webino_basalam_sync_settings', $settings);
    }

    public static function sanitizeSettings($input)
    {
        $input = array_merge(self::getSettings() ?: [], $input);

        $input[SettingsConfig::DEFAULT_WEIGHT] = absint($input[SettingsConfig::DEFAULT_WEIGHT]);
        $input[SettingsConfig::DEFAULT_PREPARATION] = absint($input[SettingsConfig::DEFAULT_PREPARATION]);
        $input[SettingsConfig::DISCOUNT_REDUCTION_PERCENT] = min(100, absint($input[SettingsConfig::DISCOUNT_REDUCTION_PERCENT]));

        return $input;
    }

    public static function isProductUpdateSelectionValid(?array $settings = null): bool
    {
        $settings = array_merge(self::getSettings() ?: [], $settings ?: []);

        if (($settings[SettingsConfig::SYNC_PRODUCT_FIELDS] ?? 'all') !== 'custom') return true;

        foreach (SettingsConfig::CUSTOM_PRODUCT_UPDATE_FIELDS as $field) {
            $value = $settings[$field] ?? null;
            if ($value === true || $value === 1 || $value === '1') return true;
        }

        return false;
    }

    public static function getEffectiveTasksPerMinute()
    {
        $isAuto = self::getSettings(SettingsConfig::TASKS_PER_MINUTE_AUTO) == 'true';

        if ($isAuto) {
            $monitor = webinoBasalamContainer()->get(SystemResourceMonitor::class);

            return $monitor->calculateOptimalTasksPerMinute();
        } else {
            return self::getSettings(SettingsConfig::TASKS_PER_MINUTE) ?? 10;
        }
    }
}
