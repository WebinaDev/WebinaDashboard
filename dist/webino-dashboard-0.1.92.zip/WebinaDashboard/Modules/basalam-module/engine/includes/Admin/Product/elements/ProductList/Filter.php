<?php

namespace WebinoBasalam\Admin\Product\elements\ProductList;

use WebinoBasalam\Utilities\ProductMetaKey;

defined('ABSPATH') || exit;

class Filter
{
    public function renderFilterDropdown()
    {
        $selected = sanitize_text_field(isset($_GET['webino_basalam_not_added'])) ? sanitize_text_field(wp_unslash($_GET['webino_basalam_not_added'])) : '';
        wp_nonce_field('webino_basalam_filter_action', '_webino_basalam_filter_nonce'); ?>
        <select name="webino_basalam_not_added" class="basalam-font-pelak-12">
            <option value="">فیلتر باسلام</option>
            <option value="0" <?php selected($selected, '0'); ?>>محصولات اضافه شده به باسلام</option>
            <option value="1" <?php selected($selected, '1'); ?>>محصولات اضافه نشده به باسلام</option>
        </select>
<?php
    }

    public function applyFilterToQuery($query)
    {
        global $pagenow;

        if (
            is_admin()
            && $query->is_main_query()
            && $pagenow === 'edit.php'
            && isset($_GET['_webino_basalam_filter_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_webino_basalam_filter_nonce'])), 'webino_basalam_filter_action')
        ) {
            $postType = isset($_GET['post_type']) ? sanitize_text_field(wp_unslash($_GET['post_type'])) : '';
            $filterValue = isset($_GET['webino_basalam_not_added']) ? sanitize_text_field(wp_unslash($_GET['webino_basalam_not_added'])) : '';

            if ($postType === 'product') {
                if ($filterValue === '1') {
                    $query->set('meta_query', [
                        [
                            'key'     => ProductMetaKey::basalamProductId(),
                            'compare' => 'NOT EXISTS',
                        ],
                    ]);
                } elseif ($filterValue === '0') {
                    $query->set('meta_query', [
                        [
                            'key'     => ProductMetaKey::basalamProductId(),
                            'compare' => 'EXISTS',
                        ],
                    ]);
                }
            }
        }
    }
}
