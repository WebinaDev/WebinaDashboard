<?php
/**
 * Bale bot module bootstrap.
 *
 * Shared bot REST and Bale engine boot run from Webino_Dashboard_Bots_Core when this module is installed and active.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
