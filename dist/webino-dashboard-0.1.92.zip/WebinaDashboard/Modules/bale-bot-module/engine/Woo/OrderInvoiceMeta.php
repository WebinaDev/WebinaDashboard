<?php

namespace Webino_Dashboard_Bots_Bale\Woo;

/**
 * Order post meta for Bale invoice binding.
 */
class OrderInvoiceMeta {

	public const TARGET_CHAT_ID = '_woobale_invoice_target_chat_id';
}
