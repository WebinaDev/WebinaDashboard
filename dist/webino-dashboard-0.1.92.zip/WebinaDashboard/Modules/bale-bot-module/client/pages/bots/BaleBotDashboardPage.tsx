import { useTranslation } from 'react-i18next'

import { BotDashboardPanel } from '../../components/bots/BotDashboardPanel'
import { PageShell } from '@/components/PageShell'

export default function BaleBotDashboardPage() {
  const { t } = useTranslation()
  return (
    <PageShell title={t('bots.dashboardTitle', { provider: t('bots.baleTitle') })} description={t('bots.description')}>
      <BotDashboardPanel provider="bale" />
    </PageShell>
  )
}
