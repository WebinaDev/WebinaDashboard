export type BotProvider = 'bale' | 'telegram'

export const BOT_PROVIDERS: BotProvider[] = ['bale', 'telegram']
