import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import {
  type AiEntityKey,
  type AiFieldSpec,
  type AiSettings,
  fetchAiSettings,
  fetchGapGptModels,
  saveAiSettings,
} from '../lib/ai-content-api'

const ENTITIES: {
  id: AiEntityKey
  doKey: keyof AiSettings
  promptKey: keyof AiSettings
  titleKey: string
  fields: string[]
}[] = [
  {
    id: 'product',
    doKey: 'do_product',
    promptKey: 'prompt_product',
    titleKey: 'aiContent.settingsProduct',
    fields: [
      'name',
      'slug',
      'english_name',
      'short_description',
      'description',
      'ai_review_summary',
      'faqs',
      'attributes',
      'tags',
      'seo',
    ],
  },
  {
    id: 'product_cat',
    doKey: 'do_product_cat',
    promptKey: 'prompt_product_cat',
    titleKey: 'aiContent.settingsProductCat',
    fields: ['description', 'seo'],
  },
  {
    id: 'product_brand',
    doKey: 'do_product_brand',
    promptKey: 'prompt_product_brand',
    titleKey: 'aiContent.settingsBrand',
    fields: ['description', 'seo'],
  },
  {
    id: 'blog',
    doKey: 'do_blog',
    promptKey: 'prompt_blog',
    titleKey: 'aiContent.settingsBlog',
    fields: ['title', 'slug', 'excerpt', 'content', 'tags', 'seo'],
  },
  {
    id: 'blog_cat',
    doKey: 'do_blog_cat',
    promptKey: 'prompt_blog_cat',
    titleKey: 'aiContent.settingsBlogCat',
    fields: ['description', 'seo'],
  },
]

const LENGTH_FIELDS: Record<string, Array<AiFieldSpec['unit']>> = {
  short_description: ['paragraphs', 'words'],
  description: ['words', 'paragraphs'],
  ai_review_summary: ['words', 'paragraphs'],
  faqs: ['count'],
  excerpt: ['paragraphs', 'words'],
  content: ['words', 'paragraphs'],
}

export default function AiSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [draft, setDraft] = useState<Partial<AiSettings> | null>(null)

  const q = useQuery({
    queryKey: ['ai-content', 'settings'],
    queryFn: fetchAiSettings,
  })
  useQueryErrorToast(q)

  const hasGapKey = !!q.data?.has_gapgpt_key
  const modelsQ = useQuery({
    queryKey: ['ai-content', 'gapgpt-models'],
    queryFn: () => fetchGapGptModels(false),
    enabled: hasGapKey,
  })
  useQueryErrorToast(modelsQ)

  useEffect(() => {
    if (q.data) {
      setDraft({
        ...q.data,
        grok_api_key: '',
        gemini_api_key: '',
        openai_api_key: '',
        gapgpt_api_key: '',
      })
    }
  }, [q.data])

  const save = useMutation({
    mutationFn: () => saveAiSettings(draft ?? {}),
    onSuccess: async (res) => {
      toast.success(t('common.saved'))
      setDraft({
        ...res,
        grok_api_key: '',
        gemini_api_key: '',
        openai_api_key: '',
        gapgpt_api_key: '',
      })
      await qc.invalidateQueries({ queryKey: ['ai-content', 'settings'] })
      await qc.invalidateQueries({ queryKey: ['ai-content', 'gapgpt-models'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const refreshModels = useMutation({
    mutationFn: () => fetchGapGptModels(true),
    onSuccess: (data) => {
      qc.setQueryData(['ai-content', 'gapgpt-models'], data)
      toast.success(t('aiContent.gapgptRefreshModels'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const modelIds = useMemo(() => {
    const ids = (modelsQ.data?.models ?? []).map((m) => m.id).filter(Boolean)
    const selected = (draft?.gapgpt_model || '').trim()
    if (selected && !ids.includes(selected)) ids.unshift(selected)
    return ids
  }, [modelsQ.data, draft?.gapgpt_model])

  if (!draft) {
    return <div className="text-sm text-muted-foreground">{t('common.loading')}</div>
  }

  const set = <K extends keyof AiSettings>(key: K, value: AiSettings[K]) => {
    setDraft((d) => ({ ...(d ?? {}), [key]: value }))
  }

  const patchField = (entity: AiEntityKey, field: string, patch: Partial<AiFieldSpec>) => {
    setDraft((d) => {
      const fields = { ...(d?.fields ?? {}) } as AiSettings['fields']
      const current = fields[entity]?.[field] ?? { enabled: true, length: 0, unit: 'words' as const }
      fields[entity] = { ...(fields[entity] ?? {}), [field]: { ...current, ...patch } }
      return { ...(d ?? {}), fields }
    })
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProviders')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <Label>{t('aiContent.defaultProvider')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.default_provider ?? 'grok'}
              onChange={(e) => set('default_provider', e.target.value)}
            >
              <option value="grok">Grok</option>
              <option value="gemini">Gemini</option>
              <option value="openai">ChatGPT</option>
              <option value="gapgpt">{t('aiContent.gapgpt')}</option>
            </select>
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Grok API key {draft.has_grok_key ? `(${draft.grok_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.grok_api_key ?? ''}
              onChange={(e) => set('grok_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Gemini API key {draft.has_gemini_key ? `(${draft.gemini_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.gemini_api_key ?? ''}
              onChange={(e) => set('gemini_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>OpenAI API key {draft.has_openai_key ? `(${draft.openai_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.openai_api_key ?? ''}
              onChange={(e) => set('openai_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>
              {t('aiContent.gapgptKey')} {draft.has_gapgpt_key ? `(${draft.gapgpt_api_key_masked})` : ''}
            </Label>
            <Input
              type="password"
              value={draft.gapgpt_api_key ?? ''}
              onChange={(e) => set('gapgpt_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1">
            <Label>Grok model</Label>
            <Input value={draft.grok_model ?? ''} onChange={(e) => set('grok_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Gemini model</Label>
            <Input value={draft.gemini_model ?? ''} onChange={(e) => set('gemini_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>OpenAI model</Label>
            <Input value={draft.openai_model ?? ''} onChange={(e) => set('openai_model', e.target.value)} />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.gapgptModel')}</Label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <select
                className="flex h-9 w-full rounded-md border bg-background px-3 text-sm disabled:opacity-60"
                value={draft.gapgpt_model ?? ''}
                disabled={!hasGapKey || modelsQ.isLoading}
                onChange={(e) => set('gapgpt_model', e.target.value)}
              >
                {modelIds.length === 0 ? (
                  <option value={draft.gapgpt_model ?? ''}>{draft.gapgpt_model || '—'}</option>
                ) : (
                  modelIds.map((id) => (
                    <option key={id} value={id}>
                      {id}
                    </option>
                  ))
                )}
              </select>
              <Button
                type="button"
                variant="outline"
                disabled={!hasGapKey || refreshModels.isPending || modelsQ.isFetching}
                onClick={() => void refreshModels.mutateAsync()}
              >
                {t('aiContent.gapgptRefreshModels')}
              </Button>
            </div>
            {!hasGapKey ? (
              <p className="text-muted-foreground text-xs">{t('aiContent.gapgptSaveKeyFirst')}</p>
            ) : modelsQ.isFetched && modelIds.length === 0 ? (
              <p className="text-muted-foreground text-xs">{t('aiContent.gapgptNoModels')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProfile')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.siteName')}</Label>
            <Input value={draft.site_name ?? ''} onChange={(e) => set('site_name', e.target.value)} />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.siteTopic')}</Label>
            <Textarea rows={2} value={draft.site_topic ?? ''} onChange={(e) => set('site_topic', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.tone')}</Label>
            <Input value={draft.tone ?? ''} onChange={(e) => set('tone', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.language')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.language ?? 'fa'}
              onChange={(e) => set('language', e.target.value)}
            >
              <option value="fa">{t('aiContent.lang.fa')}</option>
              <option value="en">{t('aiContent.lang.en')}</option>
            </select>
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.temperature')}</Label>
            <Input
              type="number"
              min={0}
              max={2}
              step={0.05}
              value={draft.temperature ?? 0.55}
              onChange={(e) => set('temperature', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.maxTokens')}</Label>
            <Input
              type="number"
              min={0}
              value={draft.max_tokens ?? 0}
              onChange={(e) => set('max_tokens', Number(e.target.value))}
            />
            <p className="text-muted-foreground text-xs">{t('aiContent.maxTokensHint')}</p>
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.seoSep')}</Label>
            <Input value={draft.seo_sep ?? ' - '} onChange={(e) => set('seo_sep', e.target.value)} />
          </div>
          <div className="flex items-center gap-2 pt-6">
            <Checkbox
              checked={!!draft.require_site_name}
              onCheckedChange={(v) => set('require_site_name', Boolean(v))}
              id="require_site_name"
            />
            <Label htmlFor="require_site_name">{t('aiContent.requireSiteName')}</Label>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>{t('aiContent.settingsSystemPrompt')}</CardTitle>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => set('prompt_system', draft.prompt_defaults?.prompt_system ?? '')}
          >
            {t('aiContent.resetPrompt')}
          </Button>
        </CardHeader>
        <CardContent>
          <Textarea rows={10} value={draft.prompt_system ?? ''} onChange={(e) => set('prompt_system', e.target.value)} />
        </CardContent>
      </Card>

      {ENTITIES.map((ent) => {
        const enabled = Boolean(draft[ent.doKey])
        const promptVal = String(draft[ent.promptKey] ?? '')
        return (
          <Card key={ent.id}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle>{t(ent.titleKey)}</CardTitle>
              <div className="flex items-center gap-2">
                <Label htmlFor={`do-${ent.id}`} className="text-sm font-normal">
                  {t('aiContent.doEntity')}
                </Label>
                <Switch
                  id={`do-${ent.id}`}
                  checked={enabled}
                  onCheckedChange={(v) => set(ent.doKey, Boolean(v) as never)}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <Label>{t('aiContent.entityPrompt')}</Label>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => set(ent.promptKey, (draft.prompt_defaults?.[String(ent.promptKey)] ?? '') as never)}
                  >
                    {t('aiContent.resetPrompt')}
                  </Button>
                </div>
                <Textarea
                  rows={4}
                  disabled={!enabled}
                  value={promptVal}
                  onChange={(e) => set(ent.promptKey, e.target.value as never)}
                />
              </div>
              {ent.fields.map((field) => {
                const spec = draft.fields?.[ent.id]?.[field] ?? { enabled: true, length: 0, unit: 'words' as const }
                const units = LENGTH_FIELDS[field]
                return (
                  <div key={field} className="flex flex-wrap items-center gap-3 border-b py-2 last:border-0">
                    <Switch
                      checked={!!spec.enabled}
                      disabled={!enabled}
                      onCheckedChange={(v) => patchField(ent.id, field, { enabled: Boolean(v) })}
                    />
                    <span className="min-w-[10rem] flex-1 text-sm">{t(`aiContent.field.${field}`)}</span>
                    {units ? (
                      <>
                        <Input
                          className="w-24"
                          type="number"
                          min={0}
                          disabled={!enabled || !spec.enabled}
                          value={spec.length}
                          onChange={(e) => patchField(ent.id, field, { length: Number(e.target.value) })}
                        />
                        <select
                          className="flex h-9 rounded-md border bg-background px-2 text-sm"
                          disabled={!enabled || !spec.enabled}
                          value={spec.unit}
                          onChange={(e) => patchField(ent.id, field, { unit: e.target.value as AiFieldSpec['unit'] })}
                        >
                          {units.map((u) => (
                            <option key={u} value={u}>
                              {t(`aiContent.unit.${u}`)}
                            </option>
                          ))}
                        </select>
                      </>
                    ) : null}
                  </div>
                )
              })}
            </CardContent>
          </Card>
        )
      })}

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsAutomation')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <Label>{t('aiContent.dailyBlogQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_blog_quota ?? 1}
              onChange={(e) => set('daily_blog_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.dailyProductQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_product_quota ?? 5}
              onChange={(e) => set('daily_product_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.publishStatus')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.publish_status ?? 'draft'}
              onChange={(e) => set('publish_status', e.target.value)}
            >
              <option value="draft">draft</option>
              <option value="pending">pending</option>
              <option value="publish">publish</option>
            </select>
          </div>
          <div className="flex items-center gap-2 pt-6">
            <Checkbox
              checked={!!draft.auto_publish}
              onCheckedChange={(v) => set('auto_publish', Boolean(v))}
              id="auto_publish"
            />
            <Label htmlFor="auto_publish">{t('aiContent.autoPublish')}</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox checked={!!draft.enabled} onCheckedChange={(v) => set('enabled', Boolean(v))} id="enabled" />
            <Label htmlFor="enabled">{t('aiContent.enabled')}</Label>
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => void save.mutateAsync()} disabled={save.isPending}>
        {t('common.save')}
      </Button>
    </div>
  )
}
