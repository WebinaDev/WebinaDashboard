<?php
/**
 * AI provider router (Grok / Gemini / OpenAI / GapGPT).
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unified chat completion with JSON output and fallback.
 */
final class Webino_Dashboard_AI_Providers {

	/**
	 * @param string               $system System prompt.
	 * @param string               $user User prompt.
	 * @param array<string,mixed>  $schema Optional JSON schema hint (for prompt).
	 * @param string|null          $force_provider Optional provider slug.
	 * @return array{ok:bool,content?:string,data?:array,provider?:string,tokens_in?:int,tokens_out?:int,error?:string}
	 */
	public static function complete( $system, $user, $schema = array(), $force_provider = null ) {
		$settings = Webino_Dashboard_AI_Content_Settings::get();
		$order    = is_array( $settings['fallback_order'] ) ? $settings['fallback_order'] : array( 'grok', 'gemini', 'openai', 'gapgpt' );

		if ( $force_provider ) {
			$order = array( sanitize_key( (string) $force_provider ) );
		} else {
			$default = sanitize_key( (string) $settings['default_provider'] );
			$order   = array_values( array_unique( array_merge( array( $default ), $order ) ) );
		}

		$schema_hint = '';
		if ( ! empty( $schema ) ) {
			$schema_hint = "\n\nReturn ONLY valid JSON matching this shape (no markdown):\n" . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		}

		$last_error = 'No provider available';
		foreach ( $order as $provider ) {
			$key = self::key_for( $provider, $settings );
			if ( '' === $key ) {
				continue;
			}

			$result = self::call_provider( $provider, $key, $settings, (string) $system . $schema_hint, (string) $user );
			if ( ! empty( $result['ok'] ) ) {
				$parsed = self::parse_json_content( (string) ( $result['content'] ?? '' ) );
				if ( is_wp_error( $parsed ) ) {
					$last_error = $parsed->get_error_message();
					continue;
				}
				$result['data']     = $parsed;
				$result['provider'] = $provider;
				return $result;
			}
			$last_error = (string) ( $result['error'] ?? 'Provider failed' );
		}

		return array(
			'ok'    => false,
			'error' => $last_error,
		);
	}

	/**
	 * @param string              $provider Provider.
	 * @param array<string,mixed> $settings Settings.
	 * @return string
	 */
	private static function key_for( $provider, $settings ) {
		$map = array(
			'grok'   => 'grok_api_key',
			'gemini' => 'gemini_api_key',
			'openai' => 'openai_api_key',
			'gapgpt' => 'gapgpt_api_key',
		);
		$field = $map[ $provider ] ?? '';
		return $field ? trim( (string) ( $settings[ $field ] ?? '' ) ) : '';
	}

	/**
	 * @param string              $provider Provider.
	 * @param string              $api_key Key.
	 * @param array<string,mixed> $settings Settings.
	 * @param string              $system System.
	 * @param string              $user User.
	 * @return array{ok:bool,content?:string,tokens_in?:int,tokens_out?:int,error?:string}
	 */
	private static function call_provider( $provider, $api_key, $settings, $system, $user ) {
		if ( 'gemini' === $provider ) {
			return self::call_gemini( $api_key, (string) ( $settings['gemini_model'] ?? 'gemini-2.0-flash' ), $system, $user );
		}
		if ( 'openai' === $provider ) {
			return self::call_openai_compatible(
				'https://api.openai.com/v1/chat/completions',
				$api_key,
				(string) ( $settings['openai_model'] ?? 'gpt-4o-mini' ),
				$system,
				$user
			);
		}
		if ( 'gapgpt' === $provider ) {
			return self::call_openai_compatible(
				'https://api.gapgpt.app/v1/chat/completions',
				$api_key,
				(string) ( $settings['gapgpt_model'] ?? 'gpt-5.6-terra' ),
				$system,
				$user
			);
		}
		return self::call_openai_compatible(
			'https://api.x.ai/v1/chat/completions',
			$api_key,
			(string) ( $settings['grok_model'] ?? 'grok-2-latest' ),
			$system,
			$user
		);
	}

	/**
	 * @param string $url Endpoint.
	 * @param string $api_key Key.
	 * @param string $model Model.
	 * @param string $system System.
	 * @param string $user User.
	 * @return array{ok:bool,content?:string,tokens_in?:int,tokens_out?:int,error?:string}
	 */
	private static function call_openai_compatible( $url, $api_key, $model, $system, $user ) {
		$body = array(
			'model'       => $model,
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user', 'content' => $user ),
			),
			'temperature' => 0.55,
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 120,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'error' => $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $data ) && isset( $data['error']['message'] ) ? (string) $data['error']['message'] : 'HTTP ' . $code;
			return array( 'ok' => false, 'error' => $msg );
		}

		$content = '';
		if ( is_array( $data ) && isset( $data['choices'][0]['message']['content'] ) ) {
			$content = (string) $data['choices'][0]['message']['content'];
		}

		return array(
			'ok'         => '' !== trim( $content ),
			'content'    => $content,
			'tokens_in'  => isset( $data['usage']['prompt_tokens'] ) ? (int) $data['usage']['prompt_tokens'] : 0,
			'tokens_out' => isset( $data['usage']['completion_tokens'] ) ? (int) $data['usage']['completion_tokens'] : 0,
			'error'      => '' === trim( $content ) ? 'Empty completion' : '',
		);
	}

	/**
	 * @param string $api_key Key.
	 * @param string $model Model.
	 * @param string $system System.
	 * @param string $user User.
	 * @return array{ok:bool,content?:string,tokens_in?:int,tokens_out?:int,error?:string}
	 */
	private static function call_gemini( $api_key, $model, $system, $user ) {
		$model = sanitize_text_field( $model );
		$url   = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $api_key );

		$body = array(
			'systemInstruction' => array(
				'parts' => array( array( 'text' => $system ) ),
			),
			'contents'          => array(
				array(
					'role'  => 'user',
					'parts' => array( array( 'text' => $user ) ),
				),
			),
			'generationConfig'  => array(
				'temperature'      => 0.55,
				'responseMimeType' => 'application/json',
			),
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 120,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'error' => $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $data ) && isset( $data['error']['message'] ) ? (string) $data['error']['message'] : 'HTTP ' . $code;
			return array( 'ok' => false, 'error' => $msg );
		}

		$content = '';
		if ( is_array( $data ) && isset( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
			$content = (string) $data['candidates'][0]['content']['parts'][0]['text'];
		}

		$usage_in  = isset( $data['usageMetadata']['promptTokenCount'] ) ? (int) $data['usageMetadata']['promptTokenCount'] : 0;
		$usage_out = isset( $data['usageMetadata']['candidatesTokenCount'] ) ? (int) $data['usageMetadata']['candidatesTokenCount'] : 0;

		return array(
			'ok'         => '' !== trim( $content ),
			'content'    => $content,
			'tokens_in'  => $usage_in,
			'tokens_out' => $usage_out,
			'error'      => '' === trim( $content ) ? 'Empty completion' : '',
		);
	}

	/**
	 * @param string $content Raw model content.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function parse_json_content( $content ) {
		$content = trim( (string) $content );
		if ( preg_match( '/```(?:json)?\s*([\s\S]*?)```/i', $content, $m ) ) {
			$content = trim( $m[1] );
		}
		$data = json_decode( $content, true );
		if ( ! is_array( $data ) ) {
			$start = strpos( $content, '{' );
			$end   = strrpos( $content, '}' );
			if ( false !== $start && false !== $end && $end > $start ) {
				$data = json_decode( substr( $content, $start, $end - $start + 1 ), true );
			}
		}
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'ai_json', __( 'Model returned invalid JSON.', 'webino-dashboard' ) );
		}
		return $data;
	}

	/**
	 * Live GapGPT catalog (OpenAI-compatible GET /v1/models).
	 *
	 * @param bool $refresh Bypass short cache.
	 * @return list<array{id:string,owned_by:string}>|WP_Error
	 */
	public static function list_gapgpt_models( $refresh = false ) {
		$settings = Webino_Dashboard_AI_Content_Settings::get();
		$api_key  = trim( (string) ( $settings['gapgpt_api_key'] ?? '' ) );
		if ( '' === $api_key ) {
			return new WP_Error(
				'gapgpt_no_key',
				__( 'Enter a GapGPT API key and save settings first.', 'webino-dashboard' ),
				array( 'status' => 400 )
			);
		}

		$cache_key = 'webino_ai_gapgpt_models';
		if ( ! $refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$response = wp_remote_get(
			'https://api.gapgpt.app/v1/models',
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'gapgpt_models', $response->get_error_message(), array( 'status' => 502 ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $data ) && isset( $data['error']['message'] ) ? (string) $data['error']['message'] : 'HTTP ' . $code;
			return new WP_Error( 'gapgpt_models', $msg, array( 'status' => $code >= 400 && $code < 600 ? $code : 502 ) );
		}

		$rows = array();
		$list = array();
		if ( is_array( $data ) && isset( $data['data'] ) && is_array( $data['data'] ) ) {
			$list = $data['data'];
		} elseif ( is_array( $data ) && isset( $data['models'] ) && is_array( $data['models'] ) ) {
			$list = $data['models'];
		} elseif ( is_array( $data ) && isset( $data[0] ) ) {
			$list = $data;
		}

		foreach ( $list as $item ) {
			if ( is_string( $item ) ) {
				$id = sanitize_text_field( $item );
				if ( '' !== $id ) {
					$rows[] = array(
						'id'       => $id,
						'owned_by' => '',
					);
				}
				continue;
			}
			if ( ! is_array( $item ) ) {
				continue;
			}
			$id = sanitize_text_field( (string) ( $item['id'] ?? $item['name'] ?? '' ) );
			if ( '' === $id ) {
				continue;
			}
			$rows[] = array(
				'id'       => $id,
				'owned_by' => sanitize_text_field( (string) ( $item['owned_by'] ?? $item['ownedBy'] ?? '' ) ),
			);
		}

		usort(
			$rows,
			static function ( $a, $b ) {
				return strcasecmp( (string) $a['id'], (string) $b['id'] );
			}
		);

		set_transient( $cache_key, $rows, 5 * MINUTE_IN_SECONDS );
		return $rows;
	}
}
