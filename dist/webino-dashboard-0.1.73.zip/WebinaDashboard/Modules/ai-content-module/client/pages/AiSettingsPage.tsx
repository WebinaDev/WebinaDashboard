import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import {
  type AiSettings,
  fetchAiSettings,
  fetchGapGptModels,
  saveAiSettings,
} from '../lib/ai-content-api'

export default function AiSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [draft, setDraft] = useState<Partial<AiSettings> | null>(null)

  const q = useQuery({
    queryKey: ['ai-content', 'settings'],
    queryFn: fetchAiSettings,
  })
  useQueryErrorToast(q)

  const hasGapKey = !!q.data?.has_gapgpt_key
  const modelsQ = useQuery({
    queryKey: ['ai-content', 'gapgpt-models'],
    queryFn: () => fetchGapGptModels(false),
    enabled: hasGapKey,
  })
  useQueryErrorToast(modelsQ)

  useEffect(() => {
    if (q.data) {
      setDraft({
        ...q.data,
        grok_api_key: '',
        gemini_api_key: '',
        openai_api_key: '',
        gapgpt_api_key: '',
      })
    }
  }, [q.data])

  const save = useMutation({
    mutationFn: () => saveAiSettings(draft ?? {}),
    onSuccess: async (res) => {
      toast.success(t('common.saved'))
      setDraft({
        ...res,
        grok_api_key: '',
        gemini_api_key: '',
        openai_api_key: '',
        gapgpt_api_key: '',
      })
      await qc.invalidateQueries({ queryKey: ['ai-content', 'settings'] })
      await qc.invalidateQueries({ queryKey: ['ai-content', 'gapgpt-models'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const refreshModels = useMutation({
    mutationFn: () => fetchGapGptModels(true),
    onSuccess: (data) => {
      qc.setQueryData(['ai-content', 'gapgpt-models'], data)
      toast.success(t('aiContent.gapgptRefreshModels'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const modelIds = useMemo(() => {
    const ids = (modelsQ.data?.models ?? []).map((m) => m.id).filter(Boolean)
    const selected = (draft?.gapgpt_model || '').trim()
    if (selected && !ids.includes(selected)) ids.unshift(selected)
    return ids
  }, [modelsQ.data, draft?.gapgpt_model])

  if (!draft) {
    return <div className="text-sm text-muted-foreground">{t('common.loading')}</div>
  }

  const set = <K extends keyof AiSettings>(key: K, value: AiSettings[K]) => {
    setDraft((d) => ({ ...(d ?? {}), [key]: value }))
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProviders')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <Label>{t('aiContent.defaultProvider')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.default_provider ?? 'grok'}
              onChange={(e) => set('default_provider', e.target.value)}
            >
              <option value="grok">Grok</option>
              <option value="gemini">Gemini</option>
              <option value="openai">ChatGPT</option>
              <option value="gapgpt">{t('aiContent.gapgpt')}</option>
            </select>
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Grok API key {draft.has_grok_key ? `(${draft.grok_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.grok_api_key ?? ''}
              onChange={(e) => set('grok_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Gemini API key {draft.has_gemini_key ? `(${draft.gemini_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.gemini_api_key ?? ''}
              onChange={(e) => set('gemini_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>OpenAI API key {draft.has_openai_key ? `(${draft.openai_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.openai_api_key ?? ''}
              onChange={(e) => set('openai_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>
              {t('aiContent.gapgptKey')} {draft.has_gapgpt_key ? `(${draft.gapgpt_api_key_masked})` : ''}
            </Label>
            <Input
              type="password"
              value={draft.gapgpt_api_key ?? ''}
              onChange={(e) => set('gapgpt_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1">
            <Label>Grok model</Label>
            <Input value={draft.grok_model ?? ''} onChange={(e) => set('grok_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Gemini model</Label>
            <Input value={draft.gemini_model ?? ''} onChange={(e) => set('gemini_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>OpenAI model</Label>
            <Input value={draft.openai_model ?? ''} onChange={(e) => set('openai_model', e.target.value)} />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.gapgptModel')}</Label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <select
                className="flex h-9 w-full rounded-md border bg-background px-3 text-sm disabled:opacity-60"
                value={draft.gapgpt_model ?? ''}
                disabled={!hasGapKey || modelsQ.isLoading}
                onChange={(e) => set('gapgpt_model', e.target.value)}
              >
                {modelIds.length === 0 ? (
                  <option value={draft.gapgpt_model ?? ''}>{draft.gapgpt_model || '—'}</option>
                ) : (
                  modelIds.map((id) => (
                    <option key={id} value={id}>
                      {id}
                    </option>
                  ))
                )}
              </select>
              <Button
                type="button"
                variant="outline"
                disabled={!hasGapKey || refreshModels.isPending || modelsQ.isFetching}
                onClick={() => void refreshModels.mutateAsync()}
              >
                {t('aiContent.gapgptRefreshModels')}
              </Button>
            </div>
            {!hasGapKey ? (
              <p className="text-muted-foreground text-xs">{t('aiContent.gapgptSaveKeyFirst')}</p>
            ) : modelsQ.isFetched && modelIds.length === 0 ? (
              <p className="text-muted-foreground text-xs">{t('aiContent.gapgptNoModels')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProfile')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.siteTopic')}</Label>
            <Textarea rows={2} value={draft.site_topic ?? ''} onChange={(e) => set('site_topic', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.tone')}</Label>
            <Input value={draft.tone ?? ''} onChange={(e) => set('tone', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.language')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.language ?? 'fa'}
              onChange={(e) => set('language', e.target.value)}
            >
              <option value="fa">{t('aiContent.lang.fa')}</option>
              <option value="en">{t('aiContent.lang.en')}</option>
            </select>
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.dailyBlogQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_blog_quota ?? 1}
              onChange={(e) => set('daily_blog_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.dailyProductQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_product_quota ?? 5}
              onChange={(e) => set('daily_product_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.publishStatus')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.publish_status ?? 'draft'}
              onChange={(e) => set('publish_status', e.target.value)}
            >
              <option value="draft">draft</option>
              <option value="pending">pending</option>
              <option value="publish">publish</option>
            </select>
          </div>
          <div className="flex items-center gap-2 pt-6">
            <Checkbox
              checked={!!draft.auto_publish}
              onCheckedChange={(v) => set('auto_publish', Boolean(v))}
              id="auto_publish"
            />
            <Label htmlFor="auto_publish">{t('aiContent.autoPublish')}</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox checked={!!draft.enabled} onCheckedChange={(v) => set('enabled', Boolean(v))} id="enabled" />
            <Label htmlFor="enabled">{t('aiContent.enabled')}</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              checked={!!draft.require_site_name}
              onCheckedChange={(v) => set('require_site_name', Boolean(v))}
              id="require_site_name"
            />
            <Label htmlFor="require_site_name">{t('aiContent.requireSiteName')}</Label>
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => void save.mutateAsync()} disabled={save.isPending}>
        {t('common.save')}
      </Button>
    </div>
  )
}
