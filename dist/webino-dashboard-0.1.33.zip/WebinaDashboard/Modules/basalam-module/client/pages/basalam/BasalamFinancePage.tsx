import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamFinancePage() {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['basalam', 'finance'],
    queryFn: () =>
      apiFetch<{
        ok?: boolean
        balance?: unknown
        settlements?: unknown
        history?: unknown
      }>('basalam/finance/balance'),
  })

  const balance = q.data?.balance as Record<string, unknown> | undefined

  return (
    <PageShell title={t('basalam.financeTitle')} description={t('basalam.financeSubtitle')}>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.balance')}</CardTitle>
          </CardHeader>
          <CardContent>
            {balance ? (
              <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs">
                {JSON.stringify(balance, null, 2)}
              </pre>
            ) : (
              <p className="text-muted-foreground text-sm">{t('basalam.financeWpAdminHint')}</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.settlements')}</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs">
              {JSON.stringify(
                { settlements: q.data?.settlements ?? null, history: q.data?.history ?? null },
                null,
                2,
              )}
            </pre>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  )
}
