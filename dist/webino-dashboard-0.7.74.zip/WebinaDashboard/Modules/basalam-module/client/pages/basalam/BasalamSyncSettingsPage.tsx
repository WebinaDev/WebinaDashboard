import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamSyncSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [draft, setDraft] = useState<Record<string, unknown>>({})

  const settingsQ = useQuery({
    queryKey: ['basalam', 'settings'],
    queryFn: () =>
      apiFetch<{ settings: Record<string, unknown>; connected?: boolean }>('basalam/settings'),
  })

  useEffect(() => {
    if (settingsQ.data?.settings) {
      setDraft(settingsQ.data.settings)
    }
  }, [settingsQ.data])

  const save = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('basalam/settings', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: async () => {
      toast.success(t('basalam.settingsSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'settings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const s = draft
  const setField = (key: string, value: unknown) => setDraft((prev) => ({ ...prev, [key]: value }))

  const toggles: Array<{ key: string; label: string }> = [
    { key: 'sync_status_product', label: t('basalam.syncProducts') },
    { key: 'sync_status_order', label: t('basalam.syncOrders') },
    { key: 'auto_confirm_order', label: t('basalam.autoConfirm') },
    { key: 'round_price', label: t('basalam.roundPrice') },
    { key: 'add_attr_to_desc_product', label: t('basalam.addAttrToDesc') },
    { key: 'add_short_desc_to_desc_product', label: t('basalam.addShortDesc') },
    { key: 'all_products_wholesale', label: t('basalam.allWholesale') },
    { key: 'cap_preparation_to_category_max', label: t('basalam.capPrep') },
    { key: 'tasks_per_minute_auto', label: t('basalam.tasksAuto') },
    { key: 'developer_mode', label: t('basalam.developerMode') },
  ]

  const syncFieldKeys = [
    'sync_product_field_name',
    'sync_product_field_photos',
    'sync_product_field_price',
    'sync_product_field_stock',
    'sync_product_field_weight',
    'sync_product_field_description',
    'sync_product_field_attr',
    'sync_product_field_video',
    'sync_product_field_variant_price',
    'sync_product_field_variant_stock',
  ]

  return (
    <PageShell title={t('basalam.settingsTitle')} description={t('basalam.settingsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncToggles')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {toggles.map((item) => (
            <Button
              key={item.key}
              variant={s[item.key] ? 'default' : 'outline'}
              onClick={() => setField(item.key, !s[item.key])}
            >
              {item.label}
            </Button>
          ))}
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.selectiveSync')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            variant={s.sync_product_fields === 'all' ? 'default' : 'outline'}
            onClick={() => setField('sync_product_fields', 'all')}
          >
            {t('basalam.syncAllFields')}
          </Button>
          <Button
            variant={s.sync_product_fields === 'custom' ? 'default' : 'outline'}
            onClick={() => setField('sync_product_fields', 'custom')}
          >
            {t('basalam.syncCustomFields')}
          </Button>
          {s.sync_product_fields === 'custom'
            ? syncFieldKeys.map((key) => (
                <Button
                  key={key}
                  size="sm"
                  variant={s[key] ? 'default' : 'outline'}
                  onClick={() => setField(key, !s[key])}
                >
                  {key.replace('sync_product_field_', '')}
                </Button>
              ))
            : null}
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncFields')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {(
            [
              ['default_weight', 'basalam.field.defaultWeight'],
              ['default_package_weight', 'basalam.field.defaultPackageWeight'],
              ['default_preparation', 'basalam.field.defaultPreparation'],
              ['default_stock_quantity', 'basalam.field.defaultStock'],
              ['tasks_per_minute', 'basalam.field.tasksPerMinute'],
              ['price_change_value', 'basalam.field.priceChange'],
              ['discount_duration', 'basalam.field.discountDays'],
              ['discount_reduction_percent', 'basalam.field.discountPercent'],
              ['product_prefix_title', 'basalam.field.productPrefix'],
              ['product_suffix_title', 'basalam.field.productSuffix'],
              ['customer_prefix_name', 'basalam.field.customerPrefix'],
              ['customer_suffix_name', 'basalam.field.customerSuffix'],
              ['safe_stock', 'basalam.field.safeStock'],
              ['video_meta_key', 'basalam.field.videoMeta'],
              ['video_source', 'basalam.field.videoSource'],
              ['video_inherit_mode', 'basalam.field.videoInherit'],
              ['order_statues_type', 'basalam.field.orderStatusMode'],
              ['order_shipping_method', 'basalam.field.shippingMethod'],
              ['variable_product_stock_source', 'basalam.field.variableStockSource'],
              ['product_price_field', 'basalam.field.productPriceField'],
            ] as Array<[string, string]>
          ).map(([key, label]) => (
            <label key={key} className="space-y-1 text-sm">
              <span>{t(label)}</span>
              <Input
                value={String(s[key] ?? '')}
                onChange={(e) =>
                  setField(
                    key,
                    key.includes('title') ||
                      key.includes('prefix') ||
                      key.includes('suffix') ||
                      key.includes('meta') ||
                      key.includes('mode') ||
                      key.includes('source') ||
                      key.includes('type') ||
                      key.includes('method') ||
                      key.includes('field')
                      ? e.target.value
                      : Number(e.target.value) || e.target.value
                  )
                }
              />
            </label>
          ))}
          <div className="md:col-span-2">
            <Button onClick={() => save.mutate(draft)} disabled={save.isPending}>
              {t('basalam.saveSettings')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </PageShell>
  )
}
