import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type Status = {
  engine?: boolean
  connected?: boolean
  vendor_id?: string | number | null
  jobs_pending?: number
  webhook_url?: string
  webhook_id?: string | number | null
  version?: string
}

export default function BasalamHomePage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [params, setParams] = useSearchParams()
  const [callbackUrl, setCallbackUrl] = useState('')
  const [accessToken, setAccessToken] = useState('')
  const [refreshToken, setRefreshToken] = useState('')
  const [vendorId, setVendorId] = useState('')

  const statusQ = useQuery({
    queryKey: ['basalam', 'status'],
    queryFn: () => apiFetch<Status>('basalam/status'),
    refetchInterval: 10000,
  })

  useEffect(() => {
    if (params.get('oauth') === 'connected') {
      toast.success(t('basalam.oauthConnected'))
      void qc.invalidateQueries({ queryKey: ['basalam'] })
      const next = new URLSearchParams(params)
      next.delete('oauth')
      setParams(next, { replace: true })
    }
  }, [params, qc, setParams, t])

  const oauth = useMutation({
    mutationFn: () => apiFetch<{ url: string }>('basalam/oauth/start', { method: 'POST' }),
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url
        return
      }
      toast.error(t('basalam.oauthMissingUrl'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const oauthPaste = useMutation({
    mutationFn: (url: string) =>
      apiFetch<{ ok?: boolean; connected?: boolean }>('basalam/oauth/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callback_url: url }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.oauthConnected'))
      setCallbackUrl('')
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const oauthManual = useMutation({
    mutationFn: () =>
      apiFetch('basalam/oauth/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          access_token: accessToken.trim(),
          refresh_token: refreshToken.trim(),
          vendor_id: vendorId.trim() || undefined,
        }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.oauthConnected'))
      setAccessToken('')
      setRefreshToken('')
      setVendorId('')
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const refresh = useMutation({
    mutationFn: () => apiFetch('basalam/oauth/refresh', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.tokenRefreshed'))
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const disconnect = useMutation({
    mutationFn: () => apiFetch('basalam/oauth/disconnect', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.disconnected'))
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const setupWebhook = useMutation({
    mutationFn: () => apiFetch('basalam/webhook/setup', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.webhookConfigured'))
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const pullOrders = useMutation({
    mutationFn: () => apiFetch('basalam/sync/orders/pull', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.ordersPullQueued'))
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const s = statusQ.data

  return (
    <PageShell title={t('basalam.title')} description={t('basalam.subtitle')}>
      <div className="mb-4 flex flex-wrap gap-2">
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/products">{t('basalam.nav.products')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/booth">{t('basalam.nav.booth')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/orders">{t('basalam.nav.orders')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/categories">{t('basalam.nav.categories')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/settings">{t('basalam.nav.settings')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/finance">{t('basalam.nav.finance')}</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/settings/shop/basalam/logs">{t('basalam.nav.logs')}</Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.connection')}</CardTitle>
            <CardDescription>{t('basalam.connectionHintWebina')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm">
              {s?.connected ? t('basalam.connected') : t('basalam.notConnected')}
              {s?.vendor_id ? ` · vendor #${s.vendor_id}` : ''}
            </p>
            <p className="text-muted-foreground text-xs">
              engine {s?.version ?? '—'} · jobs {s?.jobs_pending ?? 0}
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => oauth.mutate()} disabled={oauth.isPending}>
                {t('basalam.connectOAuth')}
              </Button>
              {s?.connected ? (
                <>
                  <Button variant="secondary" onClick={() => refresh.mutate()} disabled={refresh.isPending}>
                    {t('basalam.refreshToken')}
                  </Button>
                  <Button variant="outline" onClick={() => disconnect.mutate()} disabled={disconnect.isPending}>
                    {t('basalam.disconnect')}
                  </Button>
                </>
              ) : null}
            </div>
            <p className="text-muted-foreground text-xs leading-relaxed">{t('basalam.oauthWafHint')}</p>
            <div className="space-y-2 border-t pt-3">
              <p className="text-sm font-medium">{t('basalam.oauthPasteTitle')}</p>
              <Textarea
                value={callbackUrl}
                onChange={(e) => setCallbackUrl(e.target.value)}
                placeholder={t('basalam.oauthPastePlaceholder')}
                rows={3}
                className="font-mono text-xs"
              />
              <Button
                variant="secondary"
                disabled={oauthPaste.isPending || !callbackUrl.trim()}
                onClick={() => oauthPaste.mutate(callbackUrl.trim())}
              >
                {t('basalam.oauthPasteSave')}
              </Button>
            </div>
            <div className="space-y-2 border-t pt-3">
              <p className="text-sm font-medium">{t('basalam.manualTokenTitle')}</p>
              <p className="text-muted-foreground text-xs">{t('basalam.manualTokenHint')}</p>
              <Textarea
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
                placeholder="access_token"
                rows={2}
                className="font-mono text-xs"
              />
              <Textarea
                value={refreshToken}
                onChange={(e) => setRefreshToken(e.target.value)}
                placeholder="refresh_token"
                rows={2}
                className="font-mono text-xs"
              />
              <Input
                value={vendorId}
                onChange={(e) => setVendorId(e.target.value)}
                placeholder="vendor_id (optional)"
              />
              <Button
                variant="secondary"
                disabled={oauthManual.isPending || !accessToken.trim()}
                onClick={() => oauthManual.mutate()}
              >
                {t('basalam.manualTokenSave')}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.operations')}</CardTitle>
            <CardDescription>{t('basalam.operationsHint')}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button onClick={() => pullOrders.mutate()} disabled={pullOrders.isPending || !s?.connected}>
              {t('basalam.pullOrders')}
            </Button>
            <Button
              variant="secondary"
              onClick={() => setupWebhook.mutate()}
              disabled={setupWebhook.isPending || !s?.connected}
            >
              {t('basalam.setupWebhook')}
            </Button>
            <Button asChild variant="outline">
              <Link to="/settings/shop/basalam/products">{t('basalam.nav.products')}</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/settings/shop/pricing/marketplaces">{t('wnc.openPricingTab')}</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>{t('basalam.webhook')}</CardTitle>
            <CardDescription>
              {s?.webhook_id ? t('basalam.webhookConfigured') : t('basalam.webhookPending')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <code className="bg-muted block overflow-x-auto rounded-md p-3 text-xs">{s?.webhook_url ?? '—'}</code>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  )
}
