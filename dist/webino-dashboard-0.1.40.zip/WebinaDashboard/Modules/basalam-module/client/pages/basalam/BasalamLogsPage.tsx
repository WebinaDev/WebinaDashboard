import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

type JobRow = { id?: number; type?: string; status?: string; error_message?: string }

export default function BasalamLogsPage() {
  const { t } = useTranslation()
  const jobsQ = useQuery({
    queryKey: ['basalam', 'jobs', 'all'],
    queryFn: () => apiFetch<{ jobs: JobRow[] }>('basalam/jobs'),
    refetchInterval: 8000,
  })
  const logsQ = useQuery({
    queryKey: ['basalam', 'logs'],
    queryFn: () => apiFetch<{ hint?: string; logs: unknown[] }>('basalam/logs'),
  })
  const covQ = useQuery({
    queryKey: ['basalam', 'coverage'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/coverage/endpoints'),
  })

  return (
    <PageShell title={t('basalam.logsTitle')} description={t('basalam.logsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.coverage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted max-h-60 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(covQ.data ?? {}, null, 2)}
          </pre>
        </CardContent>
      </Card>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.recentJobs')}</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-start">
                <th className="py-2 pe-2">ID</th>
                <th className="py-2 pe-2">{t('basalam.col.type')}</th>
                <th className="py-2 pe-2">{t('basalam.col.status')}</th>
                <th className="py-2">{t('basalam.col.error')}</th>
              </tr>
            </thead>
            <tbody>
              {(jobsQ.data?.jobs ?? []).map((j) => (
                <tr key={String(j.id)} className="border-b">
                  <td className="py-2 pe-2">{j.id}</td>
                  <td className="py-2 pe-2 font-mono text-xs">{j.type}</td>
                  <td className="py-2 pe-2">{j.status}</td>
                  <td className="text-muted-foreground py-2 text-xs">{j.error_message || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.logsTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-2 text-sm">{logsQ.data?.hint}</p>
          <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(logsQ.data?.logs ?? [], null, 2)}
          </pre>
        </CardContent>
      </Card>
    </PageShell>
  )
}
