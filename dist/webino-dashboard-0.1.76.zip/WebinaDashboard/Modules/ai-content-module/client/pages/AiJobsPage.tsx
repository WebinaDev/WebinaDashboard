import { Link, useSearchParams } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { useEffect, useRef } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { jobPhase, jobPhasePercent } from '@/lib/aiJobProgress'
import { toastApiError } from '@/lib/apiError'
import { type AiJob, fetchAiJobs, retryAiJob, runDueJobs } from '../lib/ai-content-api'

const FILTERS = ['', 'pending', 'running', 'failed', 'done'] as const

function jobTargetHref(job: AiJob): string | null {
  if (job.target_type === 'calendar') return '/ai-content/calendar'
  if (job.target_id < 1) return null
  if (job.target_type === 'product') return `/shop/products/${job.target_id}`
  if (job.target_type === 'post') return `/magazine/posts/${job.target_id}`
  if (job.target_type === 'product_cat' || job.target_type === 'product_brand') {
    return '/ai-content/taxonomies'
  }
  return null
}

function statusVariant(status: string): 'default' | 'secondary' | 'destructive' | 'outline' {
  if (status === 'done') return 'default'
  if (status === 'failed') return 'destructive'
  if (status === 'running') return 'secondary'
  return 'outline'
}

function isActiveJob(job: AiJob) {
  return job.status === 'pending' || job.status === 'running'
}

export default function AiJobsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [params, setParams] = useSearchParams()
  const status = params.get('status') ?? ''
  const filter = FILTERS.includes(status as (typeof FILTERS)[number]) ? status : ''

  const jobsQ = useQuery({
    queryKey: ['ai-content', 'jobs', filter],
    queryFn: () => fetchAiJobs({ status: filter || undefined, limit: 80 }),
    refetchInterval: (q) => ((q.state.data?.items ?? []).some(isActiveJob) ? 2000 : false),
  })
  useQueryErrorToast(jobsQ)

  const autoRunLock = useRef(false)
  useEffect(() => {
    const pending = (jobsQ.data?.items ?? []).filter((j) => j.status === 'pending')
    if (!pending.length || autoRunLock.current) {
      return
    }
    autoRunLock.current = true
    void runDueJobs(1)
      .then(() => qc.invalidateQueries({ queryKey: ['ai-content'] }))
      .finally(() => {
        autoRunLock.current = false
      })
  }, [jobsQ.data, qc])

  const retry = useMutation({
    mutationFn: (id: number) => retryAiJob(id),
    onSuccess: () => {
      toast.success(t('aiContent.jobRetried'))
      void qc.invalidateQueries({ queryKey: ['ai-content'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const runDue = useMutation({
    mutationFn: () => runDueJobs(1),
    onSuccess: (res) => {
      toast.success(t('aiContent.jobsRunDueDone', { count: res.count }))
      void qc.invalidateQueries({ queryKey: ['ai-content'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const setFilter = (next: string) => {
    const nextParams = new URLSearchParams(params)
    if (next) nextParams.set('status', next)
    else nextParams.delete('status')
    setParams(nextParams, { replace: true })
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {FILTERS.map((key) => (
          <Button
            key={key || 'all'}
            size="sm"
            variant={filter === key ? 'default' : 'outline'}
            onClick={() => setFilter(key)}
          >
            {t(key ? `aiContent.jobsFilter.${key}` : 'aiContent.jobsFilter.all')}
          </Button>
        ))}
        <Button size="sm" className="ms-auto" disabled={runDue.isPending} onClick={() => void runDue.mutateAsync()}>
          {t('aiContent.jobsRunDue')}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.jobsPageTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {jobsQ.isPending ? <Skeleton className="h-24 w-full rounded-xl" /> : null}
          {(jobsQ.data?.items ?? []).map((job) => {
            const href = jobTargetHref(job)
            return (
              <div
                key={job.id}
                className="flex flex-wrap items-start justify-between gap-2 border-b py-3 text-sm last:border-0"
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">#{job.id}</span>
                    <span>{t(`aiContent.jobType.${job.job_type}`, { defaultValue: job.job_type })}</span>
                    <Badge variant={statusVariant(job.status)}>
                      {t(`aiContent.jobStatus.${job.status}`, { defaultValue: job.status })}
                    </Badge>
                    {job.provider ? (
                      <span className="text-muted-foreground">{job.provider}</span>
                    ) : null}
                  </div>
                  <div className="text-muted-foreground">
                    {href ? (
                      <Link className="underline-offset-2 hover:underline" to={href}>
                        {job.target_type}
                        {job.target_id > 0 ? ` #${job.target_id}` : ''}
                      </Link>
                    ) : (
                      <span>
                        {job.target_type}
                        {job.target_id > 0 ? ` #${job.target_id}` : ''}
                      </span>
                    )}
                    {job.attempts > 0 ? ` · ${t('aiContent.jobsAttempts', { count: job.attempts })}` : ''}
                    {job.tokens_in || job.tokens_out
                      ? ` · ${t('aiContent.jobsTokens', { inCount: job.tokens_in || 0, outCount: job.tokens_out || 0 })}`
                      : ''}
                    {job.created_at ? ` · ${job.created_at}` : ''}
                  </div>
                  {job.error_message ? (
                    <div className="text-destructive">{job.error_message}</div>
                  ) : isActiveJob(job) ? (
                    <div className="space-y-1">
                      <div className="bg-muted h-1.5 overflow-hidden rounded-full">
                        <div
                          className="bg-primary h-full transition-[width] duration-500"
                          style={{ width: `${jobPhasePercent(jobPhase(job))}%` }}
                        />
                      </div>
                      <div className="text-muted-foreground text-xs">
                        {t(`aiContent.phase.${jobPhase(job)}`, { defaultValue: jobPhase(job) })}
                      </div>
                    </div>
                  ) : job.result_summary &&
                    !['queued', 'provider', 'seo', 'writing', 'done'].includes(job.result_summary) ? (
                    <div className="text-muted-foreground">{job.result_summary}</div>
                  ) : null}
                </div>
                {job.status === 'failed' ? (
                  <Button size="sm" variant="outline" disabled={retry.isPending} onClick={() => void retry.mutateAsync(job.id)}>
                    {t('aiContent.retry')}
                  </Button>
                ) : null}
              </div>
            )
          })}
          {!jobsQ.isPending && !jobsQ.data?.items?.length ? (
            <p className="text-sm text-muted-foreground">{t('aiContent.noJobs')}</p>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
