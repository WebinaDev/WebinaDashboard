import type { TFunction } from 'i18next'

export type BasalamJobLike = {
  id?: number
  job_type?: string
  type?: string
  status?: string
  error_message?: string
  created_at?: string | number
  started_at?: string | number
  completed_at?: string | number
  updated_at?: string | number
}

const JOB_TYPE_KEYS: Record<string, string> = {
  sync_basalam_create_all_products: 'basalam.job.createAllProducts',
  sync_basalam_update_all_products: 'basalam.job.updateAllProducts',
  sync_basalam_bulk_update_products: 'basalam.job.bulkUpdateProducts',
  sync_basalam_create_single_product: 'basalam.job.createProduct',
  sync_basalam_update_single_product: 'basalam.job.updateProduct',
  sync_basalam_auto_connect_products: 'basalam.job.autoConnect',
  sync_basalam_fetch_orders: 'basalam.job.fetchOrders',
  sync_basalam_quick_update: 'basalam.job.quickUpdate',
  webino_basalam_discount_tasks: 'basalam.job.discounts',
}

const STATUS_KEYS: Record<string, string> = {
  pending: 'basalam.jobStatus.pending',
  processing: 'basalam.jobStatus.processing',
  completed: 'basalam.jobStatus.completed',
  failed: 'basalam.jobStatus.failed',
  success: 'basalam.jobStatus.completed',
}

export function basalamJobType(job: BasalamJobLike): string {
  return String(job.job_type || job.type || '')
}

export function basalamJobTypeLabel(raw: string | undefined, t: TFunction): string {
  if (!raw) return '—'
  const key = JOB_TYPE_KEYS[raw]
  if (key) return t(key)
  return t(`basalam.job.${raw}`, {
    defaultValue: raw.replace(/^sync_basalam_/, '').replace(/_/g, ' '),
  })
}

export function basalamJobStatusLabel(raw: string | undefined, t: TFunction): string {
  if (!raw) return '—'
  const key = STATUS_KEYS[raw]
  if (key) return t(key)
  return t(`basalam.jobStatus.${raw}`, { defaultValue: raw })
}
