import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronDown } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { BasalamNav } from '../../components/BasalamNav'
import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import { Input } from '@/components/ui/input'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type ProductSample = {
  items?: Array<{ id: number; weight?: string | number; stock_quantity?: number | null }>
}

export default function BasalamSyncSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [draft, setDraft] = useState<Record<string, unknown>>({})
  const [advancedOpen, setAdvancedOpen] = useState(false)

  const settingsQ = useQuery({
    queryKey: ['basalam', 'settings'],
    queryFn: () =>
      apiFetch<{ settings: Record<string, unknown>; connected?: boolean }>('basalam/settings'),
  })

  useEffect(() => {
    if (settingsQ.data?.settings) {
      setDraft(settingsQ.data.settings)
    }
  }, [settingsQ.data])

  const save = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('basalam/settings', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: async () => {
      toast.success(t('basalam.settingsSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'settings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const fillFromCatalog = useMutation({
    mutationFn: async () => {
      const data = await apiFetch<ProductSample>('shop/products?per_page=20&status=publish')
      const items = data.items ?? []
      let weightSum = 0
      let weightN = 0
      let stockSum = 0
      let stockN = 0
      for (const p of items) {
        const w = Number(p.weight)
        if (Number.isFinite(w) && w > 0) {
          weightSum += w
          weightN += 1
        }
        if (typeof p.stock_quantity === 'number' && p.stock_quantity >= 0) {
          stockSum += p.stock_quantity
          stockN += 1
        }
      }
      const next = { ...draft }
      if (weightN > 0 && (!next.default_weight || Number(next.default_weight) === 0)) {
        next.default_weight = Math.round(weightSum / weightN)
      }
      if (weightN > 0 && (!next.default_package_weight || Number(next.default_package_weight) === 0)) {
        next.default_package_weight = Math.max(50, Math.round(weightSum / weightN / 10))
      }
      if (stockN > 0 && (!next.default_stock_quantity || Number(next.default_stock_quantity) === 0)) {
        next.default_stock_quantity = Math.max(1, Math.round(stockSum / stockN))
      }
      if (!next.default_preparation || Number(next.default_preparation) === 0) {
        next.default_preparation = 3
      }
      setDraft(next)
      return next
    },
    onSuccess: () => toast.success(t('basalam.defaultsFilled')),
    onError: (e: Error) => toastApiError(t, e),
  })

  const s = draft
  const setField = (key: string, value: unknown) => setDraft((prev) => ({ ...prev, [key]: value }))
  const isOn = (value: unknown) =>
    value === true || value === 'yes' || value === 1 || value === '1' || value === 'true'

  const setToggle = (key: string) => {
    const yesNoKeys = new Set([
      'add_attr_to_desc_product',
      'add_short_desc_to_desc_product',
      'add_full_desc_to_desc_product',
      'cap_preparation_to_category_max',
    ])
    if (yesNoKeys.has(key)) {
      setField(key, isOn(s[key]) ? 'no' : 'yes')
      return
    }
    if (key === 'round_price') {
      setField(key, s[key] && s[key] !== 'none' ? 'none' : 'round')
      return
    }
    if (key === 'all_products_wholesale') {
      setField(key, s[key] && s[key] !== 'none' ? 'none' : 'yes')
      return
    }
    setField(key, !isOn(s[key]))
  }

  const toggleActive = (key: string) => {
    if (key === 'round_price') return Boolean(s[key] && s[key] !== 'none')
    if (key === 'all_products_wholesale') return Boolean(s[key] && s[key] !== 'none')
    if (key === 'add_full_desc_to_desc_product') {
      return s[key] === undefined || s[key] === null || s[key] === '' || isOn(s[key])
    }
    return isOn(s[key])
  }

  const toggles: Array<{ key: string; label: string }> = [
    { key: 'sync_status_product', label: t('basalam.syncProducts') },
    { key: 'sync_status_order', label: t('basalam.syncOrders') },
    { key: 'auto_confirm_order', label: t('basalam.autoConfirm') },
    { key: 'round_price', label: t('basalam.roundPrice') },
    { key: 'add_full_desc_to_desc_product', label: t('basalam.addFullDesc') },
    { key: 'add_attr_to_desc_product', label: t('basalam.addAttrToDesc') },
    { key: 'add_short_desc_to_desc_product', label: t('basalam.addShortDesc') },
    { key: 'all_products_wholesale', label: t('basalam.allWholesale') },
    { key: 'cap_preparation_to_category_max', label: t('basalam.capPrep') },
    { key: 'chat_notify_admins', label: t('basalam.chatNotify') },
  ]

  const syncFieldKeys = [
    'sync_product_field_name',
    'sync_product_field_photos',
    'sync_product_field_price',
    'sync_product_field_stock',
    'sync_product_field_weight',
    'sync_product_field_description',
    'sync_product_field_attr',
    'sync_product_field_video',
    'sync_product_field_variant_price',
    'sync_product_field_variant_stock',
  ]

  const syncFieldLabel = (key: string) =>
    t(`basalam.syncField.${key.replace('sync_product_field_', '')}`, {
      defaultValue: key.replace('sync_product_field_', ''),
    })

  return (
    <PageShell title={t('basalam.settingsTitle')} description={t('basalam.settingsSubtitle')}>
      <BasalamNav />
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncToggles')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {toggles.map((item) => (
            <Button
              key={item.key}
              variant={toggleActive(item.key) ? 'default' : 'outline'}
              onClick={() => setToggle(item.key)}
            >
              {item.label}
            </Button>
          ))}
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.selectiveSync')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            variant={s.sync_product_fields === 'all' ? 'default' : 'outline'}
            onClick={() => setField('sync_product_fields', 'all')}
          >
            {t('basalam.syncAllFields')}
          </Button>
          <Button
            variant={s.sync_product_fields === 'custom' ? 'default' : 'outline'}
            onClick={() => setField('sync_product_fields', 'custom')}
          >
            {t('basalam.syncCustomFields')}
          </Button>
          {s.sync_product_fields === 'custom'
            ? syncFieldKeys.map((key) => (
                <Button
                  key={key}
                  size="sm"
                  variant={s[key] ? 'default' : 'outline'}
                  onClick={() => setField(key, !s[key])}
                >
                  {syncFieldLabel(key)}
                </Button>
              ))
            : null}
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.defaultProductValues')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {(
            [
              ['default_weight', 'basalam.field.defaultWeight'],
              ['default_package_weight', 'basalam.field.defaultPackageWeight'],
              ['default_preparation', 'basalam.field.defaultPreparation'],
              ['default_stock_quantity', 'basalam.field.defaultStock'],
              ['discount_duration', 'basalam.field.discountDays'],
              ['discount_reduction_percent', 'basalam.field.discountPercent'],
              ['safe_stock', 'basalam.field.safeStock'],
              ['price_change_value', 'basalam.field.priceChange'],
              ['product_prefix_title', 'basalam.field.productPrefix'],
              ['product_suffix_title', 'basalam.field.productSuffix'],
            ] as Array<[string, string]>
          ).map(([key, label]) => (
            <label key={key} className="space-y-1 text-sm">
              <span>{t(label)}</span>
              <Input
                value={String(s[key] ?? '')}
                onChange={(e) =>
                  setField(
                    key,
                    key.includes('title') || key.includes('prefix') || key.includes('suffix')
                      ? e.target.value
                      : Number(e.target.value) || e.target.value,
                  )
                }
              />
            </label>
          ))}
          <div className="flex flex-wrap gap-2 md:col-span-2">
            <Button variant="secondary" onClick={() => fillFromCatalog.mutate()} disabled={fillFromCatalog.isPending}>
              {t('basalam.fillFromCatalog')}
            </Button>
            <Button onClick={() => save.mutate(draft)} disabled={save.isPending}>
              {t('basalam.saveSettings')}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Collapsible open={advancedOpen} onOpenChange={setAdvancedOpen}>
        <Card>
          <CardHeader className="pb-3">
            <CollapsibleTrigger asChild>
              <button type="button" className="flex w-full items-center justify-between text-start">
                <CardTitle className="text-base">{t('basalam.advanced')}</CardTitle>
                <ChevronDown className={`size-4 transition-transform ${advancedOpen ? 'rotate-180' : ''}`} />
              </button>
            </CollapsibleTrigger>
          </CardHeader>
          <CollapsibleContent>
            <CardContent className="grid gap-3 border-t pt-4 md:grid-cols-2">
              <Button
                variant={s.developer_mode ? 'default' : 'outline'}
                onClick={() => setField('developer_mode', !s.developer_mode)}
              >
                {t('basalam.developerMode')}
              </Button>
              <Button
                variant={s.tasks_per_minute_auto ? 'default' : 'outline'}
                onClick={() => setField('tasks_per_minute_auto', !s.tasks_per_minute_auto)}
              >
                {t('basalam.tasksAuto')}
              </Button>
              {(
                [
                  ['tasks_per_minute', 'basalam.field.tasksPerMinute'],
                  ['video_meta_key', 'basalam.field.videoMeta'],
                  ['video_source', 'basalam.field.videoSource'],
                  ['video_inherit_mode', 'basalam.field.videoInherit'],
                  ['order_statues_type', 'basalam.field.orderStatusMode'],
                  ['order_shipping_method', 'basalam.field.shippingMethod'],
                  ['variable_product_stock_source', 'basalam.field.variableStockSource'],
                  ['product_price_field', 'basalam.field.productPriceField'],
                  ['customer_prefix_name', 'basalam.field.customerPrefix'],
                  ['customer_suffix_name', 'basalam.field.customerSuffix'],
                ] as Array<[string, string]>
              ).map(([key, label]) => (
                <label key={key} className="space-y-1 text-sm">
                  <span>{t(label)}</span>
                  <Input
                    value={String(s[key] ?? '')}
                    onChange={(e) => setField(key, e.target.value)}
                  />
                </label>
              ))}
              <div className="md:col-span-2">
                <Button onClick={() => save.mutate(draft)} disabled={save.isPending}>
                  {t('basalam.saveSettings')}
                </Button>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </PageShell>
  )
}
