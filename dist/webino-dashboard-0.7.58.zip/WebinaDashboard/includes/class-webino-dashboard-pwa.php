<?php
/**
 * Progressive Web App: manifest + service worker under /dashboard/.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Serves installable PWA assets with the correct scope (/dashboard/).
 */
final class Webino_Dashboard_PWA {

	const MANIFEST_PATH = 'manifest.webmanifest';
	const SW_PATH       = 'sw.js';

	/**
	 * Theme color for status bar / splash.
	 *
	 * @return string
	 */
	public static function theme_color() {
		return '#0f172a';
	}

	/**
	 * Background color for splash.
	 *
	 * @return string
	 */
	public static function background_color() {
		return '#ffffff';
	}

	/**
	 * Whether the current dashboard path is a PWA static asset (no trailing slash).
	 *
	 * @param string|null $path Optional wd_path; defaults to query var.
	 * @return bool
	 */
	public static function is_pwa_asset_path( $path = null ) {
		if ( null === $path ) {
			$path = trim( (string) get_query_var( 'wd_path' ), '/' );
		} else {
			$path = trim( (string) $path, '/' );
		}
		return self::MANIFEST_PATH === $path || self::SW_PATH === $path;
	}

	/**
	 * Absolute URL for a bundled PWA icon (falls back to site icon when available).
	 *
	 * @param int    $size Preferred size (192, 512, 180).
	 * @param string $purpose 'any' | 'maskable' | 'apple'.
	 * @return string
	 */
	public static function icon_url( $size, $purpose = 'any' ) {
		$size = (int) $size;
		if ( 'apple' === $purpose ) {
			$site = get_site_icon_url( 180 );
			if ( $site ) {
				return $site;
			}
			return plugins_url( 'assets/pwa/apple-touch-icon.png', WEBINO_DASHBOARD_FILE );
		}

		$site = get_site_icon_url( $size );
		if ( $site && 'maskable' !== $purpose ) {
			return $site;
		}

		$file = 'maskable' === $purpose
			? sprintf( 'assets/pwa/icon-%d-maskable.png', $size )
			: sprintf( 'assets/pwa/icon-%d.png', $size );

		$path = WEBINO_DASHBOARD_DIR . $file;
		if ( is_readable( $path ) ) {
			return plugins_url( $file, WEBINO_DASHBOARD_FILE );
		}

		// Last resort: any-purpose sibling or favicon svg.
		$fallback = WEBINO_DASHBOARD_DIR . sprintf( 'assets/pwa/icon-%d.png', $size );
		if ( is_readable( $fallback ) ) {
			return plugins_url( sprintf( 'assets/pwa/icon-%d.png', $size ), WEBINO_DASHBOARD_FILE );
		}

		return plugins_url( 'assets/dashboard-build/favicon.svg', WEBINO_DASHBOARD_FILE );
	}

	/**
	 * Web App Manifest payload (shared by /dashboard/manifest and REST).
	 *
	 * @return array<string,mixed>
	 */
	public static function manifest_body() {
		$start = Webino_Dashboard_Rewrite::url();
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$locale = is_string( $locale ) && '' !== $locale ? str_replace( '_', '-', $locale ) : 'en';
		$is_rtl = ( 0 === strpos( strtolower( $locale ), 'fa' ) ) || ( function_exists( 'is_rtl' ) && is_rtl() );

		$site_name = get_bloginfo( 'name' );
		$dash_label = __( 'Dashboard', 'webino-dashboard' );
		$name = '' !== $site_name ? $site_name . ' — ' . $dash_label : $dash_label;

		$short = $dash_label;
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $short ) > 12 ) {
			$short = mb_substr( $short, 0, 12 );
		} elseif ( strlen( $short ) > 12 ) {
			$short = substr( $short, 0, 12 );
		}

		$icons = array(
			array(
				'src'     => self::icon_url( 192, 'any' ),
				'sizes'   => '192x192',
				'type'    => 'image/png',
				'purpose' => 'any',
			),
			array(
				'src'     => self::icon_url( 512, 'any' ),
				'sizes'   => '512x512',
				'type'    => 'image/png',
				'purpose' => 'any',
			),
			array(
				'src'     => self::icon_url( 192, 'maskable' ),
				'sizes'   => '192x192',
				'type'    => 'image/png',
				'purpose' => 'maskable',
			),
			array(
				'src'     => self::icon_url( 512, 'maskable' ),
				'sizes'   => '512x512',
				'type'    => 'image/png',
				'purpose' => 'maskable',
			),
		);

		return array(
			'id'               => $start,
			'name'             => $name,
			'short_name'       => $short,
			'description'      => get_bloginfo( 'description', 'display' ) ?: __( 'Store dashboard', 'webino-dashboard' ),
			'start_url'        => $start,
			'scope'            => $start,
			'display'          => 'standalone',
			'display_override' => array( 'standalone', 'browser' ),
			'background_color' => self::background_color(),
			'theme_color'      => self::theme_color(),
			'lang'             => $locale,
			'dir'              => $is_rtl ? 'rtl' : 'ltr',
			'icons'            => $icons,
		);
	}

	/**
	 * Absolute dashboard-relative URL for PWA assets.
	 *
	 * @param string $asset manifest.webmanifest | sw.js
	 * @return string
	 */
	public static function asset_url( $asset ) {
		$asset = ltrim( (string) $asset, '/' );
		// Do not use Rewrite::url() — it forces a trailing slash (breaks SW/manifest URLs).
		return untrailingslashit( home_url( '/dashboard/' . $asset ) );
	}

	/**
	 * Pathname of the dashboard scope (for Service-Worker-Allowed header).
	 *
	 * @return string e.g. /dashboard/ or /subdir/dashboard/
	 */
	public static function scope_path() {
		$path = wp_parse_url( Webino_Dashboard_Rewrite::url(), PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			return '/dashboard/';
		}
		return trailingslashit( $path );
	}

	/**
	 * Serve manifest or service worker and exit when matched.
	 *
	 * @return void
	 */
	public static function maybe_serve() {
		if ( ! webino_dashboard()->rewrite->is_dashboard_request() ) {
			return;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}
		if ( wp_doing_ajax() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		$path = trim( (string) get_query_var( 'wd_path' ), '/' );
		if ( self::MANIFEST_PATH === $path ) {
			self::serve_manifest();
		}
		if ( self::SW_PATH === $path ) {
			self::serve_service_worker();
		}
	}

	/**
	 * @return void
	 */
	private static function serve_manifest() {
		$body = wp_json_encode( self::manifest_body(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( ! is_string( $body ) ) {
			$status = 500;
			status_header( $status );
			nocache_headers();
			exit;
		}

		status_header( 200 );
		header( 'Content-Type: application/manifest+json; charset=' . get_option( 'blog_charset' ), true );
		header( 'Cache-Control: no-cache, must-revalidate, max-age=0', true );
		header( 'X-Content-Type-Options: nosniff', true );
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON body.
		exit;
	}

	/**
	 * @return void
	 */
	private static function serve_service_worker() {
		$candidates = array(
			WEBINO_DASHBOARD_DIR . 'assets/dashboard-build/dashboard-sw.js',
			WEBINO_DASHBOARD_DIR . 'client/public/dashboard-sw.js',
		);
		$file = null;
		foreach ( $candidates as $candidate ) {
			if ( is_readable( $candidate ) ) {
				$file = $candidate;
				break;
			}
		}
		if ( null === $file ) {
			status_header( 404 );
			nocache_headers();
			exit;
		}

		$raw = file_get_contents( $file );
		if ( ! is_string( $raw ) ) {
			status_header( 500 );
			nocache_headers();
			exit;
		}

		status_header( 200 );
		header( 'Content-Type: application/javascript; charset=UTF-8', true );
		header( 'Cache-Control: no-cache, must-revalidate, max-age=0', true );
		header( 'Service-Worker-Allowed: ' . self::scope_path(), true );
		header( 'X-Content-Type-Options: nosniff', true );
		echo $raw; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JS source.
		exit;
	}
}
