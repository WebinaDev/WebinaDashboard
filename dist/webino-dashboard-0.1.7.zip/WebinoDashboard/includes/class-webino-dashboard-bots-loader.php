<?php
/**
 * Embedded Bale + Telegram bot engines (ported from woobale).
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Autoloads bot trees and boots engines when WooCommerce is active.
 */
final class Webino_Dashboard_Bots_Loader {

	const WOOBALE_STANDALONE = 'woobale/woobale.php';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_boot' ), 24 );
	}

	/**
	 * @return void
	 */
	public static function register_autoloaders(): void {
		static $registered = false;
		if ( $registered ) {
			return;
		}
		$registered = true;

		if ( ! defined( 'WEBINO_DASHBOARD_BOTS_BALE_DIR' ) ) {
			define( 'WEBINO_DASHBOARD_BOTS_BALE_DIR', WEBINO_DASHBOARD_DIR . 'includes/bots/bale/' );
		}
		if ( ! defined( 'WEBINO_DASHBOARD_BOTS_TELEGRAM_DIR' ) ) {
			define( 'WEBINO_DASHBOARD_BOTS_TELEGRAM_DIR', WEBINO_DASHBOARD_DIR . 'includes/bots/telegram/' );
		}

		spl_autoload_register( array( __CLASS__, 'autoload_bale' ), true, true );
		spl_autoload_register( array( __CLASS__, 'autoload_telegram' ), true, true );
	}

	/**
	 * @param string $class Class name.
	 * @return void
	 */
	public static function autoload_bale( $class ) {
		$prefix = 'Webino_Dashboard_Bots_Bale\\';
		$len    = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}
		$relative = substr( $class, $len );
		$file     = WEBINO_DASHBOARD_BOTS_BALE_DIR . str_replace( '\\', '/', $relative ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}

	/**
	 * @param string $class Class name.
	 * @return void
	 */
	public static function autoload_telegram( $class ) {
		$prefix = 'Webino_Dashboard_Bots_Telegram\\';
		$len    = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}
		$relative = substr( $class, $len );
		$file     = WEBINO_DASHBOARD_BOTS_TELEGRAM_DIR . str_replace( '\\', '/', $relative ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}

	/**
	 * @return bool
	 */
	private static function standalone_woobale_active(): bool {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active( self::WOOBALE_STANDALONE );
	}

	/**
	 * @return void
	 */
	public static function maybe_boot(): void {
		static $done = false;
		if ( $done ) {
			return;
		}

		if ( ! class_exists( 'WooCommerce', false ) ) {
			return;
		}

		$done = true;

		self::register_autoloaders();

		if ( ! self::standalone_woobale_active() ) {
			require_once WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-bots-campaign-migrate.php';
			Webino_Dashboard_Bots_Campaign_Migration::run();
		}

		Webino_Dashboard_Install::ensure_dashboard_bot_sessions_table();

		if ( ! defined( 'WEBINO_DASHBOARD_BOTS_EMBEDDED' ) ) {
			define( 'WEBINO_DASHBOARD_BOTS_EMBEDDED', true );
		}

		if ( ! self::standalone_woobale_active() && class_exists( 'Webino_Dashboard_Bots_Bale\Core\Plugin', false ) ) {
			\Webino_Dashboard_Bots_Bale\Core\Plugin::bootstrap_secrets();
			\Webino_Dashboard_Bots_Bale\Core\Plugin::instance()->init();
		}

		if ( class_exists( 'Webino_Dashboard_Bots_Telegram\Core\Plugin', false ) ) {
			\Webino_Dashboard_Bots_Telegram\Core\Plugin::bootstrap_secrets();
			\Webino_Dashboard_Bots_Telegram\Core\Plugin::instance()->init();
		}
	}
}
