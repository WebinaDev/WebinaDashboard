<?php
/**
 * Default module registry (sidebar) — filterable.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds default module tree from README.
 */
class Webino_Dashboard_Modules {

	/**
	 * Whether a dashboard module slug is enabled (option). Overview (home) is always on.
	 * `settings-app` falls back to legacy `webino_dashboard_module_settings_active` if needed.
	 *
	 * @param string $slug Module id.
	 * @return bool
	 */
	public static function is_module_enabled( $slug ) {
		$slug = sanitize_key( (string) $slug );
		if ( '' === $slug || 'home' === $slug ) {
			return true;
		}
		if ( 'settings-app' === $slug ) {
			$explicit = get_option( 'webino_dashboard_module_settings-app_active', null );
			if ( null !== $explicit ) {
				return (bool) $explicit;
			}
			return (bool) get_option( 'webino_dashboard_module_settings_active', true );
		}
		return (bool) get_option( 'webino_dashboard_module_' . $slug . '_active', true );
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public static function get_default_modules() {
		$wfcp_settings_children = array(
			array(
				'id'             => 'wfcp-dashboard',
				'title'          => __( 'WFCP dashboard', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/dashboard',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-currency',
				'title'          => __( 'Currency', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/currency',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-exchange',
				'title'          => __( 'Exchange rate', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/exchange',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-retail',
				'title'          => __( 'Retail pricing', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/retail',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-credit',
				'title'          => __( 'Credit', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/credit',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-installment',
				'title'          => __( 'Installments', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/installment',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-wholesale',
				'title'          => __( 'Wholesale', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/wholesale',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-notifications',
				'title'          => __( 'Texts & descriptions', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/notifications',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-style',
				'title'          => __( 'Styles', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/style',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
			array(
				'id'             => 'wfcp-advanced',
				'title'          => __( 'Advanced', 'webino-dashboard' ),
				'path'           => '/settings/wfcp/advanced',
				'capability'     => 'edit_products',
				'requires_wfcp'  => true,
			),
		);

		$modules = array(
			array(
				'id'          => 'home',
				'title'       => __( 'Overview', 'webino-dashboard' ),
				'path'        => '/',
				'capability'  => 'read',
				'icon'        => 'layout-dashboard',
			),
			array(
				'id'          => 'magazine',
				'title'       => __( 'Magazine', 'webino-dashboard' ),
				'path'        => '/magazine',
				'capability'  => 'edit_posts',
				'icon'        => 'newspaper',
				'children'    => array(
					array( 'id' => 'posts', 'title' => __( 'All posts', 'webino-dashboard' ), 'path' => '/magazine/posts', 'capability' => 'edit_posts' ),
					array( 'id' => 'post-new', 'title' => __( 'Add post', 'webino-dashboard' ), 'path' => '/magazine/new', 'capability' => 'edit_posts' ),
					array( 'id' => 'categories', 'title' => __( 'Categories', 'webino-dashboard' ), 'path' => '/magazine/categories', 'capability' => 'manage_categories' ),
				),
			),
			array(
				'id'          => 'media',
				'title'       => __( 'Media library', 'webino-dashboard' ),
				'path'        => '/media',
				'capability'  => 'upload_files',
				'icon'        => 'images',
			),
			array(
				'id'          => 'pages',
				'title'       => __( 'Site pages', 'webino-dashboard' ),
				'path'        => '/pages',
				'capability'  => 'edit_pages',
				'icon'        => 'file-text',
			),
			array(
				'id'          => 'shop',
				'title'       => __( 'Store', 'webino-dashboard' ),
				'path'        => '/shop',
				'capability'  => 'edit_products',
				'icon'        => 'shopping-bag',
				'children'    => array(
					array( 'id' => 'products', 'title' => __( 'Products', 'webino-dashboard' ), 'path' => '/shop/products', 'capability' => 'edit_products' ),
					array( 'id' => 'product-new', 'title' => __( 'Add product', 'webino-dashboard' ), 'path' => '/shop/products/new', 'capability' => 'edit_products' ),
					array( 'id' => 'brands', 'title' => __( 'Brands', 'webino-dashboard' ), 'path' => '/shop/brands', 'capability' => 'manage_product_terms' ),
					array( 'id' => 'product-cats', 'title' => __( 'Product categories', 'webino-dashboard' ), 'path' => '/shop/product-categories', 'capability' => 'manage_product_terms' ),
					array( 'id' => 'attributes', 'title' => __( 'Attributes', 'webino-dashboard' ), 'path' => '/shop/attributes', 'capability' => 'manage_product_terms' ),
					array(
						'id'            => 'wfcp-bulk',
						'title'         => __( 'Price list (bulk)', 'webino-dashboard' ),
						'path'          => '/shop/wfcp/bulk-editor',
						'capability'    => 'edit_products',
						'requires_wfcp' => true,
					),
					array(
						'id'            => 'wfcp-quick',
						'title'         => __( 'Quick add products', 'webino-dashboard' ),
						'path'          => '/shop/wfcp/quick-add',
						'capability'    => 'edit_products',
						'requires_wfcp' => true,
					),
					array(
						'id'            => 'wfcp-price',
						'title'         => __( 'Bulk price change', 'webino-dashboard' ),
						'path'          => '/shop/wfcp/price-changer',
						'capability'    => 'manage_woocommerce',
						'requires_wfcp' => true,
					),
					array(
						'id'                     => 'bale-bot',
						'title'                  => __( 'Bale bot (WooBale)', 'webino-dashboard' ),
						'path'                   => '/shop/bots/bale/dashboard',
						'capability'             => 'manage_woocommerce',
						'requires_woocommerce'   => true,
					),
					array(
						'id'                     => 'telegram-bot',
						'title'                  => __( 'Telegram bot', 'webino-dashboard' ),
						'path'                   => '/shop/bots/telegram/dashboard',
						'capability'             => 'manage_woocommerce',
						'requires_woocommerce'   => true,
					),
				),
			),
			array(
				'id'          => 'orders',
				'title'       => __( 'Orders', 'webino-dashboard' ),
				'path'        => '/orders',
				'capability'  => 'edit_shop_orders',
				'icon'        => 'package',
				'children'    => array(
					array( 'id' => 'order-list', 'title' => __( 'Orders', 'webino-dashboard' ), 'path' => '/orders/list', 'capability' => 'edit_shop_orders' ),
					array( 'id' => 'order-reports', 'title' => __( 'Reports', 'webino-dashboard' ), 'path' => '/orders/reports', 'capability' => 'view_woocommerce_reports' ),
				),
			),
			array(
				'id'          => 'marketing',
				'title'       => __( 'Marketing', 'webino-dashboard' ),
				'path'        => '/marketing',
				'capability'  => 'edit_shop_coupons',
				'icon'        => 'percent',
				'children'    => array(
					array( 'id' => 'coupons', 'title' => __( 'Coupons', 'webino-dashboard' ), 'path' => '/marketing/coupons', 'capability' => 'edit_shop_coupons' ),
				),
			),
			array(
				'id'          => 'users',
				'title'       => __( 'Users', 'webino-dashboard' ),
				'path'        => '/users',
				'capability'  => 'list_users',
				'icon'        => 'users',
				'children'    => array(
					array( 'id' => 'user-list', 'title' => __( 'Users', 'webino-dashboard' ), 'path' => '/users/list', 'capability' => 'list_users' ),
					array( 'id' => 'user-new', 'title' => __( 'Add user', 'webino-dashboard' ), 'path' => '/users/new', 'capability' => 'create_users' ),
					array( 'id' => 'comments', 'title' => __( 'Comments', 'webino-dashboard' ), 'path' => '/users/comments', 'capability' => 'moderate_comments' ),
				),
			),
			array(
				'id'          => 'analytics',
				'title'       => __( 'Analytics', 'webino-dashboard' ),
				'path'        => '/analytics',
				'capability'  => 'view_woocommerce_reports',
				'icon'        => 'bar-chart-2',
			),
			array(
				'title'                 => __( 'Settings', 'webino-dashboard' ),
				'path'                  => '/settings',
				'capability'            => 'manage_options',
				'icon'                  => 'settings',
				'ignore_parent_toggle'  => true,
				'children'              => array_merge(
					array(
						array(
							'id'          => 'settings-app',
							'title'       => __( 'Dashboard preferences', 'webino-dashboard' ),
							'path'        => '/settings',
							'capability'  => 'manage_options',
						),
					),
					$wfcp_settings_children
				),
			),
		);

		/**
		 * Filter registered dashboard modules (sidebar).
		 *
		 * @param array<int,array<string,mixed>> $modules Tree.
		 */
		return apply_filters( 'webino_dashboard_modules', $modules );
	}

	/**
	 * All module ids (recursive) for settings / options. Skips nodes with exclude_from_module_toggle.
	 *
	 * @param array<int,array<string,mixed>> $modules Modules tree.
	 * @return list<string>
	 */
	public static function collect_module_ids( $modules ) {
		$ids = array();
		foreach ( $modules as $m ) {
			self::collect_module_ids_walk( $m, $ids );
		}
		return array_values( array_unique( $ids ) );
	}

	/**
	 * @param array<string,mixed> $node Node.
	 * @param list<string>        $ids  Out ids.
	 * @return void
	 */
	private static function collect_module_ids_walk( $node, array &$ids ) {
		if ( ! is_array( $node ) ) {
			return;
		}
		$id = isset( $node['id'] ) ? (string) $node['id'] : '';
		if ( $id && empty( $node['exclude_from_module_toggle'] ) ) {
			$ids[] = $id;
		}
		if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
			foreach ( $node['children'] as $c ) {
				self::collect_module_ids_walk( $c, $ids );
			}
		}
	}
}
