<?php
/**
 * Extended REST: home widgets, post/page CRUD, media upload, orders, coupons, comments, brands, reports.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers additional routes.
 */
class Webino_Dashboard_REST_Crud {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register' ), 11 );
	}

	/**
	 * @return void
	 */
	public static function register() {
		register_rest_route(
			self::NS,
			'/dashboard/home',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'dashboard_home' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
			)
		);

		register_rest_route(
			self::NS,
			'/content/posts/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'post_get' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_posts' );
					},
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'post_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_posts' );
					},
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'post_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'delete_posts' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/posts',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'post_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_posts' );
					},
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/categories',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'categories_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_categories' ); },
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'categories_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_categories' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/categories/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'categories_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_categories' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'categories_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_categories' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/pages/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'page_get' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_pages' ); },
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'page_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_pages' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'page_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'delete_pages' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/pages',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'page_create' ),
				'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_pages' ); },
			)
		);

		register_rest_route(
			self::NS,
			'/content/media',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'media_upload' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'upload_files' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/media/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'media_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'upload_files' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'media_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'delete_posts' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/content/media/terms',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'media_terms_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'upload_files' ); },
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'media_terms_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'upload_files' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/product-categories',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'product_categories_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' )
							|| Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
					},
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'product_category_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
					},
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/product-categories/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'product_category_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
					},
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'product_category_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
					},
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/global-attributes',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'global_attribute_create' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/shop/global-attributes/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'global_attribute_delete' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/users/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'user_get' ),
					'permission_callback' => function ( $request ) {
						$uid = (int) $request['id'];
						return Webino_Dashboard_Rest_Base::can( 'list_users' ) || get_current_user_id() === $uid;
					},
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'user_patch' ),
					'permission_callback' => function ( $request ) {
						return current_user_can( 'edit_user', (int) $request['id'] );
					},
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'user_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'delete_users' );
					},
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'product_get' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'product_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products/(?P<id>\d+)/variations',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'product_variations_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'product_variation_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products/(?P<id>\d+)/variations/(?P<vid>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'product_variation_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'product_variation_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'product_create' ),
				'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
			)
		);

		register_rest_route(
			self::NS,
			'/shop/brands',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'brands_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_products' ); },
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'brands_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/brands/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'brands_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'brands_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/orders/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'order_get' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_orders' ); },
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'order_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_orders' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/shop/reports/sales',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'reports_sales' ),
				'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'view_woocommerce_reports' ); },
			)
		);

		register_rest_route(
			self::NS,
			'/marketing/coupons/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'coupon_get' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_coupons' ); },
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'coupon_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_coupons' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'coupon_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_coupons' ); },
				),
			)
		);

		register_rest_route(
			self::NS,
			'/marketing/coupons',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'coupon_create' ),
				'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'edit_shop_coupons' ); },
			)
		);

		register_rest_route(
			self::NS,
			'/comments/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PATCH',
					'callback'            => array( __CLASS__, 'comment_patch' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'moderate_comments' ); },
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( __CLASS__, 'comment_delete' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'moderate_comments' ); },
				),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function dashboard_home() {
		$recent_posts = array();
		$post_status    = current_user_can( 'edit_posts' ) ? 'any' : 'publish';
		$q              = new WP_Query(
			array(
				'post_type'      => 'post',
				'posts_per_page' => 5,
				'post_status'    => $post_status,
			)
		);
		while ( $q->have_posts() ) {
			$q->the_post();
			$recent_posts[] = array(
				'id'    => get_the_ID(),
				'title' => get_the_title(),
			);
		}
		wp_reset_postdata();

		$orders = array();
		if ( function_exists( 'wc_get_orders' ) && current_user_can( 'edit_shop_orders' ) ) {
			foreach ( wc_get_orders( array( 'limit' => 5, 'orderby' => 'date', 'order' => 'DESC' ) ) as $o ) {
				$orders[] = array(
					'id'     => $o->get_id(),
					'total'  => $o->get_total(),
					'status' => $o->get_status(),
				);
			}
		}

		return new WP_REST_Response(
			array(
				'recent_posts' => $recent_posts,
				'recent_orders'=> $orders,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function post_get( $request ) {
		$p = Webino_Dashboard_Rest_Base::get_post_for_type( (int) $request['id'], 'post' );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$cap = 'publish' === $p->post_status ? 'read_post' : 'edit_post';
		$ok  = Webino_Dashboard_Rest_Base::assert_post_cap( $p, $cap );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		return new WP_REST_Response( self::serialize_post( $p ) );
	}

	/**
	 * @param WP_Post $p Post.
	 * @return array<string,mixed>
	 */
	private static function serialize_post( $p ) {
		return array(
			'id'        => (int) $p->ID,
			'title'     => $p->post_title,
			'content'   => $p->post_content,
			'excerpt'   => $p->post_excerpt,
			'status'    => $p->post_status,
			'categories'=> wp_get_post_categories( $p->ID ),
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function post_create( $request ) {
		$id = wp_insert_post(
			array(
				'post_title'   => sanitize_text_field( (string) $request->get_param( 'title' ) ),
				'post_content' => (string) $request->get_param( 'content' ),
				'post_status'  => sanitize_key( (string) $request->get_param( 'status' ) ) ?: 'draft',
				'post_type'    => 'post',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$cats = $request->get_param( 'categories' );
		if ( is_array( $cats ) ) {
			wp_set_post_categories( $id, array_map( 'intval', $cats ) );
		}
		return new WP_REST_Response( self::serialize_post( get_post( $id ) ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function post_patch( $request ) {
		$id = (int) $request['id'];
		$p  = Webino_Dashboard_Rest_Base::get_post_for_type( $id, 'post' );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$ok = Webino_Dashboard_Rest_Base::assert_post_cap( $p, 'edit_post' );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$args = array( 'ID' => $id );
		if ( null !== $request->get_param( 'title' ) ) {
			$args['post_title'] = sanitize_text_field( (string) $request->get_param( 'title' ) );
		}
		if ( null !== $request->get_param( 'content' ) ) {
			$args['post_content'] = (string) $request->get_param( 'content' );
		}
		if ( null !== $request->get_param( 'status' ) ) {
			$args['post_status'] = sanitize_key( (string) $request->get_param( 'status' ) );
		}
		wp_update_post( $args );
		$cats = $request->get_param( 'categories' );
		if ( is_array( $cats ) ) {
			wp_set_post_categories( $id, array_map( 'intval', $cats ) );
		}
		return new WP_REST_Response( self::serialize_post( get_post( $id ) ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function post_delete( $request ) {
		$id = (int) $request['id'];
		$r  = wp_delete_post( $id, true );
		if ( ! $r ) {
			return new WP_Error( 'fail', 'Delete failed', array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function categories_list() {
		$terms = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return new WP_REST_Response( array( 'items' => array() ) );
		}
		$items = array();
		foreach ( $terms as $t ) {
			$items[] = array(
				'id'    => (int) $t->term_id,
				'name'  => $t->name,
				'slug'  => $t->slug,
				'count' => (int) $t->count,
			);
		}
		return new WP_REST_Response( array( 'items' => $items ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function categories_create( $request ) {
		$r = wp_insert_term(
			sanitize_text_field( (string) $request->get_param( 'name' ) ),
			'category',
			array(
				'slug'        => sanitize_title( (string) $request->get_param( 'slug' ) ),
				'description' => (string) $request->get_param( 'description' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'id' => (int) $r['term_id'] ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function categories_patch( $request ) {
		$id = (int) $request['id'];
		$r  = wp_update_term(
			$id,
			'category',
			array(
				'name'        => sanitize_text_field( (string) $request->get_param( 'name' ) ),
				'slug'        => sanitize_title( (string) $request->get_param( 'slug' ) ),
				'description' => (string) $request->get_param( 'description' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function categories_delete( $request ) {
		$r = wp_delete_term( (int) $request['id'], 'category' );
		if ( is_wp_error( $r ) || ! $r ) {
			return new WP_Error( 'fail', 'Delete failed', array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function page_get( $request ) {
		$p = Webino_Dashboard_Rest_Base::get_post_for_type( (int) $request['id'], 'page' );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$cap = 'publish' === $p->post_status ? 'read_post' : 'edit_page';
		$ok  = Webino_Dashboard_Rest_Base::assert_post_cap( $p, $cap );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		return new WP_REST_Response(
			array(
				'id'      => (int) $p->ID,
				'title'   => $p->post_title,
				'content' => $p->post_content,
				'status'  => $p->post_status,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function page_create( $request ) {
		$id = wp_insert_post(
			array(
				'post_title'   => sanitize_text_field( (string) $request->get_param( 'title' ) ),
				'post_content' => (string) $request->get_param( 'content' ),
				'post_status'  => sanitize_key( (string) $request->get_param( 'status' ) ) ?: 'draft',
				'post_type'    => 'page',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		return new WP_REST_Response( array( 'id' => (int) $id ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function page_patch( $request ) {
		$id = (int) $request['id'];
		$p  = Webino_Dashboard_Rest_Base::get_post_for_type( $id, 'page' );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$ok = Webino_Dashboard_Rest_Base::assert_post_cap( $p, 'edit_page' );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$args = array( 'ID' => $id );
		if ( null !== $request->get_param( 'title' ) ) {
			$args['post_title'] = sanitize_text_field( (string) $request->get_param( 'title' ) );
		}
		if ( null !== $request->get_param( 'content' ) ) {
			$args['post_content'] = (string) $request->get_param( 'content' );
		}
		if ( null !== $request->get_param( 'status' ) ) {
			$args['post_status'] = sanitize_key( (string) $request->get_param( 'status' ) );
		}
		wp_update_post( $args );
		return self::page_get( $request );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function page_delete( $request ) {
		wp_delete_post( (int) $request['id'], true );
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function media_upload() {
		if ( empty( $_FILES['file'] ) ) {
			return new WP_Error( 'no_file', __( 'No file uploaded.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$aid = media_handle_upload( 'file', 0 );
		if ( is_wp_error( $aid ) ) {
			return $aid;
		}
		return new WP_REST_Response(
			array(
				'id'  => (int) $aid,
				'url' => (string) wp_get_attachment_url( (int) $aid ),
			),
			201
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function media_delete( $request ) {
		if ( ! wp_delete_attachment( (int) $request['id'], true ) ) {
			return new WP_Error( 'fail', 'Delete failed', array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * Assign media categories / folder to an attachment.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function media_patch( $request ) {
		$id = (int) $request['id'];
		if ( ! get_post( $id ) || 'attachment' !== get_post_type( $id ) ) {
			return new WP_Error( 'not_found', __( 'Attachment not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}

		$cats = $request->get_param( 'category_ids' );
		if ( is_array( $cats ) && taxonomy_exists( 'webino_media_category' ) ) {
			$ids = array_map( 'intval', $cats );
			$ids = array_values( array_filter( $ids ) );
			wp_set_object_terms( $id, $ids, 'webino_media_category', false );
		}

		if ( null !== $request->get_param( 'folder_id' ) && taxonomy_exists( 'webino_media_folder' ) ) {
			$fid = $request->get_param( 'folder_id' );
			if ( null === $fid || '' === $fid ) {
				wp_set_object_terms( $id, array(), 'webino_media_folder', false );
			} else {
				$fid = (int) $fid;
				if ( $fid > 0 ) {
					wp_set_object_terms( $id, array( $fid ), 'webino_media_folder', false );
				}
			}
		}

		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * List media category + folder terms.
	 *
	 * @return WP_REST_Response
	 */
	public static function media_terms_list() {
		$categories = array();
		$folders    = array();
		if ( taxonomy_exists( 'webino_media_category' ) ) {
			$terms = get_terms( array( 'taxonomy' => 'webino_media_category', 'hide_empty' => false ) );
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$categories[] = array(
						'id'   => (int) $t->term_id,
						'name' => $t->name,
						'slug' => $t->slug,
					);
				}
			}
		}
		if ( taxonomy_exists( 'webino_media_folder' ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'webino_media_folder',
					'hide_empty' => false,
				)
			);
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$folders[] = array(
						'id'     => (int) $t->term_id,
						'name'   => $t->name,
						'slug'   => $t->slug,
						'parent' => (int) $t->parent,
					);
				}
			}
		}
		return new WP_REST_Response(
			array(
				'categories' => $categories,
				'folders'    => $folders,
			)
		);
	}

	/**
	 * Create a media category or folder term.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function media_terms_create( $request ) {
		$kind   = sanitize_key( (string) $request->get_param( 'kind' ) );
		$name   = sanitize_text_field( (string) $request->get_param( 'name' ) );
		$parent = (int) $request->get_param( 'parent' );
		if ( '' === $name ) {
			return new WP_Error( 'invalid', __( 'Name required.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		if ( 'folder' === $kind ) {
			if ( ! taxonomy_exists( 'webino_media_folder' ) ) {
				return new WP_Error( 'no_tax', 'Folder taxonomy missing', array( 'status' => 400 ) );
			}
			$args = array( 'slug' => sanitize_title( $name ) );
			if ( $parent > 0 ) {
				$args['parent'] = $parent;
			}
			$r = wp_insert_term( $name, 'webino_media_folder', $args );
		} elseif ( 'category' === $kind ) {
			if ( ! taxonomy_exists( 'webino_media_category' ) ) {
				return new WP_Error( 'no_tax', 'Category taxonomy missing', array( 'status' => 400 ) );
			}
			$r = wp_insert_term( $name, 'webino_media_category', array( 'slug' => sanitize_title( $name ) ) );
		} else {
			return new WP_Error( 'invalid', __( 'kind must be category or folder.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'id' => (int) $r['term_id'] ), 201 );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function product_categories_list() {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return new WP_REST_Response( array( 'items' => array() ) );
		}
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return new WP_REST_Response( array( 'items' => array() ) );
		}
		$items = array();
		foreach ( $terms as $t ) {
			$items[] = array(
				'id'    => (int) $t->term_id,
				'name'  => $t->name,
				'slug'  => $t->slug,
				'count' => (int) $t->count,
			);
		}
		return new WP_REST_Response( array( 'items' => $items ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_category_create( $request ) {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return new WP_Error( 'no_tax', __( 'Taxonomy missing.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$name = sanitize_text_field( (string) $request->get_param( 'name' ) );
		if ( '' === $name ) {
			return new WP_Error( 'invalid', __( 'Name required.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$slug   = sanitize_title( (string) ( $request->get_param( 'slug' ) ?: $name ) );
		$parent = (int) $request->get_param( 'parent' );
		$args   = array( 'slug' => $slug );
		if ( $parent > 0 ) {
			$args['parent'] = $parent;
		}
		$r = wp_insert_term( $name, 'product_cat', $args );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'id' => (int) $r['term_id'] ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_category_patch( $request ) {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return new WP_Error( 'no_tax', __( 'Taxonomy missing.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$id = (int) $request['id'];
		$args = array();
		if ( null !== $request->get_param( 'name' ) ) {
			$args['name'] = sanitize_text_field( (string) $request->get_param( 'name' ) );
		}
		if ( null !== $request->get_param( 'slug' ) ) {
			$args['slug'] = sanitize_title( (string) $request->get_param( 'slug' ) );
		}
		if ( null !== $request->get_param( 'parent' ) ) {
			$args['parent'] = (int) $request->get_param( 'parent' );
		}
		if ( array() === $args ) {
			return new WP_Error( 'invalid', __( 'No fields to update.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$r = wp_update_term( $id, 'product_cat', $args );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_category_delete( $request ) {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return new WP_Error( 'no_tax', __( 'Taxonomy missing.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$id = (int) $request['id'];
		$r   = wp_delete_term( $id, 'product_cat' );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( ! $r ) {
			return new WP_Error( 'not_found', __( 'Term not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function global_attribute_create( $request ) {
		if ( ! function_exists( 'wc_create_attribute' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$name = sanitize_text_field( (string) $request->get_param( 'name' ) );
		if ( '' === $name ) {
			return new WP_Error( 'invalid', __( 'Name required.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$slug = sanitize_title( (string) ( $request->get_param( 'slug' ) ?: $name ) );
		$attr_id = wc_create_attribute(
			array(
				'name'         => $name,
				'slug'         => $slug,
				'type'         => 'select',
				'order_by'     => 'menu_order',
				'has_archives' => false,
			)
		);
		if ( is_wp_error( $attr_id ) ) {
			return $attr_id;
		}
		return new WP_REST_Response( array( 'id' => (int) $attr_id ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function global_attribute_delete( $request ) {
		if ( ! function_exists( 'wc_delete_attribute' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$id = (int) $request['id'];
		$r   = wc_delete_attribute( $id );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function user_get( $request ) {
		$u = get_userdata( (int) $request['id'] );
		if ( ! $u ) {
			return new WP_Error( 'not_found', __( 'User not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		return new WP_REST_Response(
			array(
				'id'      => (int) $u->ID,
				'login'   => $u->user_login,
				'email'   => $u->user_email,
				'name'    => $u->display_name,
				'roles'   => array_values( $u->roles ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function user_patch( $request ) {
		$id = (int) $request['id'];
		if ( ! get_userdata( $id ) ) {
			return new WP_Error( 'not_found', __( 'User not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		$args = array( 'ID' => $id );
		if ( null !== $request->get_param( 'display_name' ) ) {
			$args['display_name'] = sanitize_text_field( (string) $request->get_param( 'display_name' ) );
		}
		if ( null !== $request->get_param( 'user_email' ) ) {
			$args['user_email'] = sanitize_email( (string) $request->get_param( 'user_email' ) );
		}
		$r = wp_update_user( $args );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return self::user_get( $request );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function user_delete( $request ) {
		$id = (int) $request['id'];
		if ( get_current_user_id() === $id ) {
			return new WP_Error( 'self', __( 'Cannot delete yourself.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		require_once ABSPATH . 'wp-admin/includes/user.php';
		if ( ! get_userdata( $id ) ) {
			return new WP_Error( 'not_found', __( 'User not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		wp_delete_user( $id );
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * Featured image, gallery, categories, brands, custom attributes, dimensions (WC).
	 *
	 * @param WC_Product      $p Product instance.
	 * @param WP_REST_Request $request Request.
	 * @return void
	 */
	private static function apply_product_catalog_fields( $p, $request ) {
		if ( null !== $request->get_param( 'image_id' ) ) {
			$img = (int) $request->get_param( 'image_id' );
			$p->set_image_id( $img > 0 ? $img : 0 );
		}
		if ( null !== $request->get_param( 'gallery_ids' ) && is_array( $request->get_param( 'gallery_ids' ) ) ) {
			$g = array_values( array_filter( array_map( 'intval', $request->get_param( 'gallery_ids' ) ) ) );
			$p->set_gallery_image_ids( $g );
		}
		if ( null !== $request->get_param( 'category_ids' ) && is_array( $request->get_param( 'category_ids' ) ) ) {
			$p->set_category_ids( array_values( array_filter( array_map( 'intval', $request->get_param( 'category_ids' ) ) ) ) );
		}
		if ( taxonomy_exists( 'product_brand' ) && null !== $request->get_param( 'brand_ids' ) && is_array( $request->get_param( 'brand_ids' ) ) ) {
			$b = array_values( array_filter( array_map( 'intval', $request->get_param( 'brand_ids' ) ) ) );
			wp_set_object_terms( $p->get_id(), $b, 'product_brand', false );
		}
		$raw_attrs = $request->get_param( 'product_attributes' );
		if ( is_array( $raw_attrs ) && class_exists( 'WC_Product_Attribute' ) ) {
			$attr_objects = array();
			foreach ( $raw_attrs as $i => $row ) {
				if ( ! is_array( $row ) || empty( $row['name'] ) || empty( $row['options'] ) || ! is_array( $row['options'] ) ) {
					continue;
				}
				$attr = new WC_Product_Attribute();
				$attr->set_id( isset( $row['attribute_id'] ) ? (int) $row['attribute_id'] : 0 );
				$name = sanitize_text_field( (string) $row['name'] );
				$attr->set_name( $name );
				$attr->set_options( array_map( 'sanitize_text_field', array_map( 'strval', $row['options'] ) ) );
				$attr->set_position( (int) $i );
				$attr->set_visible( isset( $row['visible'] ) ? (bool) $row['visible'] : true );
				$is_var_product = $p->is_type( 'variable' );
				$attr->set_variation( $is_var_product && ! empty( $row['variation'] ) );
				$key = sanitize_title( $name );
				$aid = isset( $row['attribute_id'] ) ? (int) $row['attribute_id'] : 0;
				if ( $aid > 0 && function_exists( 'wc_attribute_taxonomy_id_to_name' ) ) {
					$tax_name = wc_attribute_taxonomy_id_to_name( $aid );
					if ( is_string( $tax_name ) && '' !== $tax_name ) {
						$attr->set_id( $aid );
						$attr->set_name( $tax_name );
						$key = $tax_name;
					}
				}
				$attr_objects[ $key ] = $attr;
			}
			if ( array() !== $attr_objects ) {
				$p->set_attributes( $attr_objects );
			}
		}
		foreach ( array( 'weight', 'length', 'width', 'height' ) as $dim ) {
			if ( null === $request->get_param( $dim ) ) {
				continue;
			}
			$val = sanitize_text_field( (string) $request->get_param( $dim ) );
			if ( 'weight' === $dim ) {
				$p->set_weight( $val );
			} elseif ( 'length' === $dim ) {
				$p->set_length( $val );
			} elseif ( 'width' === $dim ) {
				$p->set_width( $val );
			} elseif ( 'height' === $dim ) {
				$p->set_height( $val );
			}
		}
	}

	/**
	 * Virtual, tax, linked products, tags, etc.
	 *
	 * @param WC_Product      $p Product.
	 * @param WP_REST_Request $request Request.
	 * @return void
	 */
	private static function apply_product_extended_fields( $p, $request ) {
		if ( null !== $request->get_param( 'virtual' ) ) {
			$p->set_virtual( (bool) $request->get_param( 'virtual' ) );
		}
		if ( null !== $request->get_param( 'downloadable' ) ) {
			$p->set_downloadable( (bool) $request->get_param( 'downloadable' ) );
		}
		if ( null !== $request->get_param( 'featured' ) ) {
			$p->set_featured( (bool) $request->get_param( 'featured' ) );
		}
		if ( null !== $request->get_param( 'sold_individually' ) ) {
			$p->set_sold_individually( (bool) $request->get_param( 'sold_individually' ) );
		}
		if ( null !== $request->get_param( 'catalog_visibility' ) ) {
			$vis = sanitize_text_field( (string) $request->get_param( 'catalog_visibility' ) );
			if ( in_array( $vis, array( 'visible', 'catalog', 'search', 'hidden' ), true ) ) {
				$p->set_catalog_visibility( $vis );
			}
		}
		if ( null !== $request->get_param( 'tax_status' ) ) {
			$ts = sanitize_text_field( (string) $request->get_param( 'tax_status' ) );
			if ( in_array( $ts, array( 'taxable', 'shipping', 'none' ), true ) ) {
				$p->set_tax_status( $ts );
			}
		}
		if ( null !== $request->get_param( 'tax_class' ) ) {
			$p->set_tax_class( sanitize_text_field( (string) $request->get_param( 'tax_class' ) ) );
		}
		if ( null !== $request->get_param( 'shipping_class_id' ) ) {
			$p->set_shipping_class_id( (int) $request->get_param( 'shipping_class_id' ) );
		}
		if ( null !== $request->get_param( 'backorders' ) ) {
			$bo = sanitize_key( (string) $request->get_param( 'backorders' ) );
			if ( in_array( $bo, array( 'no', 'notify', 'yes' ), true ) ) {
				$p->set_backorders( $bo );
			}
		}
		if ( null !== $request->get_param( 'low_stock_amount' ) ) {
			$ls = $request->get_param( 'low_stock_amount' );
			$p->set_low_stock_amount( null === $ls || '' === $ls ? null : (int) $ls );
		}
		if ( null !== $request->get_param( 'purchase_note' ) ) {
			$p->set_purchase_note( sanitize_textarea_field( (string) $request->get_param( 'purchase_note' ) ) );
		}
		if ( null !== $request->get_param( 'menu_order' ) ) {
			$p->set_menu_order( (int) $request->get_param( 'menu_order' ) );
		}
		if ( null !== $request->get_param( 'upsell_ids' ) && is_array( $request->get_param( 'upsell_ids' ) ) ) {
			$p->set_upsell_ids( array_values( array_filter( array_map( 'intval', $request->get_param( 'upsell_ids' ) ) ) ) );
		}
		if ( null !== $request->get_param( 'cross_sell_ids' ) && is_array( $request->get_param( 'cross_sell_ids' ) ) ) {
			$p->set_cross_sell_ids( array_values( array_filter( array_map( 'intval', $request->get_param( 'cross_sell_ids' ) ) ) ) );
		}
		if ( null !== $request->get_param( 'tag_ids' ) && is_array( $request->get_param( 'tag_ids' ) ) && taxonomy_exists( 'product_tag' ) ) {
			$tag_ids = array_values( array_filter( array_map( 'intval', $request->get_param( 'tag_ids' ) ) ) );
			wp_set_object_terms( $p->get_id(), $tag_ids, 'product_tag', false );
		}
		if ( null !== $request->get_param( 'date_on_sale_from' ) ) {
			$raw = $request->get_param( 'date_on_sale_from' );
			if ( null === $raw || '' === $raw ) {
				$p->set_date_on_sale_from( null );
			} elseif ( class_exists( 'WC_DateTime' ) ) {
				$ts = strtotime( (string) $raw );
				if ( $ts ) {
					$p->set_date_on_sale_from( new WC_DateTime( '@' . $ts ) );
				}
			}
		}
		if ( null !== $request->get_param( 'date_on_sale_to' ) ) {
			$raw = $request->get_param( 'date_on_sale_to' );
			if ( null === $raw || '' === $raw ) {
				$p->set_date_on_sale_to( null );
			} elseif ( class_exists( 'WC_DateTime' ) ) {
				$ts = strtotime( (string) $raw );
				if ( $ts ) {
					$p->set_date_on_sale_to( new WC_DateTime( '@' . $ts ) );
				}
			}
		}
		if ( $p->is_type( 'grouped' ) && null !== $request->get_param( 'grouped_children_ids' ) && is_array( $request->get_param( 'grouped_children_ids' ) ) ) {
			$ids = array_values( array_filter( array_map( 'intval', $request->get_param( 'grouped_children_ids' ) ) ) );
			$p->set_children_ids( $ids );
		}
		if ( $p->is_type( 'external' ) ) {
			if ( null !== $request->get_param( 'product_url' ) ) {
				$p->set_product_url( esc_url_raw( (string) $request->get_param( 'product_url' ) ) );
			}
			if ( null !== $request->get_param( 'button_text' ) ) {
				$p->set_button_text( sanitize_text_field( (string) $request->get_param( 'button_text' ) ) );
			}
		}
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_get( $request ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return new WP_Error( 'no_wc', 'WC inactive', array( 'status' => 400 ) );
		}
		$p = wc_get_product( (int) $request['id'] );
		if ( ! $p ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( Webino_Dashboard_REST::map_product_row( $p ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_patch( $request ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return new WP_Error( 'no_wc', 'WC inactive', array( 'status' => 400 ) );
		}
		$id = (int) $request['id'];
		$p   = wc_get_product( $id );
		if ( ! $p ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		if ( null !== $request->get_param( 'name' ) ) {
			$p->set_name( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		}
		$is_variable = $p->is_type( 'variable' );
		if ( ! $is_variable ) {
			if ( null !== $request->get_param( 'regular_price' ) ) {
				$pr = wc_format_decimal( $request->get_param( 'regular_price' ) );
				$p->set_regular_price( $pr );
				$p->set_price( $pr );
			}
			if ( null !== $request->get_param( 'stock_quantity' ) ) {
				$p->set_stock_quantity( (int) $request->get_param( 'stock_quantity' ) );
			}
			if ( null !== $request->get_param( 'sale_price' ) ) {
				$sale = (string) $request->get_param( 'sale_price' );
				$p->set_sale_price( '' !== $sale ? wc_format_decimal( $sale ) : '' );
				if ( '' !== $sale ) {
					$p->set_price( wc_format_decimal( $sale ) );
				} else {
					$p->set_price( $p->get_regular_price() ? wc_format_decimal( $p->get_regular_price() ) : '' );
				}
			}
		}
		if ( null !== $request->get_param( 'description' ) ) {
			$p->set_description( wp_kses_post( (string) $request->get_param( 'description' ) ) );
		}
		if ( null !== $request->get_param( 'short_description' ) ) {
			$p->set_short_description( wp_kses_post( (string) $request->get_param( 'short_description' ) ) );
		}
		if ( null !== $request->get_param( 'sku' ) ) {
			$p->set_sku( sanitize_text_field( (string) $request->get_param( 'sku' ) ) );
		}
		if ( null !== $request->get_param( 'status' ) ) {
			$st = sanitize_key( (string) $request->get_param( 'status' ) );
			if ( in_array( $st, array( 'draft', 'pending', 'publish', 'private' ), true ) ) {
				$p->set_status( $st );
			}
		}
		if ( ! $is_variable && null !== $request->get_param( 'manage_stock' ) ) {
			$p->set_manage_stock( (bool) $request->get_param( 'manage_stock' ) );
		}
		self::apply_product_catalog_fields( $p, $request );
		self::apply_product_extended_fields( $p, $request );
		$p->save();

		$wfcp = $request->get_param( 'wfcp' );
		if ( is_array( $wfcp ) && array() !== $wfcp ) {
			$sub = new WP_REST_Request( 'PATCH' );
			$sub->set_route( '/' . Webino_Dashboard_REST::NS . '/shop/products/' . $id . '/wfcp' );
			$sub->set_url_params( array( 'id' => $id ) );
			$sub->set_param( 'wfcp', $wfcp );
			$result = Webino_Dashboard_REST::shop_product_wfcp_patch( $sub );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return self::product_get( $request );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_create( $request ) {
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Product_Simple' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$ptype = sanitize_key( (string) $request->get_param( 'type' ) );
		if ( 'variable' === $ptype && class_exists( 'WC_Product_Variable' ) ) {
			$p = new WC_Product_Variable();
		} elseif ( 'grouped' === $ptype && class_exists( 'WC_Product_Grouped' ) ) {
			$p = new WC_Product_Grouped();
		} elseif ( 'external' === $ptype && class_exists( 'WC_Product_External' ) ) {
			$p = new WC_Product_External();
		} else {
			$p = new WC_Product_Simple();
		}
		$p->set_name( sanitize_text_field( (string) $request->get_param( 'name' ) ) ?: 'Product' );
		$p->set_status( 'draft' );
		$p->save();
		$pid = $p->get_id();
		$p2  = wc_get_product( $pid );
		if ( $p2 ) {
			self::apply_product_catalog_fields( $p2, $request );
			$p2->save();
		}
		return new WP_REST_Response( array( 'id' => $pid ), 201 );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function brands_list() {
		if ( ! taxonomy_exists( 'product_brand' ) ) {
			return new WP_REST_Response( array( 'items' => array() ) );
		}
		$terms = get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) {
			return new WP_REST_Response( array( 'items' => array() ) );
		}
		$items = array();
		foreach ( $terms as $t ) {
			$items[] = array( 'id' => (int) $t->term_id, 'name' => $t->name, 'slug' => $t->slug );
		}
		return new WP_REST_Response( array( 'items' => $items ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function brands_create( $request ) {
		if ( ! taxonomy_exists( 'product_brand' ) ) {
			return new WP_Error( 'no_tax', 'Brand taxonomy missing', array( 'status' => 400 ) );
		}
		$r = wp_insert_term( sanitize_text_field( (string) $request->get_param( 'name' ) ), 'product_brand', array( 'slug' => sanitize_title( (string) $request->get_param( 'slug' ) ) ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'id' => (int) $r['term_id'] ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function brands_patch( $request ) {
		$r = wp_update_term(
			(int) $request['id'],
			'product_brand',
			array(
				'name' => sanitize_text_field( (string) $request->get_param( 'name' ) ),
				'slug' => sanitize_title( (string) $request->get_param( 'slug' ) ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function brands_delete( $request ) {
		$r = wp_delete_term( (int) $request['id'], 'product_brand' );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( ! $r ) {
			return new WP_Error( 'fail', __( 'Could not delete term.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WC_Product_Variation $v Variation.
	 * @return array<string,mixed>
	 */
	private static function map_variation_row( $v ) {
		if ( ! is_a( $v, 'WC_Product_Variation' ) ) {
			return array();
		}
		return array(
			'id'             => $v->get_id(),
			'sku'            => $v->get_sku(),
			'regular_price'  => $v->get_regular_price(),
			'sale_price'     => $v->get_sale_price(),
			'price'          => $v->get_price(),
			'manage_stock'   => $v->get_manage_stock(),
			'stock_quantity' => $v->get_stock_quantity(),
			'stock_status'   => $v->get_stock_status(),
			'image_id'       => (int) $v->get_image_id(),
			'attributes'     => $v->get_attributes(),
			'status'         => $v->get_status(),
		);
	}

	/**
	 * @param WC_Product_Variation $v Variation.
	 * @param WP_REST_Request      $request Request.
	 * @return void
	 */
	private static function apply_variation_request( $v, $request ) {
		if ( null !== $request->get_param( 'sku' ) ) {
			$v->set_sku( sanitize_text_field( (string) $request->get_param( 'sku' ) ) );
		}
		if ( null !== $request->get_param( 'regular_price' ) ) {
			$rp = wc_format_decimal( $request->get_param( 'regular_price' ) );
			$v->set_regular_price( $rp );
		}
		if ( null !== $request->get_param( 'sale_price' ) ) {
			$sp = (string) $request->get_param( 'sale_price' );
			$v->set_sale_price( '' !== $sp ? wc_format_decimal( $sp ) : '' );
		}
		if ( null !== $request->get_param( 'manage_stock' ) ) {
			$v->set_manage_stock( (bool) $request->get_param( 'manage_stock' ) );
		}
		if ( null !== $request->get_param( 'stock_quantity' ) ) {
			$sq = $request->get_param( 'stock_quantity' );
			$v->set_stock_quantity( null === $sq || '' === $sq ? null : (int) $sq );
		}
		if ( null !== $request->get_param( 'stock_status' ) ) {
			$st = sanitize_key( (string) $request->get_param( 'stock_status' ) );
			if ( in_array( $st, array( 'instock', 'outofstock', 'onbackorder' ), true ) ) {
				$v->set_stock_status( $st );
			}
		}
		if ( null !== $request->get_param( 'image_id' ) ) {
			$img = (int) $request->get_param( 'image_id' );
			$v->set_image_id( $img > 0 ? $img : 0 );
		}
		$attrs = $request->get_param( 'attributes' );
		if ( is_array( $attrs ) ) {
			$clean = array();
			foreach ( $attrs as $k => $val ) {
				$key = sanitize_text_field( (string) $k );
				if ( '' === $key ) {
					continue;
				}
				$clean[ $key ] = sanitize_text_field( (string) $val );
			}
			$v->set_attributes( $clean );
		}
		$reg = $v->get_regular_price();
		$sal = $v->get_sale_price();
		if ( $sal && '' !== $sal ) {
			$v->set_price( wc_format_decimal( $sal ) );
		} elseif ( $reg && '' !== $reg ) {
			$v->set_price( wc_format_decimal( $reg ) );
		}
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_variations_list( $request ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$parent_id = (int) $request['id'];
		$parent    = wc_get_product( $parent_id );
		if ( ! $parent || ! $parent->is_type( 'variable' ) ) {
			return new WP_Error( 'invalid_parent', __( 'Not a variable product.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 50 ) );
		$children = $parent->get_children();
		$total    = count( $children );
		$offset   = ( $page - 1 ) * $per_page;
		$slice    = array_slice( $children, $offset, $per_page );
		$items    = array();
		foreach ( $slice as $vid ) {
			$v = wc_get_product( (int) $vid );
			if ( $v && $v->is_type( 'variation' ) ) {
				$items[] = self::map_variation_row( $v );
			}
		}
		return new WP_REST_Response(
			array(
				'items' => $items,
				'page'  => $page,
				'total' => $total,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_variation_create( $request ) {
		if ( ! class_exists( 'WC_Product_Variation' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$parent_id = (int) $request['id'];
		$parent    = wc_get_product( $parent_id );
		if ( ! $parent || ! $parent->is_type( 'variable' ) ) {
			return new WP_Error( 'invalid_parent', __( 'Not a variable product.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$v = new WC_Product_Variation();
		$v->set_parent_id( $parent_id );
		$v->set_status( 'publish' );
		self::apply_variation_request( $v, $request );
		$v->save();
		$v2 = wc_get_product( $v->get_id() );
		return new WP_REST_Response( $v2 && $v2->is_type( 'variation' ) ? self::map_variation_row( $v2 ) : self::map_variation_row( $v ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_variation_patch( $request ) {
		$parent_id = (int) $request['id'];
		$vid       = (int) $request['vid'];
		$v         = wc_get_product( $vid );
		if ( ! $v || ! $v->is_type( 'variation' ) || (int) $v->get_parent_id() !== $parent_id ) {
			return new WP_Error( 'not_found', __( 'Variation not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		self::apply_variation_request( $v, $request );
		$v->save();
		$v2 = wc_get_product( $vid );
		return new WP_REST_Response( $v2 && $v2->is_type( 'variation' ) ? self::map_variation_row( $v2 ) : self::map_variation_row( $v ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function product_variation_delete( $request ) {
		$parent_id = (int) $request['id'];
		$vid       = (int) $request['vid'];
		$v         = wc_get_product( $vid );
		if ( ! $v || ! $v->is_type( 'variation' ) || (int) $v->get_parent_id() !== $parent_id ) {
			return new WP_Error( 'not_found', __( 'Variation not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}
		$r = wp_delete_post( $vid, true );
		if ( ! $r ) {
			return new WP_Error( 'fail', __( 'Could not delete variation.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function order_get( $request ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$o = wc_get_order( (int) $request['id'] );
		if ( ! $o ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( self::map_order_rest( $o ) );
	}

	/**
	 * Full order payload for dashboard detail view.
	 *
	 * @param WC_Order $o Order.
	 * @return array<string,mixed>
	 */
	private static function map_order_rest( $o ) {
		$items_out = array();
		foreach ( array_values( $o->get_items() ) as $item ) {
			$product = $item->get_product();
			$sku     = $product && is_callable( array( $product, 'get_sku' ) ) ? (string) $product->get_sku() : '';
			$items_out[] = array(
				'name'          => $item->get_name(),
				'quantity'      => $item->get_quantity(),
				'subtotal'      => $item->get_subtotal(),
				'total'         => $item->get_total(),
				'sku'           => $sku,
				'product_id'    => (int) $item->get_product_id(),
				'variation_id'  => (int) $item->get_variation_id(),
			);
		}
		$dc = $o->get_date_created();
		$dm = $o->get_date_modified();
		return array(
			'id'                   => $o->get_id(),
			'number'               => $o->get_order_number(),
			'status'               => $o->get_status(),
			'total'                => $o->get_total(),
			'subtotal'             => $o->get_subtotal(),
			'total_discount'       => $o->get_discount_total(),
			'shipping_total'       => $o->get_shipping_total(),
			'currency'             => $o->get_currency(),
			'payment_method'       => $o->get_payment_method(),
			'payment_method_title' => $o->get_payment_method_title(),
			'customer_note'        => $o->get_customer_note(),
			'billing'              => array(
				'first_name' => $o->get_billing_first_name(),
				'last_name'  => $o->get_billing_last_name(),
				'company'    => $o->get_billing_company(),
				'email'      => $o->get_billing_email(),
				'phone'      => $o->get_billing_phone(),
				'address_1'  => $o->get_billing_address_1(),
				'address_2'  => $o->get_billing_address_2(),
				'city'       => $o->get_billing_city(),
				'state'      => $o->get_billing_state(),
				'postcode'   => $o->get_billing_postcode(),
				'country'    => $o->get_billing_country(),
			),
			'shipping'             => array(
				'first_name' => $o->get_shipping_first_name(),
				'last_name'  => $o->get_shipping_last_name(),
				'company'    => $o->get_shipping_company(),
				'address_1'  => $o->get_shipping_address_1(),
				'address_2'  => $o->get_shipping_address_2(),
				'city'       => $o->get_shipping_city(),
				'state'      => $o->get_shipping_state(),
				'postcode'   => $o->get_shipping_postcode(),
				'country'    => $o->get_shipping_country(),
			),
			'date_created'         => $dc ? $dc->format( 'c' ) : null,
			'date_modified'        => $dm ? $dm->format( 'c' ) : null,
			'items'                => $items_out,
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function order_patch( $request ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$o = wc_get_order( (int) $request['id'] );
		if ( ! $o ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		$st = sanitize_text_field( (string) $request->get_param( 'status' ) );
		if ( $st ) {
			$o->update_status( $st );
		}
		return self::order_get( $request );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function reports_sales( $request ) {
		$from_ts = strtotime( (string) $request->get_param( 'from' ) ) ?: strtotime( '-30 days' );
		$to_ts   = strtotime( (string) $request->get_param( 'to' ) ) ?: time();
		$sum     = 0.0;
		$n       = 0;
		if ( function_exists( 'wc_get_orders' ) ) {
			$from_date = gmdate( 'Y-m-d', $from_ts );
			$to_date   = gmdate( 'Y-m-d', $to_ts );
			foreach (
				wc_get_orders(
					array(
						'limit'          => -1,
						'status'         => array( 'completed', 'processing' ),
						'date_created'   => $from_date . '...' . $to_date,
						'return'         => 'objects',
					)
				) as $o
			) {
				$sum += (float) $o->get_total();
				++$n;
			}
		}
		return new WP_REST_Response(
			array(
				'revenue'      => $sum,
				'order_count'  => $n,
				'from'         => $from_ts,
				'to'           => $to_ts,
				'from_date'    => gmdate( 'c', $from_ts ),
				'to_date'      => gmdate( 'c', $to_ts ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function coupon_get( $request ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$c = new WC_Coupon( (int) $request['id'] );
		if ( ! $c->get_id() ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( Webino_Dashboard_REST::map_coupon_rest( $c ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function coupon_create( $request ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$c = new WC_Coupon();
		$c->set_code( sanitize_text_field( (string) $request->get_param( 'code' ) ) );
		$c->set_discount_type( sanitize_key( (string) $request->get_param( 'type' ) ) ?: 'fixed_cart' );
		$c->set_amount( (string) $request->get_param( 'amount' ) );
		self::apply_coupon_rest_fields( $c, $request );
		$c->save();
		return new WP_REST_Response( Webino_Dashboard_REST::map_coupon_rest( $c ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function coupon_patch( $request ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$c = new WC_Coupon( (int) $request['id'] );
		if ( ! $c->get_id() ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		if ( $request->get_param( 'amount' ) !== null ) {
			$c->set_amount( (string) $request->get_param( 'amount' ) );
		}
		if ( $request->get_param( 'code' ) ) {
			$c->set_code( sanitize_text_field( (string) $request->get_param( 'code' ) ) );
		}
		if ( null !== $request->get_param( 'type' ) ) {
			$c->set_discount_type( sanitize_key( (string) $request->get_param( 'type' ) ) ?: 'fixed_cart' );
		}
		self::apply_coupon_rest_fields( $c, $request );
		$c->save();
		return self::coupon_get( $request );
	}

	/**
	 * Optional WooCommerce coupon fields from REST request.
	 *
	 * @param WC_Coupon       $c Coupon.
	 * @param WP_REST_Request $request Request.
	 * @return void
	 */
	private static function apply_coupon_rest_fields( $c, $request ) {
		if ( null !== $request->get_param( 'description' ) ) {
			$c->set_description( sanitize_textarea_field( (string) $request->get_param( 'description' ) ) );
		}
		if ( null !== $request->get_param( 'minimum_amount' ) ) {
			$c->set_minimum_amount( wc_format_decimal( (string) $request->get_param( 'minimum_amount' ) ) );
		}
		if ( null !== $request->get_param( 'maximum_amount' ) ) {
			$c->set_maximum_amount( wc_format_decimal( (string) $request->get_param( 'maximum_amount' ) ) );
		}
		if ( null !== $request->get_param( 'usage_limit' ) ) {
			$ul = $request->get_param( 'usage_limit' );
			$c->set_usage_limit( null === $ul || '' === $ul ? null : (int) $ul );
		}
		if ( null !== $request->get_param( 'individual_use' ) ) {
			$c->set_individual_use( (bool) $request->get_param( 'individual_use' ) );
		}
		if ( null !== $request->get_param( 'free_shipping' ) ) {
			$c->set_free_shipping( (bool) $request->get_param( 'free_shipping' ) );
		}
		if ( null !== $request->get_param( 'exclude_sale_items' ) ) {
			$c->set_exclude_sale_items( (bool) $request->get_param( 'exclude_sale_items' ) );
		}
		if ( null !== $request->get_param( 'date_expires' ) ) {
			$raw = $request->get_param( 'date_expires' );
			if ( null === $raw || '' === $raw ) {
				$c->set_date_expires( null );
			} elseif ( is_numeric( $raw ) ) {
				$c->set_date_expires( new WC_DateTime( '@' . (int) $raw ) );
			} else {
				$ts = strtotime( (string) $raw );
				if ( $ts ) {
					$c->set_date_expires( new WC_DateTime( '@' . $ts ) );
				}
			}
		}
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function coupon_delete( $request ) {
		if ( ! class_exists( 'WC_Coupon' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$c = new WC_Coupon( (int) $request['id'] );
		if ( ! $c->get_id() ) {
			return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		wp_delete_post( $c->get_id(), true );
		return new WP_REST_Response( array( 'deleted' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function comment_patch( $request ) {
		$id = (int) $request['id'];
		$st  = sanitize_key( (string) $request->get_param( 'status' ) );
		if ( 'approved' === $st ) {
			wp_set_comment_status( $id, 'approve' );
		} elseif ( 'spam' === $st ) {
			wp_spam_comment( $id );
		} elseif ( 'hold' === $st ) {
			wp_set_comment_status( $id, 'hold' );
		}
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function comment_delete( $request ) {
		wp_delete_comment( (int) $request['id'], true );
		return new WP_REST_Response( array( 'deleted' => true ) );
	}
}
