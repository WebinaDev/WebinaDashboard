<?php
/**
 * Outbound license checks to webina.dev (CRM) — separate from inbound CRM→site REST.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persists CRM license state, schedules periodic checks, exposes bootstrap payload.
 */
final class Webino_Dashboard_License {

	const CRON_HOOK = 'webino_dashboard_license_cron';

	const TABLE_ROW_ID = 1;

	/**
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * @var bool
	 */
	private static $checked_this_request = false;

	/**
	 * @var array<string,mixed>|null
	 */
	private $row_cache = null;

	/**
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'ensure_license_table' ), 3 );
		add_action( 'init', array( $this, 'maybe_schedule_cron' ), 5 );
		add_action( self::CRON_HOOK, array( $this, 'cron_check' ) );
		add_action( 'wp_ajax_nopriv_webino_dashboard_license_webhook', array( $this, 'ajax_webhook_stub' ) );
		add_action( 'wp_ajax_webino_dashboard_license_webhook', array( $this, 'ajax_webhook_stub' ) );
		add_action( 'wp_ajax_nopriv_maneli_license_webhook', array( $this, 'ajax_crm_webhook' ) );
		add_action( 'wp_ajax_maneli_license_webhook', array( $this, 'ajax_crm_webhook' ) );
	}

	/**
	 * @return void
	 */
	public function ensure_license_table() {
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $wpdb->get_var( "SHOW TABLES LIKE '" . esc_sql( $table ) . "'" ) === $table ) {
			return;
		}
		Webino_Dashboard_Install::ensure_dashboard_license_table();
	}

	/**
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'webino_dashboard_license';
	}

	/**
	 * @return void
	 */
	public function maybe_schedule_cron() {
		if ( wp_next_scheduled( self::CRON_HOOK ) ) {
			return;
		}
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'webino_dashboard_license_12h', self::CRON_HOOK );
	}

	/**
	 * @return void
	 */
	public function cron_check() {
		$this->remote_license_check( true, 'cron' );
	}

	/**
	 * Optional CRM webhook (extend via filter).
	 *
	 * @return void
	 */
	public function ajax_webhook_stub() {
		$allow = apply_filters( 'webino_dashboard_license_webhook_enabled', false );
		if ( ! $allow ) {
			wp_die( '', '', 403 );
		}
		do_action( 'webino_dashboard_license_webhook' );
		wp_die( 'ok', '', 200 );
	}

	/**
	 * Inbound webhook from WebinoCRM (legacy action name).
	 *
	 * @return void
	 */
	public function ajax_crm_webhook() {
		$domain = isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['domain'] ) ) : '';
		$type   = isset( $_POST['action_type'] ) ? sanitize_key( wp_unslash( (string) $_POST['action_type'] ) ) : '';
		$cur    = $this->get_current_domain();
		if ( $domain && $this->normalize_site_domain( $domain ) !== $cur ) {
			wp_die( '', '', 403 );
		}
		$now = current_time( 'mysql' );
		if ( in_array( $type, array( 'deactivate', 'cancel', 'cancelled', 'expired', 'inactive' ), true ) ) {
			$this->save_row(
				array(
					'domain'     => $cur,
					'status'     => 'inactive' === $type ? 'inactive' : $type,
					'message'    => __( 'License updated by CRM webhook.', 'webino-dashboard' ),
					'last_check' => $now,
				)
			);
		} elseif ( 'activate' === $type ) {
			$this->save_row(
				array(
					'domain'       => $cur,
					'status'       => 'active',
					'message'      => __( 'License activated by CRM webhook.', 'webino-dashboard' ),
					'activated_at' => $now,
					'last_check'   => $now,
				)
			);
		}
		do_action( 'webino_dashboard_license_webhook', $type, $domain );
		wp_die( 'ok', '', 200 );
	}

	/**
	 * Hostname for CRM (no scheme/path, www stripped).
	 *
	 * @return string
	 */
	/**
	 * Normalize host for license row vs site (strip scheme/path, lowercase, drop leading www).
	 *
	 * @param string $host Host or URL fragment from CRM/DB.
	 * @return string
	 */
	public function normalize_site_domain( $host ) {
		$host = trim( (string) $host );
		if ( '' === $host ) {
			return '';
		}
		if ( false !== strpos( $host, '://' ) || 0 === strpos( $host, '//' ) ) {
			$parsed = wp_parse_url( 0 === strpos( $host, '//' ) ? 'https:' . $host : $host, PHP_URL_HOST );
			$host   = is_string( $parsed ) ? $parsed : $host;
		}
		$host = strtolower( $host );
		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}
		$slash = strpos( $host, '/' );
		if ( false !== $slash ) {
			$host = substr( $host, 0, $slash );
		}
		return $host;
	}

	/**
	 * @return string
	 */
	public function get_current_domain() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $this->normalize_site_domain( is_string( $host ) ? $host : '' );
	}

	/**
	 * @return list<string>
	 */
	public function get_server_urls() {
		$urls = array( 'https://webina.dev' );
		if ( (bool) apply_filters( 'webino_dashboard_license_allow_http_fallback', false ) ) {
			$urls[] = 'http://webina.dev';
		}
		/**
		 * License CRM base URLs (no trailing path). HTTPS first, then HTTP when allowed.
		 *
		 * @param list<string> $urls Base URLs.
		 */
		$urls = apply_filters( 'webino_dashboard_license_server_urls', $urls );
		$https = array();
		$http  = array();
		foreach ( (array) $urls as $u ) {
			$u = esc_url_raw( (string) $u );
			if ( ! $u ) {
				continue;
			}
			$u = untrailingslashit( $u );
			if ( 0 === strpos( $u, 'https://' ) ) {
				$https[] = $u;
			} elseif ( 0 === strpos( $u, 'http://' ) ) {
				$http[] = $u;
			}
		}
		return array_values( array_unique( array_merge( $https, $http ) ) );
	}

	/**
	 * CRM public hostname (for Host header on local-NIC bypass).
	 *
	 * @return string
	 */
	private function crm_public_host() {
		foreach ( $this->get_server_urls() as $u ) {
			$h = wp_parse_url( $u, PHP_URL_HOST );
			if ( is_string( $h ) && '' !== $h ) {
				return $h;
			}
		}
		return 'webina.dev';
	}

	/**
	 * Local NIC base when CRM and site share one server (avoids hairpin NAT).
	 *
	 * @return string Empty when bypass disabled or SERVER_ADDR unavailable.
	 */
	private function local_bypass_base() {
		if ( (bool) apply_filters( 'webino_dashboard_license_disable_local_bypass', false ) ) {
			return '';
		}
		$addr = isset( $_SERVER['SERVER_ADDR'] ) ? (string) $_SERVER['SERVER_ADDR'] : '';
		if ( '' === $addr || ! filter_var( $addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return '';
		}
		return 'https://' . $addr;
	}

	/**
	 * @param string $base Request base URL.
	 * @return bool
	 */
	private function is_local_bypass_base( $base ) {
		$host = wp_parse_url( (string) $base, PHP_URL_HOST );
		return is_string( $host ) && filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
	}

	/**
	 * True when this WordPress install resolves to the same IP as the CRM host.
	 *
	 * @return bool
	 */
	private function is_same_server_as_crm() {
		if ( (bool) apply_filters( 'webino_dashboard_license_disable_local_bypass', false ) ) {
			return false;
		}
		$crm_host  = $this->crm_public_host();
		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! $crm_host || ! is_string( $site_host ) || '' === $site_host ) {
			return false;
		}
		$crm_ip  = gethostbyname( $crm_host );
		$site_ip = gethostbyname( $site_host );
		if ( ! $crm_ip || ! $site_ip || $crm_ip === $crm_host || $site_ip === $site_host ) {
			return false;
		}
		return $crm_ip === $site_ip;
	}

	/**
	 * CRM bases to try: local NIC first on same server, then public HTTPS/HTTP.
	 *
	 * @return list<string>
	 */
	private function get_request_bases() {
		$public = $this->get_server_urls();
		if ( ! $this->is_same_server_as_crm() ) {
			return $public;
		}
		$local = $this->local_bypass_base();
		if ( '' === $local ) {
			return $public;
		}
		return array_values( array_unique( array_merge( array( $local ), $public ) ) );
	}

	/**
	 * @return bool
	 */
	public function verify_ssl() {
		/**
		 * Whether to verify SSL for outbound license HTTP requests.
		 *
		 * @param bool $verify Default true.
		 */
		return (bool) apply_filters( 'webino_dashboard_license_verify_ssl', true );
	}

	/**
	 * @return int
	 */
	private function http_timeout() {
		return max( 3, (int) apply_filters( 'webino_dashboard_license_http_timeout', 6 ) );
	}

	/**
	 * @return int
	 */
	private function http_connect_timeout() {
		return max( 2, (int) apply_filters( 'webino_dashboard_license_http_connect_timeout', 2 ) );
	}

	/**
	 * Max seconds for one license HTTP round-trip (all bases/retries).
	 *
	 * @return int
	 */
	private function wall_clock_cap() {
		return max( 5, (int) apply_filters( 'webino_dashboard_license_wall_clock_cap', 8 ) );
	}

	/**
	 * @param string $code Transport error_code from CRM client.
	 * @return bool
	 */
	private function is_unreachable_transport_code( $code ) {
		return in_array( (string) $code, array( 'timeout', 'transport', 'empty_reply' ), true );
	}

	/**
	 * @return int
	 */
	private function http_retry_count() {
		return max( 0, (int) apply_filters( 'webino_dashboard_license_http_retry_count', 0 ) );
	}

	/**
	 * Retries: one extra attempt on wp-cron only; sync UI clicks fail fast.
	 *
	 * @param string $context sync|cron.
	 * @return int
	 */
	private function http_retry_count_for_context( $context ) {
		if ( 'cron' === $context ) {
			return max( 0, (int) apply_filters( 'webino_dashboard_license_cron_http_retry_count', 1 ) );
		}
		return $this->http_retry_count();
	}

	/**
	 * @return list<int>
	 */
	private function http_retry_backoff_ms() {
		$backoff = apply_filters( 'webino_dashboard_license_http_retry_backoff_ms', array( 500 ) );
		return is_array( $backoff ) ? array_map( 'intval', $backoff ) : array( 500 );
	}

	/**
	 * @return string
	 */
	private function correlation_id() {
		return 'wd-lic-' . wp_generate_password( 12, false );
	}

	/**
	 * @param array<string,mixed> $body Request body (domain optional; defaults to site host).
	 * @return array<string,mixed>
	 */
	private function build_request_body( array $body ) {
		$domain = isset( $body['domain'] ) ? $this->normalize_site_domain( (string) $body['domain'] ) : $this->get_current_domain();
		return array(
			'domain' => $domain,
		);
	}

	/**
	 * @param WP_Error $error Transport error.
	 * @return bool
	 */
	private function is_retryable_transport_error( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return false;
		}
		$code = $error->get_error_code();
		if ( in_array( $code, array( 'http_request_failed', 'http_request_not_executed' ), true ) ) {
			return '' !== $this->transport_error_code_from_message( $error->get_error_message() );
		}
		return false;
	}

	/**
	 * Classify transport failure for retry mapping and user-facing error_code.
	 *
	 * @param string $message Raw WP HTTP error message.
	 * @return string empty_reply|timeout|transport|'' when not retryable.
	 */
	private function transport_error_code_from_message( $message ) {
		$msg = strtolower( trim( (string) $message ) );
		if ( '' === $msg ) {
			return 'transport';
		}
		if ( false !== strpos( $msg, 'curl error 52' )
			|| false !== strpos( $msg, 'empty reply from server' )
			|| false !== strpos( $msg, 'unexpected eof' ) ) {
			return 'empty_reply';
		}
		if ( false !== strpos( $msg, 'timed out' )
			|| false !== strpos( $msg, 'curl error 28' ) ) {
			return 'timeout';
		}
		if ( false !== strpos( $msg, 'could not resolve' )
			|| false !== strpos( $msg, 'connection reset' )
			|| false !== strpos( $msg, 'connection refused' )
			|| false !== strpos( $msg, 'connection' ) ) {
			return 'transport';
		}
		return '';
	}

	/**
	 * @param string $raw Raw transport message.
	 * @return string
	 */
	private function friendly_transport_error( $raw ) {
		$msg = trim( (string) $raw );
		if ( '' === $msg ) {
			return __( 'License server is unavailable.', 'webino-dashboard' );
		}
		$lower = strtolower( $msg );
		if ( false !== strpos( $lower, 'curl error 28' ) || false !== strpos( $lower, 'timed out' ) ) {
			return __( 'License server did not respond in time. Please try again shortly.', 'webino-dashboard' );
		}
		if ( false !== strpos( $lower, 'curl error 52' ) || false !== strpos( $lower, 'empty reply from server' ) ) {
			return __( 'License server closed the connection without a response. Please try again shortly.', 'webino-dashboard' );
		}
		if ( false !== strpos( $lower, 'could not resolve' ) ) {
			return __( 'License server hostname could not be resolved.', 'webino-dashboard' );
		}
		if ( false !== strpos( $lower, 'ssl' ) ) {
			return __( 'Secure connection to the license server failed.', 'webino-dashboard' );
		}
		return $msg;
	}

	/**
	 * @param string              $path Relative path.
	 * @param array<string,mixed> $meta Log context.
	 * @return void
	 */
	private function log_license_http( $path, array $meta ) {
		if ( ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( '[Webino Dashboard License] ' . $path . ' ' . wp_json_encode( $meta ) );
	}

	/**
	 * @param string $event Metric key suffix.
	 * @return void
	 */
	private function bump_license_metric( $event ) {
		$key  = 'webino_license_metric_' . sanitize_key( $event );
		$val  = (int) get_transient( $key );
		set_transient( $key, $val + 1, DAY_IN_SECONDS );
	}

	/**
	 * @param string              $path Relative to site root, e.g. wp-json/webinocrm/v1/license/check.
	 * @param array<string,mixed> $body Body fields.
	 * @param string              $context sync|cron.
	 * @return array{ ok: bool, code?: int, data?: mixed, error?: string, error_code?: string, transport_raw?: string }
	 */
	private function post_first_server( $path, array $body, $context = 'sync' ) {
		$path            = ltrim( (string) $path, '/' );
		$payload         = $this->build_request_body( $body );
		$correlation     = $this->correlation_id();
		$retries         = $this->http_retry_count_for_context( $context );
		$backoff_ms      = $this->http_retry_backoff_ms();
		$wall_started    = microtime( true );
		$wall_cap        = $this->wall_clock_cap();
		$wall_cap_msg    = __( 'License request exceeded time limit.', 'webino-dashboard' );
		$last_error      = '';
		$last_raw_error  = '';
		$last_code       = 0;

		foreach ( $this->get_request_bases() as $base ) {
			if ( ( microtime( true ) - $wall_started ) >= $wall_cap ) {
				$last_error = $wall_cap_msg;
				break;
			}

			$is_local  = $this->is_local_bypass_base( $base );
			$transport = $is_local ? 'local_bypass' : 'remote';
			$url       = trailingslashit( $base ) . $path;
			for ( $attempt = 0; $attempt <= $retries; $attempt++ ) {
				if ( ( microtime( true ) - $wall_started ) >= $wall_cap ) {
					$last_error = $wall_cap_msg;
					break 2;
				}
				if ( $attempt > 0 && isset( $backoff_ms[ $attempt - 1 ] ) ) {
					usleep( (int) $backoff_ms[ $attempt - 1 ] * 1000 );
				}

				$started = microtime( true );
				$headers = array(
					'Content-Type'            => 'application/json; charset=utf-8',
					'X-Webino-Correlation-Id' => $correlation,
				);
				if ( $is_local ) {
					$headers['Host'] = $this->crm_public_host();
				}
				$args = array(
					'timeout'         => $this->http_timeout(),
					'connect_timeout' => $this->http_connect_timeout(),
					'httpversion'     => '1.1',
					'headers'         => $headers,
					'body'            => wp_json_encode( $payload ),
					'sslverify'       => $is_local ? false : ( 0 === strpos( $base, 'https://' ) ? $this->verify_ssl() : false ),
				);

				$response = wp_remote_post( $url, $args );
				$elapsed  = (int) round( ( microtime( true ) - $started ) * 1000 );

				if ( is_wp_error( $response ) ) {
					$last_error      = $response->get_error_message();
					$last_raw_error  = $last_error;
					$transport_cd = $this->transport_error_code_from_message( $last_error );
					$this->log_license_http(
						$path,
						array(
							'transport'      => $transport,
							'base_url'       => $base,
							'url'            => $url,
							'attempt'        => $attempt,
							'latency_ms'     => $elapsed,
							'error'          => $last_error,
							'error_code'     => $transport_cd ? $transport_cd : 'transport',
							'correlation_id' => $correlation,
						)
					);
					if ( $this->is_retryable_transport_error( $response ) && $attempt < $retries ) {
						continue;
					}
					break;
				}

				$code = (int) wp_remote_retrieve_response_code( $response );
				$raw  = (string) wp_remote_retrieve_body( $response );
				$data = json_decode( $raw, true );
				$last_code = $code;

				$this->log_license_http(
					$path,
					array(
						'transport'      => $transport,
						'base_url'       => $base,
						'url'            => $url,
						'attempt'        => $attempt,
						'latency_ms'     => $elapsed,
						'http_code'      => $code,
						'correlation_id' => $correlation,
					)
				);

				if ( $code >= 200 && $code < 300 ) {
					return array(
						'ok'   => true,
						'code' => $code,
						'data' => null !== $data ? $data : $raw,
					);
				}

				if ( $code >= 400 && $code < 500 ) {
					$err_msg = '';
					if ( is_array( $data ) && ! empty( $data['message'] ) ) {
						$err_msg = (string) $data['message'];
					}
					return array(
						'ok'         => false,
						'code'       => $code,
						'data'       => $data,
						'error'      => $err_msg ? $err_msg : __( 'License server rejected the request.', 'webino-dashboard' ),
						'error_code' => is_array( $data ) && ! empty( $data['code'] ) ? (string) $data['code'] : 'http_' . $code,
					);
				}

				$last_error = sprintf(
					/* translators: %d: HTTP status code */
					__( 'License server returned HTTP %d.', 'webino-dashboard' ),
					$code
				);
				if ( $code >= 500 && $attempt < $retries ) {
					continue;
				}
				break;
			}
		}

		if ( '' !== $last_error ) {
			$final_cd = $this->transport_error_code_from_message( $last_error );
			if ( '' !== $final_cd ) {
				$this->bump_license_metric( $final_cd );
			}
		}

		if ( '' === $last_error ) {
			$last_error = __( 'No license servers configured.', 'webino-dashboard' );
		}

		$transport_cd = $this->transport_error_code_from_message( $last_error );
		if ( '' === $transport_cd ) {
			$transport_cd = 'transport';
		}

		if ( $last_error === $wall_cap_msg ) {
			$friendly = sprintf(
				/* translators: 1: seconds cap, 2: last raw transport error */
				__( 'License server did not respond within %1$d seconds. Last raw error: %2$s', 'webino-dashboard' ),
				$wall_cap,
				'' !== $last_raw_error ? $last_raw_error : __( 'no transport error captured', 'webino-dashboard' )
			);
		} else {
			$friendly = $this->friendly_transport_error( $last_error );
		}

		$fail = array(
			'ok'         => false,
			'code'       => $last_code,
			'error'      => $friendly,
			'error_code' => $transport_cd,
		);
		if ( '' !== $last_raw_error ) {
			$fail['transport_raw'] = $last_raw_error;
		}
		return $fail;
	}

	/**
	 * Admin connectivity probes to webina.dev (CRM).
	 *
	 * @return array<string,mixed>
	 */
	public function run_license_diagnostics() {
		$domain      = $this->get_current_domain();
		$bases       = $this->get_server_urls();
		$base        = ! empty( $bases[0] ) ? (string) $bases[0] : 'https://webina.dev';
		$base        = trailingslashit( $base );
		$same_server = $this->is_same_server_as_crm();
		$local_base  = $this->local_bypass_base();
		$check_body  = wp_json_encode( array( 'domain' => $domain ) );

		$probes = array();
		if ( $same_server && '' !== $local_base ) {
			$probes[] = $this->diagnostic_probe(
				'local_bypass_license_check',
				'POST',
				trailingslashit( $local_base ) . 'wp-json/webinocrm/v1/license/check',
				6,
				$check_body,
				true
			);
		}
		$probes[] = $this->diagnostic_probe( 'crm_home', 'GET', $base, 4 );
		$probes[] = $this->diagnostic_probe( 'crm_rest_namespace', 'GET', $base . 'wp-json/webinocrm/v1/', 4 );
		$probes[] = $this->diagnostic_probe(
			'license_check',
			'POST',
			$base . 'wp-json/webinocrm/v1/license/check',
			6,
			$check_body
		);

		$transport = 'streams';
		if ( function_exists( 'curl_version' ) ) {
			$transport = 'curl';
		}

		return array(
			'site_domain'          => $domain,
			'crm_base'             => rtrim( $base, '/' ),
			'same_server_detected' => $same_server,
			'local_bypass_base'    => ( $same_server && '' !== $local_base ) ? $local_base : null,
			'crm_host'             => $this->crm_public_host(),
			'wp_remote_transport'  => $transport,
			'probes'               => $probes,
		);
	}

	/**
	 * @param string      $name     Probe id.
	 * @param string      $method   HTTP method.
	 * @param string      $url      Full URL.
	 * @param int         $timeout  Seconds.
	 * @param string|null $body     Request body for POST.
	 * @param bool        $local_bypass Send Host header for CRM vhost via local NIC IP.
	 * @return array<string,mixed>
	 */
	private function diagnostic_probe( $name, $method, $url, $timeout, $body = null, $local_bypass = false ) {
		$started = microtime( true );
		$headers = array();
		if ( null !== $body ) {
			$headers['Content-Type'] = 'application/json; charset=utf-8';
		}
		if ( $local_bypass ) {
			$headers['Host'] = $this->crm_public_host();
		}
		$args = array(
			'method'          => $method,
			'timeout'         => $timeout,
			'connect_timeout' => min( 2, $timeout ),
			'httpversion'     => '1.1',
			'sslverify'       => $local_bypass ? false : ( 0 === strpos( $url, 'https://' ) ? $this->verify_ssl() : false ),
		);
		if ( ! empty( $headers ) ) {
			$args['headers'] = $headers;
		}
		if ( null !== $body ) {
			$args['body'] = $body;
		}

		$response = wp_remote_request( $url, $args );
		$elapsed  = (int) round( ( microtime( true ) - $started ) * 1000 );

		$probe = array(
			'name'        => (string) $name,
			'url'         => (string) $url,
			'method'      => (string) $method,
			'latency_ms'  => $elapsed,
			'ok'          => false,
			'http_code'   => 0,
			'error'       => '',
			'body_snippet' => '',
			'fastpath_detected' => false,
		);

		if ( is_wp_error( $response ) ) {
			$probe['error'] = $response->get_error_message();
			return $probe;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$fp   = wp_remote_retrieve_header( $response, 'x-webino-fastpath' );
		if ( '' === $fp ) {
			$fp = wp_remote_retrieve_header( $response, 'X-Webino-Fastpath' );
		}

		$probe['http_code']          = $code;
		$probe['ok']                 = $code >= 200 && $code < 500;
		$probe['body_snippet']       = function_exists( 'mb_substr' ) ? mb_substr( $raw, 0, 500 ) : substr( $raw, 0, 500 );
		$probe['fastpath_detected']  = '1' === (string) $fp;

		return $probe;
	}

	/**
	 * @param mixed $payload Decoded JSON or array.
	 * @return array{ status: string, message: string, expiry: ?string, demo: bool }
	 */
	private function normalize_crm_payload( $payload ) {
		$status  = 'inactive';
		$message = '';
		$expiry  = null;
		$demo    = false;

		if ( is_string( $payload ) ) {
			return array(
				'status'  => 'error',
				'message' => __( 'Invalid response from license server.', 'webino-dashboard' ),
				'expiry'  => null,
				'demo'    => false,
			);
		}

		$root = is_array( $payload ) ? $payload : array();
		if ( isset( $root['data'] ) && is_array( $root['data'] ) ) {
			$root = $root['data'];
		}

		$raw_status = isset( $root['status'] ) ? strtolower( (string) $root['status'] ) : '';
		if ( '' === $raw_status && isset( $root['license_status'] ) ) {
			$raw_status = strtolower( (string) $root['license_status'] );
		}

		if ( in_array( $raw_status, array( 'active', 'valid', 'ok', 'licensed', 'success' ), true ) ) {
			$status = 'active';
		} elseif ( in_array( $raw_status, array( 'demo', 'trial' ), true ) ) {
			$status = 'active';
			$demo   = true;
		} elseif ( in_array( $raw_status, array( 'expired', 'inactive', 'invalid', 'disabled' ), true ) ) {
			$status = $raw_status;
		} elseif ( '' !== $raw_status ) {
			$status = $raw_status;
		}

		if ( ! empty( $root['message'] ) ) {
			$message = (string) $root['message'];
		} elseif ( ! empty( $root['msg'] ) ) {
			$message = (string) $root['msg'];
		}

		foreach ( array( 'expiry', 'expires_at', 'expiry_date', 'expires' ) as $k ) {
			if ( ! empty( $root[ $k ] ) ) {
				$expiry = (string) $root[ $k ];
				break;
			}
		}

		if ( isset( $root['is_demo'] ) ) {
			$demo = (bool) $root['is_demo'];
		}
		if ( isset( $root['demo'] ) && $root['demo'] ) {
			$demo = true;
		}

		return array(
			'status'  => $status,
			'message' => $message,
			'expiry'  => $expiry,
			'demo'    => $demo,
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private function get_row() {
		if ( null !== $this->row_cache ) {
			return $this->row_cache;
		}
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is internal.
		$row = $wpdb->get_row( "SELECT * FROM {$table} WHERE id = " . (int) self::TABLE_ROW_ID, ARRAY_A );
		if ( ! is_array( $row ) ) {
			$row = array(
				'id'           => self::TABLE_ROW_ID,
				'domain'       => '',
				'status'       => 'inactive',
				'message'      => '',
				'expiry_date'  => null,
				'is_demo'      => 0,
				'activated_at' => null,
				'last_check'   => null,
				'license_key'  => null,
			);
		}
		$this->row_cache = $row;
		return $this->row_cache;
	}

	/**
	 * @param array<string,mixed> $data Data.
	 * @return void
	 */
	public function save_row( array $data ) {
		global $wpdb;
		$table = self::table_name();
		$data  = wp_parse_args(
			$data,
			array(
				'id'           => self::TABLE_ROW_ID,
				'domain'       => $this->get_current_domain(),
				'status'       => 'inactive',
				'message'      => '',
				'expiry_date'  => null,
				'is_demo'      => 0,
				'activated_at' => null,
				'last_check'   => current_time( 'mysql' ),
				'license_key'  => null,
			)
		);
		$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d", self::TABLE_ROW_ID ) );
		if ( $exists ) {
			unset( $data['id'] );
			$wpdb->update( $table, $data, array( 'id' => self::TABLE_ROW_ID ) );
		} else {
			$wpdb->insert( $table, $data );
		}
		$this->row_cache = null;
	}

	/**
	 * @param bool $persist_errors Whether to write connection errors to DB.
	 * @return array<string,mixed> Normalized result for REST/UI.
	 */
	public function remote_license_check( $persist_errors = true, $context = 'sync' ) {
		$domain = $this->get_current_domain();
		$result  = $this->post_first_server(
			'wp-json/webinocrm/v1/license/check',
			array_merge(
				array( 'domain' => $domain ),
				(array) apply_filters( 'webino_dashboard_license_check_body', array() )
			),
			$context
		);

		$now = current_time( 'mysql' );

		if ( ! $result['ok'] ) {
			$msg           = isset( $result['error'] ) ? (string) $result['error'] : __( 'License server error.', 'webino-dashboard' );
			$transport_raw = ! empty( $result['transport_raw'] ) ? (string) $result['transport_raw'] : '';
			$err_code      = ! empty( $result['error_code'] ) ? (string) $result['error_code'] : '';
			$was_ok        = false;
			if ( $persist_errors ) {
				$this->row_cache = null;
				$prev    = $this->get_row();
				$prev_st = isset( $prev['status'] ) ? strtolower( (string) $prev['status'] ) : '';
				$was_ok  = ! empty( $prev['is_demo'] )
					|| in_array( $prev_st, array( 'active', 'valid', 'ok', 'licensed' ), true );
				if ( '' !== $transport_raw ) {
					$db_message = '[diag] ' . $transport_raw;
				} elseif ( ! $was_ok && 'timeout' === $err_code ) {
					$db_message = '[unreachable] ' . $msg;
				}
				// Do not overwrite a known-good license with "error" on transient network/CRM failure.
				if ( $was_ok ) {
					$this->save_row(
						array(
							'last_check' => $now,
							'message'    => $db_message,
						)
					);
				} else {
					$this->save_row(
						array(
							'domain'     => $domain,
							'status'     => 'error',
							'message'    => $db_message,
							'last_check' => $now,
						)
					);
				}
			}
			$this->row_cache = null;
			$active = $this->is_license_active( false );
			$r      = $this->get_row();
			$out = array(
				'active'  => $active,
				'status'  => isset( $r['status'] ) ? (string) $r['status'] : 'error',
				'message' => $msg,
				'expiry'  => ! empty( $r['expiry_date'] ) ? (string) $r['expiry_date'] : null,
				'demo'    => ! empty( $r['is_demo'] ),
			);
			if ( '' !== $err_code ) {
				$out['error_code'] = $err_code;
			}
			if ( '' !== $transport_raw ) {
				$out['transport_raw'] = $transport_raw;
			}
			if (
				$was_ok
				&& $active
				&& $this->is_unreachable_transport_code( $err_code )
				&& ! (bool) apply_filters( 'webino_dashboard_license_disable_fallback', false )
			) {
				$out['warning'] = 'crm_unreachable';
			}
			return $out;
		}

		$norm = $this->normalize_crm_payload( $result['data'] ?? array() );
		$exp  = null;
		if ( ! empty( $norm['expiry'] ) ) {
			$ts = strtotime( $norm['expiry'] );
			if ( $ts ) {
				$exp = gmdate( 'Y-m-d H:i:s', $ts );
			}
		}

		$this->save_row(
			array(
				'domain'      => $domain,
				'status'      => $norm['status'],
				'message'     => $norm['message'],
				'expiry_date' => $exp,
				'is_demo'     => $norm['demo'] ? 1 : 0,
				'last_check'  => $now,
			)
		);

		return array(
			'active'  => $this->is_license_active( false ),
			'status'  => $norm['status'],
			'message' => $norm['message'],
			'expiry'  => $norm['expiry'],
			'demo'    => $norm['demo'],
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public function remote_activate() {
		$domain = $this->get_current_domain();
		$result = $this->post_first_server(
			'wp-json/webinocrm/v1/license/activate',
			array_merge(
				array( 'domain' => $domain ),
				(array) apply_filters( 'webino_dashboard_license_activate_body', array() )
			),
			'sync'
		);

		$now = current_time( 'mysql' );

		if ( ! $result['ok'] ) {
			$msg = isset( $result['error'] ) ? (string) $result['error'] : __( 'Activation request failed.', 'webino-dashboard' );
			$this->save_row(
				array(
					'domain'     => $domain,
					'status'     => 'error',
					'message'    => $msg,
					'last_check' => $now,
				)
			);
			$out = array(
				'active'  => false,
				'status'  => 'error',
				'message' => $msg,
				'expiry'  => null,
				'demo'    => false,
			);
			if ( ! empty( $result['error_code'] ) ) {
				$out['error_code'] = (string) $result['error_code'];
			}
			return $out;
		}

		$norm = $this->normalize_crm_payload( $result['data'] ?? array() );
		$exp  = null;
		if ( ! empty( $norm['expiry'] ) ) {
			$ts = strtotime( $norm['expiry'] );
			if ( $ts ) {
				$exp = gmdate( 'Y-m-d H:i:s', $ts );
			}
		}

		$this->save_row(
			array(
				'domain'       => $domain,
				'status'       => $norm['status'],
				'message'      => $norm['message'],
				'expiry_date'  => $exp,
				'is_demo'      => $norm['demo'] ? 1 : 0,
				'activated_at' => $now,
				'last_check'   => $now,
			)
		);

		return array(
			'active'  => $this->is_license_active( false ),
			'status'  => $norm['status'],
			'message' => $norm['message'],
			'expiry'  => $norm['expiry'],
			'demo'    => $norm['demo'],
		);
	}

	/**
	 * @param bool $use_cache Skip duplicate remote calls in one request.
	 * @return void
	 */
	public function check_license_status( $use_cache = true ) {
		if ( $use_cache && self::$checked_this_request ) {
			return;
		}
		self::$checked_this_request = true;
		$this->remote_license_check( true );
	}

	/**
	 * @param bool $reload Reload row from DB.
	 * @return bool
	 */
	public function is_license_active( $reload = true ) {
		if ( $reload ) {
			$this->row_cache = null;
		}
		$row = $this->get_row();
		if ( ! empty( $row['is_demo'] ) ) {
			return true;
		}
		$st = isset( $row['status'] ) ? strtolower( (string) $row['status'] ) : '';
		if ( ! in_array( $st, array( 'active', 'valid', 'ok', 'licensed' ), true ) ) {
			return false;
		}
		if ( ! empty( $row['expiry_date'] ) ) {
			$ex = strtotime( (string) $row['expiry_date'] );
			if ( $ex && time() > $ex ) {
				return false;
			}
		}
		$dom = isset( $row['domain'] ) ? $this->normalize_site_domain( (string) $row['domain'] ) : '';
		$cur = $this->get_current_domain();
		if ( $dom && $dom !== $cur ) {
			return false;
		}
		return true;
	}

	/**
	 * @return bool
	 */
	public function is_demo_mode() {
		$row = $this->get_row();
		return ! empty( $row['is_demo'] );
	}

	/**
	 * @return bool
	 */
	public function should_gate_dashboard() {
		if ( ! apply_filters( 'webino_dashboard_license_gate_enabled', true ) ) {
			return false;
		}
		if ( apply_filters( 'webino_dashboard_skip_license_gate', false ) ) {
			return false;
		}
		return ! $this->is_license_active( true );
	}

	/**
	 * Public snapshot for bootstrap + window.webinoDashboard.
	 *
	 * @return array<string,mixed>
	 */
	public function get_bootstrap_payload() {
		$row = $this->get_row();
		return array(
			'active'  => $this->is_license_active( false ),
			'status'  => isset( $row['status'] ) ? (string) $row['status'] : 'unknown',
			'message' => isset( $row['message'] ) ? (string) $row['message'] : '',
			'expiry'  => isset( $row['expiry_date'] ) && $row['expiry_date'] ? (string) $row['expiry_date'] : null,
			'demo'    => $this->is_demo_mode(),
			'domain'  => $this->get_current_domain(),
		);
	}
}

add_filter(
	'cron_schedules',
	static function ( $schedules ) {
		if ( ! isset( $schedules['webino_dashboard_license_12h'] ) ) {
			$schedules['webino_dashboard_license_12h'] = array(
				'interval' => 12 * HOUR_IN_SECONDS,
				'display'  => __( 'Every 12 hours (Webino license)', 'webino-dashboard' ),
			);
		}
		return $schedules;
	}
);
