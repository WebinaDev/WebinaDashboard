<?php
/**
 * Notifications settings tab
 *
 * @package    WFCP
 * @subpackage WFCP/admin/partials/tabs
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

$notifications = WFCP_Helper::get_settings( 'notifications' );
?>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'متن‌های نمایشی', 'webina-woo-core' ); ?></h2>
	
	<form class="wfcp-settings-form" data-section="notifications">
		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="installment_text">
				<?php esc_html_e( 'متن خرید اقساطی', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="text" 
				name="installment_text" 
				id="installment_text" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $notifications['installment_text'] ?? 'خرید اقساطی' ); ?>"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="credit_text">
				<?php esc_html_e( 'متن خرید اعتباری', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="text" 
				name="credit_text" 
				id="credit_text" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $notifications['credit_text'] ?? 'خرید اعتباری' ); ?>"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="cash_description">
				<?php esc_html_e( 'توضیح خرید نقدی', 'webina-woo-core' ); ?>
			</label>
			<textarea name="cash_description" id="cash_description" class="wfcp-form-control" rows="3"><?php echo esc_textarea( $notifications['cash_description'] ?? '' ); ?></textarea>
			<small><?php esc_html_e( 'متن دلخواه زیر قیمت نقدی در صفحه محصول', 'webina-woo-core' ); ?></small>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="installment_description">
				<?php esc_html_e( 'توضیح خرید اقساطی', 'webina-woo-core' ); ?>
			</label>
			<textarea name="installment_description" id="installment_description" class="wfcp-form-control" rows="3"><?php echo esc_textarea( $notifications['installment_description'] ?? '' ); ?></textarea>
			<small><?php esc_html_e( 'متن دلخواه در بلوک خرید اقساطی', 'webina-woo-core' ); ?></small>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="credit_description">
				<?php esc_html_e( 'توضیح خرید اعتباری', 'webina-woo-core' ); ?>
			</label>
			<textarea name="credit_description" id="credit_description" class="wfcp-form-control" rows="3"><?php echo esc_textarea( $notifications['credit_description'] ?? '' ); ?></textarea>
			<small><?php esc_html_e( 'متن دلخواه در بلوک خرید اعتباری', 'webina-woo-core' ); ?></small>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="need_review">
				<?php esc_html_e( 'متن نیاز به بررسی', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="text" 
				name="need_review" 
				id="need_review" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $notifications['need_review'] ?? 'نیاز به بررسی' ); ?>"
			>
		</div>

		<button type="submit" class="wfcp-btn wfcp-btn-primary">
			<?php esc_html_e( 'ذخیره تنظیمات', 'webina-woo-core' ); ?>
		</button>
	</form>
</div>

