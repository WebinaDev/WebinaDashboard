<?php
/**
 * Advanced settings tab
 *
 * @package    WFCP
 * @subpackage WFCP/admin/partials/tabs
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
?>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'تنظیمات پیشرفته', 'webina-woo-core' ); ?></h2>
	
	<div class="wfcp-form-group">
		<label class="wfcp-form-label"><?php esc_html_e( 'محاسبه مجدد قیمت‌ها', 'webina-woo-core' ); ?></label>
		<p><?php esc_html_e( 'با استفاده از این گزینه می‌توانید تمام قیمت‌های محصولات را بر اساس تنظیمات فعلی مجدداً محاسبه کنید.', 'webina-woo-core' ); ?></p>
		
		<div class="wfcp-checkbox" style="margin-bottom: 15px;">
			<input type="checkbox" id="wfcp-dry-run" value="1">
			<label for="wfcp-dry-run"><?php esc_html_e( 'حالت Dry Run (فقط لاگ، بدون ذخیره)', 'webina-woo-core' ); ?></label>
		</div>
		
		<button type="button" class="wfcp-btn wfcp-btn-primary wfcp-recalculate-all">
			<?php esc_html_e( 'محاسبه مجدد', 'webina-woo-core' ); ?>
		</button>
	</div>

	<div class="wfcp-form-group">
		<label class="wfcp-form-label"><?php esc_html_e( 'حذف کش', 'webina-woo-core' ); ?></label>
		<p><?php esc_html_e( 'تمام کش‌های محاسبات قیمت را حذف می‌کند.', 'webina-woo-core' ); ?></p>
		<button type="button" class="wfcp-btn wfcp-btn-secondary wfcp-delete-transients">
			<?php esc_html_e( 'حذف کش', 'webina-woo-core' ); ?>
		</button>
	</div>

	<div class="wfcp-form-group">
		<label class="wfcp-form-label"><?php esc_html_e( 'بکاپ و بازگردانی', 'webina-woo-core' ); ?></label>
		<p><?php esc_html_e( 'تنظیمات را به صورت JSON دانلود یا وارد کنید.', 'webina-woo-core' ); ?></p>
		<button type="button" class="wfcp-btn wfcp-btn-success wfcp-export-settings" style="margin-left: 10px;">
			<?php esc_html_e( 'دانلود بکاپ', 'webina-woo-core' ); ?>
		</button>
		<button type="button" class="wfcp-btn wfcp-btn-secondary wfcp-import-settings">
			<?php esc_html_e( 'وارد کردن بکاپ', 'webina-woo-core' ); ?>
		</button>
	</div>
</div>

