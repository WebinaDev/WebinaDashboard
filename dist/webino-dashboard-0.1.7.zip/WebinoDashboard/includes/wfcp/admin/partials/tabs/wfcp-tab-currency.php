<?php
/**
 * Currency settings tab
 *
 * @package    WFCP
 * @subpackage WFCP/admin/partials/tabs
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

$general = WFCP_Helper::get_settings( 'general' );
?>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'تنظیمات واحد پول', 'webina-woo-core' ); ?></h2>
	
	<form class="wfcp-settings-form" data-section="currency">
		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="currency">
				<?php esc_html_e( 'واحد پول نمایشی', 'webina-woo-core' ); ?>
			</label>
			<select name="currency" id="currency" class="wfcp-form-control wfcp-form-control-medium">
				<option value="IRR" <?php selected( $general['currency'] ?? 'IRR', 'IRR' ); ?>>ریال (IRR)</option>
				<option value="IRT" <?php selected( $general['currency'] ?? 'IRR', 'IRT' ); ?>>تومان (IRT)</option>
				<option value="USD" <?php selected( $general['currency'] ?? 'IRR', 'USD' ); ?>>دلار (USD)</option>
				<option value="EUR" <?php selected( $general['currency'] ?? 'IRR', 'EUR' ); ?>>یورو (EUR)</option>
				<option value="GBP" <?php selected( $general['currency'] ?? 'IRR', 'GBP' ); ?>>پوند (GBP)</option>
			</select>
			<small><?php esc_html_e( 'واحد پولی که در فرانت‌اند نمایش داده می‌شود', 'webina-woo-core' ); ?></small>
		</div>

		<button type="submit" class="wfcp-btn wfcp-btn-primary">
			<?php esc_html_e( 'ذخیره تنظیمات', 'webina-woo-core' ); ?>
		</button>
	</form>
</div>

