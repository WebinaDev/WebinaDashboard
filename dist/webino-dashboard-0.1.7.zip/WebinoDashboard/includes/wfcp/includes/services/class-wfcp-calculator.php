<?php
/**
 * Price Calculator Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Price Calculator Service
 */
class WFCP_Calculator {

	/**
	 * Calculate price based on type
	 *
	 * @param float  $base_price Base purchase price.
	 * @param string $type       Price type: retail, credit, installment, wholesale.
	 * @param int    $product_id Optional. Product ID.
	 * @param array  $args       Optional. Additional arguments.
	 * @return float
	 */
	public static function calculate_price( $base_price, $type = 'retail', $product_id = null, $args = array() ) {
		// Check cache first
		$cache_key = self::get_cache_key( $base_price, $type, $product_id, $args );
		$cached = get_transient( $cache_key );
		
		if ( false !== $cached ) {
			return floatval( $cached );
		}

		$price = floatval( $base_price );

		// Get exchange rate (from API if enabled, otherwise manual)
		$general = WFCP_Helper::get_settings( 'general' );
		$api_enabled = isset( $general['api_enabled'] ) && $general['api_enabled'];
		
		$exchange_rate = $general['exchange_rate'] ?? 42000;
		
		// If API is enabled, try to get latest rate (but use cached if available)
		if ( $api_enabled && isset( $general['api_key'] ) && ! empty( $general['api_key'] ) ) {
			// Use stored exchange rate (updated by cron or manual update)
			$exchange_rate = $general['exchange_rate'] ?? 42000;
		}
		
		$purchase_currency = $general['purchase_currency'] ?? 'base';
		$exchange_rate_enabled = isset( $general['exchange_rate_enabled'] ) ? (bool) $general['exchange_rate_enabled'] : true;

		// Apply exchange rate only when enabled and purchase_currency is 'base'
		// If exchange_rate_enabled is false or purchase_currency is 'display', price is used as-is (no conversion)
		if ( $exchange_rate_enabled && $exchange_rate && $exchange_rate > 0 ) {
			if ( ! $purchase_currency || $purchase_currency === 'base' ) {
				$price = $price * floatval( $exchange_rate );
			}
		}

		// Calculate based on type
		switch ( $type ) {
			case 'retail':
				$price = self::calculate_retail_price( $price );
				break;

			case 'credit':
				$price = self::calculate_credit_price( $price );
				break;

			case 'installment':
				$months = isset( $args['months'] ) ? intval( $args['months'] ) : 3;
				$price  = self::calculate_installment_price( $price, $months );
				break;

			case 'wholesale':
				$price = self::calculate_wholesale_price( $price, $product_id );
				break;
		}

		// Round price if enabled (for retail only)
		if ( 'retail' === $type ) {
			$round_enabled = WFCP_Helper::get_settings( 'retail', 'round_enabled' );
			if ( $round_enabled ) {
				$round_to = WFCP_Helper::get_settings( 'retail', 'round_to' );
				if ( $round_to ) {
					$price = WFCP_Helper::round_price( $price, intval( $round_to ) );
				}
			}
		}

		// Cache the result (1 hour)
		set_transient( $cache_key, $price, HOUR_IN_SECONDS );

		return floatval( $price );
	}

	/**
	 * Calculate retail price
	 *
	 * @param float $base_price Base price.
	 * @return float
	 */
	private static function calculate_retail_price( $base_price ) {
		$profit_percent = WFCP_Helper::get_settings( 'retail', 'profit_percent' );
		
		if ( ! $profit_percent || $profit_percent <= 0 ) {
			return $base_price;
		}

		$profit = ( $base_price * floatval( $profit_percent ) ) / 100;
		return $base_price + $profit;
	}

	/**
	 * Calculate credit price
	 *
	 * @param float $base_price Base price.
	 * @return float
	 */
	private static function calculate_credit_price( $base_price ) {
		$enabled = WFCP_Helper::get_settings( 'credit', 'enabled' );
		
		if ( ! $enabled ) {
			return $base_price;
		}

		$increase_percent = WFCP_Helper::get_settings( 'credit', 'increase_percent' );
		
		if ( ! $increase_percent || $increase_percent <= 0 ) {
			return $base_price;
		}

		$increase = ( $base_price * floatval( $increase_percent ) ) / 100;
		return $base_price + $increase;
	}

	/**
	 * Calculate installment price
	 *
	 * @param float $base_price Base price.
	 * @param int   $months     Number of months.
	 * @return float
	 */
	private static function calculate_installment_price( $base_price, $months ) {
		$enabled = WFCP_Helper::get_settings( 'installment', 'enabled' );
		
		if ( ! $enabled ) {
			return $base_price;
		}

		$plans = WFCP_Helper::get_settings( 'installment', 'plans' );
		
		if ( ! is_array( $plans ) || empty( $plans ) ) {
			return $base_price;
		}

		// Find matching plan
		$plan = null;
		foreach ( $plans as $p ) {
			if ( isset( $p['months'] ) && intval( $p['months'] ) === $months ) {
				$plan = $p;
				break;
			}
		}

		if ( ! $plan || ! isset( $plan['interest'] ) ) {
			return $base_price;
		}

		$interest_percent = floatval( $plan['interest'] );
		$total_interest   = ( $base_price * $interest_percent ) / 100;
		$total_price      = $base_price + $total_interest;
		
		// Prevent division by zero
		if ( $months <= 0 ) {
			return $base_price;
		}
		
		$monthly_payment  = $total_price / $months;

		return $monthly_payment;
	}

	/**
	 * Calculate wholesale price
	 *
	 * @param float $base_price Base price.
	 * @param int   $product_id Product ID.
	 * @return float
	 */
	private static function calculate_wholesale_price( $base_price, $product_id = null ) {
		$enabled = WFCP_Helper::get_settings( 'wholesale', 'enabled' );
		
		if ( ! $enabled ) {
			return $base_price;
		}

		$strategy = WFCP_Helper::get_settings( 'wholesale', 'strategy' );
		
		$discount_percent = 0;

		switch ( $strategy ) {
			case 'global':
				$discount_percent = WFCP_Helper::get_settings( 'wholesale', 'discount_percent' );
				break;

			case 'category':
				if ( $product_id ) {
					$terms = wp_get_post_terms( $product_id, 'product_cat' );
					if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
						$category_rules = WFCP_Helper::get_settings( 'wholesale', 'category_rules' );
						foreach ( $terms as $term ) {
							if ( isset( $category_rules[ $term->term_id ] ) ) {
								$discount_percent = floatval( $category_rules[ $term->term_id ] );
								break;
							}
						}
					}
				}
				break;

			case 'product':
				if ( $product_id ) {
					$custom_rule = get_post_meta( $product_id, '_wfcp_wholesale_custom_rule', true );
					if ( $custom_rule && isset( $custom_rule['discount_percent'] ) ) {
						$discount_percent = floatval( $custom_rule['discount_percent'] );
					}
				}
				break;
		}

		if ( ! $discount_percent || $discount_percent <= 0 ) {
			return $base_price;
		}

		// Prevent discount from being more than 100%
		if ( $discount_percent >= 100 ) {
			$discount_percent = 99.99;
		}

		$discount = ( $base_price * $discount_percent ) / 100;
		return max( 0, $base_price - $discount ); // Prevent negative prices
	}

	/**
	 * Get cache key
	 *
	 * @param float  $base_price Base price.
	 * @param string $type       Price type.
	 * @param int    $product_id Product ID.
	 * @param array  $args       Additional arguments.
	 * @return string
	 */
	private static function get_cache_key( $base_price, $type, $product_id, $args ) {
		$key = 'wfcp_price_' . md5( $base_price . $type . $product_id . serialize( $args ) );
		return $key;
	}
}

