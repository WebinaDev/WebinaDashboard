<?php
/**
 * Cart Manager Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Cart Manager Service
 */
class WFCP_Cart_Manager {

	/**
	 * Validate cart item addition
	 *
	 * @param bool $passed Validation result.
	 * @param int  $product_id Product ID.
	 * @param int  $quantity Quantity.
	 * @return bool|WP_Error
	 */
	public static function validate_add_to_cart( $passed, $product_id, $quantity ) {
		if ( ! $passed ) {
			return $passed;
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $passed;
		}

		$cart = WC()->cart;
		
		if ( $cart->is_empty() ) {
			return $passed;
		}

		// Get purchase type from request
		$new_purchase_type = isset( $_REQUEST['purchase_type'] ) ? sanitize_text_field( $_REQUEST['purchase_type'] ) : 'cash';

		// Check existing cart items
		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			$existing_purchase_type = isset( $cart_item['wfcp_purchase_type'] ) ? $cart_item['wfcp_purchase_type'] : 'cash';

			// If types are different, prevent addition
			if ( $existing_purchase_type !== $new_purchase_type ) {
				$error_message = __( 'امکان خرید همزمان محصول اقساطی و نقدی وجود ندارد. سبد خرید را خالی کنید.', 'webina-woo-core' );
				wc_add_notice( $error_message, 'error' );
				return false;
			}
		}

		return $passed;
	}

	/**
	 * Add purchase type to cart item data
	 *
	 * @param array $cart_item_data Cart item data.
	 * @param int   $product_id Product ID.
	 * @return array
	 */
	public static function add_cart_item_data( $cart_item_data, $product_id ) {
		$purchase_type = isset( $_REQUEST['purchase_type'] ) ? sanitize_text_field( $_REQUEST['purchase_type'] ) : 'cash';
		
		$cart_item_data['wfcp_purchase_type'] = $purchase_type;
		
		// Add installment months if applicable
		if ( 'installment' === $purchase_type && isset( $_REQUEST['installment_months'] ) ) {
			$cart_item_data['wfcp_installment_months'] = intval( $_REQUEST['installment_months'] );
		}
		
		return $cart_item_data;
	}

	/**
	 * Display purchase type in cart
	 *
	 * @param array $item_data Cart item data.
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public static function get_item_data( $item_data, $cart_item ) {
		if ( ! isset( $cart_item['wfcp_purchase_type'] ) ) {
			return $item_data;
		}

		$purchase_type = $cart_item['wfcp_purchase_type'];
		
		$labels = array(
			'cash'        => __( 'نقدی', 'webina-woo-core' ),
			'credit'      => __( 'اعتباری', 'webina-woo-core' ),
			'installment' => __( 'اقساطی', 'webina-woo-core' ),
		);

		$label = isset( $labels[ $purchase_type ] ) ? $labels[ $purchase_type ] : $purchase_type;
		
		// Add months for installment
		if ( 'installment' === $purchase_type && isset( $cart_item['wfcp_installment_months'] ) ) {
			$months = intval( $cart_item['wfcp_installment_months'] );
			$label .= ' (' . sprintf( __( '%d ماهه', 'webina-woo-core' ), $months ) . ')';
		}

		$item_data[] = array(
			'name'  => __( 'نوع خرید', 'webina-woo-core' ),
			'value' => $label,
		);

		return $item_data;
	}
}

