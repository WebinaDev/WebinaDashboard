<?php
/**
 * Batch Processing Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Batch Processing Service
 */
class WFCP_Batch_Process {

	/**
	 * Recalculate all product prices
	 *
	 * @param bool $dry_run Dry run mode (don't save to database).
	 * @return array
	 */
	public static function recalculate_all( $dry_run = false ) {
		$results = array(
			'success' => 0,
			'failed'  => 0,
			'log'     => array(),
		);

		// Get all products
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => -1,
			'post_status'     => 'any',
		);

		$products = get_posts( $args );

		foreach ( $products as $product ) {
			$product_id = $product->ID;
			
			// Skip if price is locked
			if ( WFCP_Helper::is_product_price_locked( $product_id ) ) {
				$results['log'][] = sprintf( 'محصول #%d: قیمت قفل شده است', $product_id );
				continue;
			}

			$purchase_price = WFCP_Helper::get_product_purchase_price( $product_id );
			
			if ( ! $purchase_price ) {
				$results['log'][] = sprintf( 'محصول #%d: قیمت خرید تعیین نشده', $product_id );
				$results['failed']++;
				continue;
			}

			// Calculate retail price
			$retail_price = WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product_id );

			if ( $dry_run ) {
				$results['log'][] = sprintf( 
					'محصول #%d (%s): قیمت خرید: %s، قیمت تکی: %s', 
					$product_id,
					$product->post_title,
					WFCP_Helper::format_price( $purchase_price ),
					WFCP_Helper::format_price( $retail_price )
				);
			} else {
				// Update WooCommerce price
				update_post_meta( $product_id, '_regular_price', $retail_price );
				update_post_meta( $product_id, '_price', $retail_price );
				
				// Clear product cache
				wc_delete_product_transients( $product_id );
				
				$results['log'][] = sprintf( 
					'محصول #%d (%s): قیمت به‌روزرسانی شد', 
					$product_id,
					$product->post_title
				);
			}

			$results['success']++;
		}

		// Write log file if dry run
		if ( $dry_run ) {
			self::write_log( $results['log'] );
		}

		return $results;
	}

	/**
	 * Write log to file
	 *
	 * @param array $log Log entries.
	 * @return bool
	 */
	private static function write_log( $log ) {
		$upload_dir = wp_upload_dir();
		
		// Check if upload directory is writable
		if ( empty( $upload_dir['error'] ) ) {
			$log_dir = $upload_dir['basedir'] . '/wfcp-logs';
			
			// Create directory if it doesn't exist
			if ( ! file_exists( $log_dir ) ) {
				wp_mkdir_p( $log_dir );
			}

			// Check if directory is writable
			if ( ! is_writable( $log_dir ) ) {
				return false;
			}

			$log_file = $log_dir . '/recalculate-' . date( 'Y-m-d-H-i-s' ) . '.log';
			$content  = implode( "\n", $log );
			
			return file_put_contents( $log_file, $content ) !== false;
		}
		
		return false;
	}

	/**
	 * Delete all transients
	 *
	 * @return int Number of deleted transients.
	 */
	public static function delete_transients() {
		global $wpdb;
		
		$deleted = $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wfcp_%'" );
		$deleted += $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wfcp_%'" );
		
		return $deleted;
	}

	/**
	 * Export settings to JSON
	 *
	 * @return string JSON encoded settings.
	 */
	public static function export_settings() {
		$settings = WFCP_Helper::get_settings();
		return wp_json_encode( $settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
	}

	/**
	 * Import settings from JSON
	 *
	 * @param string $json JSON encoded settings.
	 * @return bool|WP_Error
	 */
	public static function import_settings( $json ) {
		$settings = json_decode( $json, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'invalid_json', __( 'فرمت JSON نامعتبر است.', 'webina-woo-core' ) );
		}

		return update_option( 'wfcp_settings', $settings );
	}
}

