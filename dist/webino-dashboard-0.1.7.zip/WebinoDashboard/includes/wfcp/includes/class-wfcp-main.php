<?php
/**
 * The core plugin class.
 *
 * @package    WFCP
 * @subpackage WFCP/includes
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The core plugin class.
 */
class WFCP_Main {

	/**
	 * The loader that's responsible for maintaining and registering all hooks.
	 *
	 * @var WFCP_Loader
	 */
	protected $loader;

	/**
	 * Define the core functionality of the plugin.
	 */
	public function __construct( $loader ) {
		$this->loader = $loader;
		$this->load_dependencies();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->init_bulk_price_change();
	}

	/**
	 * Load the required dependencies for this plugin.
	 */
	private function load_dependencies() {
		/**
		 * The class responsible for defining internationalization functionality
		 */
		require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once WFCP_PLUGIN_DIR . 'admin/class-wfcp-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing side.
		 */
		require_once WFCP_PLUGIN_DIR . 'public/class-wfcp-public.php';

		/**
		 * Exchange Rate API Service
		 */
		require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-exchange-api.php';
	}

	/**
	 * Register all of the hooks related to the admin area functionality.
	 */
	private function define_admin_hooks() {
		$plugin_admin = new WFCP_Admin();

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_admin_menu' );
		$this->loader->add_action( 'wp_ajax_wfcp_save_settings', $plugin_admin, 'ajax_save_settings' );
		$this->loader->add_action( 'wp_ajax_wfcp_update_product_price', $plugin_admin, 'ajax_update_product_price' );
		$this->loader->add_action( 'wp_ajax_wfcp_recalculate_all', $plugin_admin, 'ajax_recalculate_all' );
		$this->loader->add_action( 'wp_ajax_wfcp_delete_transients', $plugin_admin, 'ajax_delete_transients' );
		$this->loader->add_action( 'wp_ajax_wfcp_export_settings', $plugin_admin, 'ajax_export_settings' );
		$this->loader->add_action( 'wp_ajax_wfcp_import_settings', $plugin_admin, 'ajax_import_settings' );
		$this->loader->add_action( 'wp_ajax_wfcp_update_lock_price', $plugin_admin, 'ajax_update_lock_price' );
		$this->loader->add_action( 'wp_ajax_wfcp_test_api', $plugin_admin, 'ajax_test_api' );
		$this->loader->add_action( 'wp_ajax_wfcp_update_exchange_rate', $plugin_admin, 'ajax_update_exchange_rate' );
		$this->loader->add_action( 'wp_ajax_wfcp_update_all_prices', $plugin_admin, 'ajax_update_all_prices' );
		$this->loader->add_action( 'wp_ajax_wfcp_quick_add_product', $plugin_admin, 'ajax_quick_add_product' );

		// Price Manager page AJAX
		$this->loader->add_action( 'wp_ajax_wfcp_pm_get_products', $plugin_admin, 'ajax_pm_get_products' );
		$this->loader->add_action( 'wp_ajax_wfcp_pm_update_price', $plugin_admin, 'ajax_pm_update_price' );
		$this->loader->add_action( 'wp_ajax_wfcp_pm_update_stock', $plugin_admin, 'ajax_pm_update_stock' );
		$this->loader->add_action( 'wp_ajax_wfcp_pm_update_brand', $plugin_admin, 'ajax_pm_update_brand' );
		
		// Cron job for auto update
		$this->loader->add_action( 'wfcp_auto_update_exchange_rate', 'WFCP_Exchange_API', 'update_exchange_rate' );
		add_action( 'init', array( $this, 'schedule_auto_update' ), 20 );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality.
	 */
	private function define_public_hooks() {
		$plugin_public = new WFCP_Public();

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		$this->loader->add_action( 'woocommerce_before_single_product', $plugin_public, 'maybe_hide_default_add_to_cart', 5 );
		$this->loader->add_action( 'woocommerce_single_product_summary', $plugin_public, 'display_pricing_box', 25 );
		
		// Cart management hooks
		$this->loader->add_filter( 'woocommerce_add_to_cart_validation', 'WFCP_Cart_Manager', 'validate_add_to_cart', 10, 3 );
		$this->loader->add_filter( 'woocommerce_add_cart_item_data', 'WFCP_Cart_Manager', 'add_cart_item_data', 10, 2 );
		$this->loader->add_filter( 'woocommerce_get_item_data', 'WFCP_Cart_Manager', 'get_item_data', 10, 2 );
		
		// Load i18n
		$plugin_i18n = new WFCP_i18n();
		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Schedule auto update cron job
	 */
	public function schedule_auto_update() {
		$general = WFCP_Helper::get_settings( 'general' );
		
		if ( ! isset( $general['api_enabled'] ) || ! $general['api_enabled'] ) {
			wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );
			return;
		}

		if ( ! isset( $general['auto_update_enabled'] ) || ! $general['auto_update_enabled'] ) {
			wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );
			return;
		}

		$hour = isset( $general['auto_update_hour'] ) ? intval( $general['auto_update_hour'] ) : 0;
		
		// Clear existing schedule
		wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );
		
		// Calculate next run time (today at specified hour, or tomorrow if hour has passed)
		$current_time = current_time( 'timestamp' );
		$today = strtotime( date( 'Y-m-d', $current_time ) );
		$scheduled_time = $today + ( $hour * HOUR_IN_SECONDS );
		
		if ( $scheduled_time <= $current_time ) {
			// If hour has passed today, schedule for tomorrow
			$scheduled_time = $scheduled_time + DAY_IN_SECONDS;
		}
		
		// Schedule daily recurrence
		wp_schedule_event( $scheduled_time, 'daily', 'wfcp_auto_update_exchange_rate' );
	}

	/**
	 * Initialize the Bulk Price Change service (hooks registered in its constructor).
	 */
	private function init_bulk_price_change() {
		if ( class_exists( 'WFCP_Bulk_Price_Change' ) ) {
			$GLOBALS['wfcp_bulk_price_change'] = new WFCP_Bulk_Price_Change();
		}
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 */
	public function run() {
		$this->loader->run();
	}
}

