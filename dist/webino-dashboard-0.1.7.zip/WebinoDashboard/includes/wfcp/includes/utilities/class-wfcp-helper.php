<?php
/**
 * Helper functions
 *
 * @package    WFCP
 * @subpackage WFCP/includes/utilities
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Helper functions class
 */
class WFCP_Helper {

	/**
	 * Get plugin settings
	 *
	 * @param string $section Optional. Settings section.
	 * @param string $key     Optional. Settings key.
	 * @return mixed
	 */
	public static function get_settings( $section = null, $key = null ) {
		$settings = get_option( 'wfcp_settings', array() );

		if ( null === $section ) {
			return $settings;
		}

		if ( ! isset( $settings[ $section ] ) ) {
			return null;
		}

		if ( null === $key ) {
			return $settings[ $section ];
		}

		if ( ! isset( $settings[ $section ][ $key ] ) ) {
			return null;
		}

		return $settings[ $section ][ $key ];
	}

	/**
	 * Update plugin settings
	 *
	 * @param string $section Settings section.
	 * @param array  $data    Settings data.
	 * @return bool
	 */
	public static function update_settings( $section, $data ) {
		$settings = self::get_settings();
		
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$settings[ $section ] = $data;
		
		return update_option( 'wfcp_settings', $settings );
	}

	/**
	 * Sanitize price value
	 *
	 * @param mixed $price Price value.
	 * @return float
	 */
	public static function sanitize_price( $price ) {
		if ( is_array( $price ) ) {
			return 0.0;
		}
		$price = sanitize_text_field( (string) $price );
		$price = str_replace( array( ',', ' ' ), '', $price );
		return floatval( $price );
	}

	/**
	 * Format price for display
	 *
	 * @param float  $price    Price value.
	 * @param string $currency Optional. Currency code.
	 * @return string
	 */
	public static function format_price( $price, $currency = null ) {
		if ( null === $currency ) {
			$currency = self::get_settings( 'general', 'currency' );
		}

		$formatted = number_format( $price, 0, '.', ',' );
		
		$symbol = self::get_currency_symbol( $currency );
		
		return $formatted . ' ' . $symbol;
	}

	/**
	 * Get currency symbol
	 *
	 * @param string $currency Currency code.
	 * @return string
	 */
	public static function get_currency_symbol( $currency = null ) {
		if ( null === $currency ) {
			$currency = self::get_settings( 'general', 'currency' );
		}

		$symbols = array(
			'IRR' => 'ریال',
			'IRT' => 'تومان',
			'USD' => '$',
			'EUR' => '€',
			'GBP' => '£',
		);

		return isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : $currency;
	}

	/**
	 * Format price with IRT (Toman) symbol HTML for product display.
	 *
	 * @param float $price Price value.
	 * @return string HTML: formatted number + woocommerce-Price-currencySymbol span.
	 */
	public static function format_price_with_irt_symbol( $price ) {
		$formatted = number_format( (float) $price, 0, '.', ',' );
		$symbol    = '<span class="woocommerce-Price-currencySymbol"><span class="ishop-currency-symbol ishop-currency-irt">IRT</span></span>';
		return $formatted . ' ' . $symbol;
	}

	/**
	 * Round price
	 *
	 * @param float $price Price to round.
	 * @param int   $to    Round to this value.
	 * @return float
	 */
	public static function round_price( $price, $to = 1000 ) {
		return round( $price / $to ) * $to;
	}

	/**
	 * Check if plugin is enabled
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) self::get_settings( 'general', 'enabled' );
	}

	/**
	 * Get product purchase price
	 *
	 * @param int $product_id Product ID.
	 * @return float|null
	 */
	public static function get_product_purchase_price( $product_id ) {
		$price = get_post_meta( $product_id, '_wfcp_purchase_price', true );
		return $price ? floatval( $price ) : null;
	}

	/**
	 * Check if product price is locked
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function is_product_price_locked( $product_id ) {
		return (bool) get_post_meta( $product_id, '_wfcp_lock_price', true );
	}

	/**
	 * Reschedule or clear the exchange rate auto-update cron.
	 * Safe to call from AJAX (does not fire init hook).
	 */
	public static function reschedule_exchange_cron() {
		$general = self::get_settings( 'general' );
		if ( ! is_array( $general ) ) {
			$general = array();
		}

		if ( empty( $general['api_enabled'] ) || empty( $general['auto_update_enabled'] ) ) {
			wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );
			return;
		}

		$hour = isset( $general['auto_update_hour'] ) ? intval( $general['auto_update_hour'] ) : 0;
		wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );

		$current_time = current_time( 'timestamp' );
		$today        = strtotime( date( 'Y-m-d', $current_time ) );
		$scheduled_time = $today + ( $hour * HOUR_IN_SECONDS );
		if ( $scheduled_time <= $current_time ) {
			$scheduled_time += DAY_IN_SECONDS;
		}
		wp_schedule_event( $scheduled_time, 'daily', 'wfcp_auto_update_exchange_rate' );
	}
}

