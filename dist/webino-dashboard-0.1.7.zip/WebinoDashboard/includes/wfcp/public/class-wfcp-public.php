<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package    WFCP
 * @subpackage WFCP/public
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The public-facing functionality of the plugin.
 */
class WFCP_Public {

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 */
	public function enqueue_styles() {
		if ( ! is_product() ) {
			return;
		}

		wp_enqueue_style(
			'wfcp-public-style',
			WFCP_PLUGIN_URL . 'public/css/wfcp-public-style.css',
			array(),
			WFCP_VERSION,
			'all'
		);

		$style = WFCP_Helper::get_settings( 'style' );
		if ( ! is_array( $style ) ) {
			$style = array();
		}
		$box_bg     = isset( $style['box_background'] ) && $style['box_background'] ? $style['box_background'] : '#ffffff';
		$box_border = isset( $style['box_border_color'] ) && $style['box_border_color'] ? $style['box_border_color'] : '#e0e0e0';
		$btn_bg     = isset( $style['button_background'] ) && $style['button_background'] ? $style['button_background'] : '#2271b1';
		$btn_text   = isset( $style['button_text_color'] ) && $style['button_text_color'] ? $style['button_text_color'] : '#ffffff';
		$price_color = isset( $style['price_color'] ) && $style['price_color'] ? $style['price_color'] : '#2271b1';
		$radius     = isset( $style['border_radius'] ) ? absint( $style['border_radius'] ) : 8;
		$radius     = $radius <= 50 ? $radius : 8;

		$css = sprintf(
			'.wfcp-pricing-box{--wfcp-box-bg:%s;--wfcp-box-border:%s;--wfcp-box-radius:%dpx;--wfcp-btn-bg:%s;--wfcp-btn-text:%s;--wfcp-price-color:%s;}',
			esc_attr( $box_bg ),
			esc_attr( $box_border ),
			$radius,
			esc_attr( $btn_bg ),
			esc_attr( $btn_text ),
			esc_attr( $price_color )
		);
		wp_add_inline_style( 'wfcp-public-style', $css );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 */
	public function enqueue_scripts() {
		if ( ! is_product() ) {
			return;
		}

		wp_enqueue_script(
			'wfcp-public',
			WFCP_PLUGIN_URL . 'public/js/wfcp-public.js',
			array( 'jquery' ),
			WFCP_VERSION,
			false
		);

		wp_localize_script(
			'wfcp-public',
			'wfcpPublic',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wfcp_public_nonce' ),
			)
		);
	}

	/**
	 * Hide default WooCommerce add-to-cart when this product uses WFCP pricing box.
	 */
	public function maybe_hide_default_add_to_cart() {
		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! WFCP_Helper::is_enabled() ) {
			return;
		}
		if ( ! WFCP_Helper::get_product_purchase_price( $product->get_id() ) ) {
			return;
		}
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
	}

	/**
	 * Display pricing box on single product page
	 */
	public function display_pricing_box() {
		global $product;

		if ( ! $product || ! WFCP_Helper::is_enabled() ) {
			return;
		}

		require_once WFCP_PLUGIN_DIR . 'public/partials/wfcp-product-display.php';
	}
}

