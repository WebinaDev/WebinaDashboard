<?php
/**
 * Product pricing display template
 *
 * @package    WFCP
 * @subpackage WFCP/public/partials
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

global $product;

if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
	return;
}

$purchase_price = WFCP_Helper::get_product_purchase_price( $product->get_id() );

if ( ! $purchase_price ) {
	return;
}

$settings = WFCP_Helper::get_settings();
$notifications = $settings['notifications'] ?? array();

// Calculate prices
$retail_price = WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product->get_id() );

// Credit
$credit_enabled = WFCP_Helper::get_settings( 'credit', 'enabled' );
$credit_price   = 0;
if ( $credit_enabled ) {
	$credit_price = WFCP_Calculator::calculate_price( $purchase_price, 'credit', $product->get_id() );
}

// Installment
$installment_enabled = WFCP_Helper::get_settings( 'installment', 'enabled' );
$installment_plans  = array();
if ( $installment_enabled ) {
	$plans_config = WFCP_Helper::get_settings( 'installment', 'plans' );
	if ( is_array( $plans_config ) ) {
		foreach ( $plans_config as $plan ) {
			$months = isset( $plan['months'] ) ? intval( $plan['months'] ) : 0;
			if ( $months > 0 ) {
				$monthly_price = WFCP_Calculator::calculate_price( $purchase_price, 'installment', $product->get_id(), array( 'months' => $months ) );
				$installment_plans[] = array(
					'months'        => $months,
					'monthly_price' => $monthly_price,
					'total_price'  => $monthly_price * $months,
				);
			}
		}
	}
}

$credit_text      = $notifications['credit_text'] ?? 'خرید اعتباری';
$installment_text = $notifications['installment_text'] ?? 'خرید اقساطی';

// Payment gateways by type
$available_gateways = array();
if ( function_exists( 'WC' ) && WC()->payment_gateways ) {
	$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
}
$retail_gateway_ids     = isset( $settings['retail']['gateways'] ) && is_array( $settings['retail']['gateways'] ) ? $settings['retail']['gateways'] : array();
$installment_gateway_ids = isset( $settings['installment']['gateways'] ) && is_array( $settings['installment']['gateways'] ) ? $settings['installment']['gateways'] : array();
$credit_gateway_ids      = isset( $settings['credit']['gateways'] ) && is_array( $settings['credit']['gateways'] ) ? $settings['credit']['gateways'] : array();

$add_to_cart_label = __( 'افزودن به سبد خرید', 'webina-woo-core' );

/**
 * Output gateways list (logos + title + description)
 *
 * @param array $gateway_ids Gateway IDs.
 * @param array $available   Available gateways from WC.
 */
if ( ! function_exists( 'wfcp_render_gateways_list' ) ) {
function wfcp_render_gateways_list( $gateway_ids, $available ) {
	if ( empty( $gateway_ids ) || empty( $available ) ) {
		return;
	}
	echo '<ul class="wfcp-gateways-list">';
	foreach ( $gateway_ids as $gid ) {
		if ( ! isset( $available[ $gid ] ) ) {
			continue;
		}
		$gateway = $available[ $gid ];
		$icon    = $gateway->get_icon();
		$title   = $gateway->get_title();
		$desc    = $gateway->get_description();
		echo '<li class="wfcp-gateway-item">';
		if ( $icon ) {
			echo '<span class="wfcp-gateway-icon">' . wp_kses_post( $icon ) . '</span>';
		}
		echo '<span class="wfcp-gateway-info">';
		echo '<span class="wfcp-gateway-title">' . esc_html( $title ) . '</span>';
		if ( $desc ) {
			echo '<span class="wfcp-gateway-desc">' . wp_kses_post( $desc ) . '</span>';
		}
		echo '</span></li>';
	}
	echo '</ul>';
}
}

/**
 * Output gateways logos only (no title/description), small, for next to button.
 *
 * @param array $gateway_ids Gateway IDs.
 * @param array $available   Available gateways from WC.
 */
if ( ! function_exists( 'wfcp_render_gateways_logos_only' ) ) {
function wfcp_render_gateways_logos_only( $gateway_ids, $available ) {
	if ( empty( $gateway_ids ) || empty( $available ) ) {
		return;
	}
	echo '<ul class="wfcp-gateways-list wfcp-gateways-list--logos-only">';
	foreach ( $gateway_ids as $gid ) {
		if ( ! isset( $available[ $gid ] ) ) {
			continue;
		}
		$gateway = $available[ $gid ];
		$icon    = $gateway->get_icon();
		if ( ! $icon ) {
			continue;
		}
		echo '<li class="wfcp-gateway-item">';
		echo '<span class="wfcp-gateway-icon">' . wp_kses_post( $icon ) . '</span>';
		echo '</li>';
	}
	echo '</ul>';
}
}

/**
 * Quantity selector markup (reused in each row)
 */
if ( ! function_exists( 'wfcp_quantity_markup' ) ) {
function wfcp_quantity_markup() {
	?>
	<div class="wfcp-quantity-wrap">
		<button type="button" class="wfcp-qty-minus" aria-label="<?php esc_attr_e( 'کم کردن', 'webina-woo-core' ); ?>">−</button>
		<input type="number" class="wfcp-qty-input" value="1" min="1" step="1" aria-label="<?php esc_attr_e( 'تعداد', 'webina-woo-core' ); ?>">
		<button type="button" class="wfcp-qty-plus" aria-label="<?php esc_attr_e( 'افزودن', 'webina-woo-core' ); ?>">+</button>
	</div>
	<?php
}
}
?>

<div class="wfcp-pricing-box">
	<!-- Cash Row: خرید نقدی (same structure as installment/credit) -->
	<div class="wfcp-pricing-row cash">
		<div class="wfcp-pricing-info">
			<div class="wfcp-pricing-icon">💵</div>
			<div class="wfcp-pricing-details">
				<h3 class="wfcp-pricing-title"><?php esc_html_e( 'خرید نقدی', 'webina-woo-core' ); ?></h3>
				<p class="wfcp-pricing-amount"><?php echo wp_kses_post( WFCP_Helper::format_price_with_irt_symbol( $retail_price ) ); ?></p>
				<?php if ( ! empty( $notifications['cash_description'] ) ) : ?>
					<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['cash_description'] ); ?></div>
				<?php endif; ?>
				<?php wfcp_render_gateways_logos_only( $retail_gateway_ids, $available_gateways ); ?>
			</div>
		</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $retail_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-cash" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-purchase-type="cash" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>"><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
	</div>

	<?php if ( $installment_enabled && ! empty( $installment_plans ) ) : ?>
		<!-- Installment Row -->
		<div class="wfcp-pricing-row installment">
			<div class="wfcp-pricing-info">
				<div class="wfcp-pricing-icon">📅</div>
				<div class="wfcp-pricing-details">
					<h3 class="wfcp-pricing-title"><?php echo esc_html( $installment_text ); ?></h3>
					<div class="wfcp-installment-plans-list">
						<?php foreach ( $installment_plans as $index => $plan ) : ?>
							<div class="wfcp-installment-plan-item <?php echo 0 === $index ? 'active' : ''; ?>" data-months="<?php echo esc_attr( $plan['months'] ); ?>">
								<span class="wfcp-installment-plan-months"><?php printf( esc_html__( '%d ماهه', 'webina-woo-core' ), $plan['months'] ); ?></span>
								<span class="wfcp-installment-plan-price"><?php printf( esc_html__( 'هر قسط %s', 'webina-woo-core' ), wp_kses_post( WFCP_Helper::format_price_with_irt_symbol( $plan['monthly_price'] ) ) ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
					<?php if ( ! empty( $notifications['installment_description'] ) ) : ?>
						<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['installment_description'] ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $installment_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<?php $first_plan_months = $installment_plans[0]['months']; ?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-installment" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-purchase-type="installment" data-months="<?php echo esc_attr( $first_plan_months ); ?>" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>"><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $credit_enabled && $credit_price > 0 ) : ?>
		<!-- Credit Row -->
		<div class="wfcp-pricing-row credit">
			<div class="wfcp-pricing-info">
				<div class="wfcp-pricing-icon">💳</div>
				<div class="wfcp-pricing-details">
					<h3 class="wfcp-pricing-title"><?php echo esc_html( $credit_text ); ?></h3>
					<p class="wfcp-pricing-amount"><?php echo wp_kses_post( WFCP_Helper::format_price_with_irt_symbol( $credit_price ) ); ?></p>
					<?php if ( ! empty( $notifications['credit_description'] ) ) : ?>
						<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['credit_description'] ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $credit_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-credit" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-purchase-type="credit" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>"><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
		</div>
	<?php endif; ?>
</div>
