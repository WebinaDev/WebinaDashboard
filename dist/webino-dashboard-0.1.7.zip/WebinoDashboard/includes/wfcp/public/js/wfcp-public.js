/**
 * Public JavaScript
 *
 * @package    WFCP
 * @subpackage WFCP/public/js
 */

(function($) {
	'use strict';

	var addToCartText = 'افزودن به سبد خرید';
	var addingText   = 'در حال افزودن...';

	$(document).ready(function() {
		// Quantity +/- buttons
		$(document).on('click', '.wfcp-qty-minus', function() {
			var $wrap = $(this).closest('.wfcp-quantity-wrap');
			var $input = $wrap.find('.wfcp-qty-input');
			var val = parseInt($input.val(), 10) || 1;
			if (val > 1) {
				$input.val(val - 1);
			}
		});
		$(document).on('click', '.wfcp-qty-plus', function() {
			var $wrap = $(this).closest('.wfcp-quantity-wrap');
			var $input = $wrap.find('.wfcp-qty-input');
			var val = parseInt($input.val(), 10) || 1;
			$input.val(val + 1);
		});

		// Add to cart: all buttons (cash, installment, credit) – no default form, always AJAX
		$(document).on('click', '.wfcp-btn-add', function(e) {
			e.preventDefault();
			var $button = $(this);
			var $row = $button.closest('.wfcp-pricing-row');
			var quantity = 1;
			var $qtyInput = $row.find('.wfcp-qty-input');
			if ($qtyInput.length) {
				quantity = parseInt($qtyInput.val(), 10) || 1;
				if (quantity < 1) quantity = 1;
			}
			var purchaseType = $button.data('purchase-type') || 'cash';
			var productId = $button.data('product-id');
			var months = $button.data('months');
			if (purchaseType === 'installment') {
				var $selectedPlan = $('.wfcp-installment-plan-item.active');
				if ($selectedPlan.length) {
					months = $selectedPlan.data('months') || months;
				}
			}
			addToCartAjax(productId, purchaseType, $button, months, quantity);
		});

		// Installment plan selection
		$(document).on('click', '.wfcp-installment-plan-item', function() {
			var $item = $(this);
			var months = $item.data('months');
			var $button = $('.wfcp-btn-add-installment');
			if ($button.length) {
				$button.data('months', months);
			}
			$('.wfcp-installment-plan-item').removeClass('active');
			$item.addClass('active');
		});
	});

	function addToCartAjax(productId, purchaseType, $button, months, quantity) {
		quantity = quantity || 1;
		var originalText = $button.data('original-text') || addToCartText;
		$button.prop('disabled', true).text(addingText);

		var ajaxUrl = typeof wc_add_to_cart_params !== 'undefined'
			? wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'add_to_cart')
			: wfcpPublic.ajaxUrl;

		var data = {
			product_id: productId,
			purchase_type: purchaseType,
			quantity: quantity
		};
		if (purchaseType === 'installment' && months) {
			data.installment_months = months;
		}

		$.ajax({
			url: ajaxUrl,
			type: 'POST',
			data: data,
			success: function(response) {
				if (response.error && response.product_url) {
					window.location = response.product_url;
					return;
				}
				if (typeof wc_add_to_cart_params !== 'undefined') {
					$(document.body).trigger('added_to_cart', [response.fragments || {}, response.cart_hash || '', $button]);
				}
				if (response.message) {
					showMessage(response.message, 'success');
				} else {
					showMessage('محصول با موفقیت به سبد خرید اضافه شد', 'success');
				}
				$button.prop('disabled', false).text(originalText);
			},
			error: function() {
				showMessage('خطا در افزودن به سبد خرید', 'error');
				$button.prop('disabled', false).text(originalText);
			}
		});
	}

	function showMessage(message, type) {
		type = type || 'info';
		if (typeof wc_add_to_cart_params !== 'undefined') {
			$(document.body).trigger('wc_add_to_cart', { fragments: {}, cart_hash: '', button: null });
		}
		var $message = $('<div class="wfcp-message wfcp-message-' + type + '">' + message + '</div>');
		$('.wfcp-pricing-box').before($message);
		setTimeout(function() {
			$message.fadeOut(function() {
				$(this).remove();
			});
		}, 3000);
	}

})(jQuery);
