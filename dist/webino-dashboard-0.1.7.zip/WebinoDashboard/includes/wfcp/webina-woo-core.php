<?php
/**
 * Plugin Name: Webina Woo Core
 * Plugin URI: https://webina.dev
 * Description: سیستم پیشرفته مدیریت قیمت‌گذاری چند لایه برای ووکامرس (تکی، اعتباری، اقساطی، عمده)
 * Version: 1.1.0
 * Author: توسعه و طراحی وبینا
 * Author URI: https://webina.dev
 * Text Domain: webina-woo-core
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 */
define( 'WFCP_VERSION', '1.1.0' );
define( 'WFCP_PLUGIN_NAME', 'webina-woo-core' );
define( 'WFCP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WFCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WFCP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Check if WooCommerce is active
 */
function wfcp_check_woocommerce() {
	// Check if WooCommerce plugin is active
	if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ), true ) ) {
		// Also check for network activated plugins (multisite)
		if ( is_multisite() ) {
			$active_plugins = get_site_option( 'active_sitewide_plugins', array() );
			if ( ! isset( $active_plugins['woocommerce/woocommerce.php'] ) ) {
				add_action( 'admin_notices', 'wfcp_woocommerce_missing_notice' );
				return false;
			}
		} else {
			add_action( 'admin_notices', 'wfcp_woocommerce_missing_notice' );
			return false;
		}
	}
	
	// Double check class exists
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'wfcp_woocommerce_missing_notice' );
		return false;
	}
	
	return true;
}

/**
 * WooCommerce missing notice
 */
function wfcp_woocommerce_missing_notice() {
	?>
	<div class="notice notice-error">
		<p><?php esc_html_e( 'Webina Woo Core requires WooCommerce to be installed and active.', 'webina-woo-core' ); ?></p>
	</div>
	<?php
}

/**
 * The code that runs during plugin activation.
 */
function activate_wfcp() {
	require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-activator.php';
	WFCP_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_wfcp() {
	require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-deactivator.php';
	WFCP_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wfcp' );
register_deactivation_hook( __FILE__, 'deactivate_wfcp' );

/**
 * Begins execution of the plugin.
 * Use plugins_loaded hook to ensure WooCommerce is loaded first.
 */
function run_wfcp() {
	// Wait for plugins to be loaded, especially WooCommerce
	add_action( 'plugins_loaded', 'wfcp_init', 20 );
}

/**
 * Initialize the plugin after WooCommerce is loaded
 */
function wfcp_init() {
	if ( ! wfcp_check_woocommerce() ) {
		return;
	}

	/**
	 * The core plugin class that is used to define internationalization,
	 * admin-specific hooks, and public-facing site hooks.
	 */
	require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-loader.php';
	require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-i18n.php';
	require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-main.php';
	require_once WFCP_PLUGIN_DIR . 'includes/utilities/class-wfcp-helper.php';
	require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-calculator.php';
	require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-cart-manager.php';
	require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-batch-process.php';

	// Bulk Price Change service
	require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-bulk-price-change.php';

	$loader = new WFCP_Loader();
	$plugin = new WFCP_Main( $loader );
	$plugin->run();
}

// Initialize plugin
run_wfcp();

