<?php
/**
 * REST API for dashboard SPA.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers routes under webino-dashboard/v1.
 */
class Webino_Dashboard_REST {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/bootstrap',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'bootstrap' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
			)
		);

		register_rest_route(
			self::NS,
			'/license/remote-check',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'license_remote_check' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_manage_license' ),
			)
		);

		register_rest_route(
			self::NS,
			'/license/remote-activate',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'license_remote_activate' ),
				'permission_callback' => static function () {
					return current_user_can( 'manage_options' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/license/diagnostics',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'license_diagnostics' ),
				'permission_callback' => static function () {
					return current_user_can( 'manage_options' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/auth/session',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'auth_session' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/auth/login',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'auth_login' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/auth/logout',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'auth_logout' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
			)
		);

		register_rest_route(
			self::NS,
			'/webinocrm/v1/license/check',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'license_check' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/webinocrm/v1/license/activate',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'license_activate' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/module/(?P<slug>[a-z0-9\-]+)/licensed',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'module_licensed' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
			)
		);

		register_rest_route(
			self::NS,
			'/analytics/summary',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'analytics_summary' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_view_analytics' ),
			)
		);

		register_rest_route(
			self::NS,
			'/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'settings_get' ),
					'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'settings_post' ),
					'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_read' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/manifest.webmanifest',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'manifest' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'shop_products' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_products' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/shop/products/(?P<id>\d+)/wfcp',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( __CLASS__, 'shop_product_wfcp_patch' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_products' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/accounting/summary',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'accounting_summary' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_view_accounting' ),
			)
		);

		register_rest_route(
			self::NS,
			'/accounting/(?P<resource>[a-z\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'accounting_list' ),
				'permission_callback' => array( 'Webino_Dashboard_Rest_Base', 'can_view_accounting' ),
			)
		);

		register_rest_route(
			self::NS,
			'/content/posts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'content_posts' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_posts' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/content/pages',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'content_pages' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_pages' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/content/media',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'content_media' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'upload_files' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/shop/orders',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'shop_orders' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_shop_orders' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/marketing/coupons',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'marketing_coupons' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_shop_coupons' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/shop/attributes',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'shop_attributes' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'edit_products' );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/users',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'users_list' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'list_users' );
					},
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'users_create' ),
					'permission_callback' => function () {
						return Webino_Dashboard_Rest_Base::can( 'create_users' );
					},
				),
			)
		);

		register_rest_route(
			self::NS,
			'/comments',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'comments_list' ),
				'permission_callback' => function () {
					return Webino_Dashboard_Rest_Base::can( 'moderate_comments' );
				},
			)
		);
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function bootstrap() {
		$uid    = get_current_user_id();
		$ui_loc = $uid ? (string) get_user_meta( $uid, 'webino_dashboard_locale', true ) : '';
		$locale = $ui_loc ? $ui_loc : determine_locale();

		$modules = Webino_Dashboard_Modules::get_default_modules();
		$modules = self::filter_modules_by_capabilities( $modules );
		$modules = self::filter_modules_without_wfcp( $modules );
		$modules = self::filter_modules_without_woocommerce( $modules );
		$modules = self::filter_inactive_modules( $modules );

		$ui_theme = $uid ? (string) get_user_meta( $uid, 'webino_dashboard_theme', true ) : '';

		$cap_whitelist = array(
			'read',
			'edit_posts',
			'delete_posts',
			'manage_categories',
			'upload_files',
			'edit_pages',
			'delete_pages',
			'edit_products',
			'manage_product_terms',
			'edit_shop_orders',
			'view_woocommerce_reports',
			'edit_shop_coupons',
			'manage_woocommerce',
			'list_users',
			'create_users',
			'edit_users',
			'delete_users',
			'moderate_comments',
			'manage_options',
		);
		$capabilities = array();
		foreach ( $cap_whitelist as $c ) {
			if ( current_user_can( $c ) ) {
				$capabilities[] = $c;
			}
		}

		$ui_accent = $uid ? (string) get_user_meta( $uid, 'webino_dashboard_accent', true ) : '';
		$ui_fs     = $uid ? (string) get_user_meta( $uid, 'webino_dashboard_fullscreen', true ) : '';

		$wp_user = wp_get_current_user();
		$user    = array(
			'name'   => ( $wp_user && $wp_user->exists() ) ? (string) $wp_user->display_name : '',
			'email'  => ( $wp_user && $wp_user->exists() ) ? (string) $wp_user->user_email : '',
			'avatar' => ( $wp_user && $wp_user->exists() ) ? (string) get_avatar_url( $wp_user->ID, array( 'size' => 64 ) ) : '',
		);

		return new WP_REST_Response(
			array(
				'modules'      => $modules,
				'locale'       => $locale,
				'uiTheme'      => $ui_theme ? $ui_theme : 'system',
				'uiAccent'     => $ui_accent ? $ui_accent : 'default',
				'uiFullscreen' => ( '1' === $ui_fs || 'true' === $ui_fs ),
				'capabilities' => $capabilities,
				'user'         => $user,
				'site'         => array(
					'name' => get_bloginfo( 'name' ),
					'url'  => home_url( '/' ),
					'icon' => self::site_icon_url(),
				),
				'flags'        => array(
					'woocommerce'  => class_exists( 'WooCommerce' ),
					'wfcp'         => class_exists( 'WFCP_Helper' ),
					'baleBot'      => class_exists( 'WooCommerce' ) && self::bot_token_configured( 'bale' ),
					'telegramBot'  => class_exists( 'WooCommerce' ) && self::bot_token_configured( 'telegram' ),
				),
				'license'      => Webino_Dashboard_License::instance()->get_bootstrap_payload(),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function license_remote_check() {
		$out = Webino_Dashboard_License::instance()->remote_license_check( true );
		return new WP_REST_Response( $out );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function license_remote_activate() {
		$out = Webino_Dashboard_License::instance()->remote_activate();
		return new WP_REST_Response( $out );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function license_diagnostics() {
		$out = Webino_Dashboard_License::instance()->run_license_diagnostics();
		return new WP_REST_Response( $out );
	}

	/**
	 * Remove modules disabled via options (webino_dashboard_module_{id}_active). Overview (home) is always shown.
	 *
	 * @param array<int, array<string, mixed>> $modules Modules.
	 * @return array<int, array<string, mixed>>
	 */
	private static function filter_inactive_modules( $modules ) {
		$out = array();
		foreach ( $modules as $m ) {
			$kept = self::filter_inactive_module_node( $m );
			if ( null !== $kept ) {
				$out[] = $kept;
			}
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $m Module node.
	 * @return array<string,mixed>|null
	 */
	private static function filter_inactive_module_node( $m ) {
		if ( ! is_array( $m ) ) {
			return null;
		}
		$mid = isset( $m['id'] ) ? (string) $m['id'] : '';

		if ( ! empty( $m['children'] ) && is_array( $m['children'] ) ) {
			$kids = array();
			foreach ( $m['children'] as $c ) {
				$child = self::filter_inactive_module_node( $c );
				if ( null !== $child ) {
					$kids[] = $child;
				}
			}
			$m['children'] = $kids;
			if ( empty( $kids ) ) {
				return null;
			}
			$ignore_parent = ! empty( $m['ignore_parent_toggle'] );
			if ( ! $ignore_parent && $mid && ! Webino_Dashboard_Modules::is_module_enabled( $mid ) ) {
				return null;
			}
			return $m;
		}

		if ( $mid && ! Webino_Dashboard_Modules::is_module_enabled( $mid ) ) {
			return null;
		}
		return $m;
	}

	/**
	 * Remove WFCP-only nodes when the core is not loaded.
	 *
	 * @param array<int, array<string, mixed>> $modules Modules.
	 * @return array<int, array<string, mixed>>
	 */
	private static function filter_modules_without_wfcp( $modules ) {
		if ( class_exists( 'WFCP_Helper', false ) ) {
			return $modules;
		}
		$out = array();
		foreach ( $modules as $m ) {
			$pruned = self::strip_wfcp_required_nodes( $m );
			if ( null !== $pruned ) {
				$out[] = $pruned;
			}
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $m Module node.
	 * @return array<string,mixed>|null
	 */
	private static function strip_wfcp_required_nodes( $m ) {
		if ( ! is_array( $m ) ) {
			return null;
		}
		if ( ! empty( $m['requires_wfcp'] ) ) {
			return null;
		}
		if ( ! empty( $m['children'] ) && is_array( $m['children'] ) ) {
			$kids = array();
			foreach ( $m['children'] as $c ) {
				$child = self::strip_wfcp_required_nodes( $c );
				if ( null !== $child ) {
					$kids[] = $child;
				}
			}
			$m['children'] = $kids;
			if ( empty( $kids ) ) {
				$mid = isset( $m['id'] ) ? (string) $m['id'] : '';
				if ( '' === $mid ) {
					return null;
				}
			}
		}
		return $m;
	}

	/**
	 * Remove modules that require WooCommerce when WC is inactive.
	 *
	 * @param array<int, array<string, mixed>> $modules Modules.
	 * @return array<int, array<string, mixed>>
	 */
	private static function filter_modules_without_woocommerce( $modules ) {
		if ( class_exists( 'WooCommerce', false ) ) {
			return $modules;
		}
		$out = array();
		foreach ( $modules as $m ) {
			$pruned = self::strip_woocommerce_required_nodes( $m );
			if ( null !== $pruned ) {
				$out[] = $pruned;
			}
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $m Module node.
	 * @return array<string,mixed>|null
	 */
	private static function strip_woocommerce_required_nodes( $m ) {
		if ( ! is_array( $m ) ) {
			return null;
		}
		if ( ! empty( $m['requires_woocommerce'] ) ) {
			return null;
		}
		if ( ! empty( $m['children'] ) && is_array( $m['children'] ) ) {
			$kids = array();
			foreach ( $m['children'] as $c ) {
				$child = self::strip_woocommerce_required_nodes( $c );
				if ( null !== $child ) {
					$kids[] = $child;
				}
			}
			$m['children'] = $kids;
			if ( empty( $kids ) ) {
				$mid = isset( $m['id'] ) ? (string) $m['id'] : '';
				if ( '' === $mid ) {
					return null;
				}
			}
		}
		return $m;
	}

	/**
	 * @param string $which bale|telegram.
	 * @return bool
	 */
	private static function bot_token_configured( $which ) {
		$opt = ( 'telegram' === $which ) ? 'webino_dashboard_telegram_bot_settings' : 'webino_dashboard_bale_bot_settings';
		$s   = get_option( $opt, array() );
		if ( ! is_array( $s ) ) {
			return false;
		}
		$t = isset( $s['bot_token'] ) ? trim( (string) $s['bot_token'] ) : '';
		return '' !== $t;
	}

	/**
	 * @param array<int, array<string, mixed>> $modules Modules.
	 * @return array<int, array<string, mixed>>
	 */
	private static function filter_modules_by_capabilities( $modules ) {
		$out = array();
		foreach ( $modules as $m ) {
			$kept = self::filter_module_cap_node( $m, 'read' );
			if ( null !== $kept ) {
				$out[] = $kept;
			}
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $m          Module node.
	 * @param string              $parent_cap Default capability from parent.
	 * @return array<string,mixed>|null
	 */
	private static function filter_module_cap_node( $m, $parent_cap = 'read' ) {
		if ( ! is_array( $m ) ) {
			return null;
		}
		$cap = isset( $m['capability'] ) ? (string) $m['capability'] : $parent_cap;
		if ( ! empty( $m['children'] ) && is_array( $m['children'] ) ) {
			$kids = array();
			foreach ( $m['children'] as $c ) {
				$child = self::filter_module_cap_node( $c, $cap );
				if ( null !== $child ) {
					$kids[] = $child;
				}
			}
			if ( empty( $kids ) ) {
				return null;
			}
			$m['children'] = $kids;
			return $m;
		}
		if ( ! current_user_can( $cap ) ) {
			return null;
		}
		return $m;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	/**
	 * @return WP_REST_Response
	 */
	public static function auth_session() {
		$logged = is_user_logged_in();
		$out    = array( 'logged_in' => $logged );
		if ( $logged ) {
			$u = wp_get_current_user();
			$out['user'] = array(
				'id'    => (int) $u->ID,
				'login' => $u->user_login,
				'name'  => $u->display_name,
			);
		}
		return new WP_REST_Response( $out );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function auth_login( $request ) {
		if ( ! Webino_Dashboard_Rest_Base::rate_limit_ok( 'login', 30, 300 ) ) {
			return new WP_Error( 'too_many', __( 'Too many attempts.', 'webino-dashboard' ), array( 'status' => 429 ) );
		}

		if ( ! Webino_Dashboard_Rest_Base::verify_login_nonce( (string) $request->get_param( 'login_nonce' ) ) ) {
			return new WP_Error( 'invalid_nonce', __( 'Invalid login token. Refresh the page and try again.', 'webino-dashboard' ), array( 'status' => 403 ) );
		}

		$login    = (string) $request->get_param( 'login' );
		$password = (string) $request->get_param( 'password' );
		if ( '' === $login || '' === $password ) {
			return new WP_Error( 'invalid', __( 'Missing credentials.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}

		$user = Webino_Dashboard_Rest_Base::resolve_user_from_login( $login );
		if ( ! $user ) {
			return new WP_Error( 'invalid', __( 'Invalid credentials.', 'webino-dashboard' ), array( 'status' => 401 ) );
		}

		$creds = array(
			'user_login'    => $user->user_login,
			'user_password' => $password,
			'remember'      => (bool) $request->get_param( 'remember' ),
		);

		$signon = wp_signon( $creds, is_ssl() );
		if ( is_wp_error( $signon ) ) {
			return new WP_Error( 'invalid', __( 'Invalid credentials.', 'webino-dashboard' ), array( 'status' => 401 ) );
		}

		wp_set_current_user( $signon->ID );

		return new WP_REST_Response(
			array(
				'success' => true,
				'user'    => array(
					'id'    => $signon->ID,
					'login' => $signon->user_login,
					'name'  => $signon->display_name,
				),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function auth_logout() {
		wp_logout();
		return new WP_REST_Response( array( 'success' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function license_check( $request ) {
		if ( ! Webino_Dashboard_Rest_Base::rate_limit_ok( 'license_check', 60, 300 ) ) {
			return new WP_Error( 'too_many', __( 'Too many attempts.', 'webino-dashboard' ), array( 'status' => 429 ) );
		}

		global $wpdb;
		$table  = Webino_Dashboard_Rest_Base::licenses_table();
		$domain = (string) $request->get_param( 'domain' );
		if ( '' === $domain ) {
			$domain = wp_parse_url( home_url(), PHP_URL_HOST );
		}
		$key = (string) $request->get_param( 'license_key' );

		if ( $key ) {
			$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE domain = %s AND license_key = %s ORDER BY id DESC LIMIT 1", $domain, $key );
		} else {
			$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE domain = %s ORDER BY id DESC LIMIT 1", $domain );
		}

		$row = $wpdb->get_row( $sql, ARRAY_A );
		if ( ! $row ) {
			return new WP_REST_Response( array( 'data' => array( 'status' => 'invalid', 'expiry_date' => null, 'remaining_days' => 0, 'remaining_percentage' => 0 ) ) );
		}

		$exp        = $row['expires_at'] ? strtotime( $row['expires_at'] . ' UTC' ) : null;
		$valid_time = ! $exp || $exp > time();
		$max_users  = isset( $row['max_users'] ) ? (int) $row['max_users'] : 0;
		$user_count = (int) $wpdb->get_var( "SELECT COUNT(ID) FROM {$wpdb->users}" );
		$valid      = 'active' === $row['status'] && $valid_time && ( $max_users <= 0 || $user_count <= $max_users );

		$remaining = $exp ? max( 0, (int) floor( ( $exp - time() ) / DAY_IN_SECONDS ) ) : 365;

		return new WP_REST_Response(
			array(
				'data' => array(
					'status'                 => $valid ? 'valid' : 'invalid',
					'expiry_date'            => $row['expires_at'] ? gmdate( 'Y-m-d', strtotime( $row['expires_at'] ) ) : null,
					'remaining_days'         => $remaining,
					'remaining_percentage'   => $exp ? min( 100, $remaining ) : 100,
				),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function license_activate( $request ) {
		if ( ! Webino_Dashboard_Rest_Base::rate_limit_ok( 'license_activate', 20, 300 ) ) {
			return new WP_Error( 'too_many', __( 'Too many attempts.', 'webino-dashboard' ), array( 'status' => 429 ) );
		}

		$domain = sanitize_text_field( (string) $request->get_param( 'domain' ) );
		$key    = sanitize_text_field( (string) $request->get_param( 'license_key' ) );
		if ( '' === $domain || '' === $key ) {
			return new WP_Error( 'invalid', 'domain and license_key required', array( 'status' => 400 ) );
		}

		global $wpdb;
		$table = Webino_Dashboard_Rest_Base::licenses_table();

		$expires_at = $request->get_param( 'expires_at' );
		$max_users  = $request->get_param( 'max_users' );

		$data = array(
			'domain'     => $domain,
			'license_key'=> $key,
			'status'     => 'active',
			'expires_at' => $expires_at ? gmdate( 'Y-m-d H:i:s', strtotime( (string) $expires_at ) ) : null,
			'max_users'  => null !== $max_users ? (int) $max_users : 0,
			'meta'       => wp_json_encode( array( 'activated_via' => 'api' ) ),
			'updated_at' => current_time( 'mysql', true ),
		);

		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE domain = %s AND license_key = %s LIMIT 1", $domain, $key ) );
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing ) );
			$id = (int) $existing;
		} else {
			$data['created_at'] = current_time( 'mysql', true );
			$wpdb->insert( $table, $data );
			$id = (int) $wpdb->insert_id;
		}

		return new WP_REST_Response(
			array(
				'data' => array(
					'status'     => 'ok',
					'message'    => 'License stored',
					'license_id' => $id,
				),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function module_licensed( $request ) {
		$slug = sanitize_key( (string) $request['slug'] );
		$ok    = (bool) get_option( 'webino_dashboard_module_' . $slug . '_active', true );
		return new WP_REST_Response( array( 'licensed' => $ok ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function analytics_summary( $request ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new WP_REST_Response(
				array(
					'period_days'   => 30,
					'order_count'   => 0,
					'revenue'       => 0,
					'currency'      => '',
					'from'          => time() - 30 * DAY_IN_SECONDS,
					'to'            => time(),
					'from_date'     => gmdate( 'c', time() - 30 * DAY_IN_SECONDS ),
					'to_date'       => gmdate( 'c', time() ),
					'note'          => 'WooCommerce inactive',
					'daily_revenue' => array(),
				)
			);
		}

		$days = (int) $request->get_param( 'days' );
		if ( $days < 1 ) {
			$days = 30;
		}
		$days = min( 365, $days );

		$to_ts   = time();
		$from_ts = $to_ts - $days * DAY_IN_SECONDS;
		$after   = gmdate( 'Y-m-d H:i:s', $from_ts );

		$orders = wc_get_orders(
			array(
				'limit'        => -1,
				'status'       => array( 'completed', 'processing' ),
				'date_created' => '>' . $after,
				'return'       => 'ids',
			)
		);

		$revenue = 0.0;
		$daily   = array();
		foreach ( $orders as $oid ) {
			$o = wc_get_order( $oid );
			if ( ! $o ) {
				continue;
			}
			$amt = (float) $o->get_total();
			$revenue += $amt;
			$dc      = $o->get_date_created();
			$day_key = $dc ? $dc->date( 'Y-m-d' ) : gmdate( 'Y-m-d', $to_ts );
			if ( ! isset( $daily[ $day_key ] ) ) {
				$daily[ $day_key ] = 0.0;
			}
			$daily[ $day_key ] += $amt;
		}
		ksort( $daily );
		$daily_out = array();
		foreach ( $daily as $d => $sum ) {
			$daily_out[] = array(
				'date'    => $d,
				'revenue' => $sum,
			);
		}

		return new WP_REST_Response(
			array(
				'period_days'   => $days,
				'order_count'   => count( $orders ),
				'revenue'       => $revenue,
				'currency'      => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '',
				'from'          => $from_ts,
				'to'            => $to_ts,
				'from_date'     => gmdate( 'c', $from_ts ),
				'to_date'       => gmdate( 'c', $to_ts ),
				'daily_revenue' => $daily_out,
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		$user_id = get_current_user_id();
		$body    = array(
			'ui_locale'             => get_user_meta( $user_id, 'webino_dashboard_locale', true ) ?: '',
			'ui_theme'              => get_user_meta( $user_id, 'webino_dashboard_theme', true ) ?: 'system',
			'ui_accent'             => get_user_meta( $user_id, 'webino_dashboard_accent', true ) ?: 'default',
			'ui_fullscreen_default' => ( '1' === (string) get_user_meta( $user_id, 'webino_dashboard_fullscreen', true ) ),
		);
		if ( current_user_can( 'manage_options' ) ) {
			$body['dashboard_modules'] = self::settings_dashboard_modules_payload();
		}
		return new WP_REST_Response( $body );
	}

	/**
	 * Whether a module slug is enabled (option); overview (home) is always on.
	 *
	 * @param string $slug Module id.
	 * @return bool
	 */
	/**
	 * Top-level + nested module ids/titles with active flag for settings UI.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function settings_dashboard_modules_payload() {
		$mods = Webino_Dashboard_Modules::get_default_modules();
		$out  = array();
		foreach ( $mods as $m ) {
			self::settings_modules_payload_walk( $m, $out, '' );
		}
		return $out;
	}

	/**
	 * @param array<string,mixed>    $node   Module node.
	 * @param array<int,array<string,mixed>> $out    Accumulator.
	 * @param string                 $prefix Title prefix for nested items.
	 * @return void
	 */
	private static function settings_modules_payload_walk( $node, array &$out, $prefix ) {
		if ( ! is_array( $node ) ) {
			return;
		}
		$id = isset( $node['id'] ) ? (string) $node['id'] : '';
		if ( $id && empty( $node['exclude_from_module_toggle'] ) ) {
			$title = isset( $node['title'] ) ? (string) $node['title'] : $id;
			if ( $prefix ) {
				$title = $prefix . ' — ' . $title;
			}
			$out[] = array(
				'id'     => $id,
				'title'  => $title,
				'active' => Webino_Dashboard_Modules::is_module_enabled( $id ),
			);
		}
		if ( ! empty( $node['children'] ) && is_array( $node['children'] ) ) {
			$group = isset( $node['title'] ) && ! $id ? (string) $node['title'] : '';
			$next  = $prefix;
			if ( $group && ! $id ) {
				$next = $prefix ? $prefix . ' / ' . $group : $group;
			}
			foreach ( $node['children'] as $c ) {
				self::settings_modules_payload_walk( $c, $out, $next );
			}
		}
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_post( $request ) {
		$user_id = get_current_user_id();
		$loc     = sanitize_text_field( (string) $request->get_param( 'ui_locale' ) );
		$theme   = sanitize_key( (string) $request->get_param( 'ui_theme' ) );
		$accent  = sanitize_key( (string) $request->get_param( 'ui_accent' ) );
		if ( $loc ) {
			update_user_meta( $user_id, 'webino_dashboard_locale', $loc );
		}
		if ( $theme ) {
			update_user_meta( $user_id, 'webino_dashboard_theme', $theme );
		}
		if ( $accent ) {
			$allowed = array( 'default', 'red', 'rose', 'orange', 'green', 'blue', 'yellow', 'violet' );
			if ( in_array( $accent, $allowed, true ) ) {
				update_user_meta( $user_id, 'webino_dashboard_accent', $accent );
			}
		}
		if ( null !== $request->get_param( 'ui_fullscreen_default' ) ) {
			update_user_meta( $user_id, 'webino_dashboard_fullscreen', ! empty( $request->get_param( 'ui_fullscreen_default' ) ) ? '1' : '0' );
		}
		$mods_param = $request->get_param( 'modules' );
		if ( is_array( $mods_param ) && current_user_can( 'manage_options' ) ) {
			$allowed = array_flip( Webino_Dashboard_Modules::collect_module_ids( Webino_Dashboard_Modules::get_default_modules() ) );
			foreach ( $mods_param as $slug => $active ) {
				$slug = sanitize_key( (string) $slug );
				if ( 'settings' === $slug ) {
					$slug = 'settings-app';
				}
				if ( '' === $slug || 'home' === $slug || ! isset( $allowed[ $slug ] ) ) {
					continue;
				}
				update_option( 'webino_dashboard_module_' . $slug . '_active', ! empty( $active ) ? '1' : '0' );
				if ( 'settings-app' === $slug ) {
					update_option( 'webino_dashboard_module_settings_active', ! empty( $active ) ? '1' : '0' );
				}
			}
		}
		return self::settings_get();
	}

	/**
	 * Absolute URL for Open Graph / PWA branding.
	 *
	 * @return string
	 */
	public static function site_icon_url() {
		$icon = get_site_icon_url();
		if ( $icon ) {
			return $icon;
		}
		return plugins_url( 'assets/dashboard-build/favicon.svg', WEBINO_DASHBOARD_FILE );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function manifest() {
		$body = array(
			'name'               => get_bloginfo( 'name' ) . ' — ' . __( 'Dashboard', 'webino-dashboard' ),
			'short_name'         => 'Dashboard',
			'start_url'          => home_url( '/dashboard/' ),
			'display'            => 'standalone',
			'background_color'   => '#ffffff',
			'theme_color'        => '#0f172a',
		);
		$res = new WP_REST_Response( $body );
		$res->header( 'Content-Type', 'application/manifest+json; charset=' . get_option( 'blog_charset' ) );
		return $res;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function shop_products( $request ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}

		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$search   = sanitize_text_field( (string) $request->get_param( 'search' ) );

		$args = array(
			'status' => array( 'publish', 'draft', 'pending' ),
			'limit'  => $per_page,
			'page'   => $page,
			'return' => 'objects',
		);
		if ( $search ) {
			$args['s'] = $search;
		}

		$products = wc_get_products( $args );
		$out      = array();
		foreach ( $products as $p ) {
			$out[] = self::map_product_row( $p );
		}

		return new WP_REST_Response(
			array(
				'items' => $out,
				'page'  => $page,
			)
		);
	}

	/**
	 * @param WC_Product $p Product.
	 * @return array<string,mixed>
	 */
	public static function map_product_row( $p ) {
		$id = $p->get_id();
		$row = array(
			'id'                  => $id,
			'name'                => $p->get_name(),
			'sku'                 => $p->get_sku(),
			'status'              => $p->get_status(),
			'type'                => $p->get_type(),
			'price'               => $p->get_price(),
			'regular'             => $p->get_regular_price(),
			'sale'                => $p->get_sale_price(),
			'description'         => $p->get_description(),
			'short_description'   => $p->get_short_description(),
			'manage_stock'        => $p->get_manage_stock(),
			'stock'               => $p->get_stock_quantity(),
			'stock_status'        => $p->get_stock_status(),
			'image_id'            => (int) $p->get_image_id(),
			'gallery_ids'         => array_map( 'intval', (array) $p->get_gallery_image_ids() ),
			'category_ids'      => array_map( 'intval', (array) $p->get_category_ids() ),
			'brand_ids'           => array(),
			'product_attributes'  => array(),
			'weight'              => $p->get_weight(),
			'length'              => $p->get_length(),
			'width'               => $p->get_width(),
			'height'              => $p->get_height(),
		);

		if ( taxonomy_exists( 'product_brand' ) ) {
			$bids = wp_get_post_terms( $id, 'product_brand', array( 'fields' => 'ids' ) );
			$row['brand_ids'] = is_wp_error( $bids ) ? array() : array_map( 'intval', $bids );
		}

		foreach ( $p->get_attributes() as $attr ) {
			if ( ! is_a( $attr, 'WC_Product_Attribute' ) ) {
				continue;
			}
			$row['product_attributes'][] = array(
				'name'       => $attr->get_name(),
				'options'    => $attr->get_options(),
				'variation'  => $attr->get_variation(),
				'visible'    => $attr->get_visible(),
				'taxonomy'   => $attr->is_taxonomy(),
				'attribute_id' => $attr->get_id(),
			);
		}

		$row['virtual']             = $p->get_virtual();
		$row['downloadable']        = $p->get_downloadable();
		$row['catalog_visibility']  = $p->get_catalog_visibility();
		$row['featured']            = $p->get_featured();
		$row['sold_individually']   = $p->get_sold_individually();
		$row['backorders']          = $p->get_backorders();
		$row['low_stock_amount']    = $p->get_low_stock_amount();
		$row['shipping_class_id']   = $p->get_shipping_class_id();
		$row['tax_status']          = $p->get_tax_status();
		$row['tax_class']           = $p->get_tax_class();
		$row['upsell_ids']          = array_map( 'intval', $p->get_upsell_ids() );
		$row['cross_sell_ids']      = array_map( 'intval', $p->get_cross_sell_ids() );
		$row['purchase_note']       = $p->get_purchase_note();
		$row['menu_order']          = $p->get_menu_order();
		$dsf                        = $p->get_date_on_sale_from();
		$dst                        = $p->get_date_on_sale_to();
		$row['date_on_sale_from']   = $dsf ? $dsf->format( 'c' ) : null;
		$row['date_on_sale_to']     = $dst ? $dst->format( 'c' ) : null;
		$tids                       = wp_get_post_terms( $id, 'product_tag', array( 'fields' => 'ids' ) );
		$row['tag_ids']             = is_wp_error( $tids ) ? array() : array_map( 'intval', $tids );
		$row['variation_ids']       = $p->is_type( 'variable' ) ? array_map( 'intval', $p->get_children() ) : array();

		if ( $p->is_type( 'grouped' ) ) {
			$row['grouped_children_ids'] = array_map( 'intval', $p->get_children() );
		} else {
			$row['grouped_children_ids'] = array();
		}

		if ( $p->is_type( 'external' ) ) {
			$row['product_url'] = $p->get_product_url();
			$row['button_text'] = $p->get_button_text();
		} else {
			$row['product_url'] = '';
			$row['button_text'] = '';
		}

		if ( $p->is_downloadable() && method_exists( $p, 'get_downloads' ) ) {
			$dls = array();
			foreach ( $p->get_downloads() as $dl ) {
				if ( is_object( $dl ) && method_exists( $dl, 'get_file' ) ) {
					$dls[] = array(
						'name' => method_exists( $dl, 'get_name' ) ? $dl->get_name() : '',
						'file' => $dl->get_file(),
						'id'   => method_exists( $dl, 'get_id' ) ? $dl->get_id() : '',
					);
				}
			}
			$row['downloads'] = $dls;
		} else {
			$row['downloads'] = array();
		}

		$row['wfcp'] = array(
			'purchase_price' => get_post_meta( $id, '_wfcp_purchase_price', true ),
			'lock_price'     => (bool) get_post_meta( $id, '_wfcp_lock_price', true ),
			'wholesale_rule' => get_post_meta( $id, '_wfcp_wholesale_custom_rule', true ),
		);

		if ( class_exists( 'WFCP_Helper' ) ) {
			$row['wfcp']['settings_currency'] = WFCP_Helper::get_settings( 'general', 'currency' );
		}

		return $row;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function shop_product_wfcp_patch( $request ) {
		$id = (int) $request['id'];
		$p  = wc_get_product( $id );
		if ( ! $p ) {
			return new WP_Error( 'not_found', __( 'Product not found.', 'webino-dashboard' ), array( 'status' => 404 ) );
		}

		$wfcp = (array) $request->get_param( 'wfcp' );
		if ( isset( $wfcp['purchase_price'] ) ) {
			$pp = class_exists( 'WFCP_Helper' ) ? WFCP_Helper::sanitize_price( $wfcp['purchase_price'] ) : (float) $wfcp['purchase_price'];
			update_post_meta( $id, '_wfcp_purchase_price', $pp );
		}
		if ( isset( $wfcp['lock_price'] ) ) {
			update_post_meta( $id, '_wfcp_lock_price', ! empty( $wfcp['lock_price'] ) ? '1' : '0' );
		}
		if ( isset( $wfcp['regular_price'] ) ) {
			$price = wc_format_decimal( $wfcp['regular_price'] );
			$p->set_regular_price( $price );
			$p->set_price( $price );
			$p->save();
		}

		return new WP_REST_Response( self::map_product_row( wc_get_product( $id ) ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function accounting_summary() {
		global $wpdb;
		$t = Webino_Dashboard_Rest_Base::accounting_table( 'fiscal_years' );
		$c = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" );
		return new WP_REST_Response( array( 'fiscal_years' => $c ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function accounting_list( $request ) {
		global $wpdb;

		$map = array(
			'fiscal-years'         => 'fiscal_years',
			'journals'             => 'journal_entries',
			'persons'              => 'persons',
			'products'             => 'products',
			'invoices'             => 'invoices',
			'cash-accounts'        => 'cash_accounts',
			'receipts'             => 'receipt_vouchers',
			'checks'               => 'checks',
			'chart'                => 'chart_accounts',
			'warehouses'           => 'warehouses',
			'warehouse-stock'      => 'warehouse_stock',
			'person-categories'    => 'person_categories',
			'product-categories'   => 'product_categories',
			'units'                => 'units',
			'price-lists'          => 'price_lists',
			'price-list-items'     => 'price_list_items',
			'user-defaults'        => 'user_defaults',
		);

		$res = sanitize_key( (string) $request['resource'] );
		if ( ! isset( $map[ $res ] ) ) {
			return new WP_Error( 'invalid_resource', $res, array( 'status' => 404 ) );
		}

		$table = Webino_Dashboard_Rest_Base::accounting_table( $map[ $res ] );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is whitelisted.
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A );

		return new WP_REST_Response( array( 'data' => $rows ? $rows : array() ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function content_posts( $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$q        = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'paged'          => $page,
				'posts_per_page' => $per_page,
				's'              => sanitize_text_field( (string) $request->get_param( 'search' ) ),
			)
		);
		$items = array();
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = array(
				'id'      => get_the_ID(),
				'title'   => get_the_title(),
				'status'  => get_post_status(),
				'date'    => gmdate( 'c', strtotime( get_post()->post_date_gmt ? get_post()->post_date_gmt : get_post()->post_date ) ),
				'excerpt' => wp_strip_all_tags( get_the_excerpt() ),
			);
		}
		wp_reset_postdata();
		return new WP_REST_Response( array( 'items' => $items, 'page' => $page, 'found' => (int) $q->found_posts ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function content_pages( $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$q        = new WP_Query(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'paged'          => $page,
				'posts_per_page' => $per_page,
			)
		);
		$items = array();
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = array(
				'id'     => get_the_ID(),
				'title'  => get_the_title(),
				'status' => get_post_status(),
			);
		}
		wp_reset_postdata();
		return new WP_REST_Response( array( 'items' => $items, 'page' => $page ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function content_media( $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 40 ) );
		$folder   = (int) $request->get_param( 'folder' );
		$category = (int) $request->get_param( 'category' );

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'paged'          => $page,
			'posts_per_page' => $per_page,
		);

		$tax_query = array();
		if ( $folder > 0 && taxonomy_exists( 'webino_media_folder' ) ) {
			$tax_query[] = array(
				'taxonomy'         => 'webino_media_folder',
				'field'            => 'term_id',
				'terms'            => $folder,
				'include_children' => true,
			);
		}
		if ( $category > 0 && taxonomy_exists( 'webino_media_category' ) ) {
			$tax_query[] = array(
				'taxonomy' => 'webino_media_category',
				'field'    => 'term_id',
				'terms'    => $category,
			);
		}
		if ( array() !== $tax_query ) {
			$args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $tax_query );
		}

		$q = new WP_Query( $args );
		$items = array();
		while ( $q->have_posts() ) {
			$q->the_post();
			$aid   = get_the_ID();
			$cats  = taxonomy_exists( 'webino_media_category' )
				? wp_get_post_terms( $aid, 'webino_media_category', array( 'fields' => 'all' ) ) : array();
			$folds = taxonomy_exists( 'webino_media_folder' )
				? wp_get_post_terms( $aid, 'webino_media_folder', array( 'fields' => 'all' ) ) : array();
			if ( is_wp_error( $cats ) ) {
				$cats = array();
			}
			if ( is_wp_error( $folds ) ) {
				$folds = array();
			}
			$items[] = array(
				'id'         => $aid,
				'title'      => get_the_title(),
				'url'        => wp_get_attachment_url( $aid ),
				'mime'       => get_post_mime_type(),
				'categories' => array_map(
					static function ( $t ) {
						return array( 'id' => (int) $t->term_id, 'name' => $t->name, 'slug' => $t->slug );
					},
					$cats
				),
				'folders'    => array_map(
					static function ( $t ) {
						return array(
							'id'     => (int) $t->term_id,
							'name'   => $t->name,
							'slug'   => $t->slug,
							'parent' => (int) $t->parent,
						);
					},
					$folds
				),
			);
		}
		wp_reset_postdata();
		return new WP_REST_Response(
			array(
				'items' => $items,
				'page'  => $page,
				'total' => (int) $q->found_posts,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function shop_orders( $request ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$orders   = wc_get_orders(
			array(
				'limit'   => $per_page,
				'page'    => $page,
				'orderby' => 'date',
				'order'   => 'DESC',
				'return'  => 'objects',
			)
		);
		$items = array();
		foreach ( $orders as $o ) {
			$items[] = array(
				'id'     => $o->get_id(),
				'number' => $o->get_order_number(),
				'status' => $o->get_status(),
				'total'  => $o->get_total(),
				'currency'=> $o->get_currency(),
				'date'   => $o->get_date_created() ? $o->get_date_created()->format( 'c' ) : null,
			);
		}
		return new WP_REST_Response( array( 'items' => $items, 'page' => $page ) );
	}

	/**
	 * Serialize coupon for REST list/detail.
	 *
	 * @param WC_Coupon $c Coupon.
	 * @return array<string,mixed>
	 */
	public static function map_coupon_rest( $c ) {
		if ( ! is_a( $c, 'WC_Coupon' ) ) {
			return array();
		}
		$exp = $c->get_date_expires();
		return array(
			'id'                 => $c->get_id(),
			'code'               => $c->get_code(),
			'amount'             => $c->get_amount(),
			'type'               => $c->get_discount_type(),
			'description'        => $c->get_description(),
			'date_expires'       => $exp ? $exp->format( 'c' ) : null,
			'minimum_amount'     => $c->get_minimum_amount(),
			'maximum_amount'     => $c->get_maximum_amount(),
			'usage_limit'        => $c->get_usage_limit(),
			'usage_count'        => $c->get_usage_count(),
			'individual_use'     => $c->get_individual_use(),
			'free_shipping'      => $c->get_free_shipping(),
			'exclude_sale_items' => $c->get_exclude_sale_items(),
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function marketing_coupons( $request ) {
		if ( ! function_exists( 'wc_get_coupon_types' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$q        = new WP_Query(
			array(
				'post_type'      => 'shop_coupon',
				'post_status'    => 'publish',
				'paged'          => $page,
				'posts_per_page' => $per_page,
			)
		);
		$items = array();
		while ( $q->have_posts() ) {
			$q->the_post();
			if ( ! class_exists( 'WC_Coupon' ) ) {
				break;
			}
			$c       = new WC_Coupon( get_the_ID() );
			$items[] = self::map_coupon_rest( $c );
		}
		wp_reset_postdata();
		return new WP_REST_Response( array( 'items' => $items, 'page' => $page ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function shop_attributes() {
		if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return new WP_Error( 'no_wc', __( 'WooCommerce is not active.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$attrs = wc_get_attribute_taxonomies();
		$out   = array();
		foreach ( $attrs as $a ) {
			$out[] = (array) $a;
		}
		return new WP_REST_Response( array( 'items' => $out ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function users_list( $request ) {
		$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$users  = get_users(
			array(
				'number' => 50,
				'search' => $search ? '*' . $search . '*' : '',
				'fields' => array( 'ID', 'user_login', 'user_email', 'display_name' ),
			)
		);
		$items = array();
		foreach ( $users as $u ) {
			$items[] = array(
				'id'    => (int) $u->ID,
				'login' => $u->user_login,
				'email' => $u->user_email,
				'name'  => $u->display_name,
			);
		}
		return new WP_REST_Response( array( 'items' => $items ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function users_create( $request ) {
		$login = sanitize_user( (string) $request->get_param( 'user_login' ), true );
		$email = sanitize_email( (string) $request->get_param( 'user_email' ) );
		$pass  = (string) $request->get_param( 'user_pass' );
		$role_check = Webino_Dashboard_Rest_Base::sanitize_assignable_role( (string) $request->get_param( 'role' ) );
		if ( is_wp_error( $role_check ) ) {
			return $role_check;
		}
		$role = $role_check;
		if ( '' === $login || ! is_email( $email ) || strlen( $pass ) < 8 ) {
			return new WP_Error( 'invalid', __( 'Invalid user data.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$uid = wp_insert_user(
			array(
				'user_login' => $login,
				'user_email' => $email,
				'user_pass'  => $pass,
				'role'       => $role,
			)
		);
		if ( is_wp_error( $uid ) ) {
			return $uid;
		}
		return new WP_REST_Response( array( 'id' => (int) $uid ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function comments_list( $request ) {
		$status = sanitize_key( (string) $request->get_param( 'status' ) ) ?: 'hold';
		$list   = get_comments(
			array(
				'status' => $status,
				'number' => 50,
			)
		);
		$items = array();
		foreach ( $list as $c ) {
			$items[] = array(
				'id'      => (int) $c->comment_ID,
				'post'    => (int) $c->comment_post_ID,
				'author'  => $c->comment_author,
				'content' => wp_strip_all_tags( $c->comment_content ),
				'status'  => wp_get_comment_status( $c->comment_ID ),
			);
		}
		return new WP_REST_Response( array( 'items' => $items ) );
	}
}
