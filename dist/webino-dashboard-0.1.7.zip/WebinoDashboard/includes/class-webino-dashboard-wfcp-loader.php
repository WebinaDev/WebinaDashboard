<?php
/**
 * Loads bundled webina-woo-core when the standalone plugin is not active.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defines WFCP_* constants and bootstraps WFCP_Main after WooCommerce.
 */
final class Webino_Dashboard_WFCP_Loader {

	const STANDALONE_PLUGIN = 'webina-woo-core/webina-woo-core.php';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_load_bundled' ), 21 );
	}

	/**
	 * @return bool
	 */
	private static function standalone_plugin_active() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active( self::STANDALONE_PLUGIN );
	}

	/**
	 * @return void
	 */
	public static function maybe_load_bundled() {
		if ( self::standalone_plugin_active() ) {
			return;
		}

		if ( class_exists( 'WFCP_Main', false ) ) {
			return;
		}

		if ( ! self::woocommerce_ready() ) {
			return;
		}

		$dir = WEBINO_DASHBOARD_DIR . 'includes/wfcp/';
		if ( ! is_dir( $dir ) || ! is_readable( $dir . 'includes/class-wfcp-main.php' ) ) {
			return;
		}

		if ( ! defined( 'WEBINO_DASHBOARD_BUNDLED_WFCP' ) ) {
			define( 'WEBINO_DASHBOARD_BUNDLED_WFCP', true );
		}

		self::define_wfcp_constants( $dir );
		self::run_wfcp();
		add_action( 'admin_menu', array( __CLASS__, 'remove_wp_admin_menus' ), 999 );
	}

	/**
	 * @return bool
	 */
	private static function woocommerce_ready() {
		if ( ! did_action( 'plugins_loaded' ) ) {
			return false;
		}
		if ( ! class_exists( 'WooCommerce', false ) ) {
			return false;
		}
		return true;
	}

	/**
	 * @param string $dir Absolute path to bundled plugin root (trailing slash).
	 * @return void
	 */
	private static function define_wfcp_constants( $dir ) {
		if ( defined( 'WFCP_PLUGIN_DIR' ) ) {
			return;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- local version file.
		$ver = '1.1.0';
		if ( is_readable( $dir . 'webina-woo-core.php' ) && preg_match( '/Version:\\s*([0-9.]+)/', (string) file_get_contents( $dir . 'webina-woo-core.php' ), $m ) ) {
			$ver = $m[1];
		}
		define( 'WFCP_VERSION', $ver );
		define( 'WFCP_PLUGIN_NAME', 'webina-woo-core' );
		define( 'WFCP_PLUGIN_DIR', $dir );
		define( 'WFCP_PLUGIN_URL', plugins_url( 'includes/wfcp', WEBINO_DASHBOARD_FILE ) . '/' );
		define( 'WFCP_PLUGIN_BASENAME', plugin_basename( $dir . 'webina-woo-core.php' ) );
	}

	/**
	 * @return void
	 */
	private static function run_wfcp() {
		if ( ! self::wfcp_check_woocommerce() ) {
			return;
		}

		require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-loader.php';
		require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-i18n.php';
		require_once WFCP_PLUGIN_DIR . 'includes/class-wfcp-main.php';
		require_once WFCP_PLUGIN_DIR . 'includes/utilities/class-wfcp-helper.php';
		require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-calculator.php';
		require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-cart-manager.php';
		require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-batch-process.php';
		require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-bulk-price-change.php';

		$loader = new WFCP_Loader();
		$plugin = new WFCP_Main( $loader );
		$plugin->run();
	}

	/**
	 * Same checks as webina-woo-core bootstrap (without loading the standalone main file).
	 *
	 * @return bool
	 */
	private static function wfcp_check_woocommerce() {
		$active = (array) get_option( 'active_plugins', array() );
		if ( ! in_array( 'woocommerce/woocommerce.php', $active, true ) ) {
			if ( is_multisite() ) {
				$net = (array) get_site_option( 'active_sitewide_plugins', array() );
				if ( ! isset( $net['woocommerce/woocommerce.php'] ) ) {
					return false;
				}
			} else {
				return false;
			}
		}
		return class_exists( 'WooCommerce', false );
	}

	/**
	 * @return void
	 */
	public static function remove_wp_admin_menus() {
		if ( ! defined( 'WEBINO_DASHBOARD_BUNDLED_WFCP' ) || ! WEBINO_DASHBOARD_BUNDLED_WFCP ) {
			return;
		}
		remove_menu_page( 'wfcp-settings' );
	}
}
