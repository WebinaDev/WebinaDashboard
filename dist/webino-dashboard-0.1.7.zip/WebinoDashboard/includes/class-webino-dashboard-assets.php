<?php
/**
 * Enqueue dashboard SPA assets only on /dashboard.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Asset registration for Vite build output.
 */
class Webino_Dashboard_Assets {

	/**
	 * True when Vite entry JS is missing on disk (enqueue aborted).
	 *
	 * @var bool
	 */
	private static $build_missing = false;

	/**
	 * @return bool
	 */
	public static function is_build_missing() {
		return self::$build_missing;
	}

	/**
	 * Cache-bust token for shell / service worker (max filemtime of entry assets).
	 *
	 * @return string
	 */
	public static function get_deploy_asset_version() {
		$build_dir = WEBINO_DASHBOARD_DIR . 'assets/dashboard-build/';
		$resolved  = self::resolve_entry_assets( $build_dir );
		if ( null === $resolved ) {
			return WEBINO_DASHBOARD_VERSION;
		}
		$version = is_readable( $resolved['js_path'] ) ? (int) filemtime( $resolved['js_path'] ) : 0;
		if ( '' !== $resolved['css_path'] && is_readable( $resolved['css_path'] ) ) {
			$version = max( $version, (int) filemtime( $resolved['css_path'] ) );
		}
		return (string) max( 1, $version );
	}

	/**
	 * @param string $url Absolute asset URL.
	 * @return array{ok: bool, status: int, content_type: string|null}
	 */
	private static function probe_asset_http( $url ) {
		$res = wp_remote_head(
			$url,
			array(
				'timeout'   => 8,
				'sslverify' => true,
			)
		);
		if ( is_wp_error( $res ) ) {
			return array(
				'ok'           => false,
				'status'       => 0,
				'content_type' => $res->get_error_message(),
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$type = wp_remote_retrieve_header( $res, 'content-type' );
		return array(
			'ok'           => $code >= 200 && $code < 400,
			'status'       => $code,
			'content_type' => is_string( $type ) ? $type : null,
		);
	}

	/**
	 * Visible notice when the SPA build was not deployed.
	 *
	 * @return void
	 */
	public static function render_build_missing_notice() {
		if ( ! self::$build_missing ) {
			return;
		}
		$msg = esc_html__( 'Dashboard build files are missing on the server.', 'webino-dashboard' );
		$hint = esc_html__( 'Upload assets/dashboard-build from: cd client && npm run build', 'webino-dashboard' );
		echo '<div id="wd-php-build-missing" role="alert" style="box-sizing:border-box;padding:1.5rem;font-family:system-ui,sans-serif;background:#fef2f2;color:#7f1d1d;min-height:50vh;">';
		echo '<p style="margin:0 0 0.5rem;font-size:1.125rem;font-weight:600;">' . $msg . '</p>';
		echo '<p style="margin:0;font-size:0.875rem;">' . $hint . '</p>';
		echo '</div>';
		echo '<script>try{var n=document.getElementById("wd-php-build-missing"),r=document.getElementById("root");if(n&&r){r.innerHTML=n.outerHTML;n.remove();}}catch(e){}</script>';
	}

	/**
	 * @return void
	 */
	public function __construct() {
		add_filter( 'script_loader_tag', array( $this, 'force_app_script_module' ), 10, 3 );
		add_action( 'template_redirect', array( $this, 'maybe_serve_deploy_diag' ), 0 );
	}

	/**
	 * JSON deploy diagnostics for admins (?wd_diag=1 on /dashboard).
	 *
	 * @return void
	 */
	public function maybe_serve_deploy_diag() {
		if ( ! webino_dashboard()->rewrite->is_dashboard_request() ) {
			return;
		}
		if ( ! isset( $_GET['wd_diag'] ) || '1' !== (string) wp_unslash( $_GET['wd_diag'] ) ) {
			return;
		}
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			status_header( 403 );
			wp_die( esc_html__( 'Forbidden', 'webino-dashboard' ), '', array( 'response' => 403 ) );
		}

		$build_dir   = WEBINO_DASHBOARD_DIR . 'assets/dashboard-build/';
		$assets_php  = WEBINO_DASHBOARD_DIR . 'includes/class-webino-dashboard-assets.php';
		$resolved    = self::resolve_entry_assets( $build_dir );
		$opcache_on  = function_exists( 'opcache_get_status' );
		$opcache_ok  = false;
		if ( $opcache_on ) {
			$st = opcache_get_status( false );
			$opcache_ok = is_array( $st ) && ! empty( $st['opcache_enabled'] );
		}

		$build_url    = WEBINO_DASHBOARD_URL . 'assets/dashboard-build/';
		$legacy_js    = $build_dir . 'assets/index.js';
		$legacy_css   = $build_dir . 'assets/index.css';
		$expected_js  = null !== $resolved ? $build_url . $resolved['js'] : null;
		$expected_css = null !== $resolved && '' !== $resolved['css'] ? $build_url . $resolved['css'] : null;
		$shared_rel   = null !== $resolved ? self::resolve_shared_chunk_rel( $build_dir, $resolved ) : null;
		$expected_shared = null !== $shared_rel ? $build_url . $shared_rel : null;

		$asset_http = array();
		if ( null !== $expected_js ) {
			$asset_http['entry_js'] = self::probe_asset_http( $expected_js );
		}
		if ( null !== $expected_css ) {
			$asset_http['entry_css'] = self::probe_asset_http( $expected_css );
		}
		if ( null !== $expected_shared ) {
			$asset_http['shared_js'] = self::probe_asset_http( $expected_shared );
		}

		$payload = array(
			'plugin_version'          => WEBINO_DASHBOARD_VERSION,
			'plugin_dir'              => WEBINO_DASHBOARD_DIR,
			'plugin_url'              => WEBINO_DASHBOARD_URL,
			'php_file_mtime'          => is_readable( $assets_php ) ? (int) filemtime( $assets_php ) : 0,
			'build_dir_exists'        => is_dir( $build_dir ),
			'build_entry_json'        => is_readable( $build_dir . 'build-entry.json' ),
			'manifest_json'           => is_readable( $build_dir . 'manifest.json' ),
			'vite_manifest'           => is_readable( $build_dir . '.vite/manifest.json' ),
			'resolved_js'             => null !== $resolved ? $resolved['js'] : null,
			'resolved_css'            => null !== $resolved ? $resolved['css'] : null,
			'resolved_js_url'         => $expected_js,
			'expected_js_url'         => $expected_js,
			'expected_css_url'        => $expected_css,
			'expected_shared_url'     => $expected_shared,
			'legacy_index_js_on_disk' => is_readable( $legacy_js ),
			'legacy_index_css_on_disk'=> is_readable( $legacy_css ),
			'asset_http'              => $asset_http,
			'deploy_asset_version'    => self::get_deploy_asset_version(),
			'build_missing'           => self::$build_missing,
			'opcache'                 => $opcache_on ? ( $opcache_ok ? 'enabled' : 'disabled' ) : 'unavailable',
			'rewrite_version'         => (string) get_option( 'webino_dashboard_rewrite_version', '' ),
		);

		nocache_headers();
		header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ), true );
		echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	/**
	 * HTML comment in head so View Source shows active plugin + entry paths.
	 *
	 * @param string|null $js_rel Relative JS under dashboard-build.
	 * @param string|null $css_rel Relative CSS under dashboard-build.
	 * @return void
	 */
	private static function render_version_marker( $js_rel, $css_rel ) {
		$ver = WEBINO_DASHBOARD_VERSION;
		if ( null === $js_rel ) {
			echo '<!-- Webino Dashboard ' . esc_html( $ver ) . ' build=MISSING -->' . "\n";
			return;
		}
		$js  = esc_html( $js_rel );
		$css = $css_rel ? esc_html( $css_rel ) : 'none';
		echo '<!-- Webino Dashboard ' . esc_html( $ver ) . ' entry=' . $js . ' css=' . $css . ' -->' . "\n";
	}

	/**
	 * Vite outputs native ES modules (`import` / `import()`). Without `type="module"`,
	 * browsers parse the file as a classic script and throw — React never mounts (#root stays empty).
	 *
	 * @param string $tag    Full script element HTML.
	 * @param string $handle Registered script handle.
	 * @param string $src    Script URL (unused).
	 * @return string
	 */
	/**
	 * @param string $build_dir Absolute path to dashboard-build (trailing slash).
	 * @return array<string,mixed>|null
	 */
	/**
	 * @param string $build_dir Absolute path to dashboard-build (trailing slash).
	 * @return array{js: string, css: string, js_path: string, css_path: string}|null
	 */
	private static function load_build_entry_json( $build_dir ) {
		$path = $build_dir . 'build-entry.json';
		if ( ! is_readable( $path ) ) {
			return null;
		}
		$raw = file_get_contents( $path );
		if ( false === $raw ) {
			return null;
		}
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['js'] ) ) {
			return null;
		}
		$js_rel  = ltrim( (string) $data['js'], '/' );
		$js_path = $build_dir . $js_rel;
		if ( ! is_readable( $js_path ) ) {
			return null;
		}
		$css_rel  = '';
		$css_path = '';
		if ( ! empty( $data['css'] ) ) {
			$css_rel  = ltrim( (string) $data['css'], '/' );
			$css_path = $build_dir . $css_rel;
			if ( ! is_readable( $css_path ) ) {
				$css_rel  = '';
				$css_path = '';
			}
		}
		return array(
			'js'       => $js_rel,
			'css'      => $css_rel,
			'js_path'  => $js_path,
			'css_path' => $css_path,
		);
	}

	/**
	 * When manifest / build-entry.json are missing (e.g. .vite not uploaded), match hashed files on disk.
	 *
	 * @param string $build_dir Absolute path to dashboard-build (trailing slash).
	 * @return array{js: string, css: string, js_path: string, css_path: string}|null
	 */
	private static function discover_hashed_entry_assets( $build_dir ) {
		$assets_dir = $build_dir . 'assets/';
		if ( ! is_dir( $assets_dir ) ) {
			return null;
		}

		$js_files = glob( $assets_dir . 'index-*.js' );
		if ( ! is_array( $js_files ) || empty( $js_files ) ) {
			return null;
		}

		$js_path = $js_files[0];
		if ( count( $js_files ) > 1 ) {
			usort(
				$js_files,
				static function ( $a, $b ) {
					return filemtime( $b ) <=> filemtime( $a );
				}
			);
			$js_path = $js_files[0];
		}

		$js_rel = 'assets/' . basename( $js_path );
		$css_rel  = '';
		$css_path = '';
		$css_files = glob( $assets_dir . 'index-*.css' );
		if ( is_array( $css_files ) && ! empty( $css_files ) ) {
			$css_path = $css_files[0];
			if ( count( $css_files ) > 1 ) {
				usort(
					$css_files,
					static function ( $a, $b ) {
						return filemtime( $b ) <=> filemtime( $a );
					}
				);
				$css_path = $css_files[0];
			}
			$css_rel = 'assets/' . basename( $css_path );
		}

		return array(
			'js'       => $js_rel,
			'css'      => $css_rel,
			'js_path'  => $js_path,
			'css_path' => $css_path,
		);
	}

	/**
	 * Resolve entry paths: build-entry.json → Vite manifest → glob hashed files.
	 *
	 * @param string $build_dir Absolute path to dashboard-build (trailing slash).
	 * @return array{js: string, css: string, js_path: string, css_path: string, manifest: array<string,mixed>|null, entry: array<string,mixed>|null}|null
	 */
	private static function resolve_entry_assets( $build_dir ) {
		$basic = self::load_build_entry_json( $build_dir );
		if ( null !== $basic ) {
			return array_merge(
				$basic,
				array(
					'manifest' => self::load_vite_manifest( $build_dir ),
					'entry'    => null,
				)
			);
		}

		$from_manifest = self::resolve_vite_entry_assets( $build_dir );
		if ( null !== $from_manifest ) {
			return $from_manifest;
		}

		$discovered = self::discover_hashed_entry_assets( $build_dir );
		if ( null === $discovered ) {
			return null;
		}

		return array_merge(
			$discovered,
			array(
				'manifest' => self::load_vite_manifest( $build_dir ),
				'entry'    => null,
			)
		);
	}

	private static function load_vite_manifest( $build_dir ) {
		$manifest_paths = array(
			$build_dir . 'manifest.json',
			$build_dir . '.vite/manifest.json',
		);

		foreach ( $manifest_paths as $path ) {
			if ( ! is_readable( $path ) ) {
				continue;
			}
			$raw = file_get_contents( $path );
			if ( false === $raw ) {
				continue;
			}
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}

		return null;
	}

	/**
	 * Resolve hashed entry JS/CSS from the Vite build manifest.
	 *
	 * @param string $build_dir Absolute path to dashboard-build (trailing slash).
	 * @return array{js: string, css: string, js_path: string, css_path: string, manifest: array<string,mixed>, entry: array<string,mixed>}|null
	 */
	private static function resolve_vite_entry_assets( $build_dir ) {
		$manifest = self::load_vite_manifest( $build_dir );

		if ( null === $manifest ) {
			return null;
		}

		$entry = null;
		foreach ( array( 'index.html', 'src/main.tsx' ) as $key ) {
			if ( isset( $manifest[ $key ] ) && is_array( $manifest[ $key ] ) ) {
				$entry = $manifest[ $key ];
				break;
			}
		}

		if ( null === $entry && ! empty( $manifest ) ) {
			foreach ( $manifest as $item ) {
				if ( is_array( $item ) && ! empty( $item['isEntry'] ) ) {
					$entry = $item;
					break;
				}
			}
		}

		if ( null === $entry || empty( $entry['file'] ) ) {
			return null;
		}

		$js_rel  = ltrim( (string) $entry['file'], '/' );
		$js_path = $build_dir . $js_rel;
		if ( ! is_readable( $js_path ) ) {
			return null;
		}

		$css_rel  = '';
		$css_path = '';
		if ( ! empty( $entry['css'] ) && is_array( $entry['css'] ) ) {
			$css_rel = ltrim( (string) $entry['css'][0], '/' );
			$css_path = $build_dir . $css_rel;
			if ( ! is_readable( $css_path ) ) {
				$css_rel  = '';
				$css_path = '';
			}
		}

		return array(
			'js'       => $js_rel,
			'css'      => $css_rel,
			'js_path'  => $js_path,
			'css_path' => $css_path,
			'manifest' => $manifest,
			'entry'    => $entry,
		);
	}

	/**
	 * @param string              $build_dir Build directory (trailing slash).
	 * @param array<string,mixed> $resolved  Result from resolve_entry_assets().
	 * @return string|null Relative path under dashboard-build.
	 */
	private static function resolve_shared_chunk_rel( $build_dir, $resolved ) {
		$manifest = isset( $resolved['manifest'] ) && is_array( $resolved['manifest'] ) ? $resolved['manifest'] : null;
		$entry    = isset( $resolved['entry'] ) && is_array( $resolved['entry'] ) ? $resolved['entry'] : null;
		if ( null !== $manifest && null !== $entry ) {
			$rel = self::resolve_vite_shared_chunk_rel( $build_dir, $manifest, $entry );
			if ( null !== $rel ) {
				return $rel;
			}
		}

		$info_path = $build_dir . 'build-entry.json';
		if ( is_readable( $info_path ) ) {
			$data = json_decode( (string) file_get_contents( $info_path ), true );
			if ( is_array( $data ) && ! empty( $data['shared'] ) ) {
				$rel = ltrim( (string) $data['shared'], '/' );
				if ( is_readable( $build_dir . $rel ) ) {
					return $rel;
				}
			}
		}

		$matches = glob( $build_dir . 'assets/dashboard-shared-*.js' );
		if ( is_array( $matches ) && ! empty( $matches[0] ) ) {
			return 'assets/' . basename( $matches[0] );
		}

		return null;
	}

	/**
	 * @param string                   $build_dir Absolute build directory (trailing slash).
	 * @param array<string,mixed>      $manifest  Vite manifest.
	 * @param array<string,mixed>      $entry     Manifest entry chunk.
	 * @return string|null Relative JS path (e.g. assets/dashboard-shared-*.js).
	 */
	private static function resolve_vite_shared_chunk_rel( $build_dir, $manifest, $entry ) {
		if ( empty( $entry['imports'] ) || ! is_array( $entry['imports'] ) ) {
			return null;
		}

		foreach ( $entry['imports'] as $import_key ) {
			if ( ! is_string( $import_key ) || false === strpos( $import_key, 'dashboard-shared' ) ) {
				continue;
			}
			if ( empty( $manifest[ $import_key ] ) || ! is_array( $manifest[ $import_key ] ) ) {
				continue;
			}
			$chunk = $manifest[ $import_key ];
			if ( empty( $chunk['file'] ) ) {
				continue;
			}
			$rel = ltrim( (string) $chunk['file'], '/' );
			if ( is_readable( $build_dir . $rel ) ) {
				return $rel;
			}
		}

		return null;
	}

	/**
	 * @param int $user_id WordPress user ID.
	 * @return array<string,mixed>|null
	 */
	private static function get_cached_bootstrap( $user_id ) {
		if ( $user_id <= 0 ) {
			return null;
		}
		$cached = get_transient( 'webino_dashboard_boot_' . $user_id );
		return is_array( $cached ) ? $cached : null;
	}

	/**
	 * @param int                  $user_id WordPress user ID.
	 * @param array<string,mixed>  $data    Bootstrap payload.
	 * @return void
	 */
	private static function set_cached_bootstrap( $user_id, $data ) {
		if ( $user_id <= 0 || ! is_array( $data ) ) {
			return;
		}
		set_transient( 'webino_dashboard_boot_' . $user_id, $data, 90 );
	}

	public function force_app_script_module( $tag, $handle, $src ) {
		if ( 'webino-dashboard-app' !== $handle ) {
			return $tag;
		}
		if ( preg_match( '/\btype\s*=\s*([\'"])module\1/i', $tag ) ) {
			return $tag;
		}
		// WordPress may emit type="text/javascript"; replace so `import` remains valid.
		$tag = preg_replace( '/\s+type\s*=\s*([\'"])text\/javascript\1/i', ' type=$1module$1', $tag, 1 );
		if ( preg_match( '/\btype\s*=\s*([\'"])module\1/i', $tag ) ) {
			return $tag;
		}
		return str_replace( '<script ', '<script type="module" ', $tag, 1 );
	}

	/**
	 * @return void
	 */
	public function enqueue() {
		$rewrite = webino_dashboard()->rewrite;
		if ( ! $rewrite->is_dashboard_request() ) {
			return;
		}

		$build_dir = WEBINO_DASHBOARD_DIR . 'assets/dashboard-build/';
		$build_url = WEBINO_DASHBOARD_URL . 'assets/dashboard-build/';

		$resolved = self::resolve_entry_assets( $build_dir );
		if ( null === $resolved ) {
			self::$build_missing = true;
			add_action(
				'wp_head',
				static function () {
					self::render_version_marker( null, null );
				},
				1
			);
			add_action(
				'wp_footer',
				static function () {
					echo '<script>console.warn("[Webino Dashboard] Build missing. Run: cd client && npm install && npm run build");</script>';
				},
				9999
			);
			return;
		}

		$entry_js      = $resolved['js_path'];
		$entry_css     = $resolved['css_path'];
		$entry_js_url  = $build_url . $resolved['js'];
		$entry_css_url = '' !== $resolved['css'] ? $build_url . $resolved['css'] : '';

		if ( '' !== $entry_css_url && is_readable( $entry_css ) ) {
			wp_enqueue_style(
				'webino-dashboard-app',
				$entry_css_url,
				array(),
				(string) filemtime( $entry_css )
			);
		}

		$shared_preload_url = null;
		$shared_rel         = self::resolve_shared_chunk_rel( $build_dir, $resolved );
		if ( null !== $shared_rel ) {
			$shared_preload_url = $build_url . $shared_rel;
		}

		$marker_js  = $resolved['js'];
		$marker_css = $resolved['css'];
		add_action(
			'wp_head',
			static function () use ( $shared_preload_url, $marker_js, $marker_css ) {
				self::render_version_marker( $marker_js, $marker_css );
				$href = esc_url( rest_url( 'webino-dashboard/v1/manifest.webmanifest' ) );
				echo '<link rel="manifest" href="' . $href . '" />' . "\n";
				if ( null !== $shared_preload_url ) {
					echo '<link rel="modulepreload" href="' . esc_url( $shared_preload_url ) . '" crossorigin />' . "\n";
				}
			},
			2
		);

		$asset_version = is_readable( $entry_js ) ? (int) filemtime( $entry_js ) : 0;
		if ( is_readable( $entry_css ) ) {
			$asset_version = max( $asset_version, (int) filemtime( $entry_css ) );
		}

		wp_enqueue_script(
			'webino-dashboard-app',
			$entry_js_url,
			array(),
			(string) filemtime( $entry_js ),
			true
		);

		$base   = trailingslashit( home_url( '/dashboard' ) );
		$uid    = get_current_user_id();
		$locale = $uid ? (string) get_user_meta( $uid, 'webino_dashboard_locale', true ) : '';
		if ( '' === $locale ) {
			$locale = determine_locale();
		}

		$bootstrap = null;
		if ( is_user_logged_in() ) {
			$bootstrap = self::get_cached_bootstrap( $uid );
			if ( null === $bootstrap ) {
				try {
					$response = Webino_Dashboard_REST::bootstrap();
					if ( $response instanceof WP_REST_Response ) {
						$bootstrap = $response->get_data();
						if ( is_array( $bootstrap ) ) {
							self::set_cached_bootstrap( $uid, $bootstrap );
						}
					}
				} catch ( Throwable $e ) {
					if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
						// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
						error_log( '[Webino Dashboard] bootstrap embed failed: ' . $e->getMessage() );
					}
					$bootstrap = null;
				}
			}
		}

		wp_localize_script(
			'webino-dashboard-app',
			'webinoDashboard',
			array(
				'version'      => WEBINO_DASHBOARD_VERSION,
				// Bumps when entry CSS/JS changes — used for service worker cache namespace (?v=).
				'assetVersion' => (string) max( 1, $asset_version ),
				'baseUrl'      => $base,
				'assetBase'    => $build_url,
				'homeUrl'      => home_url( '/' ),
				'restUrl'   => esc_url_raw( rest_url( 'webino-dashboard/v1/' ) ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'loginNonce'  => wp_create_nonce( Webino_Dashboard_Rest_Base::login_nonce_action() ),
				'locale'    => $locale,
				'isLogged'  => is_user_logged_in(),
				'userId'    => $uid,
				'siteName'    => get_bloginfo( 'name' ),
				'siteIconUrl' => Webino_Dashboard_REST::site_icon_url(),
				'license'     => Webino_Dashboard_License::instance()->get_bootstrap_payload(),
				'bootstrap'   => $bootstrap,
				'flags'       => array(
					'woocommerce'          => class_exists( 'WooCommerce', false ),
					'wfcp'                   => class_exists( 'WFCP_Helper', false ),
					'baleBot'                => class_exists( 'WooCommerce', false ) && self::bot_has_token( 'bale' ),
					'telegramBot'            => class_exists( 'WooCommerce', false ) && self::bot_has_token( 'telegram' ),
					'disableServiceWorker'   => true,
				),
			)
		);
	}

	/**
	 * Reduce theme CSS/JS noise on the isolated dashboard route.
	 *
	 * @return void
	 */
	public function dequeue_theme_on_dashboard() {
		if ( ! webino_dashboard()->rewrite->is_dashboard_request() ) {
			return;
		}

		$keep = array( 'webino-dashboard-app' );

		global $wp_styles;
		if ( $wp_styles instanceof WP_Styles ) {
			foreach ( $wp_styles->queue as $handle ) {
				if ( in_array( $handle, $keep, true ) ) {
					continue;
				}
				wp_dequeue_style( $handle );
			}
		}

		global $wp_scripts;
		if ( $wp_scripts instanceof WP_Scripts ) {
			foreach ( $wp_scripts->queue as $handle ) {
				if ( in_array( $handle, $keep, true ) ) {
					continue;
				}
				wp_dequeue_script( $handle );
			}
		}
	}

	/**
	 * @param string $which bale|telegram.
	 * @return bool
	 */
	private static function bot_has_token( $which ) {
		$opt = ( 'telegram' === $which ) ? 'webino_dashboard_telegram_bot_settings' : 'webino_dashboard_bale_bot_settings';
		$s   = get_option( $opt, array() );
		if ( ! is_array( $s ) ) {
			return false;
		}
		$t = isset( $s['bot_token'] ) ? trim( (string) $s['bot_token'] ) : '';
		return '' !== $t;
	}
}
