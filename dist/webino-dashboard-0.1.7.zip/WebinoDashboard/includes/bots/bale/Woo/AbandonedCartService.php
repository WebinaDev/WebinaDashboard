<?php

namespace Webino_Dashboard_Bots_Bale\Woo;

use Webino_Dashboard_Bots_Bale\Bale\Client;
use Webino_Dashboard_Bots_Bale\Core\Plugin;

/**
 * Remind Bale users with non-empty carts after a configurable delay.
 */
class AbandonedCartService {

	public const META_TOUCHED   = '_woobale_cart_touched_at';
	public const META_REMINDED  = '_woobale_abandon_reminded_at';
	public const CRON_HOOK      = 'woobale_abandoned_cart_cron';

	public static function init(): void {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run_cron' ) );
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::CRON_HOOK );
		}
		add_action(
			'woocommerce_checkout_order_processed',
			static function ( $order_id ) {
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					return;
				}
				$uid = (int) $order->get_user_id();
				if ( $uid < 1 ) {
					return;
				}
				delete_user_meta( $uid, self::META_TOUCHED );
				delete_user_meta( $uid, self::META_REMINDED );
			},
			20,
			1
		);
	}

	public static function touch_user_cart( int $user_id ): void {
		if ( $user_id < 1 ) {
			return;
		}
		$chat = get_user_meta( $user_id, 'woobale_chat_id', true );
		if ( ! $chat ) {
			return;
		}
		update_user_meta( $user_id, self::META_TOUCHED, time() );
	}

	public static function clear_abandon_flags_if_empty_cart( int $user_id ): void {
		$cart = new UserCartContext();
		$contents = $cart->get_cart_contents( $user_id );
		if ( empty( $contents ) ) {
			delete_user_meta( $user_id, self::META_TOUCHED );
			delete_user_meta( $user_id, self::META_REMINDED );
		}
	}

	public static function run_cron(): void {
		$s = Plugin::get_settings();
		if ( empty( $s['abandon_cart_enabled'] ) || (string) $s['abandon_cart_enabled'] === '0' ) {
			return;
		}
		$delay_h = isset( $s['abandon_cart_delay_hours'] ) ? max( 1, (int) $s['abandon_cart_delay_hours'] ) : 24;
		$delay_s = $delay_h * HOUR_IN_SECONDS;
		$now     = time();

		$user_ids = get_users(
			array(
				'fields'     => 'ID',
				'number'     => 80,
				'meta_query' => array(
					'relation' => 'AND',
					array(
						'key'     => 'woobale_chat_id',
						'compare' => '!=',
						'value'   => '',
					),
					array(
						'key'     => self::META_TOUCHED,
						'compare' => 'EXISTS',
					),
				),
			)
		);
		if ( ! is_array( $user_ids ) ) {
			return;
		}

		$cart   = new UserCartContext();
		$client = new Client();
		$tpl    = isset( $s['abandon_cart_message'] ) ? (string) $s['abandon_cart_message'] : '';
		if ( trim( $tpl ) === '' ) {
			$tpl = __( 'سبد خرید شما هنوز منتظر است. برای ادامهٔ تسویه روی دکمه زیر بزنید.', 'webino-dashboard' );
		}

		foreach ( $user_ids as $uid ) {
			$uid = (int) $uid;
			if ( $uid < 1 ) {
				continue;
			}
			$touched = (int) get_user_meta( $uid, self::META_TOUCHED, true );
			if ( $touched < 1 || ( $now - $touched ) < $delay_s ) {
				continue;
			}
			$reminded = (int) get_user_meta( $uid, self::META_REMINDED, true );
			if ( $reminded >= $touched ) {
				continue;
			}
			$contents = $cart->get_cart_contents( $uid );
			if ( empty( $contents ) ) {
				delete_user_meta( $uid, self::META_TOUCHED );
				delete_user_meta( $uid, self::META_REMINDED );
				continue;
			}

			$chat = get_user_meta( $uid, 'woobale_chat_id', true );
			if ( ! $chat ) {
				continue;
			}

			$kbd = wp_json_encode(
				array(
					'inline_keyboard' => array(
						array(
							array(
								'text'          => __( '💳 ادامهٔ تسویه حساب', 'webino-dashboard' ),
								'callback_data' => 'ch',
							),
						),
					),
				)
			);
			$client->send_message(
				array(
					'chat_id'      => (string) $chat,
					'text'         => $tpl,
					'reply_markup' => $kbd,
				)
			);
			update_user_meta( $uid, self::META_REMINDED, $now );
		}
	}
}
