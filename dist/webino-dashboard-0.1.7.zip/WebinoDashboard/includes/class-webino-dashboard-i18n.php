<?php
/**
 * Internationalization.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads plugin textdomain.
 */
class Webino_Dashboard_I18n {

	/**
	 * @return void
	 */
	public static function load_textdomain() {
		load_plugin_textdomain(
			'webino-dashboard',
			false,
			dirname( WEBINO_DASHBOARD_BASENAME ) . '/languages'
		);
	}
}
