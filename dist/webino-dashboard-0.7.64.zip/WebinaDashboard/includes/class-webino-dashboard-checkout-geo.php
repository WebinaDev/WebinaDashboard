<?php
/**
 * Checkout GEO notice: multi-source geo check + VPN warning popup.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site-level toggle + always-on checker for checkout / pay-order (cache-safe via JS).
 */
final class Webino_Dashboard_Checkout_Geo {

	const OPTION         = 'webino_dashboard_checkout_geo_notice';
	const TRANSIENT_TTL  = 600;
	const HTTP_TIMEOUT   = 2;

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'maybe_print_checkout_modal' ), 50 );
	}

	/**
	 * Enabled by default when option is missing.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$raw = get_option( self::OPTION, null );
		if ( null === $raw ) {
			return true;
		}
		return ! empty( $raw );
	}

	/**
	 * @param bool $enabled Enabled.
	 * @return void
	 */
	public static function set_enabled( $enabled ) {
		update_option( self::OPTION, $enabled ? '1' : '0', false );
	}

	/**
	 * Whether current request is a payment-related storefront page.
	 *
	 * @return bool
	 */
	public static function is_payment_page() {
		if ( is_admin() ) {
			return false;
		}

		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			return true;
		}
		if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' ) ) {
			return true;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path = strtolower( (string) wp_parse_url( $uri, PHP_URL_PATH ) );
		if ( '' !== $path ) {
			if ( false !== strpos( $path, '/checkout' ) || false !== strpos( $path, '/pay-order' ) ) {
				return true;
			}
			// Persian/pretty permalinks sometimes keep checkout slug translated.
			if ( false !== strpos( $path, 'تسویه' ) || false !== strpos( rawurldecode( $path ), 'تسویه' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Best-effort ISO country from multiple sources (any non-empty wins in order).
	 * Empty string = unknown.
	 *
	 * @return string
	 */
	public static function visitor_country() {
		$votes = self::collect_country_votes();
		foreach ( $votes as $code ) {
			if ( '' !== $code ) {
				return $code;
			}
		}
		return '';
	}

	/**
	 * True when at least one known source says country is not IR.
	 *
	 * @return bool
	 */
	public static function should_show_notice() {
		if ( ! self::is_enabled() ) {
			return false;
		}
		foreach ( self::collect_country_votes() as $code ) {
			if ( '' !== $code && 'IR' !== $code ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return list<string> Country codes (may include empty unknowns skipped).
	 */
	private static function collect_country_votes() {
		$out = array();

		$cf = self::normalize_country( isset( $_SERVER['HTTP_CF_IPCOUNTRY'] ) ? (string) wp_unslash( $_SERVER['HTTP_CF_IPCOUNTRY'] ) : '' );
		if ( '' !== $cf ) {
			$out[] = $cf;
		}

		$ip = self::client_ip();
		if ( '' === $ip || self::is_private_ip( $ip ) ) {
			return $out;
		}

		$cache_key = 'wd_geo_cc_' . md5( $ip );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			foreach ( $cached as $c ) {
				$n = self::normalize_country( (string) $c );
				if ( '' !== $n ) {
					$out[] = $n;
				}
			}
			return array_values( array_unique( $out ) );
		}

		$fresh = array();

		if ( class_exists( 'WC_Geolocation', false ) ) {
			$data = WC_Geolocation::geolocate_ip( $ip, true, false );
			if ( is_array( $data ) && ! empty( $data['country'] ) ) {
				$n = self::normalize_country( (string) $data['country'] );
				if ( '' !== $n ) {
					$fresh[] = $n;
				}
			}
		}

		if ( class_exists( 'Webino_Dashboard_Analytics_Geo', false ) ) {
			$geo = Webino_Dashboard_Analytics_Geo::lookup( $ip );
			if ( is_array( $geo ) && ! empty( $geo['country'] ) ) {
				$n = self::normalize_country( (string) $geo['country'] );
				if ( '' !== $n ) {
					$fresh[] = $n;
				}
			}
		}

		$remote = self::lookup_remote_apis( $ip );
		foreach ( $remote as $n ) {
			if ( '' !== $n ) {
				$fresh[] = $n;
			}
		}

		$fresh = array_values( array_unique( $fresh ) );
		set_transient( $cache_key, $fresh, self::TRANSIENT_TTL );

		foreach ( $fresh as $n ) {
			$out[] = $n;
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Parallel-ish remote lookups (sequential with short timeout).
	 *
	 * @param string $ip IP.
	 * @return list<string>
	 */
	private static function lookup_remote_apis( $ip ) {
		$ip  = (string) $ip;
		$out = array();
		$urls = array(
			'https://ip-api.com/json/' . rawurlencode( $ip ) . '?fields=status,countryCode',
			'https://ipwho.is/' . rawurlencode( $ip ) . '?fields=country_code,success',
			'https://get.geojs.io/v1/ip/country/' . rawurlencode( $ip ) . '.json',
		);

		foreach ( $urls as $url ) {
			$code = self::fetch_country_from_url( $url );
			if ( '' !== $code ) {
				$out[] = $code;
				// One solid remote hit is enough for PHP side; JS still verifies.
				break;
			}
		}
		return $out;
	}

	/**
	 * @param string $url Absolute URL.
	 * @return string
	 */
	private static function fetch_country_from_url( $url ) {
		$res = wp_remote_get(
			$url,
			array(
				'timeout'     => self::HTTP_TIMEOUT,
				'redirection' => 2,
				'headers'     => array(
					'Accept'     => 'application/json',
					'User-Agent' => 'WebinoDashboard/' . ( defined( 'WEBINO_DASHBOARD_VERSION' ) ? WEBINO_DASHBOARD_VERSION : '1.0' ),
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return '';
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code < 200 || $code >= 300 ) {
			return '';
		}
		$body = wp_remote_retrieve_body( $res );
		if ( ! is_string( $body ) || '' === $body ) {
			return '';
		}
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			// geojs sometimes returns plain "IR"
			$plain = self::normalize_country( trim( $body, "\" \n\r\t" ) );
			return $plain;
		}

		if ( isset( $data['status'] ) && 'success' === $data['status'] && ! empty( $data['countryCode'] ) ) {
			return self::normalize_country( (string) $data['countryCode'] );
		}
		if ( isset( $data['success'] ) && true === $data['success'] && ! empty( $data['country_code'] ) ) {
			return self::normalize_country( (string) $data['country_code'] );
		}
		if ( ! empty( $data['country'] ) ) {
			return self::normalize_country( (string) $data['country'] );
		}
		if ( ! empty( $data['country_code'] ) ) {
			return self::normalize_country( (string) $data['country_code'] );
		}
		if ( ! empty( $data['countryCode'] ) ) {
			return self::normalize_country( (string) $data['countryCode'] );
		}
		return '';
	}

	/**
	 * @param string $code Raw country.
	 * @return string
	 */
	private static function normalize_country( $code ) {
		$code = strtoupper( sanitize_text_field( (string) $code ) );
		if ( ! preg_match( '/^[A-Z]{2}$/', $code ) ) {
			return '';
		}
		if ( in_array( $code, array( 'XX', 'T1', 'A1', 'A2', 'O1' ), true ) ) {
			return '';
		}
		return $code;
	}

	/**
	 * @return string
	 */
	private static function client_ip() {
		if ( class_exists( 'WC_Geolocation', false ) ) {
			$ip = WC_Geolocation::get_ip_address();
			if ( is_string( $ip ) && '' !== $ip ) {
				return $ip;
			}
		}
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
			if ( empty( $_SERVER[ $key ] ) ) {
				continue;
			}
			$raw = sanitize_text_field( wp_unslash( (string) $_SERVER[ $key ] ) );
			if ( 'HTTP_X_FORWARDED_FOR' === $key && false !== strpos( $raw, ',' ) ) {
				$parts = explode( ',', $raw );
				$raw   = trim( (string) $parts[0] );
			}
			if ( filter_var( $raw, FILTER_VALIDATE_IP ) ) {
				return $raw;
			}
		}
		return '';
	}

	/**
	 * @param string $ip IP.
	 * @return bool
	 */
	private static function is_private_ip( $ip ) {
		return ! (bool) filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);
	}

	/**
	 * Always print checker on payment pages when feature enabled.
	 *
	 * @return void
	 */
	public static function maybe_print_checkout_modal() {
		if ( ! self::is_enabled() ) {
			return;
		}
		if ( ! self::is_payment_page() ) {
			return;
		}
		self::print_modal_markup( self::should_show_notice() );
	}

	/**
	 * Shared modal + client-side multi-GEOIP (also used by pay-order template).
	 *
	 * @param bool $show_now Show immediately from PHP vote.
	 * @return void
	 */
	public static function print_modal_markup( $show_now = false ) {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$is_fa  = is_string( $locale ) && ( 0 === strpos( strtolower( $locale ), 'fa' ) );
		$title  = $is_fa ? 'نکتهٔ پرداخت' : __( 'Payment tip', 'webino-dashboard' );
		$body   = $is_fa
			? 'اگر فیلترشکن روشن است، لطفاً خاموشش کنید تا اختلالی در روند پرداخت پیش نیاید.'
			: __( 'If you have a VPN enabled, please turn it off so your payment is not interrupted.', 'webino-dashboard' );
		$ok     = $is_fa ? 'متوجه شدم' : __( 'Got it', 'webino-dashboard' );
		$dir    = $is_fa || ( function_exists( 'is_rtl' ) && is_rtl() ) ? 'rtl' : 'ltr';
		$show   = $show_now ? '1' : '0';
		?>
		<style id="wd-geo-notice-css">
			.wd-geo-notice-overlay{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;padding:1rem;background:rgba(15,23,42,.55);backdrop-filter:blur(4px)}
			.wd-geo-notice-overlay.is-open{display:flex}
			.wd-geo-notice-dialog{max-width:26rem;width:100%;background:#fff;color:#111;border-radius:14px;padding:1.25rem 1.35rem;box-shadow:0 18px 48px rgba(0,0,0,.22);font-family:system-ui,-apple-system,sans-serif}
			.wd-geo-notice-dialog h2{margin:0 0 .65rem;font-size:1.1rem;line-height:1.35}
			.wd-geo-notice-dialog p{margin:0 0 1.1rem;font-size:.95rem;line-height:1.55;color:#334155}
			.wd-geo-notice-dialog button{appearance:none;border:0;border-radius:10px;background:#0f172a;color:#fff;padding:.7rem 1.1rem;font-size:.95rem;cursor:pointer;width:100%}
			.wd-geo-notice-dialog button:hover{background:#1e293b}
			[dir=rtl] .wd-geo-notice-dialog{text-align:right}
		</style>
		<div class="wd-geo-notice-overlay<?php echo $show_now ? ' is-open' : ''; ?>" id="wd-geo-notice" role="dialog" aria-modal="true" aria-labelledby="wd-geo-notice-title" aria-hidden="<?php echo $show_now ? 'false' : 'true'; ?>" dir="<?php echo esc_attr( $dir ); ?>" data-wd-show-now="<?php echo esc_attr( $show ); ?>">
			<div class="wd-geo-notice-dialog">
				<h2 id="wd-geo-notice-title"><?php echo esc_html( $title ); ?></h2>
				<p><?php echo esc_html( $body ); ?></p>
				<button type="button" id="wd-geo-notice-ok"><?php echo esc_html( $ok ); ?></button>
			</div>
		</div>
		<script>
		(function () {
			var overlay = document.getElementById('wd-geo-notice');
			if (!overlay || overlay.getAttribute('data-wd-bound') === '1') return;
			overlay.setAttribute('data-wd-bound', '1');

			var shown = false;
			function openModal() {
				if (shown) return;
				shown = true;
				overlay.classList.add('is-open');
				overlay.setAttribute('aria-hidden', 'false');
			}
			function close() {
				overlay.classList.remove('is-open');
				overlay.setAttribute('aria-hidden', 'true');
			}
			var btn = document.getElementById('wd-geo-notice-ok');
			if (btn) btn.addEventListener('click', close);
			overlay.addEventListener('click', function (e) {
				if (e.target === overlay) close();
			});
			document.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') close();
			});

			if (overlay.getAttribute('data-wd-show-now') === '1') {
				openModal();
			}

			function normalize(code) {
				if (!code || typeof code !== 'string') return '';
				code = code.trim().toUpperCase();
				if (!/^[A-Z]{2}$/.test(code)) return '';
				if (code === 'XX' || code === 'T1' || code === 'A1' || code === 'A2' || code === 'O1') return '';
				return code;
			}
			function consider(code) {
				code = normalize(code);
				if (code && code !== 'IR') openModal();
			}

			function getJson(url, pick) {
				var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
				var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 2200);
				return fetch(url, {
					method: 'GET',
					credentials: 'omit',
					cache: 'no-store',
					signal: ctrl ? ctrl.signal : undefined,
					headers: { 'Accept': 'application/json' }
				}).then(function (r) {
					clearTimeout(timer);
					if (!r.ok) throw new Error('bad status');
					return r.json();
				}).then(function (data) {
					consider(pick(data));
				}).catch(function () {
					clearTimeout(timer);
				});
			}

			// Browser-side sources (bypass full-page cache of PHP geo).
			getJson('https://get.geojs.io/v1/ip/country.json', function (d) {
				return d && (d.country || d.country_code || d.code);
			});
			getJson('https://api.country.is/', function (d) {
				return d && d.country;
			});
			getJson('https://ipwho.is/?fields=country_code,success', function (d) {
				return d && d.success && d.country_code;
			});
		})();
		</script>
		<?php
	}
}
