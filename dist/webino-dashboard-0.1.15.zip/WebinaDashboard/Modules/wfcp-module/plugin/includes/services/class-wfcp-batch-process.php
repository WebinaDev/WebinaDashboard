<?php
/**
 * Batch Processing Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Batch Processing Service
 */
class WFCP_Batch_Process {

	/**
	 * Product types that store a single WooCommerce customer-facing price on the product object.
	 *
	 * @var string[]
	 */
	private static $syncable_product_types = array( 'simple', 'external', 'variation' );

	/**
	 * Recalculate all product prices
	 *
	 * @param bool $dry_run Dry run mode (don't save to database).
	 * @return array
	 */
	public static function recalculate_all( $dry_run = false ) {
		$results = array(
			'success' => 0,
			'failed'  => 0,
			'log'     => array(),
		);

		$posts = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'posts_per_page' => -1,
				'post_status'    => 'any',
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		foreach ( $posts as $post ) {
			$product_id = (int) $post->ID;
			$parent_id  = (int) wp_get_post_parent_id( $product_id );

			if ( self::is_price_sync_locked( $product_id, $parent_id ) ) {
				$results['log'][] = sprintf( 'محصول #%d: قیمت قفل شده است', $product_id );
				continue;
			}

			$purchase_price = self::resolve_purchase_price_for_sync( $product_id, $parent_id );

			if ( ! $purchase_price ) {
				$results['log'][] = sprintf( 'محصول #%d: قیمت خرید تعیین نشده', $product_id );
				$results['failed']++;
				continue;
			}

			$calc_product_id = $parent_id > 0 ? $parent_id : $product_id;
			$retail_price    = WFCP_Calculator::calculate_price( $purchase_price, 'retail', $calc_product_id );

			if ( $dry_run ) {
				$results['log'][] = sprintf(
					'محصول #%d (%s): قیمت خرید: %s، قیمت تکی: %s',
					$product_id,
					$post->post_title,
					WFCP_Helper::format_price_with_irt_symbol( $purchase_price ),
					WFCP_Helper::format_price_with_irt_symbol( $retail_price )
				);
			} else {
				$wc_product = wc_get_product( $product_id );
				if ( ! $wc_product ) {
					$results['log'][] = sprintf( 'محصول #%d: شیء ووکامرس یافت نشد', $product_id );
					$results['failed']++;
					continue;
				}

				if ( ! in_array( $wc_product->get_type(), self::$syncable_product_types, true ) ) {
					$results['log'][] = sprintf(
						'محصول #%d: نوع %s — قیمت ووکامرس از تنوع‌ها/زیرمجموعه مدیریت می‌شود',
						$product_id,
						$wc_product->get_type()
					);
					continue;
				}

				$decimal = wc_format_decimal( $retail_price );
				$wc_product->set_regular_price( $decimal );
				$wc_product->set_price( $decimal );
				$wc_product->save();

				wc_delete_product_transients( $product_id );
				if ( $parent_id > 0 ) {
					wc_delete_product_transients( $parent_id );
				}

				$results['log'][] = sprintf(
					'محصول #%d (%s): قیمت به‌روزرسانی شد',
					$product_id,
					$post->post_title
				);
			}

			$results['success']++;
		}

		if ( $dry_run ) {
			self::write_log( $results['log'] );
		}

		return $results;
	}

	/**
	 * Effective purchase price for sync (variation inherits parent when own meta empty).
	 *
	 * @param int $product_id Product or variation ID.
	 * @param int $parent_id  Parent product ID for variations, else 0.
	 * @return float|null
	 */
	private static function resolve_purchase_price_for_sync( $product_id, $parent_id ) {
		$own = WFCP_Helper::get_product_purchase_price( $product_id );
		if ( null !== $own && $own > 0 ) {
			return (float) $own;
		}
		if ( $parent_id > 0 ) {
			$parent_purchase = WFCP_Helper::get_product_purchase_price( $parent_id );
			if ( null !== $parent_purchase && $parent_purchase > 0 ) {
				return (float) $parent_purchase;
			}
		}
		return null;
	}

	/**
	 * Whether WooCommerce prices should not be overwritten (matches parent lock for variations in admin UI).
	 *
	 * @param int $product_id Product or variation ID.
	 * @param int $parent_id  Parent ID for variations.
	 * @return bool
	 */
	private static function is_price_sync_locked( $product_id, $parent_id ) {
		if ( WFCP_Helper::is_product_price_locked( $product_id ) ) {
			return true;
		}
		if ( $parent_id > 0 && WFCP_Helper::is_product_price_locked( $parent_id ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Write log to file
	 *
	 * @param array $log Log entries.
	 * @return bool
	 */
	private static function write_log( $log ) {
		$upload_dir = wp_upload_dir();

		if ( empty( $upload_dir['error'] ) ) {
			$log_dir = $upload_dir['basedir'] . '/wfcp-logs';

			if ( ! file_exists( $log_dir ) ) {
				wp_mkdir_p( $log_dir );
			}

			if ( ! is_writable( $log_dir ) ) {
				return false;
			}

			$log_file = $log_dir . '/recalculate-' . gmdate( 'Y-m-d-H-i-s' ) . '.log';
			$content  = implode( "\n", $log );

			return false !== file_put_contents( $log_file, $content );
		}

		return false;
	}

	/**
	 * Delete all transients
	 *
	 * @return int Number of deleted transients.
	 */
	public static function delete_transients() {
		global $wpdb;

		$deleted  = (int) $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wfcp_%'" );
		$deleted += (int) $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wfcp_%'" );

		return $deleted;
	}

	/**
	 * Export settings to JSON
	 *
	 * @return string JSON encoded settings.
	 */
	public static function export_settings() {
		$settings = WFCP_Helper::get_settings();
		return wp_json_encode( $settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
	}

	/**
	 * Import settings from JSON
	 *
	 * @param string $json JSON encoded settings.
	 * @return bool|WP_Error
	 */
	public static function import_settings( $json ) {
		$settings = json_decode( $json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'invalid_json', __( 'فرمت JSON نامعتبر است.', 'webina-woo-core' ) );
		}

		return update_option( 'wfcp_settings', $settings );
	}
}
