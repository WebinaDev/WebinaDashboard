<?php
/**
 * ishop-theme compatibility layer for WFCP product pricing and cart UX.
 *
 * @package WFCP
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Repositions WFCP hooks to match ishop buy-box DOM without editing theme files.
 */
class WFCP_Ishop_Theme_Compat {

	/**
	 * @var bool
	 */
	private static $hooks_repositioned = false;

	/**
	 * @var WFCP_Public|null
	 */
	private static $public = null;

	/**
	 * @return bool
	 */
	public static function is_active() {
		if ( function_exists( 'ishop_theme_util' ) ) {
			return true;
		}

		$stylesheet = get_stylesheet();
		$template   = get_template();

		return in_array( 'ishop-theme', array( $stylesheet, $template ), true );
	}

	/**
	 * @param WFCP_Public $public Public facade.
	 * @return void
	 */
	public static function init( WFCP_Public $public ) {
		if ( ! self::is_active() ) {
			return;
		}

		self::$public = $public;

		add_action( 'woocommerce_before_single_product', array( __CLASS__, 'reposition_pricing_hooks' ), 1 );
		add_action( 'woocommerce_before_single_product', array( __CLASS__, 'hide_native_purchase_button' ), 10 );
		add_action( 'woocommerce_single_product_summary', array( $public, 'display_pricing_box_ishop_fallback' ), 46 );
		add_filter( 'body_class', array( __CLASS__, 'add_body_class' ) );
	}

	/**
	 * @return void
	 */
	public static function reposition_pricing_hooks() {
		if ( self::$hooks_repositioned || ! self::$public instanceof WFCP_Public ) {
			return;
		}

		$public = self::$public;

		remove_action( 'woocommerce_single_product_summary', array( $public, 'display_pricing_box' ), 25 );
		remove_action( 'woocommerce_after_variations_form', array( $public, 'display_pricing_box_variable' ), 15 );

		add_action( 'woocommerce_before_add_to_cart_form', array( $public, 'display_pricing_box_ishop_before' ), 5 );
		add_action( 'woocommerce_after_add_to_cart_form', array( $public, 'display_pricing_box_ishop_after' ), 5 );

		self::$hooks_repositioned = true;
	}

	/**
	 * Hide native purchase button only; keep ishop buy-box DOM and variations_form intact.
	 *
	 * @return void
	 */
	public static function hide_native_purchase_button() {
		global $product;

		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! WFCP_Helper::is_enabled() ) {
			return;
		}

		if ( ! WFCP_Helper::product_has_wfcp_pricing( $product ) ) {
			return;
		}

		if ( $product->is_type( 'variable' ) ) {
			remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
		}
	}

	/**
	 * @param array $classes Body classes.
	 * @return array
	 */
	public static function add_body_class( $classes ) {
		if ( self::is_active() ) {
			$classes[] = 'wfcp-ishop-theme';
		}

		if ( is_product() ) {
			global $product;
			if ( $product && is_a( $product, 'WC_Product' ) && WFCP_Helper::is_enabled() && WFCP_Helper::product_has_wfcp_pricing( $product ) ) {
				$classes[] = 'wfcp-has-pricing';
			}
		}

		return $classes;
	}
}
