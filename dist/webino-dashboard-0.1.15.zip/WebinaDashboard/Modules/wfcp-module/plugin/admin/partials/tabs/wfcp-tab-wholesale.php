<?php
/**
 * Wholesale settings tab
 *
 * @package    WFCP
 * @subpackage WFCP/admin/partials/tabs
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

$wholesale = WFCP_Helper::get_settings( 'wholesale' );
$strategy = $wholesale['strategy'] ?? 'global';
$category_rules = $wholesale['category_rules'] ?? array();
$categories = get_terms( array(
	'taxonomy'   => 'product_cat',
	'hide_empty' => false,
) );

// Use Gateway Manager for consistent gateway loading (all registered gateways)
if ( ! class_exists( 'WFCP_Gateway_Manager' ) ) {
	require_once WFCP_PLUGIN_DIR . 'includes/services/class-wfcp-gateway-manager.php';
}
$gateways = WFCP_Gateway_Manager::get_all_gateways();
$selected_gateways = WFCP_Gateway_Manager::normalize_gateway_ids( $wholesale['gateways'] ?? array() );
?>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'تنظیمات فروش عمده', 'webina-woo-core' ); ?></h2>
	
	<form class="wfcp-settings-form" data-section="wholesale">
		<div class="wfcp-form-group">
			<label class="wfcp-form-label">
				<?php esc_html_e( 'فعال‌سازی فروش عمده', 'webina-woo-core' ); ?>
			</label>
			<label class="wfcp-toggle">
				<input type="checkbox" name="enabled" value="1" <?php checked( $wholesale['enabled'] ?? false, true ); ?>>
				<span class="wfcp-toggle-slider"></span>
			</label>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="wfcp-wholesale-strategy">
				<?php esc_html_e( 'استراتژی تخفیف', 'webina-woo-core' ); ?>
			</label>
			<select name="strategy" id="wfcp-wholesale-strategy" class="wfcp-form-control wfcp-form-control-medium">
				<option value="global" <?php selected( $strategy, 'global' ); ?>>
					<?php esc_html_e( 'سراسری', 'webina-woo-core' ); ?>
				</option>
				<option value="category" <?php selected( $strategy, 'category' ); ?>>
					<?php esc_html_e( 'دسته‌بندی', 'webina-woo-core' ); ?>
				</option>
				<option value="product" <?php selected( $strategy, 'product' ); ?>>
					<?php esc_html_e( 'محصول', 'webina-woo-core' ); ?>
				</option>
			</select>
		</div>

		<?php if ( $strategy === 'global' ) : ?>
			<div class="wfcp-form-group">
				<label class="wfcp-form-label" for="discount_percent">
					<?php esc_html_e( 'درصد تخفیف عمده', 'webina-woo-core' ); ?></label>
				<small><?php esc_html_e( 'تخفیف از قیمت خرید (پس از تبدیل ارز) کم می‌شود، نه از قیمت نقدی.', 'webina-woo-core' ); ?></small>
				<input 
					type="number" 
					name="discount_percent" 
					id="discount_percent" 
					class="wfcp-form-control wfcp-form-control-small" 
					value="<?php echo esc_attr( $wholesale['discount_percent'] ?? 10 ); ?>"
					step="0.1"
					min="0"
				>
			</div>
		<?php endif; ?>

		<?php if ( $strategy === 'category' ) : ?>
			<div class="wfcp-form-group wfcp-category-rules">
				<label class="wfcp-form-label"><?php esc_html_e( 'قوانین دسته‌بندی', 'webina-woo-core' ); ?></label>
				<?php if ( ! is_wp_error( $categories ) && ! empty( $categories ) ) : ?>
					<?php foreach ( $categories as $category ) : ?>
						<div class="wfcp-form-group" style="margin-bottom: 10px;">
							<label class="wfcp-form-label" style="display: inline-block; width: 200px;">
								<?php echo esc_html( $category->name ); ?>
							</label>
							<input 
								type="number" 
								name="category_rules[<?php echo esc_attr( $category->term_id ); ?>]" 
								class="wfcp-form-control wfcp-form-control-small" 
								style="display: inline-block;"
								value="<?php echo esc_attr( $category_rules[ $category->term_id ] ?? 0 ); ?>"
								step="0.1"
								min="0"
								placeholder="<?php esc_attr_e( 'درصد تخفیف', 'webina-woo-core' ); ?>"
							>
						</div>
					<?php endforeach; ?>
				<?php else : ?>
					<p><?php esc_html_e( 'هیچ دسته‌بندی یافت نشد', 'webina-woo-core' ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( $strategy === 'product' ) : ?>
			<div class="wfcp-form-group">
				<p><?php esc_html_e( 'برای تنظیم قوانین خاص هر محصول، به صفحه ویرایش محصول مراجعه کنید.', 'webina-woo-core' ); ?></p>
			</div>
		<?php endif; ?>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label">
				<?php esc_html_e( 'درگاه‌های پرداخت برای فروش عمده', 'webina-woo-core' ); ?>
			</label>
			<?php if ( ! empty( $gateways ) ) : ?>
				<ul class="wfcp-gateway-list">
					<?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
						<li class="wfcp-gateway-item">
							<span class="wfcp-gateway-name"><?php echo esc_html( $gateway->get_title() ); ?></span>
							<label class="wfcp-toggle wfcp-gateway-toggle">
								<input 
									type="checkbox" 
									name="gateways[]" 
									value="<?php echo esc_attr( $gateway_id ); ?>"
									<?php checked( in_array( $gateway_id, $selected_gateways ), true ); ?>
								>
								<span class="wfcp-toggle-slider"></span>
							</label>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p><?php esc_html_e( 'هیچ درگاه پرداختی یافت نشد', 'webina-woo-core' ); ?></p>
				<?php if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) : ?>
					<?php
					$pg = WC()->payment_gateways;
					$raw_count = ( $pg && property_exists( $pg, 'payment_gateways' ) && is_array( $pg->payment_gateways ) ) ? count( $pg->payment_gateways ) : 0;
					$via_get = ( $pg && method_exists( $pg, 'get_payment_gateways' ) ) ? count( $pg->get_payment_gateways() ) : 0;
					?>
					<p style="color:#666; font-size:12px;">Debug: exists=<?php echo $pg ? '1' : '0'; ?> | get_all=<?php echo count( $gateways ); ?> | raw=<?php echo $raw_count; ?> | get_payment=<?php echo $via_get; ?> | sel=<?php echo count( $selected_gateways ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
			<small><?php esc_html_e( 'درگاه‌های پرداختی که برای فروش عمده قابل استفاده هستند', 'webina-woo-core' ); ?></small>
		</div>

		<button type="submit" class="wfcp-btn wfcp-btn-primary">
			<?php esc_html_e( 'ذخیره تنظیمات', 'webina-woo-core' ); ?>
		</button>
	</form>
</div>
