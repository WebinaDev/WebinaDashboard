import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useCallback, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'
import { toastApiError } from '@/lib/apiError'

import { PageShell } from '@/components/PageShell'
import { TableListSkeleton } from '@/components/TableListSkeleton'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { apiFetch } from '@/lib/api'
import { formatNumber } from '@/lib/formatNumber'
import { cn } from '@/lib/utils'

type BulkRow = {
  id: number
  name: string
  sku: string
  stock_status: string
  purchase_price: number | null
  locked: boolean
  retail: number
  credit: number
  wholesale: number
  wc_regular: string | number
  wc_sale: string | number
  is_variation: boolean
  attributes: Record<string, string>
}

type BulkResponse = {
  items: BulkRow[]
  page: number
  total_pages: number
  total_posts: number
}

type CatOption = { id: number; name: string; slug: string }

function useDebounced<T>(value: T, ms: number) {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = window.setTimeout(() => setV(value), ms)
    return () => window.clearTimeout(t)
  }, [value, ms])
  return v
}

function InlineNumber({
  value,
  disabled,
  onCommit,
}: {
  value: string | number | null | undefined
  disabled?: boolean
  onCommit: (next: string) => Promise<void>
}) {
  const [draft, setDraft] = useState(value == null || value === '' ? '' : String(value))
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    setDraft(value == null || value === '' ? '' : String(value))
  }, [value])

  async function commit() {
    const next = draft.trim()
    const prev = value == null || value === '' ? '' : String(value)
    if (next === prev || disabled) return
    setBusy(true)
    try {
      await onCommit(next)
    } finally {
      setBusy(false)
    }
  }

  return (
    <Input
      className="h-8 w-28 font-mono text-xs"
      value={draft}
      disabled={disabled || busy}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => void commit()}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          e.currentTarget.blur()
        }
      }}
    />
  )
}

export default function WfcpBulkEditorPage() {
  const { t, i18n } = useTranslation()
  const qc = useQueryClient()
  const locale = i18n.language

  const [page, setPage] = useState(1)
  const [searchInput, setSearchInput] = useState('')
  const search = useDebounced(searchInput, 350)
  const [category, setCategory] = useState('')
  const [stock, setStock] = useState('')
  const [sort, setSort] = useState('date_desc')

  useEffect(() => {
    setPage(1)
  }, [search, category, stock, sort])

  const catsQ = useQuery({
    queryKey: ['product-categories', 'wfcp-filter'],
    queryFn: () => apiFetch<{ items: CatOption[] }>('shop/product-categories?sort=name_asc&per_page=200'),
  })

  const q = useQuery({
    queryKey: ['wfcp', 'bulk-products', page, search, category, stock, sort],
    queryFn: () => {
      const p = new URLSearchParams()
      p.set('page', String(page))
      if (search.trim()) p.set('search', search.trim())
      if (category) p.set('category', category)
      if (stock) p.set('stock_status', stock)
      if (sort) p.set('sort', sort)
      return apiFetch<BulkResponse>(`wfcp/bulk-products?${p.toString()}`)
    },
  })
  useQueryErrorToast(q)

  const invalidate = useCallback(() => {
    void qc.invalidateQueries({ queryKey: ['wfcp', 'bulk-products'] })
  }, [qc])

  const patchPurchase = useMutation({
    mutationFn: ({ id, purchase_price }: { id: number; purchase_price: number }) =>
      apiFetch(`wfcp/bulk-products/${id}/purchase-price`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ purchase_price }),
      }),
    onSuccess: () => {
      invalidate()
      toast.success(t('wfcp.savedInline'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const patchWc = useMutation({
    mutationFn: ({ id, price, price_type }: { id: number; price: string; price_type: 'regular' | 'sale' }) =>
      apiFetch(`wfcp/bulk-products/${id}/wc-price`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ price, price_type }),
      }),
    onSuccess: () => {
      invalidate()
      toast.success(t('wfcp.savedInline'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const patchStock = useMutation({
    mutationFn: ({ id, stock_status }: { id: number; stock_status: string }) =>
      apiFetch(`wfcp/bulk-products/${id}/stock`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stock_status }),
      }),
    onSuccess: () => {
      invalidate()
      toast.success(t('wfcp.savedInline'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const patchLock = useMutation({
    mutationFn: ({ id, locked }: { id: number; locked: boolean }) =>
      apiFetch(`wfcp/bulk-products/${id}/lock`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ locked }),
      }),
    onSuccess: () => {
      invalidate()
      toast.success(t('wfcp.savedInline'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const items = q.data?.items ?? []
  const totalPages = Math.max(1, q.data?.total_pages ?? 1)
  const cats = catsQ.data?.items ?? []

  return (
    <PageShell title={t('wfcp.bulkTitle')} description={t('wfcp.bulkDescription')}>
      <div className="mb-4 flex flex-wrap items-end gap-2">
        <div className="min-w-[12rem] flex-1">
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder={t('wfcp.search')}
          />
        </div>
        <Select value={category || '__all'} onValueChange={(v) => setCategory(v === '__all' ? '' : v)}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder={t('wfcp.filterCategory')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">{t('wfcp.all')}</SelectItem>
            {cats.map((c) => (
              <SelectItem key={c.id} value={c.slug}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={stock || '__all'} onValueChange={(v) => setStock(v === '__all' ? '' : v)}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder={t('wfcp.stock')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">{t('wfcp.all')}</SelectItem>
            <SelectItem value="instock">{t('wfcp.stock.instock')}</SelectItem>
            <SelectItem value="outofstock">{t('wfcp.stock.outofstock')}</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder={t('wfcp.sort')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date_desc">{t('wfcp.sort.date_desc')}</SelectItem>
            <SelectItem value="date_asc">{t('wfcp.sort.date_asc')}</SelectItem>
            <SelectItem value="name_asc">{t('wfcp.sort.name_asc')}</SelectItem>
            <SelectItem value="name_desc">{t('wfcp.sort.name_desc')}</SelectItem>
            <SelectItem value="price_asc">{t('wfcp.sort.price_asc')}</SelectItem>
            <SelectItem value="price_desc">{t('wfcp.sort.price_desc')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="shadow-sm">
        <CardContent className="overflow-x-auto p-0">
          {q.isLoading ? (
            <TableListSkeleton rows={8} columns={9} />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('wfcp.colName')}</TableHead>
                  <TableHead>{t('wfcp.colAttrs')}</TableHead>
                  <TableHead>{t('wfcp.colSku')}</TableHead>
                  <TableHead>{t('wfcp.colStock')}</TableHead>
                  <TableHead>{t('wfcp.colPurchase')}</TableHead>
                  <TableHead>{t('wfcp.colRetail')}</TableHead>
                  <TableHead>{t('wfcp.colWcRegular')}</TableHead>
                  <TableHead>{t('wfcp.colWcSale')}</TableHead>
                  <TableHead>{t('wfcp.colLock')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-muted-foreground py-8 text-center text-sm">
                      {t('wfcp.emptyBulk')}
                    </TableCell>
                  </TableRow>
                ) : (
                  items.map((row) => {
                    const attrLabel = Object.values(row.attributes || {}).join(' · ')
                    return (
                      <TableRow key={row.id} className={cn(row.locked && 'bg-muted/30')}>
                        <TableCell className="max-w-[14rem] font-medium">
                          <span className="line-clamp-2">{row.name}</span>
                          {row.is_variation ? (
                            <span className="text-muted-foreground mt-0.5 block text-[10px]">#{row.id}</span>
                          ) : null}
                        </TableCell>
                        <TableCell className="text-muted-foreground max-w-[10rem] text-xs">
                          {attrLabel || '—'}
                        </TableCell>
                        <TableCell className="font-mono text-xs">{row.sku || '—'}</TableCell>
                        <TableCell>
                          <Select
                            value={row.stock_status || 'instock'}
                            onValueChange={(v) => void patchStock.mutateAsync({ id: row.id, stock_status: v })}
                          >
                            <SelectTrigger className="h-8 w-28 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="instock">{t('wfcp.stock.instock')}</SelectItem>
                              <SelectItem value="outofstock">{t('wfcp.stock.outofstock')}</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <InlineNumber
                            value={row.purchase_price}
                            disabled={row.locked}
                            onCommit={async (next) => {
                              const n = parseFloat(next.replace(/,/g, ''))
                              if (!Number.isFinite(n) || n <= 0) return
                              await patchPurchase.mutateAsync({ id: row.id, purchase_price: n })
                            }}
                          />
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {row.retail ? formatNumber(row.retail, locale) : '—'}
                        </TableCell>
                        <TableCell>
                          <InlineNumber
                            value={row.wc_regular}
                            disabled={row.locked}
                            onCommit={async (next) => {
                              await patchWc.mutateAsync({ id: row.id, price: next, price_type: 'regular' })
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <InlineNumber
                            value={row.wc_sale}
                            disabled={row.locked}
                            onCommit={async (next) => {
                              await patchWc.mutateAsync({ id: row.id, price: next, price_type: 'sale' })
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <label className="flex items-center gap-2 text-xs">
                            <Checkbox
                              checked={row.locked}
                              onCheckedChange={(v) =>
                                void patchLock.mutateAsync({ id: row.id, locked: v === true })
                              }
                            />
                            <span>{row.locked ? t('wfcp.locked') : t('wfcp.unlocked')}</span>
                          </label>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
        <p className="text-muted-foreground text-sm">
          {t('wfcp.pageOf', {
            page: formatNumber(page, locale),
            total: formatNumber(totalPages, locale),
          })}
        </p>
        <div className="flex gap-2">
          <Button type="button" variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            {t('wfcp.prev')}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
          >
            {t('wfcp.next')}
          </Button>
        </div>
      </div>
    </PageShell>
  )
}
