<?php
/**
 * TorobPay gateway module bootstrap.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dir = dirname( __FILE__ ) . '/includes/';

if ( ! class_exists( 'Webino_Dashboard_Module_Registry', false )
	|| ! Webino_Dashboard_Module_Registry::require_module_files(
		$dir,
		array(
			'class-torobpay-vendor-loader.php',
			'class-torobpay-config.php',
			'class-webino-dashboard-rest-torobpay.php',
		),
		'torobpay-gateway-module'
	) ) {
	return;
}

Webino_TorobPay_Vendor_Loader::init();
Webino_Dashboard_REST_TorobPay::init();
