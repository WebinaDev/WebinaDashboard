import type { ComponentType } from 'react'

import TorobPaySettingsPage from './pages/TorobPaySettingsPage'

export const routes: Record<string, ComponentType> = {
  'settings/shop/torobpay': TorobPaySettingsPage,
}

export default { routes }
