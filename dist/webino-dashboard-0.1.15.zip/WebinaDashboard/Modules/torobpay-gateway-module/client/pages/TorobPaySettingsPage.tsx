import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'

declare global {
  interface Window {
    webinoDashboard?: { restUrl?: string; nonce?: string }
  }
}

type VendorStatus = {
  woocommerce_ready?: boolean
  gateway_loaded?: boolean
  gateway_source?: string
}

type Settings = {
  enabled: boolean
  title: string
  description: string
  merchant_code: string
  api_key: string
  sandbox: boolean
}

export default function TorobPaySettingsPage() {
  const { t } = useTranslation()
  const [settings, setSettings] = useState<Settings | null>(null)
  const [status, setStatus] = useState<VendorStatus | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const base = window.webinoDashboard?.restUrl || '/wp-json/'
  const nonce = window.webinoDashboard?.nonce || ''

  useEffect(() => {
    fetch(`${base}webino-dashboard/v1/torobpay/settings`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((d) => {
        setSettings(d.settings)
        setStatus(d.status)
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed'))
  }, [base, nonce])

  if (error) return <div>{t('torobpay.title')}: {error}</div>
  if (!settings) return <div>{t('common.loading')}</div>

  return (
    <div style={{ display: 'grid', gap: 16, maxWidth: 640 }}>
      <h2>{t('torobpay.pageTitle')}</h2>
      <section style={{ display: 'grid', gap: 8, padding: 12, border: '1px solid #ddd', borderRadius: 8 }}>
        <strong>{t('torobpay.runtimeStatus')}</strong>
        <p>
          {t('torobpay.wcReady')}:{' '}
          {status?.woocommerce_ready ? t('torobpay.statusReady') : t('torobpay.statusMissing')}
        </p>
        <p>
          {t('torobpay.gateway')}:{' '}
          {status?.gateway_loaded ? t('torobpay.statusLoaded') : t('torobpay.statusNotLoaded')} (
          {status?.gateway_source ?? '—'})
        </p>
      </section>
      <label>
        <input
          type="checkbox"
          checked={settings.enabled}
          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
        />
        {t('torobpay.enableGateway')}
      </label>
      <label>
        {t('torobpay.fieldTitle')}
        <input value={settings.title} onChange={(e) => setSettings({ ...settings, title: e.target.value })} />
      </label>
      <label>
        {t('torobpay.fieldDescription')}
        <input value={settings.description} onChange={(e) => setSettings({ ...settings, description: e.target.value })} />
      </label>
      <label>
        {t('torobpay.merchantCode')}
        <input value={settings.merchant_code} onChange={(e) => setSettings({ ...settings, merchant_code: e.target.value })} />
      </label>
      <label>
        {t('torobpay.apiKey')}
        <input type="password" value={settings.api_key} onChange={(e) => setSettings({ ...settings, api_key: e.target.value })} />
      </label>
      <label>
        <input
          type="checkbox"
          checked={settings.sandbox}
          onChange={(e) => setSettings({ ...settings, sandbox: e.target.checked })}
        />
        {t('torobpay.sandbox')}
      </label>
      <button
        disabled={saving}
        onClick={async () => {
          setSaving(true)
          try {
            const r = await fetch(`${base}webino-dashboard/v1/torobpay/settings`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
              body: JSON.stringify(settings),
            })
            const d = await r.json()
            setSettings(d.settings)
            setStatus(d.status)
          } finally {
            setSaving(false)
          }
        }}
      >
        {saving ? t('common.saving') : t('common.save')}
      </button>
    </div>
  )
}
