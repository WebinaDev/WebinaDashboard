<?php
/**
 * REST endpoints for TorobPay gateway module.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TorobPay dashboard REST API.
 */
final class Webino_Dashboard_REST_TorobPay {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/torobpay/settings',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_get' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_post' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/torobpay/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'status' ),
			)
		);
	}

	/**
	 * @return bool
	 */
	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		return new WP_REST_Response(
			array(
				'settings' => Webino_TorobPay_Config::get(),
				'status'   => Webino_TorobPay_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		return new WP_REST_Response(
			array(
				'settings' => Webino_TorobPay_Config::save( is_array( $data ) ? $data : array() ),
				'status'   => Webino_TorobPay_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function status() {
		$vendor = Webino_TorobPay_Vendor_Loader::status();
		return new WP_REST_Response(
			array(
				'ok'                => $vendor['gateway_loaded'] && $vendor['woocommerce_ready'],
				'module'            => 'torobpay-gateway-module',
				'version'           => '4.0.0',
				'woocommerce_ready' => $vendor['woocommerce_ready'],
				'gateway_loaded'    => $vendor['gateway_loaded'],
				'gateway_source'    => $vendor['gateway_source'],
				'checked_at'        => gmdate( 'c' ),
			)
		);
	}
}
