<?php
/**
 * Dashboard-side TorobPay settings and WC gateway option proxy.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TorobPay module configuration.
 */
final class Webino_TorobPay_Config {

	const OPTION = 'webino_torobpay_module_settings';

	const WC_OPTION_KEYS = array(
		'woocommerce_torobpay_settings',
		'woocommerce_torob_pay_settings',
		'woocommerce_wc_gateway_torobpay_settings',
	);

	/**
	 * @return array<string,mixed>
	 */
	public static function get() {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$defaults = array(
			'enabled'       => false,
			'title'         => 'TorobPay',
			'description'   => '',
			'merchant_code' => '',
			'api_key'       => '',
			'sandbox'       => false,
		);
		$merged = array_merge( $defaults, $stored );
		$wc     = self::read_wc_gateway_settings();
		if ( ! empty( $wc ) ) {
			$merged['wc_gateway'] = $wc;
			if ( isset( $wc['enabled'] ) ) {
				$merged['enabled'] = ( 'yes' === (string) $wc['enabled'] );
			}
			if ( ! empty( $wc['title'] ) ) {
				$merged['title'] = (string) $wc['title'];
			}
		}
		return $merged;
	}

	/**
	 * @param array<string,mixed> $data Settings payload.
	 * @return array<string,mixed>
	 */
	public static function save( array $data ) {
		$current = self::get();
		$allowed = array( 'enabled', 'title', 'description', 'merchant_code', 'api_key', 'sandbox' );
		$next    = $current;
		foreach ( $allowed as $key ) {
			if ( array_key_exists( $key, $data ) ) {
				$next[ $key ] = $data[ $key ];
			}
		}
		$next['enabled'] = ! empty( $next['enabled'] );
		$next['sandbox'] = ! empty( $next['sandbox'] );
		foreach ( array( 'title', 'description', 'merchant_code', 'api_key' ) as $text_key ) {
			$next[ $text_key ] = sanitize_text_field( (string) ( $next[ $text_key ] ?? '' ) );
		}
		update_option( self::OPTION, $next, false );
		self::sync_to_wc_gateway( $next );
		return self::get();
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function read_wc_gateway_settings() {
		foreach ( self::WC_OPTION_KEYS as $option_key ) {
			$value = get_option( $option_key, null );
			if ( is_array( $value ) && ! empty( $value ) ) {
				return $value;
			}
		}
		return array();
	}

	/**
	 * @param array<string,mixed> $settings Module settings.
	 * @return void
	 */
	private static function sync_to_wc_gateway( array $settings ) {
		$wc_key = '';
		foreach ( self::WC_OPTION_KEYS as $option_key ) {
			$value = get_option( $option_key, null );
			if ( is_array( $value ) ) {
				$wc_key = $option_key;
				break;
			}
		}
		if ( '' === $wc_key ) {
			return;
		}
		$wc = get_option( $wc_key, array() );
		if ( ! is_array( $wc ) ) {
			$wc = array();
		}
		$wc['enabled'] = ! empty( $settings['enabled'] ) ? 'yes' : 'no';
		if ( ! empty( $settings['title'] ) ) {
			$wc['title'] = (string) $settings['title'];
		}
		if ( ! empty( $settings['description'] ) ) {
			$wc['description'] = (string) $settings['description'];
		}
		update_option( $wc_key, $wc, false );
	}
}
