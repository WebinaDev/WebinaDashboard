<?php
/**
 * Loads bundled TorobPay vendor plugin or defers to standalone install.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Vendor bootstrap for TorobPay gateway module.
 */
final class Webino_TorobPay_Vendor_Loader {

	const STANDALONE_PLUGIN = 'torobpay-woocommerce-gateway/index.php';

	const BUNDLED_ENTRY = 'torobpay-woocommerce-gateway/index.php';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_load' ), 21 );
	}

	/**
	 * @return string
	 */
	public static function vendor_dir() {
		return trailingslashit( dirname( __DIR__ ) ) . 'vendor/';
	}

	/**
	 * @return bool
	 */
	public static function woocommerce_ready() {
		return class_exists( 'WooCommerce', false );
	}

	/**
	 * @return bool
	 */
	public static function is_gateway_loaded() {
		return (bool) apply_filters( 'webino_torobpay_gateway_loaded', defined( 'TOROBPAY_WC_GATEWAY_LOADED' ) && TOROBPAY_WC_GATEWAY_LOADED );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function status() {
		return array(
			'woocommerce_ready' => self::woocommerce_ready(),
			'gateway_loaded'    => self::is_gateway_loaded(),
			'gateway_source'    => self::gateway_source(),
			'standalone_active' => self::standalone_plugin_active(),
			'bundled_present'   => is_readable( self::vendor_dir() . self::BUNDLED_ENTRY ),
		);
	}

	/**
	 * @return void
	 */
	public static function maybe_load() {
		if ( ! self::woocommerce_ready() || self::is_gateway_loaded() || self::standalone_plugin_active() ) {
			return;
		}
		$path = self::vendor_dir() . self::BUNDLED_ENTRY;
		if ( is_readable( $path ) ) {
			require_once $path;
			if ( ! defined( 'TOROBPAY_WC_GATEWAY_LOADED' ) ) {
				define( 'TOROBPAY_WC_GATEWAY_LOADED', true );
			}
		}
	}

	/**
	 * @return bool
	 */
	private static function standalone_plugin_active() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active( self::STANDALONE_PLUGIN );
	}

	/**
	 * @return string
	 */
	private static function gateway_source() {
		if ( self::is_gateway_loaded() ) {
			return self::standalone_plugin_active() ? 'standalone' : 'bundled';
		}
		if ( self::standalone_plugin_active() ) {
			return 'standalone';
		}
		if ( is_readable( self::vendor_dir() . self::BUNDLED_ENTRY ) ) {
			return 'bundled_pending';
		}
		return 'missing';
	}
}
