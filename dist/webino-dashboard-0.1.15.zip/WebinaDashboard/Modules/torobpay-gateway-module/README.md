# ماژول TorobPay Gateway

## معرفی
ماژول TorobPay درگاه پرداخت ترب‌پی را در Dashboard ثبت می‌کند. کد upstream از `vendor/` داخل ZIP یا نصب standalone بارگذاری می‌شود.

## امکانات
- صفحه تنظیمات TorobPay در پنل فروشگاه
- REST تنظیمات و وضعیت runtime
- بارگذاری vendor از `vendor/` یا پلاگین standalone

## معماری
- bootstrap: `bootstrap.php`
- vendor loader: `includes/class-torobpay-vendor-loader.php`
- config: `includes/class-torobpay-config.php`
- REST: `includes/class-webino-dashboard-rest-torobpay.php`
- frontend: `client/dist/module.js`

## Vendor bundle
قبل از انتشار ZIP، gateway licensed را در `vendor/` قرار دهید (`vendor/README.md`).

## پیش‌نیازها
- WooCommerce
- `manage_woocommerce`
- مسیر: `/settings/shop/torobpay`

## REST
- `GET/POST /wp-json/webino-dashboard/v1/torobpay/settings`
- `GET /wp-json/webino-dashboard/v1/torobpay/status`
