<?php
/**
 * REST endpoints for Torob extractor module.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Torob products extractor dashboard REST API.
 */
final class Webino_Dashboard_REST_Torob_Extractor {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/torob-extractor/settings',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_get' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_post' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/torob-extractor/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'status' ),
			)
		);
	}

	/**
	 * @return bool
	 */
	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		return new WP_REST_Response(
			array(
				'settings' => Webino_Torob_Extractor_Config::get(),
				'status'   => Webino_Torob_Extractor_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		return new WP_REST_Response(
			array(
				'settings' => Webino_Torob_Extractor_Config::save( is_array( $data ) ? $data : array() ),
				'status'   => Webino_Torob_Extractor_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function status() {
		$vendor = Webino_Torob_Extractor_Vendor_Loader::status();
		return new WP_REST_Response(
			array(
				'ok'                => $vendor['plugin_loaded'] && $vendor['woocommerce_ready'],
				'module'            => 'torob-products-extractor-module',
				'version'           => '2.1.2',
				'woocommerce_ready' => $vendor['woocommerce_ready'],
				'plugin_loaded'     => $vendor['plugin_loaded'],
				'plugin_source'     => $vendor['plugin_source'],
				'checked_at'        => gmdate( 'c' ),
			)
		);
	}
}
