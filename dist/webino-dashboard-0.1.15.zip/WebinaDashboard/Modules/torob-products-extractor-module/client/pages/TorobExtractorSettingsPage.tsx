import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'

declare global {
  interface Window {
    webinoDashboard?: { restUrl?: string; nonce?: string }
  }
}

type VendorStatus = {
  woocommerce_ready?: boolean
  plugin_loaded?: boolean
  plugin_source?: string
}

type Settings = {
  enabled: boolean
  feed_token: string
  public_key: string
  auto_sync: boolean
  sync_interval_hours: number
}

export default function TorobExtractorSettingsPage() {
  const { t } = useTranslation()
  const [settings, setSettings] = useState<Settings | null>(null)
  const [status, setStatus] = useState<VendorStatus | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const base = window.webinoDashboard?.restUrl || '/wp-json/'
  const nonce = window.webinoDashboard?.nonce || ''

  useEffect(() => {
    fetch(`${base}webino-dashboard/v1/torob-extractor/settings`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((d) => {
        setSettings(d.settings)
        setStatus(d.status)
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed'))
  }, [base, nonce])

  if (error) return <div>{t('torobExtractor.title')}: {error}</div>
  if (!settings) return <div>{t('common.loading')}</div>

  return (
    <div style={{ display: 'grid', gap: 16, maxWidth: 640 }}>
      <h2>{t('torobExtractor.pageTitle')}</h2>
      <section style={{ display: 'grid', gap: 8, padding: 12, border: '1px solid #ddd', borderRadius: 8 }}>
        <strong>{t('torobExtractor.runtimeStatus')}</strong>
        <p>
          {t('torobExtractor.wcReady')}:{' '}
          {status?.woocommerce_ready ? t('torobExtractor.statusReady') : t('torobExtractor.statusMissing')}
        </p>
        <p>
          {t('torobExtractor.extractor')}:{' '}
          {status?.plugin_loaded ? t('torobExtractor.statusLoaded') : t('torobExtractor.statusNotLoaded')} (
          {status?.plugin_source ?? '—'})
        </p>
      </section>
      <label>
        <input
          type="checkbox"
          checked={settings.enabled}
          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
        />
        {t('torobExtractor.enable')}
      </label>
      <label>
        {t('torobExtractor.feedToken')}
        <input value={settings.feed_token} onChange={(e) => setSettings({ ...settings, feed_token: e.target.value })} />
      </label>
      <label>
        {t('torobExtractor.publicKey')}
        <input value={settings.public_key} onChange={(e) => setSettings({ ...settings, public_key: e.target.value })} />
      </label>
      <label>
        <input
          type="checkbox"
          checked={settings.auto_sync}
          onChange={(e) => setSettings({ ...settings, auto_sync: e.target.checked })}
        />
        {t('torobExtractor.autoSync')}
      </label>
      <label>
        {t('torobExtractor.syncInterval')}
        <input
          type="number"
          min={1}
          value={settings.sync_interval_hours}
          onChange={(e) => setSettings({ ...settings, sync_interval_hours: Number(e.target.value) })}
        />
      </label>
      <button
        disabled={saving}
        onClick={async () => {
          setSaving(true)
          try {
            const r = await fetch(`${base}webino-dashboard/v1/torob-extractor/settings`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
              body: JSON.stringify(settings),
            })
            const d = await r.json()
            setSettings(d.settings)
            setStatus(d.status)
          } finally {
            setSaving(false)
          }
        }}
      >
        {saving ? t('common.saving') : t('common.save')}
      </button>
    </div>
  )
}
