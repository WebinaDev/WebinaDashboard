import { useMutation, useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { WncPlatformPanel } from '@/components/wnc/WncPlatformPanel'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function DigikalaSettingsPage() {
  const { t } = useTranslation()

  const settingsQ = useQuery({
    queryKey: ['digikala', 'settings'],
    queryFn: () => apiFetch<{ settings: Record<string, unknown> }>('digikala/settings'),
  })
  const healthQ = useQuery({
    queryKey: ['digikala', 'health'],
    queryFn: () => apiFetch<Record<string, unknown>>('digikala/health'),
  })

  const test = useMutation({
    mutationFn: () => apiFetch('digikala/test-connection', { method: 'POST', body: '{}' }),
    onSuccess: () => toast.success(t('wnc.testOk')),
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <PageShell title={t('digikala.title')} description={t('digikala.subtitle', 'Digikala sellers')}>
      <section className="mb-4 space-y-3 rounded-lg border border-border p-4">
        <div className="flex flex-wrap gap-2">
          <Button type="button" onClick={() => void test.mutateAsync()} disabled={test.isPending}>
            {t('wnc.testConnection')}
          </Button>
          <Button type="button" variant="secondary" asChild>
            <Link to="/settings/shop/pricing/digikala">{t('wnc.openPricingTab')}</Link>
          </Button>
        </div>
        <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
          {JSON.stringify({ settings: settingsQ.data?.settings ?? {}, health: healthQ.data ?? {} }, null, 2)}
        </pre>
      </section>
      <WncPlatformPanel platform="digikala" titleKey="wnc.modules.digikala.title" subtitleKey="wnc.modules.digikala.subtitle" embedded />
    </PageShell>
  )
}
