import type { ComponentType } from 'react'

import DigikalaSettingsPage from './pages/digikala/DigikalaSettingsPage'

export const routes: Record<string, ComponentType> = {
  'settings/shop/digikala': DigikalaSettingsPage,
  'settings/shop/digikala/sync': DigikalaSettingsPage,
  'settings/shop/digikala/jobs': DigikalaSettingsPage,
}

export default { routes }
