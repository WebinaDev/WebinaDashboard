<?php
/**
 * Digikala OAuth helper.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Digikala_Auth {

	const SETTINGS_KEY = 'webino_digikala_settings';

	/**
	 * @return array<string,mixed>
	 */
	public static function settings() {
		$defaults = array(
			'base_url'       => 'https://seller.digikala.com',
			'client_code'    => '',
			'client_secret'  => '',
			'authorization_code' => '',
			'webhook_secret' => '',
			'auto_sync'      => false,
		);
		$raw = get_option( self::SETTINGS_KEY, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		return wp_parse_args( $raw, $defaults );
	}

	/**
	 * @param array<string,mixed> $patch Patch settings.
	 * @return array<string,mixed>
	 */
	public static function save_settings( array $patch ) {
		$current = self::settings();
		$merged  = array_merge( $current, $patch );
		if ( empty( $patch['client_secret'] ) ) {
			$merged['client_secret'] = $current['client_secret'];
		}
		update_option( self::SETTINGS_KEY, $merged, false );
		return $merged;
	}

	/**
	 * @return array<string,mixed>|WP_Error
	 */
	public static function issue_token_from_code() {
		$s = self::settings();
		if ( empty( $s['authorization_code'] ) ) {
			return new WP_Error( 'dk_missing_auth_code', __( 'authorization_code is required.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$res = wp_remote_post(
			trailingslashit( $s['base_url'] ) . 'open-api/v1/auth/token',
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'authorization_code' => (string) $s['authorization_code'],
					)
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['data']['access_token'] ) ) {
			return new WP_Error( 'dk_token_failed', __( 'Could not generate Digikala token.', 'webino-dashboard' ), array( 'status' => 502, 'response' => $body ) );
		}
		self::persist_token_payload( $body['data'] );
		return $body;
	}

	/**
	 * @return string|WP_Error
	 */
	public static function access_token() {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_connections';
		$row = $wpdb->get_row( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( ! is_array( $row ) || empty( $row['access_token'] ) ) {
			return new WP_Error( 'dk_no_token', __( 'Digikala token is not configured.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$access = (string) $row['access_token'];
		$expires_at = strtotime( (string) $row['access_expires_at'] );
		if ( $expires_at && $expires_at > ( time() + 90 ) ) {
			return $access;
		}
		$refresh = self::refresh_access_token( $access, (string) $row['refresh_token'] );
		if ( is_wp_error( $refresh ) ) {
			return $refresh;
		}
		return (string) $refresh;
	}

	/**
	 * @param string $access Access token.
	 * @param string $refresh Refresh token.
	 * @return string|WP_Error
	 */
	public static function refresh_access_token( $access, $refresh ) {
		$s = self::settings();
		$res = wp_remote_post(
			trailingslashit( $s['base_url'] ) . 'open-api/v1/auth/refresh-token',
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'access_token'  => $access,
						'refresh_token' => $refresh,
					)
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['data']['access_token'] ) ) {
			return new WP_Error( 'dk_refresh_failed', __( 'Could not refresh Digikala token.', 'webino-dashboard' ), array( 'status' => 502, 'response' => $body ) );
		}
		self::persist_token_payload( $body['data'] );
		return (string) $body['data']['access_token'];
	}

	/**
	 * @param array<string,mixed> $data Token payload.
	 * @return void
	 */
	private static function persist_token_payload( array $data ) {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_connections';
		$now = gmdate( 'Y-m-d H:i:s' );
		$access_exp = isset( $data['access_token_expires_at']['date'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( (string) $data['access_token_expires_at']['date'] ) ) : gmdate( 'Y-m-d H:i:s', time() + HOUR_IN_SECONDS );
		$refresh_exp = isset( $data['refresh_token_expires_at']['date'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( (string) $data['refresh_token_expires_at']['date'] ) ) : gmdate( 'Y-m-d H:i:s', time() + WEEK_IN_SECONDS );
		$s = self::settings();
		$wpdb->insert(
			$table,
			array(
				'client_code'       => (string) $s['client_code'],
				'client_secret'     => (string) $s['client_secret'],
				'access_token'      => (string) ( $data['access_token'] ?? '' ),
				'refresh_token'     => (string) ( $data['refresh_token'] ?? '' ),
				'access_expires_at' => $access_exp,
				'refresh_expires_at'=> $refresh_exp,
				'scopes'            => wp_json_encode( $data['scopes'] ?? array() ),
				'created_at'        => $now,
				'updated_at'        => $now,
			)
		);
	}
}
