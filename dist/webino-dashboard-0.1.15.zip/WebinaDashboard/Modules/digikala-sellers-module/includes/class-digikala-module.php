<?php
/**
 * Digikala module lifecycle hooks.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Digikala_Module {

	/**
	 * @return void
	 */
	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'init', array( 'Digikala_Storage', 'ensure_schema' ) );
		add_action( 'init', array( 'Digikala_Webhook_Handler', 'register_rewrite' ) );
		add_action( 'template_redirect', array( 'Digikala_Webhook_Handler', 'handle_request' ) );
		add_action( 'webino_digikala_process_jobs', array( 'Digikala_Jobs', 'run_due_jobs' ) );
		add_action( 'woocommerce_update_product', array( 'Digikala_Inventory_Sync', 'on_product_updated' ), 20, 1 );
		add_action( 'woocommerce_order_status_changed', array( 'Digikala_Order_Sync', 'on_order_status_changed' ), 20, 4 );
		if ( ! wp_next_scheduled( 'webino_digikala_process_jobs' ) ) {
			wp_schedule_event( time() + 60, 'minute', 'webino_digikala_process_jobs' );
		}
	}

	/**
	 * @param array<string,array<string,mixed>> $schedules Schedules.
	 * @return array<string,array<string,mixed>>
	 */
	public static function cron_schedules( $schedules ) {
		if ( ! isset( $schedules['minute'] ) ) {
			$schedules['minute'] = array(
				'interval' => 60,
				'display'  => __( 'Every Minute', 'webino-dashboard' ),
			);
		}
		return $schedules;
	}
}
