<?php
/**
 * Order sync for Digikala seller module.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Digikala_Order_Sync {

	/**
	 * @param int    $order_id Order id.
	 * @param string $old Old status.
	 * @param string $new New status.
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public static function on_order_status_changed( $order_id, $old, $new, $order ) {
		$settings = Digikala_Auth::settings();
		if ( empty( $settings['auto_sync'] ) ) {
			return;
		}
		Digikala_Jobs::enqueue(
			'order_push_status',
			array(
				'order_id' => (int) $order_id,
				'status'   => (string) $new,
			),
			5
		);
	}

	/**
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $job_id Job id.
	 * @return bool
	 */
	public static function pull_orders( array $payload = array(), $job_id = 0 ) {
		$res = Digikala_Client::request( 'GET', 'open-api/v1/orders' );
		if ( is_wp_error( $res ) ) {
			Digikala_Jobs::log( 'error', 'orders', 'Order pull failed.', array( 'job_id' => $job_id, 'error' => $res->get_error_message() ) );
			return false;
		}
		$items = (array) ( $res['data']['items'] ?? array() );
		$created = 0;
		foreach ( array_slice( $items, 0, 50 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$dk_order_id = (string) ( $item['id'] ?? '' );
			if ( '' === $dk_order_id || self::mapped_wc_order_id( $dk_order_id ) > 0 ) {
				continue;
			}
			$order = wc_create_order();
			$order->set_status( 'processing' );
			$order->set_created_via( 'digikala' );
			$order->add_order_note( 'Imported from Digikala order #' . $dk_order_id );
			$order->save();
			self::upsert_map( (int) $order->get_id(), $dk_order_id, (string) ( $item['shipment_id'] ?? '' ) );
			$created++;
		}
		Digikala_Jobs::log( 'info', 'orders', 'Order pull completed.', array( 'job_id' => $job_id, 'created' => $created ) );
		return true;
	}

	/**
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $job_id Job id.
	 * @return bool
	 */
	public static function push_order_status( array $payload = array(), $job_id = 0 ) {
		$order_id = (int) ( $payload['order_id'] ?? 0 );
		if ( $order_id <= 0 ) {
			return false;
		}
		$map = self::mapped_dk_order( $order_id );
		if ( '' === $map['dk_order_id'] ) {
			return true;
		}
		$status = sanitize_key( (string) ( $payload['status'] ?? '' ) );
		$res = Digikala_Client::request(
			'POST',
			'open-api/v1/orders/status',
			array(
				'order_id' => $map['dk_order_id'],
				'status'   => $status,
			)
		);
		if ( is_wp_error( $res ) ) {
			Digikala_Jobs::log( 'error', 'orders', 'Order status push failed.', array( 'job_id' => $job_id, 'order_id' => $order_id, 'error' => $res->get_error_message() ) );
			return false;
		}
		Digikala_Jobs::log( 'info', 'orders', 'Order status pushed.', array( 'job_id' => $job_id, 'order_id' => $order_id, 'status' => $status ) );
		return true;
	}

	/**
	 * @param string $dk_order_id DK order id.
	 * @return int
	 */
	private static function mapped_wc_order_id( $dk_order_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_order_map';
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT wc_order_id FROM {$table} WHERE dk_order_id=%s LIMIT 1", $dk_order_id ) );
		return (int) $id;
	}

	/**
	 * @param int $wc_order_id WC order id.
	 * @return array{dk_order_id:string,dk_shipment_id:string}
	 */
	private static function mapped_dk_order( $wc_order_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_order_map';
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT dk_order_id, dk_shipment_id FROM {$table} WHERE wc_order_id=%d LIMIT 1", $wc_order_id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return array( 'dk_order_id' => '', 'dk_shipment_id' => '' );
		}
		return array(
			'dk_order_id'    => (string) ( $row['dk_order_id'] ?? '' ),
			'dk_shipment_id' => (string) ( $row['dk_shipment_id'] ?? '' ),
		);
	}

	/**
	 * @param int    $wc_order_id WC order id.
	 * @param string $dk_order_id DK order id.
	 * @param string $dk_shipment_id Shipment id.
	 * @return void
	 */
	private static function upsert_map( $wc_order_id, $dk_order_id, $dk_shipment_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_order_map';
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE wc_order_id=%d LIMIT 1", $wc_order_id ) );
		$data = array(
			'dk_order_id'     => $dk_order_id,
			'dk_shipment_id'  => $dk_shipment_id,
			'last_sync_at'    => gmdate( 'Y-m-d H:i:s' ),
		);
		if ( $exists ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $exists ) );
			return;
		}
		$wpdb->insert(
			$table,
			array_merge(
				$data,
				array(
					'wc_order_id' => $wc_order_id,
				)
			)
		);
	}
}
