<?php
/**
 * Phase 3 features: webhook matrix, reconciliation, health and alerting.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Digikala_Phase3_Sync {

	/**
	 * @return array<string,array<string,mixed>>
	 */
	public static function webhook_matrix() {
		return array(
			'order.created'      => array( 'job' => 'orders_pull', 'context' => 'orders' ),
			'order.updated'      => array( 'job' => 'orders_pull', 'context' => 'orders' ),
			'order.cancelled'    => array( 'job' => 'orders_pull', 'context' => 'orders' ),
			'shipment.updated'   => array( 'job' => 'phase2_shipments', 'context' => 'shipments' ),
			'inventory.updated'  => array( 'job' => 'inventory_sync', 'context' => 'inventory' ),
			'price.updated'      => array( 'job' => 'product_export', 'context' => 'product' ),
			'promotion.updated'  => array( 'job' => 'phase2_promotions', 'context' => 'promotions' ),
			'voucher.updated'    => array( 'job' => 'phase2_promotions', 'context' => 'promotions' ),
			'sbs.order.updated'  => array( 'job' => 'phase2_sbs', 'context' => 'sbs' ),
		);
	}

	/**
	 * @param string              $event Event key.
	 * @param array<string,mixed> $payload Payload.
	 * @return bool
	 */
	public static function dispatch_webhook_event( $event, array $payload ) {
		$matrix = self::webhook_matrix();
		if ( ! isset( $matrix[ $event ] ) ) {
			Digikala_Jobs::log( 'info', 'webhook', 'Unhandled webhook event.', array( 'event' => $event ) );
			return false;
		}
		$rule = $matrix[ $event ];
		$job  = (string) ( $rule['job'] ?? '' );
		if ( '' === $job ) {
			return false;
		}
		Digikala_Jobs::enqueue(
			$job,
			array(
				'source'  => 'webhook',
				'event'   => $event,
				'payload' => $payload,
			),
			2
		);
		Digikala_Jobs::log( 'info', 'webhook', 'Webhook event routed to queue.', array( 'event' => $event, 'job_type' => $job ) );
		return true;
	}

	/**
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $job_id Job id.
	 * @return bool
	 */
	public static function reconcile_products( array $payload = array(), $job_id = 0 ) {
		global $wpdb;
		$map_table = $wpdb->prefix . 'webino_dk_product_map';
		$rows      = $wpdb->get_results( "SELECT wc_product_id, dk_product_id FROM {$map_table} ORDER BY id DESC LIMIT 500", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$drift = 0;
		foreach ( (array) $rows as $row ) {
			$wc_id = (int) ( $row['wc_product_id'] ?? 0 );
			$dk_id = (string) ( $row['dk_product_id'] ?? '' );
			if ( $wc_id <= 0 || '' === $dk_id ) {
				$drift++;
				continue;
			}
			if ( ! wc_get_product( $wc_id ) ) {
				$drift++;
			}
		}
		Digikala_Jobs::log( 'info', 'reconcile', 'Product reconciliation finished.', array( 'job_id' => $job_id, 'drift_count' => $drift ) );
		return true;
	}

	/**
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $job_id Job id.
	 * @return bool
	 */
	public static function reconcile_orders( array $payload = array(), $job_id = 0 ) {
		global $wpdb;
		$map_table = $wpdb->prefix . 'webino_dk_order_map';
		$rows      = $wpdb->get_results( "SELECT wc_order_id, dk_order_id FROM {$map_table} ORDER BY id DESC LIMIT 500", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$drift = 0;
		foreach ( (array) $rows as $row ) {
			$wc_id = (int) ( $row['wc_order_id'] ?? 0 );
			$dk_id = (string) ( $row['dk_order_id'] ?? '' );
			if ( $wc_id <= 0 || '' === $dk_id || ! wc_get_order( $wc_id ) ) {
				$drift++;
			}
		}
		Digikala_Jobs::log( 'info', 'reconcile', 'Order reconciliation finished.', array( 'job_id' => $job_id, 'drift_count' => $drift ) );
		return true;
	}

	/**
	 * @param array<string,mixed> $payload Payload.
	 * @param int                 $job_id Job id.
	 * @return bool
	 */
	public static function reconcile_inventory( array $payload = array(), $job_id = 0 ) {
		global $wpdb;
		$stock_table = $wpdb->prefix . 'webino_acc_warehouse_stock';
		$rows        = $wpdb->get_results( "SELECT product_id, SUM(quantity) AS qty FROM {$stock_table} GROUP BY product_id LIMIT 1000", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$drift = 0;
		foreach ( (array) $rows as $row ) {
			$product_id = (int) ( $row['product_id'] ?? 0 );
			$qty        = (int) ( $row['qty'] ?? 0 );
			$product    = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			$wc_qty = (int) $product->get_stock_quantity();
			if ( $wc_qty !== $qty ) {
				$drift++;
			}
		}
		Digikala_Jobs::log( 'info', 'reconcile', 'Inventory reconciliation finished.', array( 'job_id' => $job_id, 'drift_count' => $drift ) );
		return true;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function health_status() {
		global $wpdb;
		$jobs_table = $wpdb->prefix . 'webino_dk_jobs';
		$logs_table = $wpdb->prefix . 'webino_dk_logs';
		$pending = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$jobs_table} WHERE status=%s", 'pending' ) );
		$running = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$jobs_table} WHERE status=%s", 'running' ) );
		$failed_24h = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$logs_table} WHERE level=%s AND created_at >= %s", 'error', gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );
		$token = Digikala_Auth::access_token();
		$auth_ok = ! is_wp_error( $token );
		$status = 'healthy';
		if ( ! $auth_ok || $failed_24h > 30 ) {
			$status = 'critical';
		} elseif ( $failed_24h > 5 || $pending > 50 ) {
			$status = 'warning';
		}
		return array(
			'status'       => $status,
			'auth_ok'      => $auth_ok,
			'queue_pending'=> $pending,
			'queue_running'=> $running,
			'errors_24h'   => $failed_24h,
			'checked_at'   => gmdate( 'c' ),
		);
	}
}
