<?php
/**
 * REST endpoints for Digikala seller integration.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Dashboard_REST_Digikala {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return bool
	 */
	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	/**
	 * @return bool
	 */
	public static function can_manage_trace() {
		if ( ! self::can_manage() ) {
			return false;
		}
		return Webino_Dashboard_License::instance()->is_license_active( false );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/digikala/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'settings_get' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'settings_post' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/test-connection',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'test_connection' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/scopes',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'scopes' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/products/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'product_import' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/products/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'product_export' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/inventory',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'inventory_sync' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/orders/pull',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'orders_pull' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/orders/push-status',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'orders_push_status' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/phase2/shipments',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'phase2_shipments' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/phase2/finance',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'phase2_finance' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/phase2/promotions',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'phase2_promotions' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/sync/phase2/sbs',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'phase2_sbs' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/jobs',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'jobs_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/logs',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'logs_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/coverage',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'coverage_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/webhook-matrix',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'webhook_matrix_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/reconcile',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'reconcile_post' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'health_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/alerts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'alerts_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digikala/coverage/endpoints',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'coverage_endpoints_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage_trace' ),
				'args'                => array(
					'status' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'job_type' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
					),
					'dispatcher' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include_pending' => array(
						'type'              => 'boolean',
						'default'           => true,
						'sanitize_callback' => 'rest_sanitize_boolean',
					),
					'refresh' => array(
						'type'              => 'boolean',
						'default'           => false,
						'sanitize_callback' => 'rest_sanitize_boolean',
					),
					'page' => array(
						'type'              => 'integer',
						'default'           => 1,
						'sanitize_callback' => 'absint',
					),
					'per_page' => array(
						'type'              => 'integer',
						'default'           => 200,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		$s = Digikala_Auth::settings();
		$s['client_secret'] = '';
		$s['has_client_secret'] = ! empty( Digikala_Auth::settings()['client_secret'] );
		$s['webhook_url'] = home_url( '/webino/digikala-webhook/' );
		return new WP_REST_Response( array( 'settings' => $s ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'invalid_body', __( 'Invalid request body.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$clean = array(
			'base_url'           => esc_url_raw( (string) ( $data['base_url'] ?? '' ) ),
			'client_code'        => sanitize_text_field( (string) ( $data['client_code'] ?? '' ) ),
			'client_secret'      => sanitize_text_field( (string) ( $data['client_secret'] ?? '' ) ),
			'authorization_code' => sanitize_text_field( (string) ( $data['authorization_code'] ?? '' ) ),
			'webhook_secret'     => sanitize_text_field( (string) ( $data['webhook_secret'] ?? '' ) ),
			'auto_sync'          => ! empty( $data['auto_sync'] ),
		);
		$saved = Digikala_Auth::save_settings( $clean );
		$saved['client_secret'] = '';
		$saved['has_client_secret'] = ! empty( Digikala_Auth::settings()['client_secret'] );
		return new WP_REST_Response( array( 'settings' => $saved ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function test_connection() {
		$token = Digikala_Auth::issue_token_from_code();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$health = Digikala_Client::request( 'GET', 'open-api/v1/' );
		if ( is_wp_error( $health ) ) {
			return $health;
		}
		return new WP_REST_Response( array( 'ok' => true, 'health' => $health ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function scopes() {
		$settings = Digikala_Auth::settings();
		$path = 'open-api/v1/auth/scopes';
		if ( ! empty( $settings['client_code'] ) ) {
			$path = 'open-api/v1/auth/scopes/' . rawurlencode( (string) $settings['client_code'] );
		}
		$res = Digikala_Client::request( 'GET', $path );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return new WP_REST_Response( $res );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function product_import( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'product_import', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function product_export( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'product_export', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function inventory_sync( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'inventory_sync', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function orders_pull( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'orders_pull', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function orders_push_status( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'order_push_status', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function phase2_shipments( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'phase2_shipments', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function phase2_finance( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'phase2_finance', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function phase2_promotions( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'phase2_promotions', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function phase2_sbs( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$job = Digikala_Jobs::enqueue( 'phase2_sbs', is_array( $body ) ? $body : array(), 0 );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function jobs_get() {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_jobs';
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 100", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return new WP_REST_Response( array( 'items' => is_array( $rows ) ? $rows : array() ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function logs_get() {
		global $wpdb;
		$table = $wpdb->prefix . 'webino_dk_logs';
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return new WP_REST_Response( array( 'items' => is_array( $rows ) ? $rows : array() ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function coverage_get() {
		return new WP_REST_Response(
			array(
				'phase1' => array(
					'authentication',
					'products',
					'inventory',
					'orders',
					'webhooks',
					'jobs_logs',
				),
				'phase2' => array(
					'shipment_package_post_tracking_commitments',
					'invoices_commission_buybox_price_stats',
					'promotions_vouchers_smart_discount_search_ads',
					'sbs_drop_shipping_plp_insight',
				),
				'phase3' => array(
					'full_webhook_matrix',
					'advanced_rate_limit_and_retry_policies',
					'conflict_resolution_and_reconciliation',
					'monitoring_alerting_health_checks',
				),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function webhook_matrix_get() {
		return new WP_REST_Response( array( 'items' => Digikala_Phase3_Sync::webhook_matrix() ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function reconcile_post( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		$type = is_array( $body ) ? sanitize_key( (string) ( $body['type'] ?? 'all' ) ) : 'all';
		$jobs = array();
		if ( 'all' === $type || 'products' === $type ) {
			$jobs[] = Digikala_Jobs::enqueue( 'reconcile_products', array(), 0 );
		}
		if ( 'all' === $type || 'orders' === $type ) {
			$jobs[] = Digikala_Jobs::enqueue( 'reconcile_orders', array(), 0 );
		}
		if ( 'all' === $type || 'inventory' === $type ) {
			$jobs[] = Digikala_Jobs::enqueue( 'reconcile_inventory', array(), 0 );
		}
		if ( empty( $jobs ) ) {
			return new WP_Error( 'bad_type', __( 'Invalid reconcile type.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		return new WP_REST_Response( array( 'ok' => true, 'job_ids' => $jobs ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function health_get() {
		return new WP_REST_Response( Digikala_Phase3_Sync::health_status() );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function alerts_get() {
		$health = Digikala_Phase3_Sync::health_status();
		$alerts = array();
		if ( ! empty( $health['auth_ok'] ) ) {
			// no alert
		} else {
			$alerts[] = array( 'level' => 'critical', 'message' => 'Authentication is not healthy.' );
		}
		if ( (int) ( $health['errors_24h'] ?? 0 ) > 5 ) {
			$alerts[] = array( 'level' => 'warning', 'message' => 'High error rate in last 24h.' );
		}
		if ( (int) ( $health['queue_pending'] ?? 0 ) > 50 ) {
			$alerts[] = array( 'level' => 'warning', 'message' => 'Queue backlog is high.' );
		}
		return new WP_REST_Response(
			array(
				'status' => $health['status'],
				'items'  => $alerts,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function coverage_endpoints_get( WP_REST_Request $request ) {
		$force_refresh = (bool) $request->get_param( 'refresh' );
		$report        = Digikala_Endpoint_Registry::report(
			array(
				'force_refresh' => $force_refresh,
			)
		);
		if ( is_wp_error( $report ) ) {
			return $report;
		}
		$list    = is_array( $report['items'] ?? null ) ? $report['items'] : array();
		$summary = is_array( $report['summary'] ?? null ) ? $report['summary'] : array();
		$meta    = is_array( $report['meta'] ?? null ) ? $report['meta'] : array();

		$status_filter = sanitize_key( (string) $request->get_param( 'status' ) );
		$job_filter    = sanitize_key( (string) $request->get_param( 'job_type' ) );
		$dispatcher_filter = sanitize_text_field( (string) $request->get_param( 'dispatcher' ) );
		$include_pending   = rest_sanitize_boolean( $request->get_param( 'include_pending' ) );

		if ( '' !== $status_filter ) {
			$list = array_values(
				array_filter(
					$list,
					static function ( $row ) use ( $status_filter ) {
						return ( $row['status'] ?? '' ) === $status_filter;
					}
				)
			);
		}

		if ( ! $include_pending ) {
			$list = array_values(
				array_filter(
					$list,
					static function ( $row ) {
						return ( $row['status'] ?? '' ) !== 'pending';
					}
				)
			);
		}

		if ( '' !== $job_filter ) {
			$list = array_values(
				array_filter(
					$list,
					static function ( $row ) use ( $job_filter ) {
						$jobs = isset( $row['job_types'] ) && is_array( $row['job_types'] ) ? $row['job_types'] : array();
						return in_array( $job_filter, $jobs, true );
					}
				)
			);
		}

		if ( '' !== $dispatcher_filter ) {
			$list = array_values(
				array_filter(
					$list,
					static function ( $row ) use ( $dispatcher_filter ) {
						$dispatchers = isset( $row['dispatchers'] ) && is_array( $row['dispatchers'] ) ? $row['dispatchers'] : array();
						foreach ( $dispatchers as $dispatcher ) {
							if ( false !== stripos( (string) $dispatcher, $dispatcher_filter ) ) {
								return true;
							}
						}
						return false;
					}
				)
			);
		}

		$per_page = min( 500, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$total    = count( $list );
		$offset   = ( $page - 1 ) * $per_page;
		$list     = array_slice( $list, $offset, $per_page );

		Digikala_Jobs::log(
			'info',
			'coverage_registry',
			'Endpoint coverage queried.',
			array(
				'refresh'        => (bool) $force_refresh,
				'status'         => $status_filter,
				'job_type'       => $job_filter,
				'dispatcher'     => $dispatcher_filter ? 'provided' : '',
				'include_pending'=> (bool) $include_pending,
				'page'           => $page,
				'per_page'       => $per_page,
			)
		);

		return new WP_REST_Response(
			array(
				'summary' => $summary,
				'items'   => $list,
				'meta'    => array_merge(
					$meta,
					array(
						'page'     => $page,
						'per_page' => $per_page,
						'total'    => $total,
					)
				),
			)
		);
	}
}
