import type { ComponentType } from 'react'

import SmsNewsletterPage from './pages/marketing/sms/SmsNewsletterPage'
import SmsPanelDashboardPage from './pages/marketing/sms/SmsPanelDashboardPage'
import SmsPatternsPage from './pages/marketing/sms/SmsPatternsPage'
import SmsPaymentCallbackPage from './pages/marketing/sms/SmsPaymentCallbackPage'
import SmsPhonebookPage from './pages/marketing/sms/SmsPhonebookPage'
import SmsReportsPage from './pages/marketing/sms/SmsReportsPage'
import SmsSendPage from './pages/marketing/sms/SmsSendPage'
import SmsTopupPage from './pages/marketing/sms/SmsTopupPage'

export const routes: Record<string, ComponentType> = {
  'marketing/sms': SmsPanelDashboardPage,
  'marketing/sms/send': SmsSendPage,
  'marketing/sms/reports': SmsReportsPage,
  'marketing/sms/phonebook': SmsPhonebookPage,
  'marketing/sms/patterns': SmsPatternsPage,
  'marketing/sms/newsletter': SmsNewsletterPage,
  'marketing/sms/topup': SmsTopupPage,
  'marketing/sms/payment-callback': SmsPaymentCallbackPage,
}

export default { routes }
