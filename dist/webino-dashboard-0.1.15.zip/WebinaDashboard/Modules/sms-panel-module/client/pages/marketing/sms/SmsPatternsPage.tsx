import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsPatterns, fetchSmsPatternRegistry } from '@/lib/modirpayamak-api'

export default function SmsPatternsPage() {
  const { t } = useTranslation()
  const patternsQ = useQuery({ queryKey: ['sms-patterns'], queryFn: () => fetchSmsPatterns() })
  const registryQ = useQuery({ queryKey: ['sms-pattern-registry'], queryFn: fetchSmsPatternRegistry })
  useQueryErrorToast(patternsQ)
  useQueryErrorToast(registryQ)

  const edgeData = patternsQ.data?.data
  type RegistryRow = { scope?: string; event_key?: string; ippanel_code?: string; sync_status?: string }
  const registry = (registryQ.data?.registry ?? []) as RegistryRow[]

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.patternsTitle')}</h1>
      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.registryTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          {registry.length === 0 ? (
            <p className="text-muted-foreground text-sm">{t('marketing.sms.noRegistry')}</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {registry.map((row, i) => (
                <li key={i} className="rounded border px-3 py-2">
                  <span className="font-mono">{row.scope}</span> / {row.event_key} — {row.ippanel_code} ({row.sync_status})
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.ippanelPatterns')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="max-h-96 overflow-auto rounded bg-muted p-3 text-xs">
            {JSON.stringify(edgeData ?? {}, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </div>
  )
}
