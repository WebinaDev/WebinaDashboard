import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsMessages, smsQueryOptions, type SmsMessage } from '@/lib/modirpayamak-api'

export default function SmsReportsPage() {
  const { t } = useTranslation()

  const messagesQ = useQuery({
    queryKey: ['sms', 'messages', 1],
    queryFn: () => fetchSmsMessages(1),
    ...smsQueryOptions,
  })
  useQueryErrorToast(messagesQ)

  const unavailable = isSmsUnavailable(messagesQ.data)
  const messages: SmsMessage[] = unavailable ? [] : (messagesQ.data?.messages ?? [])
  const loading = messagesQ.isPending

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.reportsTitle')}</h1>

      {unavailable ? (
        <SmsServiceBanner message={messagesQ.data?.message} onRetry={() => void messagesQ.refetch()} />
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.reportsTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">#</th>
                  <th className="p-2 text-start">{t('marketing.sms.type')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.status')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.cost')}</th>
                </tr>
              </thead>
              <tbody>
                {loading
                  ? Array.from({ length: 5 }, (_, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2" colSpan={4}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : messages.map((m) => (
                      <tr key={m.id} className="border-b">
                        <td className="p-2">{m.id}</td>
                        <td className="p-2">{m.sending_type}</td>
                        <td className="p-2">{m.status}</td>
                        <td className="p-2">{m.cost?.toLocaleString()}</td>
                      </tr>
                    ))}
              </tbody>
            </table>
            {!loading && !messages.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
