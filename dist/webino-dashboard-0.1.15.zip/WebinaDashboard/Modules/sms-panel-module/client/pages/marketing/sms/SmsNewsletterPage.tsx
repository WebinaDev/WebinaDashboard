import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { fetchNewsletterSubscribers, sendNewsletterCampaign } from '@/lib/modirpayamak-api'

export default function SmsNewsletterPage() {
  const { t } = useTranslation()
  const [productId, setProductId] = useState('0')
  const [message, setMessage] = useState('')

  const subsQ = useQuery({
    queryKey: ['newsletter-subs', productId],
    queryFn: () => fetchNewsletterSubscribers(parseInt(productId, 10) || 0),
  })
  useQueryErrorToast(subsQ)

  const send = useMutation({
    mutationFn: () =>
      sendNewsletterCampaign({
        product_id: parseInt(productId, 10) || 0,
        message,
      }),
    onSuccess: (res: { sent?: number }) => toast.success(t('marketing.sms.newsletterSent', { count: res.sent ?? 0 })),
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.newsletterTitle')}</h1>
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>{t('marketing.sms.newsletterCampaign')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>{t('marketing.sms.productId')}</Label>
            <Input className="mt-1" value={productId} onChange={(e) => setProductId(e.target.value)} placeholder="0" />
          </div>
          <div>
            <Label>{t('marketing.sms.message')}</Label>
            <Textarea className="mt-1" rows={4} value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <p className="text-muted-foreground text-sm">
            {t('marketing.sms.subscriberCount', { count: subsQ.data?.subscribers?.length ?? 0 })}
          </p>
          <Button type="button" disabled={send.isPending} onClick={() => send.mutate()}>
            {t('marketing.sms.sendCampaign')}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
