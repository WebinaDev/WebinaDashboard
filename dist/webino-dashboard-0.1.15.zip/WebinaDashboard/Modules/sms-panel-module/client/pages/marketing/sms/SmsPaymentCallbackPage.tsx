import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useNavigate, useSearchParams } from 'react-router-dom'

import { verifySmsTopup } from '@/lib/modirpayamak-api'

export default function SmsPaymentCallbackPage() {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [message, setMessage] = useState(t('marketing.sms.paymentVerifying'))

  useEffect(() => {
    const authority = params.get('Authority') ?? params.get('authority') ?? ''
    const status = params.get('Status') ?? params.get('status') ?? ''
    const orderId = params.get('order_id')

    verifySmsTopup({
      authority,
      status,
      order_id: orderId ? Number(orderId) : undefined,
    })
      .then((res) => {
        if (res.ok || res.credited) {
          setMessage(t('marketing.sms.paymentSuccess'))
          setTimeout(() => navigate('/marketing/sms'), 1500)
        } else {
          setMessage(t('marketing.sms.paymentFailed'))
        }
      })
      .catch(() => setMessage(t('marketing.sms.paymentFailed')))
  }, [navigate, params, t])

  return (
    <div className="flex min-h-[40vh] items-center justify-center p-6">
      <p className="text-lg">{message}</p>
    </div>
  )
}
