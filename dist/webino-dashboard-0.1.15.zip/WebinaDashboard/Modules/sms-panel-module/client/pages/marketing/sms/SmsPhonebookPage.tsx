import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { createSmsPhonebook, fetchSmsPhonebooks } from '@/lib/modirpayamak-api'

export default function SmsPhonebookPage() {
  const { t } = useTranslation()
  const [name, setName] = useState('')
  const [books, setBooks] = useState<{ id: number; name: string }[]>([])

  const load = async () => {
    const res = await fetchSmsPhonebooks()
    setBooks(res.phonebooks ?? [])
  }

  useEffect(() => {
    void load()
  }, [])

  const add = async () => {
    if (!name.trim()) return
    await createSmsPhonebook(name.trim())
    setName('')
    void load()
  }

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.phonebookTitle')}</h1>
      <Card className="max-w-md">
        <CardHeader>
          <CardTitle>{t('marketing.sms.newPhonebook')}</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
          <Button type="button" onClick={() => void add()}>
            {t('common.save')}
          </Button>
        </CardContent>
      </Card>
      <ul className="space-y-2">
        {books.map((b) => (
          <li key={b.id} className="rounded border p-3">
            {b.name}
          </li>
        ))}
      </ul>
    </div>
  )
}
