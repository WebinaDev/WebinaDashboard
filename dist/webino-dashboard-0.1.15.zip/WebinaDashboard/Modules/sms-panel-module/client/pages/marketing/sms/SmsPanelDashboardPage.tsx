import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsDashboard, smsQueryOptions, type SmsMessage } from '@/lib/modirpayamak-api'

export default function SmsPanelDashboardPage() {
  const { t } = useTranslation()

  const dashQ = useQuery({
    queryKey: ['sms', 'dashboard'],
    queryFn: () => fetchSmsDashboard(),
    ...smsQueryOptions,
  })
  useQueryErrorToast(dashQ)

  const unavailable = isSmsUnavailable(dashQ.data)
  const account = unavailable ? null : dashQ.data?.account ?? null
  const messages: SmsMessage[] = unavailable ? [] : (dashQ.data?.messages?.slice(0, 10) ?? [])
  const balanceLoading = dashQ.isPending || dashQ.isFetching

  const retry = () => {
    void dashQ.refetch()
  }

  const navLinks = [
    ['/marketing/sms/send', t('marketing.sms.send')],
    ['/marketing/sms/reports', t('marketing.sms.reports')],
    ['/marketing/sms/phonebook', t('marketing.sms.phonebook')],
    ['/marketing/sms/patterns', t('marketing.sms.patterns')],
    ['/marketing/sms/newsletter', t('marketing.sms.newsletter')],
  ] as const

  return (
    <div className="space-y-6 p-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">{t('marketing.sms.dashboardTitle')}</h1>
          <p className="text-muted-foreground text-sm">{t('marketing.sms.dashboardDesc')}</p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span>
                <Button asChild disabled={unavailable}>
                  <Link to="/marketing/sms/topup">{t('marketing.sms.topup')}</Link>
                </Button>
              </span>
            </TooltipTrigger>
            {unavailable ? <TooltipContent>{t('marketing.sms.serviceUnavailable')}</TooltipContent> : null}
          </Tooltip>
        </TooltipProvider>
      </div>

      {unavailable ? (
        <SmsServiceBanner message={dashQ.data?.message} onRetry={retry} />
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.balance')}</CardTitle>
        </CardHeader>
        <CardContent className="text-3xl font-bold">
          {balanceLoading ? (
            <Skeleton className="h-9 w-40" />
          ) : (
            <>
              {(account?.balance ?? 0).toLocaleString()} {t('marketing.sms.toman')}
            </>
          )}
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-2">
        {navLinks.map(([to, label]) => (
          <TooltipProvider key={to}>
            <Tooltip>
              <TooltipTrigger asChild>
                <span>
                  <Button variant="outline" asChild disabled={unavailable}>
                    <Link to={to}>{label}</Link>
                  </Button>
                </span>
              </TooltipTrigger>
              {unavailable ? <TooltipContent>{t('marketing.sms.serviceUnavailable')}</TooltipContent> : null}
            </Tooltip>
          </TooltipProvider>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.recentSends')}</CardTitle>
        </CardHeader>
        <CardContent>
          {balanceLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-3/4" />
            </div>
          ) : (
            <ul className="space-y-2 text-sm">
              {messages.map((m) => (
                <li key={m.id} className="flex justify-between border-b pb-2">
                  <span>{m.sending_type}</span>
                  <span>{m.status}</span>
                  <span>{m.cost?.toLocaleString()}</span>
                </li>
              ))}
              {!messages.length ? <p className="text-muted-foreground">{t('marketing.sms.noMessages')}</p> : null}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
