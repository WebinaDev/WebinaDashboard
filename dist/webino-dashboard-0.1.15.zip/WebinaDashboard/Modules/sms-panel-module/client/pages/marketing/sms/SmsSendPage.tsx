import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Loader2 } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { calculateSmsPrice, sendSms, sendSmsP2p } from '@/lib/modirpayamak-api'
import { toastApiError } from '@/lib/apiError'

type SendMode = 'webservice' | 'pattern' | 'p2p'

export default function SmsSendPage() {
  const { t } = useTranslation()
  const [mode, setMode] = useState<SendMode>('webservice')
  const [phone, setPhone] = useState('')
  const [phones, setPhones] = useState('')
  const [message, setMessage] = useState('')
  const [from, setFrom] = useState('')
  const [patternCode, setPatternCode] = useState('')
  const [patternParams, setPatternParams] = useState('')
  const [priceHint, setPriceHint] = useState<string>('')
  const [loading, setLoading] = useState(false)

  const estimate = async () => {
    try {
      const recipients = mode === 'p2p' ? phones.split(/[\n,;]+/).filter(Boolean) : [phone]
      const res = await calculateSmsPrice({
        sending_type: mode === 'pattern' ? 'pattern' : 'webservice',
        recipient_count: recipients.length,
        message: message || 'test',
      })
      if (res.customer_cost != null) setPriceHint(String(res.customer_cost))
    } catch {
      setPriceHint('')
    }
  }

  const submit = async () => {
    setLoading(true)
    try {
      if (mode === 'p2p') {
        const list = phones.split(/[\n,;]+/).map((p) => p.trim()).filter(Boolean)
        const res = await sendSmsP2p({
          sending_type: 'peer_to_peer',
          from_number: from || undefined,
          params: {
            groups: [{ message, recipients: list }],
          },
        })
        if (res.ok) toast.success(t('marketing.sms.sent'))
        else toast.error(t('marketing.sms.sendFailed'))
      } else if (mode === 'pattern') {
        let params: Record<string, string> = {}
        try {
          params = JSON.parse(patternParams || '{}') as Record<string, string>
        } catch {
          toast.error(t('marketing.sms.invalidJson'))
          setLoading(false)
          return
        }
        const res = await sendSms({
          sending_type: 'pattern',
          from_number: from || undefined,
          code: patternCode,
          recipients: [phone],
          params,
        })
        if (res.ok) toast.success(t('marketing.sms.sent'))
        else toast.error(t('marketing.sms.sendFailed'))
      } else {
        const res = await sendSms({
          phone,
          message,
          ...(from ? { from_number: from } : {}),
        })
        if (res.ok) toast.success(t('marketing.sms.sent'))
        else toast.error(t('marketing.sms.sendFailed'))
      }
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setLoading(false)
  }

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.sendTitle')}</h1>
      <Card className="max-w-xl">
        <CardHeader>
          <CardTitle>{t('marketing.sms.sendTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>{t('marketing.sms.sendMode')}</Label>
            <Select value={mode} onValueChange={(v) => setMode(v as SendMode)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="webservice">{t('marketing.sms.modeWebservice')}</SelectItem>
                <SelectItem value="pattern">{t('marketing.sms.modePattern')}</SelectItem>
                <SelectItem value="p2p">{t('marketing.sms.modeP2p')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>{t('marketing.sms.fromNumber')}</Label>
            <Input className="mt-1" value={from} onChange={(e) => setFrom(e.target.value)} placeholder="+983000505" />
          </div>
          {mode === 'p2p' ? (
            <div>
              <Label>{t('marketing.sms.phonesList')}</Label>
              <Textarea className="mt-1 font-mono text-sm" rows={4} value={phones} onChange={(e) => setPhones(e.target.value)} />
            </div>
          ) : (
            <div>
              <Label>{t('marketing.sms.phone')}</Label>
              <Input className="mt-1" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
          )}
          {mode === 'pattern' ? (
            <>
              <div>
                <Label>{t('marketing.sms.patternCode')}</Label>
                <Input className="mt-1" value={patternCode} onChange={(e) => setPatternCode(e.target.value)} />
              </div>
              <div>
                <Label>{t('marketing.sms.patternParams')}</Label>
                <Textarea
                  className="mt-1 font-mono text-sm"
                  rows={3}
                  value={patternParams}
                  onChange={(e) => setPatternParams(e.target.value)}
                  placeholder='{"order_id":"123"}'
                />
              </div>
            </>
          ) : (
            <div>
              <Label>{t('marketing.sms.message')}</Label>
              <Textarea className="mt-1" rows={4} value={message} onChange={(e) => setMessage(e.target.value)} />
            </div>
          )}
          {priceHint ? (
            <p className="text-muted-foreground text-sm">{t('marketing.sms.estimatedCost', { cost: priceHint })}</p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" onClick={() => void estimate()}>
              {t('marketing.sms.estimatePrice')}
            </Button>
            <Button type="button" disabled={loading} onClick={() => void submit()}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {t('marketing.sms.send')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
