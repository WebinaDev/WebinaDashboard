<?php
/**
 * WooCommerce order status → SMS event_key mapping.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maps WC statuses and custom hooks to CRM event keys.
 */
final class Webino_Dashboard_Sms_Order_Map {

	/**
	 * Well-known aliases (WC slug → event_key) for backwards compatibility.
	 *
	 * @return array<string,string>
	 */
	public static function status_to_event() {
		return array(
			'pending'    => 'pending_on_status',
			'processing' => 'processing',
			'on-hold'    => 'on-hold',
			'completed'  => 'completed',
			'cancelled'  => 'cancelled',
			'refunded'   => 'refunded',
			'failed'     => 'failed',
			'draft'      => 'checkout-draft',
			'checkout-draft' => 'checkout-draft',
		);
	}

	/**
	 * Custom statuses used by Webina shops (slug may vary; filterable).
	 *
	 * @return array<string,string>
	 */
	public static function custom_status_to_event() {
		$map = array(
			'sent-to-warehouse'    => 'sent-to-warehouse',
			'packaged'             => 'packaged',
			'courier'              => 'courier',
			'post'                 => 'post',
			'tipax'                => 'tipax',
			'wc-sent-to-warehouse' => 'sent-to-warehouse',
			'wc-packaged'          => 'packaged',
			'wc-courier'           => 'courier',
			'wc-post'              => 'post',
			'wc-tipax'             => 'tipax',
		);
		return apply_filters( 'webino_dashboard_sms_custom_status_map', $map );
	}

	/**
	 * Extra (non-status) SMS events.
	 *
	 * @return array<int,array{key:string,label:string,kind:string}>
	 */
	public static function extra_events() {
		return array(
			array(
				'key'   => 'pending_on_create',
				'label' => __( 'Pending payment (order created)', 'webino-dashboard' ),
				'kind'  => 'extra',
			),
			array(
				'key'   => 'post-barcode',
				'label' => __( 'Post barcode saved', 'webino-dashboard' ),
				'kind'  => 'extra',
			),
			array(
				'key'   => 'stock-low',
				'label' => __( 'Low stock', 'webino-dashboard' ),
				'kind'  => 'extra',
			),
			array(
				'key'   => 'stock-out',
				'label' => __( 'Out of stock', 'webino-dashboard' ),
				'kind'  => 'extra',
			),
		);
	}

	/**
	 * @param string $status Order status slug (with or without wc- prefix).
	 * @return string Event key (never null for a non-empty status).
	 */
	public static function event_for_status( $status ) {
		$status = sanitize_key( (string) $status );
		if ( '' === $status ) {
			return '';
		}
		if ( str_starts_with( $status, 'wc-' ) ) {
			$status = substr( $status, 3 );
		}
		$all = array_merge( self::status_to_event(), self::custom_status_to_event() );
		if ( isset( $all[ $status ] ) ) {
			return $all[ $status ];
		}
		if ( isset( $all[ 'wc-' . $status ] ) ) {
			return $all[ 'wc-' . $status ];
		}
		// Any WooCommerce status (including custom plugins) is a valid event key.
		return $status;
	}

	/**
	 * Full event catalog for UI + CRM sync: all WC statuses + extras.
	 *
	 * @return array<int,array{key:string,label:string,kind:string}>
	 */
	public static function event_catalog() {
		$catalog = array();
		$seen    = array();

		foreach ( self::extra_events() as $row ) {
			$key = sanitize_key( $row['key'] );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$catalog[]    = array(
				'key'   => $key,
				'label' => (string) $row['label'],
				'kind'  => 'extra',
			);
		}

		$wc_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		foreach ( $wc_statuses as $wc_key => $label ) {
			$slug = str_replace( 'wc-', '', sanitize_key( (string) $wc_key ) );
			if ( '' === $slug ) {
				continue;
			}
			$event_key = self::event_for_status( $slug );
			if ( '' === $event_key || isset( $seen[ $event_key ] ) ) {
				continue;
			}
			$seen[ $event_key ] = true;
			$catalog[]          = array(
				'key'   => $event_key,
				'label' => wp_strip_all_tags( (string) $label ),
				'kind'  => 'status',
			);
		}

		// Ensure well-known custom keys appear even if not registered in WC yet.
		foreach ( array_unique( array_values( self::custom_status_to_event() ) ) as $key ) {
			$key = sanitize_key( $key );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$catalog[]    = array(
				'key'   => $key,
				'label' => $key,
				'kind'  => 'status',
			);
		}

		return apply_filters( 'webino_dashboard_sms_event_catalog', $catalog );
	}

	/**
	 * @return array<int,string> All known event keys (catalog + legacy defaults).
	 */
	public static function all_event_keys() {
		$keys = array();
		foreach ( self::event_catalog() as $row ) {
			$keys[] = $row['key'];
		}
		return array_values( array_unique( $keys ) );
	}
}
