<?php
/**
 * SMS panel module bootstrap.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dir = dirname( __FILE__ ) . '/includes/';
if ( ! class_exists( 'Webino_Dashboard_Module_Registry', false )
	|| ! Webino_Dashboard_Module_Registry::require_module_files(
		$dir,
		array(
			'class-webino-dashboard-sms-settings.php',
			'class-webino-dashboard-sms.php',
			'class-webino-dashboard-sms-order-map.php',
			'class-webino-dashboard-sms-order-hooks.php',
			'class-webino-dashboard-sms-warehouse-stock.php',
			'class-webino-dashboard-rest-modirpayamak.php',
		),
		'sms-panel-module'
	) ) {
	return;
}

Webino_Dashboard_REST_ModirPayamak::init();
Webino_Dashboard_Sms_Order_Hooks::init();
