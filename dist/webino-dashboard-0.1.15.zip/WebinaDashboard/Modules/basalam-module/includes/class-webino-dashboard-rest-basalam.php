<?php
/**
 * Basalam dashboard REST endpoints.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Dashboard_REST_Basalam {
	const NS = 'webino-dashboard/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/basalam/settings',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_get' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_post' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/basalam/coverage/endpoints',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'coverage_get' ),
			)
		);
		register_rest_route(
			self::NS,
			'/basalam/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'status_get' ),
			)
		);
		register_rest_route(
			self::NS,
			'/basalam/reconcile',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'reconcile_post' ),
			)
		);
	}

	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	public static function settings_get() {
		$s = Basalam_Config::get();
		$s['client_secret'] = '';
		return new WP_REST_Response( array( 'settings' => $s ) );
	}

	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		$s = Basalam_Config::save( $data );
		$s['client_secret'] = '';
		return new WP_REST_Response( array( 'settings' => $s ) );
	}

	public static function coverage_get() {
		return new WP_REST_Response( Basalam_Endpoint_Registry::report() );
	}

	public static function status_get() {
		$wallet = Basalam_Wallet_Service::wallet_overview();
		$plans  = Basalam_Subscriptions_Service::plans();
		return new WP_REST_Response(
			array(
				'wallet_ok' => ! is_wp_error( $wallet ),
				'plans_ok'  => ! is_wp_error( $plans ),
				'jobs'      => Basalam_Jobs::queue(),
				'checked_at'=> gmdate( 'c' ),
			)
		);
	}

	public static function reconcile_post() {
		Basalam_Jobs::enqueue( 'reconcile_wallet', array(), 0 );
		Basalam_Jobs::enqueue( 'reconcile_subscriptions', array(), 0 );
		return new WP_REST_Response( array( 'ok' => true ) );
	}
}
