<?php
/**
 * Basalam auth/token service.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Basalam_Auth {
	/**
	 * @return string|WP_Error
	 */
	public static function access_token() {
		$s = Basalam_Config::get();
		$exp = (int) ( $s['token_expires_at'] ?? 0 );
		if ( ! empty( $s['access_token'] ) && $exp > time() + 60 ) {
			return (string) $s['access_token'];
		}
		return self::refresh_access_token();
	}

	/**
	 * @return string|WP_Error
	 */
	public static function refresh_access_token() {
		$s = Basalam_Config::get();
		if ( empty( $s['refresh_token'] ) ) {
			return new WP_Error( 'basalam_no_refresh_token', __( 'Missing Basalam refresh token.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}

		$response = Basalam_Client::raw_request(
			'POST',
			'/oauth/token',
			array(
				'grant_type'    => 'refresh_token',
				'refresh_token' => (string) $s['refresh_token'],
				'client_id'     => (string) $s['client_id'],
				'client_secret' => (string) $s['client_secret'],
			),
			false
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$token = (string) ( $response['access_token'] ?? '' );
		if ( '' === $token ) {
			return new WP_Error( 'basalam_token_invalid', __( 'Basalam token response is invalid.', 'webino-dashboard' ), array( 'status' => 502 ) );
		}

		$expires_in = max( 300, (int) ( $response['expires_in'] ?? 3600 ) );
		$new = Basalam_Config::save(
			array(
				'access_token'     => $token,
				'refresh_token'    => (string) ( $response['refresh_token'] ?? $s['refresh_token'] ),
				'token_expires_at' => time() + $expires_in,
			)
		);

		return (string) $new['access_token'];
	}
}
