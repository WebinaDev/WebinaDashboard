<?php
/**
 * WooCommerce Basalam payment gateway.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
	return;
}

class WC_Gateway_Basalam extends WC_Payment_Gateway {
	public function __construct() {
		$this->id                 = 'basalam_gateway';
		$this->method_title       = __( 'Basalam Gateway', 'webino-dashboard' );
		$this->method_description = __( 'Pay with Basalam integrated payment gateway.', 'webino-dashboard' );
		$this->has_fields         = false;
		$this->supports           = array( 'products', 'refunds' );
		$this->init_form_fields();
		$this->init_settings();
		$this->title = $this->get_option( 'title', __( 'Basalam', 'webino-dashboard' ) );
		$this->enabled = $this->get_option( 'enabled', 'no' );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'webino-dashboard' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Basalam Gateway', 'webino-dashboard' ),
				'default' => 'no',
			),
			'title'   => array(
				'title'   => __( 'Title', 'webino-dashboard' ),
				'type'    => 'text',
				'default' => __( 'Basalam', 'webino-dashboard' ),
			),
		);
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$init = Basalam_Gateway_Service::create_payment( $order );
		if ( is_wp_error( $init ) ) {
			wc_add_notice( $init->get_error_message(), 'error' );
			return array( 'result' => 'failure' );
		}
		$redirect = (string) ( $init['redirect_url'] ?? $order->get_checkout_payment_url( true ) );
		return array(
			'result'   => 'success',
			'redirect' => $redirect,
		);
	}
}
