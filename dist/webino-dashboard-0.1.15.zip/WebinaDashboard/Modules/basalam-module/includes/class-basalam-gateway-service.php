<?php
/**
 * Basalam gateway/payment flow service.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Basalam_Gateway_Service {
	/**
	 * @param WC_Order $order Order.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function create_payment( $order ) {
		$payload = array(
			'order_id'      => (int) $order->get_id(),
			'amount'        => (float) $order->get_total(),
			'currency'      => $order->get_currency(),
			'callback_url'  => home_url( '/wc-api/webino_basalam_gateway' ),
			'customer_phone'=> $order->get_billing_phone(),
		);
		$res = Basalam_Client::request( 'POST', '/gateway/payments', $payload );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$tx = sanitize_text_field( (string) ( $res['transaction_id'] ?? '' ) );
		if ( '' !== $tx ) {
			$order->update_meta_data( '_basalam_transaction_id', $tx );
			$order->save();
		}
		return $res;
	}

	/**
	 * @param int    $order_id Order ID.
	 * @param string $transaction_id Transaction ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function verify_payment( $order_id, $transaction_id ) {
		$res = Basalam_Client::request(
			'POST',
			'/gateway/payments/verify',
			array(
				'order_id'       => (int) $order_id,
				'transaction_id' => sanitize_text_field( $transaction_id ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$order = wc_get_order( $order_id );
		if ( $order instanceof WC_Order ) {
			$order->payment_complete( (string) ( $res['reference'] ?? '' ) );
			$order->add_order_note( __( 'Basalam payment verified.', 'webino-dashboard' ) );
			$order->save();
		}
		return $res;
	}
}
