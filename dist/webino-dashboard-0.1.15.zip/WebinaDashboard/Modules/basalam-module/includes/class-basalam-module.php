<?php
/**
 * Basalam module runtime.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Basalam_Module {
	public static function init() {
		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'register_gateway' ) );
		add_action( 'woocommerce_api_webino_basalam_gateway', array( __CLASS__, 'gateway_callback' ) );
		add_action( 'webino_basalam_process_jobs', array( 'Basalam_Jobs', 'process_due' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		Basalam_Webhook_Handler::init();
		if ( ! wp_next_scheduled( 'webino_basalam_process_jobs' ) ) {
			wp_schedule_event( time() + 60, 'basalam_minute', 'webino_basalam_process_jobs' );
		}
	}

	public static function register_gateway( $methods ) {
		if ( class_exists( 'WC_Gateway_Basalam', false ) ) {
			$methods[] = 'WC_Gateway_Basalam';
		}
		return $methods;
	}

	public static function gateway_callback() {
		$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tx       = isset( $_GET['transaction_id'] ) ? sanitize_text_field( wp_unslash( $_GET['transaction_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $order_id > 0 && '' !== $tx ) {
			$res = Basalam_Gateway_Service::verify_payment( $order_id, $tx );
			if ( is_wp_error( $res ) ) {
				wp_die( esc_html( $res->get_error_message() ) );
			}
		}
		wp_safe_redirect( wc_get_endpoint_url( 'order-received', (string) $order_id, wc_get_checkout_url() ) );
		exit;
	}

	public static function cron_schedules( $schedules ) {
		$schedules['basalam_minute'] = array(
			'interval' => 60,
			'display'  => 'Basalam every minute',
		);
		return $schedules;
	}
}
