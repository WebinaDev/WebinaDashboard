<?php
/**
 * Basalam webhook handler.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Basalam_Webhook_Handler {
	const QUERY_VAR = 'webino_basalam_webhook';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_rewrite' ) );
		add_action( 'parse_request', array( __CLASS__, 'handle_request' ) );
	}

	public static function register_rewrite() {
		add_rewrite_rule( '^webino/basalam-webhook/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
		add_filter(
			'query_vars',
			static function ( $vars ) {
				$vars[] = self::QUERY_VAR;
				return $vars;
			}
		);
	}

	public static function handle_request( $wp ) {
		if ( empty( $wp->query_vars[ self::QUERY_VAR ] ) ) {
			return;
		}
		$body = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$payload = json_decode( (string) $body, true );
		if ( ! is_array( $payload ) ) {
			status_header( 400 );
			wp_send_json_error( array( 'message' => 'Invalid payload' ), 400 );
		}
		$signature = isset( $_SERVER['HTTP_X_BASALAM_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_BASALAM_SIGNATURE'] ) ) : '';
		$secret    = (string) ( Basalam_Config::get()['webhook_secret'] ?? '' );
		if ( '' !== $secret ) {
			$computed = hash_hmac( 'sha256', (string) $body, $secret );
			if ( ! hash_equals( $computed, $signature ) ) {
				status_header( 401 );
				wp_send_json_error( array( 'message' => 'Invalid signature' ), 401 );
			}
		}
		Basalam_Jobs::enqueue( 'webhook_event', $payload, 0 );
		wp_send_json_success( array( 'ok' => true ) );
	}
}
