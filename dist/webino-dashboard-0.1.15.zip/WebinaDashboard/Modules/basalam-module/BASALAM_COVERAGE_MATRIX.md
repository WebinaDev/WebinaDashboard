# Basalam Coverage Contract

Status legend: `implemented`, `queued`, `pending`.

## Domain mapping

- `AuthAndTokenService`:
  - `POST /oauth/token` (`implemented`)
- `GatewayPaymentService`:
  - `POST /gateway/payments` (`implemented`)
  - `POST /gateway/payments/verify` (`implemented`)
- `WalletService`:
  - `GET /wallet/overview` (`implemented`)
  - `GET /wallet/settlements` (`implemented`)
- `PlansAndSubscriptionsService`:
  - `GET /subscriptions/plans` (`implemented`)
  - `GET /subscriptions/items` (`implemented`)
- `WebhookService`:
  - `POST /webhooks/events` (`implemented`)

## Woo/dashboard surfaces

- Woo gateway: `WC_Gateway_Basalam`
- Callback: `woocommerce_api_webino_basalam_gateway`
- Dashboard REST:
  - `GET/POST /webino-dashboard/v1/basalam/settings`
  - `GET /webino-dashboard/v1/basalam/status`
  - `GET /webino-dashboard/v1/basalam/coverage/endpoints`
  - `POST /webino-dashboard/v1/basalam/reconcile`
