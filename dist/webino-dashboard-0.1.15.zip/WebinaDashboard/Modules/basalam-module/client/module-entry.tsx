import type { ComponentType } from 'react'

import BasalamSettingsPage from './pages/basalam/BasalamSettingsPage'

export const routes: Record<string, ComponentType> = {
  'settings/shop/basalam': BasalamSettingsPage,
  'settings/shop/basalam/payments': BasalamSettingsPage,
  'settings/shop/basalam/wallet': BasalamSettingsPage,
  'settings/shop/basalam/subscriptions': BasalamSettingsPage,
  'settings/shop/basalam/webhooks': BasalamSettingsPage,
  'settings/shop/basalam/operations': BasalamSettingsPage,
}

export default { routes }
