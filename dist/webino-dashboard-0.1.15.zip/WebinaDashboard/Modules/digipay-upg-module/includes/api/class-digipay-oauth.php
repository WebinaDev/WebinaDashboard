<?php
/**
 * DigiPay OAuth token helper.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Digipay_OAuth {

	const OPTION_KEY = 'webino_digipay_upg_settings';

	/**
	 * @return array<string,mixed>
	 */
	public static function settings() {
		$defaults = array(
			'environment'     => 'staging',
			'client_id'       => '',
			'client_secret'   => '',
			'username'        => '',
			'password'        => '',
			'digipay_version' => '2022-02-02',
			'seller_id'       => '',
			'supplier_id'     => '',
			'category_id'     => '',
			'product_type'    => 1,
		);
		$raw = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}
		return wp_parse_args( $raw, $defaults );
	}

	/**
	 * @return string
	 */
	public static function base_url() {
		$s = self::settings();
		return 'live' === $s['environment'] ? 'https://api.mydigipay.com/digipay/api' : 'https://uat.mydigipay.info/digipay/api';
	}

	/**
	 * @return string|WP_Error
	 */
	public static function get_access_token() {
		$cache_key = 'webino_digipay_upg_token';
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && ! empty( $cached['access_token'] ) ) {
			return (string) $cached['access_token'];
		}

		$s = self::settings();
		foreach ( array( 'client_id', 'client_secret', 'username', 'password' ) as $field ) {
			if ( empty( $s[ $field ] ) ) {
				return new WP_Error( 'digipay_missing_credentials', __( 'DigiPay credentials are incomplete.', 'webino-dashboard' ), array( 'status' => 400 ) );
			}
		}

		$auth = base64_encode( $s['client_id'] . ':' . $s['client_secret'] );
		$res  = wp_remote_post(
			trailingslashit( self::base_url() ) . 'oauth/token',
			array(
				'timeout' => 25,
				'headers' => array(
					'Authorization' => 'Basic ' . $auth,
				),
				'body'    => array(
					'username'   => $s['username'],
					'password'   => $s['password'],
					'grant_type' => 'password',
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['access_token'] ) ) {
			return new WP_Error( 'digipay_auth_failed', __( 'Failed to authenticate with DigiPay.', 'webino-dashboard' ), array( 'status' => 502, 'response' => $body ) );
		}

		$ttl = isset( $body['expires_in'] ) ? max( 60, (int) $body['expires_in'] - 60 ) : 300;
		set_transient( $cache_key, $body, $ttl );
		return (string) $body['access_token'];
	}
}
