<?php
/**
 * Dashboard REST endpoints for DigiPay settings and logs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Dashboard_REST_Digipay {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return bool
	 */
	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/digipay/settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'settings_get' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'settings_post' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/digipay/test-connection',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'test_connection' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
		register_rest_route(
			self::NS,
			'/digipay/transactions',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'transactions_get' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		$settings = Digipay_OAuth::settings();
		$settings['client_secret'] = '';
		$settings['has_client_secret'] = ! empty( Digipay_OAuth::settings()['client_secret'] );
		return new WP_REST_Response( array( 'settings' => $settings ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'digipay_invalid_body', __( 'Invalid request body.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$current = Digipay_OAuth::settings();
		$merged  = array_merge( $current, $data );
		if ( empty( $data['client_secret'] ) ) {
			$merged['client_secret'] = $current['client_secret'];
		}
		update_option( Digipay_OAuth::OPTION_KEY, $merged, false );
		$merged['client_secret'] = '';
		$merged['has_client_secret'] = ! empty( $current['client_secret'] ) || ! empty( $data['client_secret'] );
		return new WP_REST_Response( array( 'settings' => $merged ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function test_connection() {
		$token = Digipay_OAuth::get_access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function transactions_get() {
		$logs = get_option( Digipay_Lifecycle::LOG_OPTION, array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}
		return new WP_REST_Response( array( 'items' => array_values( $logs ) ) );
	}
}
