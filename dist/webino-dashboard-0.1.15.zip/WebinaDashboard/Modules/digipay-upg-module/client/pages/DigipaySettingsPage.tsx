import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation } from 'react-router-dom'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type DigipaySettings = {
  environment: 'staging' | 'live'
  client_id: string
  client_secret?: string
  has_client_secret?: boolean
  username: string
  password: string
  digipay_version: string
  seller_id: string
  supplier_id: string
  category_id: string
  product_type: number
}

type DigipayLog = {
  time: string
  order_id: number
  endpoint: string
  success: boolean
  message: string
  http_code?: number | null
}

export default function DigipaySettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const location = useLocation()
  const isTransactions = location.pathname.endsWith('/transactions')

  const settingsQ = useQuery({
    queryKey: ['digipay', 'settings'],
    queryFn: async () => apiFetch<{ settings: DigipaySettings }>('digipay/settings'),
  })

  const logsQ = useQuery({
    queryKey: ['digipay', 'logs'],
    queryFn: async () => apiFetch<{ items: DigipayLog[] }>('digipay/transactions'),
    enabled: isTransactions,
  })

  const [draft, setDraft] = useState<DigipaySettings | null>(null)

  const settings = useMemo(() => {
    const incoming = settingsQ.data?.settings
    if (!incoming) return draft
    if (!draft) {
      setDraft(incoming)
      return incoming
    }
    return draft
  }, [settingsQ.data?.settings, draft])

  const save = useMutation({
    mutationFn: async () =>
      apiFetch<{ settings: DigipaySettings }>('digipay/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      }),
    onSuccess: async () => {
      toast.success(t('common.saved'))
      await qc.invalidateQueries({ queryKey: ['digipay', 'settings'] })
      await qc.invalidateQueries({ queryKey: ['payment-gateways'] })
    },
    onError: (err: Error) => toastApiError(t, err),
  })

  const testConnection = useMutation({
    mutationFn: async () => apiFetch<{ ok: boolean }>('digipay/test-connection', { method: 'POST' }),
    onSuccess: () => toast.success(t('digipay.testSuccess')),
    onError: (err: Error) => toastApiError(t, err),
  })

  const shellTitle = isTransactions ? t('digipay.transactionsTitle') : t('digipay.settingsTitle')

  return (
    <PageShell title={shellTitle} subtitle={t('digipay.settingsSubtitle')}>
      {isTransactions ? (
        <section className="rounded-lg border border-border p-4">
          <h2 className="mb-3 text-sm font-semibold">{t('digipay.transactionsTitle')}</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-muted-foreground text-xs">
                  <th className="px-2 py-2 text-start">{t('digipay.col.time')}</th>
                  <th className="px-2 py-2 text-start">{t('digipay.col.order')}</th>
                  <th className="px-2 py-2 text-start">{t('digipay.col.endpoint')}</th>
                  <th className="px-2 py-2 text-start">{t('digipay.col.status')}</th>
                  <th className="px-2 py-2 text-start">{t('digipay.col.message')}</th>
                </tr>
              </thead>
              <tbody>
                {(logsQ.data?.items ?? []).map((log, idx) => (
                  <tr key={`${log.time}-${idx}`} className="border-t">
                    <td className="px-2 py-2">{log.time}</td>
                    <td className="px-2 py-2">#{log.order_id}</td>
                    <td className="px-2 py-2">{log.endpoint}</td>
                    <td className="px-2 py-2">{log.success ? t('digipay.status.ok') : t('digipay.status.failed')}</td>
                    <td className="px-2 py-2">{log.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : (
        <section className="space-y-4 rounded-lg border border-border p-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>{t('digipay.environment')}</Label>
              <Select
                value={settings?.environment ?? 'staging'}
                onValueChange={(v) => setDraft((prev) => ({ ...(prev as DigipaySettings), environment: v as 'staging' | 'live' }))}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="staging">{t('digipay.env.staging')}</SelectItem>
                  <SelectItem value="live">{t('digipay.env.live')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Field label={t('digipay.field.version')} value={settings?.digipay_version ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), digipay_version: v }))} />
            <Field label={t('digipay.field.clientId')} value={settings?.client_id ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), client_id: v }))} />
            <Field label={t('digipay.field.clientSecret')} type="password" value={settings?.client_secret ?? ''} placeholder={settings?.has_client_secret ? '••••••••' : ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), client_secret: v }))} />
            <Field label={t('digipay.field.username')} value={settings?.username ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), username: v }))} />
            <Field label={t('digipay.field.password')} type="password" value={settings?.password ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), password: v }))} />
            <Field label={t('digipay.field.sellerId')} value={settings?.seller_id ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), seller_id: v }))} />
            <Field label={t('digipay.field.supplierId')} value={settings?.supplier_id ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), supplier_id: v }))} />
            <Field label={t('digipay.field.categoryId')} value={settings?.category_id ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), category_id: v }))} />
            <Field label={t('digipay.field.productType')} type="number" value={String(settings?.product_type ?? 1)} onChange={(v) => setDraft((p) => ({ ...(p as DigipaySettings), product_type: parseInt(v || '1', 10) }))} />
          </div>
          <div className="flex gap-2">
            <Button onClick={() => void save.mutate()} disabled={!settings || save.isPending}>{t('common.save')}</Button>
            <Button variant="outline" onClick={() => void testConnection.mutate()} disabled={testConnection.isPending}>{t('digipay.testConnection')}</Button>
          </div>
        </section>
      )}
    </PageShell>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string
  value: string
  onChange: (next: string) => void
  type?: string
  placeholder?: string
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Input type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </div>
  )
}
