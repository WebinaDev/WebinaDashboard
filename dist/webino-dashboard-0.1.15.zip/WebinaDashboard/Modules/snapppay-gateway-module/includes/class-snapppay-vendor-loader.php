<?php
/**
 * Loads bundled SnappPay / Searchwise vendor plugins or defers to standalone installs.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Vendor bootstrap for SnappPay gateway module.
 */
final class Webino_SnappPay_Vendor_Loader {

	const STANDALONE_GATEWAY = 'snapppay-woocommerce-gateway/index.php';

	const STANDALONE_SEARCHWISE = 'searchwise-woocommerce-plugin-main/searchwise-api-data-feed.php';

	const BUNDLED_GATEWAY = 'snapppay-woocommerce-gateway/index.php';

	const BUNDLED_SEARCHWISE = 'searchwise-woocommerce-plugin/searchwise-api-data-feed.php';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_load' ), 21 );
	}

	/**
	 * @return string Absolute vendor directory with trailing slash.
	 */
	public static function vendor_dir() {
		return trailingslashit( dirname( __DIR__ ) ) . 'vendor/';
	}

	/**
	 * @return bool
	 */
	public static function woocommerce_ready() {
		return class_exists( 'WooCommerce', false );
	}

	/**
	 * @return bool
	 */
	public static function is_gateway_loaded() {
		return self::gateway_loaded_marker();
	}

	/**
	 * @return bool
	 */
	public static function is_searchwise_loaded() {
		return self::searchwise_loaded_marker();
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function status() {
		return array(
			'woocommerce_ready'  => self::woocommerce_ready(),
			'gateway_loaded'     => self::is_gateway_loaded(),
			'searchwise_loaded'  => self::is_searchwise_loaded(),
			'gateway_source'     => self::gateway_source(),
			'searchwise_source'  => self::searchwise_source(),
			'standalone_gateway' => self::standalone_plugin_active( self::STANDALONE_GATEWAY ),
			'bundled_gateway'    => is_readable( self::vendor_dir() . self::BUNDLED_GATEWAY ),
		);
	}

	/**
	 * @return void
	 */
	public static function maybe_load() {
		if ( ! self::woocommerce_ready() ) {
			return;
		}

		self::maybe_load_gateway();
		self::maybe_load_searchwise();
	}

	/**
	 * @return void
	 */
	private static function maybe_load_gateway() {
		if ( self::gateway_loaded_marker() ) {
			return;
		}
		if ( self::standalone_plugin_active( self::STANDALONE_GATEWAY ) ) {
			return;
		}
		$path = self::vendor_dir() . self::BUNDLED_GATEWAY;
		if ( is_readable( $path ) ) {
			require_once $path;
			self::set_gateway_loaded_marker();
		}
	}

	/**
	 * @return void
	 */
	private static function maybe_load_searchwise() {
		if ( self::searchwise_loaded_marker() ) {
			return;
		}
		if ( self::standalone_plugin_active( self::STANDALONE_SEARCHWISE ) ) {
			return;
		}
		$path = self::vendor_dir() . self::BUNDLED_SEARCHWISE;
		if ( is_readable( $path ) ) {
			require_once $path;
			self::set_searchwise_loaded_marker();
		}
	}

	/**
	 * @param string $plugin Plugin basename relative to wp-content/plugins/.
	 * @return bool
	 */
	private static function standalone_plugin_active( $plugin ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active( $plugin );
	}

	/**
	 * @return string missing|standalone|bundled
	 */
	private static function gateway_source() {
		if ( self::gateway_loaded_marker() ) {
			return self::standalone_plugin_active( self::STANDALONE_GATEWAY ) ? 'standalone' : 'bundled';
		}
		if ( self::standalone_plugin_active( self::STANDALONE_GATEWAY ) ) {
			return 'standalone';
		}
		if ( is_readable( self::vendor_dir() . self::BUNDLED_GATEWAY ) ) {
			return 'bundled_pending';
		}
		return 'missing';
	}

	/**
	 * @return string missing|standalone|bundled
	 */
	private static function searchwise_source() {
		if ( self::searchwise_loaded_marker() ) {
			return self::standalone_plugin_active( self::STANDALONE_SEARCHWISE ) ? 'standalone' : 'bundled';
		}
		if ( self::standalone_plugin_active( self::STANDALONE_SEARCHWISE ) ) {
			return 'standalone';
		}
		if ( is_readable( self::vendor_dir() . self::BUNDLED_SEARCHWISE ) ) {
			return 'bundled_pending';
		}
		return 'missing';
	}

	/**
	 * @return bool
	 */
	private static function gateway_loaded_marker() {
		return (bool) apply_filters( 'webino_snapppay_gateway_loaded', defined( 'SNAPPPAY_WC_GATEWAY_LOADED' ) && SNAPPPAY_WC_GATEWAY_LOADED );
	}

	/**
	 * @return void
	 */
	private static function set_gateway_loaded_marker() {
		if ( ! defined( 'SNAPPPAY_WC_GATEWAY_LOADED' ) ) {
			define( 'SNAPPPAY_WC_GATEWAY_LOADED', true );
		}
	}

	/**
	 * @return bool
	 */
	private static function searchwise_loaded_marker() {
		return (bool) apply_filters( 'webino_snapppay_searchwise_loaded', defined( 'SEARCHWISE_WC_FEED_LOADED' ) && SEARCHWISE_WC_FEED_LOADED );
	}

	/**
	 * @return void
	 */
	private static function set_searchwise_loaded_marker() {
		if ( ! defined( 'SEARCHWISE_WC_FEED_LOADED' ) ) {
			define( 'SEARCHWISE_WC_FEED_LOADED', true );
		}
	}
}
