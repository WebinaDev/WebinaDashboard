<?php
/**
 * REST endpoints for SnappPay gateway module.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SnappPay dashboard REST API.
 */
final class Webino_Dashboard_REST_SnappPay {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/snapppay/settings',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_get' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_post' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/snapppay/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'status' ),
			)
		);
	}

	/**
	 * @return bool
	 */
	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		return new WP_REST_Response(
			array(
				'settings' => Webino_SnappPay_Config::get(),
				'status'   => Webino_SnappPay_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		return new WP_REST_Response(
			array(
				'settings' => Webino_SnappPay_Config::save( is_array( $data ) ? $data : array() ),
				'status'   => Webino_SnappPay_Vendor_Loader::status(),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function status() {
		$vendor = Webino_SnappPay_Vendor_Loader::status();
		return new WP_REST_Response(
			array(
				'ok'                => $vendor['gateway_loaded'] && $vendor['woocommerce_ready'],
				'module'            => 'snapppay-gateway-module',
				'version'           => '1.4.2',
				'woocommerce_ready' => $vendor['woocommerce_ready'],
				'gateway_loaded'    => $vendor['gateway_loaded'],
				'searchwise_loaded' => $vendor['searchwise_loaded'],
				'gateway_source'    => $vendor['gateway_source'],
				'searchwise_source' => $vendor['searchwise_source'],
				'checked_at'        => gmdate( 'c' ),
			)
		);
	}
}
