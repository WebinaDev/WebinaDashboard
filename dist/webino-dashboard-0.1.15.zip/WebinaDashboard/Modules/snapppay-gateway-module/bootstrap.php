<?php
/**
 * SnappPay gateway module bootstrap.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dir = dirname( __FILE__ ) . '/includes/';

if ( ! class_exists( 'Webino_Dashboard_Module_Registry', false )
	|| ! Webino_Dashboard_Module_Registry::require_module_files(
		$dir,
		array(
			'class-snapppay-vendor-loader.php',
			'class-snapppay-config.php',
			'class-webino-dashboard-rest-snapppay.php',
		),
		'snapppay-gateway-module'
	) ) {
	return;
}

Webino_SnappPay_Vendor_Loader::init();
Webino_Dashboard_REST_SnappPay::init();
