# ماژول SnappPay Gateway

## معرفی
ماژول SnappPay درگاه پرداخت اسنپ‌پی را در Dashboard ثبت می‌کند. کد upstream از `vendor/` داخل ZIP ماژول یا از نصب standalone در `wp-content/plugins/` بارگذاری می‌شود.

## امکانات
- صفحه تنظیمات SnappPay در پنل فروشگاه
- REST تنظیمات و وضعیت runtime (gateway_loaded، searchwise_loaded)
- بارگذاری vendor از `vendor/` یا پلاگین standalone
- پشتیبانی اختیاری از Searchwise feed

## معماری
- bootstrap: `bootstrap.php`
- vendor loader: `includes/class-snapppay-vendor-loader.php`
- config: `includes/class-snapppay-config.php`
- REST: `includes/class-webino-dashboard-rest-snapppay.php`
- frontend: `client/dist/module.js`

## Vendor bundle
قبل از انتشار ZIP، فایل‌های licensed را در `vendor/` قرار دهید (جزئیات در `vendor/README.md`).

## پیش‌نیازها
- WooCommerce (`requires_woocommerce: true`)
- `manage_woocommerce`
- مسیر تنظیمات: `/settings/shop/snapppay`

## REST
- `GET/POST /wp-json/webino-dashboard/v1/snapppay/settings`
- `GET /wp-json/webino-dashboard/v1/snapppay/status`

## عیب‌یابی
- اگر gateway load نمی‌شود: `vendor/snapppay-woocommerce-gateway/index.php` یا پلاگین standalone را بررسی کنید.
- اگر status `gateway_source: missing` است: vendor bundle در ZIP release وجود ندارد.
