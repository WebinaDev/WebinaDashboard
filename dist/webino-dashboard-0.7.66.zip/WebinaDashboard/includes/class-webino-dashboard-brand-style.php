<?php
/**
 * Site-level brand style: accent, palette, logo/favicon, fonts.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared brand style for dashboard + AI + WFCP.
 */
final class Webino_Dashboard_Brand_Style {

	const OPTION = 'webino_dashboard_brand_style';

	/**
	 * @return list<string>
	 */
	public static function allowed_accents() {
		return array( 'colorful', 'default', 'red', 'rose', 'orange', 'green', 'blue', 'yellow', 'violet', 'cafe', 'cosmetics', 'mobile', 'electronics' );
	}

	/**
	 * @return list<string>
	 */
	public static function allowed_fonts() {
		return array( 'yekanbakh', 'system' );
	}

	/**
	 * @return array{
	 *   accent: string,
	 *   colors: array<string, string>,
	 *   logo_id: int,
	 *   favicon_id: int,
	 *   fonts: array{body: string, heading: string, ui: string}
	 * }
	 */
	public static function defaults() {
		return array(
			'accent'     => 'colorful',
			'colors'     => array(
				'primary'   => '#0f172a',
				'secondary' => '#334155',
				'accent'    => '#e11d48',
				'bg'        => '#ffffff',
				'surface'   => '#f8fafc',
				'text'      => '#0f172a',
				'muted'     => '#64748b',
			),
			'logo_id'    => 0,
			'favicon_id' => 0,
			'fonts'      => array(
				'body'    => 'yekanbakh',
				'heading' => 'yekanbakh',
				'ui'      => 'yekanbakh',
			),
		);
	}

	/**
	 * @return array{
	 *   accent: string,
	 *   colors: array<string, string>,
	 *   logo_id: int,
	 *   favicon_id: int,
	 *   fonts: array{body: string, heading: string, ui: string}
	 * }
	 */
	public static function get() {
		$raw = get_option( self::OPTION, null );
		return self::sanitize( $raw );
	}

	/**
	 * @param mixed $raw Raw.
	 * @return array{
	 *   accent: string,
	 *   colors: array<string, string>,
	 *   logo_id: int,
	 *   favicon_id: int,
	 *   fonts: array{body: string, heading: string, ui: string}
	 * }
	 */
	public static function sanitize( $raw ) {
		$defaults = self::defaults();
		if ( ! is_array( $raw ) ) {
			return $defaults;
		}

		$out = $defaults;

		$accent = isset( $raw['accent'] ) ? sanitize_key( (string) $raw['accent'] ) : '';
		if ( 'amber' === $accent ) {
			$accent = 'orange';
		}
		if ( in_array( $accent, self::allowed_accents(), true ) ) {
			$out['accent'] = $accent;
		}

		if ( isset( $raw['colors'] ) && is_array( $raw['colors'] ) ) {
			foreach ( array_keys( $defaults['colors'] ) as $key ) {
				if ( ! isset( $raw['colors'][ $key ] ) ) {
					continue;
				}
				$hex = self::sanitize_hex( (string) $raw['colors'][ $key ] );
				if ( '' !== $hex ) {
					$out['colors'][ $key ] = $hex;
				}
			}
		}

		$out['logo_id']    = isset( $raw['logo_id'] ) ? max( 0, (int) $raw['logo_id'] ) : 0;
		$out['favicon_id'] = isset( $raw['favicon_id'] ) ? max( 0, (int) $raw['favicon_id'] ) : 0;

		if ( isset( $raw['fonts'] ) && is_array( $raw['fonts'] ) ) {
			foreach ( array( 'body', 'heading', 'ui' ) as $slot ) {
				if ( ! isset( $raw['fonts'][ $slot ] ) ) {
					continue;
				}
				$f = sanitize_key( (string) $raw['fonts'][ $slot ] );
				if ( in_array( $f, self::allowed_fonts(), true ) ) {
					$out['fonts'][ $slot ] = $f;
				}
			}
		}

		return $out;
	}

	/**
	 * @param mixed $raw Raw settings.
	 * @return array{
	 *   accent: string,
	 *   colors: array<string, string>,
	 *   logo_id: int,
	 *   favicon_id: int,
	 *   fonts: array{body: string, heading: string, ui: string}
	 * }
	 */
	public static function set( $raw ) {
		$clean = self::sanitize( $raw );
		update_option( self::OPTION, $clean, false );

		// Keep WP site icon in sync for PWA / get_site_icon_url().
		$fav = (int) $clean['favicon_id'];
		if ( $fav > 0 && wp_attachment_is_image( $fav ) ) {
			update_option( 'site_icon', $fav );
		} elseif ( 0 === $fav ) {
			// Do not clear WP site_icon automatically — leave existing WP Customizer icon.
		}

		return $clean;
	}

	/**
	 * Brand color palette (AI-compatible slots).
	 *
	 * @return array<string, string>
	 */
	public static function palette() {
		return self::get()['colors'];
	}

	/**
	 * Locked dashboard accent for all users.
	 *
	 * @return string
	 */
	public static function accent() {
		return self::get()['accent'];
	}

	/**
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */
	public static function attachment_url( $attachment_id ) {
		$id = (int) $attachment_id;
		if ( $id <= 0 ) {
			return '';
		}
		$url = wp_get_attachment_image_url( $id, 'full' );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * @return string
	 */
	public static function logo_url() {
		return self::attachment_url( self::get()['logo_id'] );
	}

	/**
	 * @return string
	 */
	public static function favicon_url() {
		$s = self::get();
		if ( ! empty( $s['favicon_id'] ) ) {
			$url = self::attachment_url( (int) $s['favicon_id'] );
			if ( '' !== $url ) {
				return $url;
			}
		}
		$site = get_site_icon_url( 192 );
		return is_string( $site ) ? $site : '';
	}

	/**
	 * CSS font-family value for a font key.
	 *
	 * @param string $key yekanbakh|system.
	 * @return string
	 */
	public static function font_family_css( $key ) {
		$key = sanitize_key( (string) $key );
		if ( 'system' === $key ) {
			return "system-ui,-apple-system,'Segoe UI',Roboto,sans-serif";
		}
		return "'Yekan Bakh',Tahoma,sans-serif";
	}

	/**
	 * Inline CSS variables for html element (FOUC-safe).
	 *
	 * @return string
	 */
	public static function inline_font_css() {
		$fonts = self::get()['fonts'];
		$body  = self::font_family_css( $fonts['body'] );
		$head  = self::font_family_css( $fonts['heading'] );
		$ui    = self::font_family_css( $fonts['ui'] );
		return '--wd-font-body:' . $body . ';--wd-font-heading:' . $head . ';--wd-font-ui:' . $ui . ';';
	}

	/**
	 * Bootstrap / REST client payload.
	 *
	 * @return array<string, mixed>
	 */
	public static function client_payload() {
		$s = self::get();
		return array(
			'accent'     => $s['accent'],
			'colors'     => $s['colors'],
			'logo_id'    => (int) $s['logo_id'],
			'favicon_id' => (int) $s['favicon_id'],
			'fonts'      => $s['fonts'],
			'logoUrl'    => self::logo_url(),
			'faviconUrl' => self::favicon_url(),
		);
	}

	/**
	 * REST GET/POST response (includes resolved URLs for pickers).
	 *
	 * @return array<string, mixed>
	 */
	public static function settings_response() {
		$s = self::get();
		return array(
			'accent'      => $s['accent'],
			'colors'      => $s['colors'],
			'logo_id'     => (int) $s['logo_id'],
			'favicon_id'  => (int) $s['favicon_id'],
			'fonts'       => $s['fonts'],
			'logo_url'    => self::logo_url(),
			'favicon_url' => self::favicon_url(),
		);
	}

	/**
	 * @param string $hex Color.
	 * @return string
	 */
	private static function sanitize_hex( $hex ) {
		$hex = trim( (string) $hex );
		if ( function_exists( 'sanitize_hex_color' ) ) {
			$s = sanitize_hex_color( $hex );
			return is_string( $s ) ? $s : '';
		}
		if ( preg_match( '/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $hex ) ) {
			return strtolower( $hex );
		}
		return '';
	}
}
