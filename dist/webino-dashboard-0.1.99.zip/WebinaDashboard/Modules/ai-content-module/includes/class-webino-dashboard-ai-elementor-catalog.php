<?php
/**
 * Live Elementor widget + local template catalog for page design prompts.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lists widgets and local templates the compiler can actually build.
 */
final class Webino_Dashboard_AI_Elementor_Catalog {

	/**
	 * Widget types the compiler can emit (plus html fallback).
	 *
	 * @return list<string>
	 */
	public static function buildable_widgets() {
		return array(
			'html',
			'heading',
			'text-editor',
			'button',
			'image',
			'icon',
			'icon-box',
			'icon-list',
			'image-box',
			'image-carousel',
			'image-gallery',
			'video',
			'counter',
			'accordion',
			'tabs',
			'toggle',
			'testimonial',
			'star-rating',
			'social-icons',
			'progress',
			'price-table',
			'alert',
			'spacer',
			'divider',
			'inner-section',
			'nested-tabs',
			'nested-accordion',
			'form',
		);
	}

	/**
	 * Catalog for the LLM prompt (installed ∩ buildable).
	 *
	 * @return array<string,mixed>
	 */
	public static function for_prompt() {
		$installed = self::installed_widget_names();
		$buildable = self::buildable_widgets();
		$widgets   = array();
		foreach ( $buildable as $name ) {
			if ( ! $installed || in_array( $name, $installed, true ) || 'html' === $name || 'inner-section' === $name ) {
				$widgets[] = $name;
			}
		}
		if ( ! in_array( 'html', $widgets, true ) ) {
			$widgets[] = 'html';
		}

		return array(
			'elementor_active'   => defined( 'ELEMENTOR_VERSION' ),
			'elementor_version'  => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '',
			'widgets'            => $widgets,
			'installed_extra'    => array_values( array_diff( $installed, $buildable ) ),
			'local_templates'    => self::local_templates(),
			'media'              => self::recent_media(),
			'notes'              => array(
				'Unknown widget names compile as html widgets.',
				'Prefer html+css for cinematic heroes, bento grids, timelines, marquees, glass cards.',
				'Never set font-family; theme fonts apply.',
				'Use media[].id for image_id / gallery_ids when images exist.',
				'import_template_ids may only use local_templates[].id.',
			),
		);
	}

	/**
	 * @return list<string>
	 */
	public static function installed_widget_names() {
		if ( ! class_exists( '\Elementor\Plugin', false ) || ! isset( \Elementor\Plugin::$instance->widgets_manager ) ) {
			return self::buildable_widgets();
		}
		$wm = \Elementor\Plugin::$instance->widgets_manager;
		if ( ! method_exists( $wm, 'get_widget_types' ) ) {
			return self::buildable_widgets();
		}
		$types = $wm->get_widget_types();
		if ( ! is_array( $types ) ) {
			return self::buildable_widgets();
		}
		$names = array();
		foreach ( $types as $key => $widget ) {
			$name = is_object( $widget ) && method_exists( $widget, 'get_name' ) ? (string) $widget->get_name() : (string) $key;
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}
		$names = array_values( array_unique( $names ) );
		sort( $names );
		return $names;
	}

	/**
	 * @return list<array{id:int,title:string,type:string}>
	 */
	public static function local_templates() {
		$q = get_posts(
			array(
				'post_type'      => 'elementor_library',
				'post_status'    => 'publish',
				'posts_per_page' => 24,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		$out = array();
		foreach ( $q as $p ) {
			$out[] = array(
				'id'    => (int) $p->ID,
				'title' => (string) $p->post_title,
				'type'  => (string) get_post_meta( $p->ID, '_elementor_template_type', true ),
			);
		}
		return $out;
	}

	/**
	 * @param int $template_id Template post ID.
	 * @return array<int,mixed>
	 */
	public static function template_elements( $template_id ) {
		$template_id = (int) $template_id;
		if ( $template_id <= 0 ) {
			return array();
		}
		$post = get_post( $template_id );
		if ( ! $post || 'elementor_library' !== $post->post_type ) {
			return array();
		}
		if ( class_exists( '\Elementor\Plugin', false ) && isset( \Elementor\Plugin::$instance->documents ) ) {
			$doc = \Elementor\Plugin::$instance->documents->get( $template_id );
			if ( $doc && method_exists( $doc, 'get_elements_data' ) ) {
				$data = $doc->get_elements_data();
				if ( is_array( $data ) ) {
					return $data;
				}
			}
		}
		$raw = get_post_meta( $template_id, '_elementor_data', true );
		if ( is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			return is_array( $decoded ) ? $decoded : array();
		}
		return array();
	}

	/**
	 * @return list<array{id:int,url:string,alt:string}>
	 */
	public static function recent_media() {
		$q = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => 16,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$out = array();
		foreach ( $q as $p ) {
			$url = wp_get_attachment_image_url( $p->ID, 'large' );
			$out[] = array(
				'id'  => (int) $p->ID,
				'url' => $url ? $url : '',
				'alt' => (string) get_post_meta( $p->ID, '_wp_attachment_image_alt', true ),
			);
		}
		return $out;
	}
}
