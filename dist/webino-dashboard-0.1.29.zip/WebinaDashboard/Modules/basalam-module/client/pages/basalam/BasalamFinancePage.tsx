import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamFinancePage() {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['basalam', 'finance'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/finance/balance'),
  })
  return (
    <PageShell title={t('basalam.financeTitle')} description={t('basalam.financeSubtitle')}>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.financeTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-3 text-sm">{t('basalam.financeWpAdminHint')}</p>
          <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(q.data ?? {}, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </PageShell>
  )
}
