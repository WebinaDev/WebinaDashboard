import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamLogsPage() {
  const { t } = useTranslation()
  const jobsQ = useQuery({
    queryKey: ['basalam', 'jobs', 'all'],
    queryFn: () => apiFetch<{ jobs: unknown[] }>('basalam/jobs'),
  })
  const logsQ = useQuery({
    queryKey: ['basalam', 'logs'],
    queryFn: () => apiFetch<{ hint?: string; logs: unknown[] }>('basalam/logs'),
  })
  const covQ = useQuery({
    queryKey: ['basalam', 'coverage'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/coverage/endpoints'),
  })

  return (
    <PageShell title={t('basalam.logsTitle')} description={t('basalam.logsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.coverage')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted max-h-60 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(covQ.data ?? {}, null, 2)}
          </pre>
        </CardContent>
      </Card>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.recentJobs')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted max-h-60 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(jobsQ.data?.jobs ?? [], null, 2)}
          </pre>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.logsTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-2 text-sm">{logsQ.data?.hint}</p>
        </CardContent>
      </Card>
    </PageShell>
  )
}
