import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamOrdersPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [orderId, setOrderId] = useState('')
  const [tracking, setTracking] = useState('')

  const pull = useMutation({
    mutationFn: () => apiFetch('basalam/sync/orders/pull', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.ordersPullQueued'))
      await qc.invalidateQueries({ queryKey: ['basalam'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const action = useMutation({
    mutationFn: (body: { path: string; payload: Record<string, unknown> }) =>
      apiFetch(body.path, { method: 'POST', body: JSON.stringify(body.payload) }),
    onSuccess: () => toast.success(t('basalam.orderActionOk')),
    onError: (e: Error) => toastApiError(t, e),
  })

  const id = Number(orderId) || 0

  return (
    <PageShell title={t('basalam.ordersTitle')} description={t('basalam.ordersSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.pullOrders')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={() => pull.mutate()} disabled={pull.isPending}>
            {t('basalam.pullOrders')}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.vendorActions')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            placeholder={t('basalam.wcOrderId')}
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
          />
          <Input
            placeholder={t('basalam.trackingCode')}
            value={tracking}
            onChange={(e) => setTracking(e.target.value)}
          />
          <div className="flex flex-wrap gap-2">
            <Button
              disabled={!id}
              onClick={() => action.mutate({ path: 'basalam/orders/confirm', payload: { order_id: id } })}
            >
              {t('basalam.confirmOrder')}
            </Button>
            <Button
              variant="secondary"
              disabled={!id}
              onClick={() =>
                action.mutate({
                  path: 'basalam/orders/cancel',
                  payload: { order_id: id, reason_id: 3481, description: '' },
                })
              }
            >
              {t('basalam.cancelOrder')}
            </Button>
            <Button
              variant="outline"
              disabled={!id || !tracking}
              onClick={() =>
                action.mutate({
                  path: 'basalam/orders/tracking',
                  payload: { order_id: id, tracking_code: tracking, shipping_method: 3197, phone: '' },
                })
              }
            >
              {t('basalam.shipOrder')}
            </Button>
          </div>
        </CardContent>
      </Card>
    </PageShell>
  )
}
