import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'

export default function BasalamTicketsPage() {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['basalam', 'tickets'],
    queryFn: () => apiFetch<{ tickets: unknown[]; hint?: string }>('basalam/tickets'),
  })
  return (
    <PageShell title={t('basalam.ticketsTitle')} description={t('basalam.ticketsSubtitle')}>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.ticketsTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-3 text-sm">{q.data?.hint ?? t('basalam.ticketsHint')}</p>
          <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(q.data?.tickets ?? [], null, 2)}
          </pre>
        </CardContent>
      </Card>
    </PageShell>
  )
}
