import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamSyncSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()

  const settingsQ = useQuery({
    queryKey: ['basalam', 'settings'],
    queryFn: () =>
      apiFetch<{ settings: Record<string, unknown>; connected?: boolean }>('basalam/settings'),
  })

  const save = useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('basalam/settings', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: async () => {
      toast.success(t('basalam.settingsSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'settings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const s = settingsQ.data?.settings ?? {}

  const toggle = (key: string) => {
    save.mutate({ [key]: !s[key] })
  }

  return (
    <PageShell title={t('basalam.settingsTitle')} description={t('basalam.settingsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.syncToggles')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant={s.sync_status_product ? 'default' : 'outline'} onClick={() => toggle('sync_status_product')}>
            {t('basalam.syncProducts')}
          </Button>
          <Button variant={s.sync_status_order ? 'default' : 'outline'} onClick={() => toggle('sync_status_order')}>
            {t('basalam.syncOrders')}
          </Button>
          <Button variant={s.auto_confirm_order ? 'default' : 'outline'} onClick={() => toggle('auto_confirm_order')}>
            {t('basalam.autoConfirm')}
          </Button>
          <Button variant={s.developer_mode ? 'default' : 'outline'} onClick={() => toggle('developer_mode')}>
            {t('basalam.developerMode')}
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.rawSettings')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted max-h-96 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(s, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </PageShell>
  )
}
