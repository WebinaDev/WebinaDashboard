import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamProductsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()

  const jobsQ = useQuery({
    queryKey: ['basalam', 'jobs'],
    queryFn: () => apiFetch<{ jobs: Array<Record<string, unknown>> }>('basalam/jobs'),
  })

  const run = useMutation({
    mutationFn: (path: string) => apiFetch(path, { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.jobQueued'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'jobs'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <PageShell title={t('basalam.productsTitle')} description={t('basalam.productsSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.productActions')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button onClick={() => run.mutate('basalam/sync/products/create-all')}>{t('basalam.createAll')}</Button>
          <Button variant="secondary" onClick={() => run.mutate('basalam/sync/products/update-all')}>
            {t('basalam.updateAll')}
          </Button>
          <Button
            variant="secondary"
            onClick={() =>
              apiFetch('basalam/sync/products/update-all', {
                method: 'POST',
                body: JSON.stringify({ mode: 'quick' }),
              })
                .then(async () => {
                  toast.success(t('basalam.jobQueued'))
                  await qc.invalidateQueries({ queryKey: ['basalam', 'jobs'] })
                })
                .catch((e: Error) => toastApiError(t, e))
            }
          >
            {t('basalam.quickUpdate')}
          </Button>
          <Button variant="outline" onClick={() => run.mutate('basalam/sync/products/connect-all')}>
            {t('basalam.autoConnect')}
          </Button>
          <Button
            variant="destructive"
            onClick={() => run.mutate('basalam/jobs/cancel')}
          >
            {t('basalam.cancelJobs')}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.recentJobs')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted max-h-96 overflow-auto rounded-md p-3 text-xs">
            {JSON.stringify(jobsQ.data?.jobs ?? [], null, 2)}
          </pre>
        </CardContent>
      </Card>
    </PageShell>
  )
}
