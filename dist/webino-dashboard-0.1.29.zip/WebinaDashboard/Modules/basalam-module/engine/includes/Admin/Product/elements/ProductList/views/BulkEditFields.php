<?php

defined('ABSPATH') || exit;
?>
<fieldset class="inline-edit-col-right sync-basalam-bulk-edit">
    <div class="inline-edit-col sync-basalam-bulk-edit__panel">
        <div class="sync-basalam-bulk-edit__header">
            <p class="basalam-p sync-basalam-bulk-edit__title">ویرایش گروهی ووسلام</p>
            <p class="basalam-p basalam-font-12 sync-basalam-bulk-edit__desc">تنظیمات باسلام را فقط برای محصولات انتخاب‌شده یکجا اعمال کنید.</p>
        </div>

        <div class="sync-basalam-bulk-edit__fields">
            <div class="sync-basalam-bulk-edit__section sync-basalam-bulk-edit__section--type">
                <label class="alignleft sync-basalam-bulk-edit__field">
                    <?php echo wp_kses_post(\WebinoBasalam\Admin\Components\CommonComponents::renderLabelWithTooltip('نوع محصول باسلام', 'اگر این گزینه را فعال کنید، محصول در باسلام به صورت محصول واحددار ارسال می‌شود و می‌توانید واحد و مقدار آن را مشخص کنید.')); ?>
                    <select name="webino_basalam_bulk_product_type_action" class="sync-basalam-bulk-select basalam-select basalam-font-pelak-12">
                        <option value="keep">بدون تغییر</option>
                        <option value="yes">فعال</option>
                        <option value="no">غیرفعال</option>
                    </select>
                </label>

                <div class="sync-basalam-bulk-type-fields">
                    <label class="alignleft sync-basalam-bulk-edit__field">
                        <span class="title basalam-p basalam-font-12">واحد محصول</span>
                        <select name="webino_basalam_bulk_product_unit" class="sync-basalam-bulk-select basalam-select basalam-font-pelak-12">
                            <?php foreach ($units as $unitId => $label) : ?>
                                <option value="<?php echo esc_attr($unitId); ?>"><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label class="alignleft sync-basalam-bulk-edit__field">
                        <span class="title basalam-p basalam-font-12">مقدار محصول</span>
                        <input type="number" name="webino_basalam_bulk_product_value" min="1" step="1" value="1" class="basalam-input basalam-font-pelak-12">
                    </label>
                </div>
            </div>

            <span class="sync-basalam-bulk-edit__divider" aria-hidden="true"></span>

            <div class="sync-basalam-bulk-edit__section sync-basalam-bulk-edit__section--wholesale">
                <label class="alignleft sync-basalam-bulk-edit__field">
                    <?php echo wp_kses_post(\WebinoBasalam\Admin\Components\CommonComponents::renderLabelWithTooltip('محصول عمده', 'با فعال کردن این گزینه، محصولات انتخاب‌شده در باسلام با حالت عمده ثبت یا به‌روزرسانی می‌شوند.')); ?>
                    <select name="webino_basalam_bulk_wholesale_action" class="sync-basalam-bulk-select basalam-select basalam-font-pelak-12">
                        <option value="keep">بدون تغییر</option>
                        <option value="yes">فعال</option>
                        <option value="no">غیرفعال</option>
                    </select>
                </label>
            </div>

            <span class="sync-basalam-bulk-edit__divider" aria-hidden="true"></span>

            <div class="sync-basalam-bulk-edit__section sync-basalam-bulk-edit__section--price-change basalam-form-group basalam-form-group-full basalam-p">
                <label class="alignleft sync-basalam-bulk-edit__field">
                    <?php echo wp_kses_post(\WebinoBasalam\Admin\Components\CommonComponents::renderLabelWithTooltip('تغییر قیمت اختصاصی', 'اگر برای این بخش مقداری تنظیم کنید، برای محصولات انتخاب‌شده به جای تغییر قیمت سراسری تنظیمات استفاده می‌شود. مقدار درصدی حداکثر 35 درصد افزایش یا 35 درصد کاهش (منفی یعنی کاهش قیمت)، خارج از بازه -100 تا 100 مبلغ ثابت تومانی.')); ?>
                    <select name="webino_basalam_bulk_price_change_action" class="sync-basalam-bulk-select basalam-select basalam-font-pelak-12">
                        <option value="keep">بدون تغییر</option>
                        <option value="set">تنظیم مقدار</option>
                        <option value="clear">حذف و استفاده از تنظیم سراسری</option>
                    </select>
                </label>

                <div class="sync-basalam-bulk-edit__field sync-basalam-bulk-price-change-value">
                    <div class="basalam-input-container">
                        <input type="text" id="sync-basalam-bulk-price-change-input" data-role="price-change-input" value="" class="basalam-input basalam-p percentage-input basalam-font-pelak-12" inputmode="text" autocomplete="off">
                        <span class="percentage-unit basalam-p basalam-min-width-0 basalam-font-13">درصد</span>
                    </div>
                    <div class="basalam-flex-end-gap-4 basalam-margin-top-8">
                        <input type="checkbox" id="sync-basalam-bulk-toggle-percentage" class="toggle-percentage" name="webino_basalam_bulk_toggle_percentage">
                        <label class="basalam-font-10" for="sync-basalam-bulk-toggle-percentage">کارمزد دسته‌بندی</label>
                    </div>
                    <input type="hidden" id="sync-basalam-bulk-price-change-value" data-role="price-change-hidden" name="webino_basalam_bulk_price_change_value" value="">
                </div>
            </div>

        </div>
    </div>
</fieldset>
