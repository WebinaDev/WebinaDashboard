<?php

namespace WebinoBasalam\Admin\Settings;

use WebinoBasalam\Admin\Settings;
use WebinoBasalam\Admin\Settings\SettingsConfig;

defined('ABSPATH') || exit;

class SettingsContainer
{
    private ?array $settings = null;

    public function getSettings($setting = null)
    {
        if ($this->settings === null) {
            $this->settings = Settings::getSettings();
        }

        if ($setting === null) return $this->settings;

        return $this->settings[$setting] ?? null;
    }

    public function hasToken(): bool
    {
        $token = ($this->getSettings(SettingsConfig::TOKEN));
        if (!$token) return false;
        return true;
    }
}
