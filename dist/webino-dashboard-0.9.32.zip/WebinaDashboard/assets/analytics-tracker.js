(function () {
  var cfg = window.webinoAnalytics;
  if (!cfg || !cfg.token) return;
  if (!cfg.endpoint && !cfg.ajaxUrl) return;

  function param(name) {
    try {
      return new URLSearchParams(window.location.search).get(name) || '';
    } catch (e) {
      return '';
    }
  }

  var payload = {
    uri: window.location.pathname + window.location.search,
    referrer: document.referrer || '',
    title: document.title || '',
    utm_source: param('utm_source'),
    utm_medium: param('utm_medium'),
    utm_campaign: param('utm_campaign'),
  };
  var body = JSON.stringify(payload);

  function sendViaAjax() {
    if (!cfg.ajaxUrl) return false;
    try {
      if (typeof fetch === 'function') {
        var fd = new FormData();
        fd.append('action', cfg.ajaxAction || 'webino_dashboard_analytics_hit');
        fd.append('token', cfg.token);
        fd.append('payload', body);
        fetch(cfg.ajaxUrl, {
          method: 'POST',
          body: fd,
          keepalive: true,
          credentials: 'omit',
          mode: 'cors',
        }).catch(function () {});
        return true;
      }
    } catch (e) {
      /* fall through */
    }
    return false;
  }

  function sendViaRest() {
    if (!cfg.endpoint) return false;
    var url =
      cfg.endpoint + (cfg.endpoint.indexOf('?') >= 0 ? '&' : '?') + 'token=' + encodeURIComponent(cfg.token);
    try {
      if (typeof fetch === 'function') {
        fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Webino-Analytics-Token': cfg.token,
          },
          body: body,
          keepalive: true,
          credentials: 'omit',
          mode: 'cors',
        }).catch(function () {
          // REST blocked (CDN/WAF) — fall back to admin-ajax.
          sendViaAjax();
        });
        return true;
      }
    } catch (e) {
      /* fall through */
    }
    try {
      if (navigator.sendBeacon) {
        var blob = new Blob([body], { type: 'application/json' });
        navigator.sendBeacon(url, blob);
        return true;
      }
    } catch (e2) {
      /* ignore */
    }
    return false;
  }

  // Prefer admin-ajax when localized (CDN often blocks /wp-json/).
  if (cfg.preferAjax && sendViaAjax()) {
    return;
  }
  if (!sendViaRest()) {
    sendViaAjax();
  }
})();
