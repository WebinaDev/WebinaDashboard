import { useEffect, useState } from 'react'

declare global {
  interface Window {
    webinoDashboard?: { restUrl?: string; nonce?: string }
  }
}

type Settings = {
  merchant_id: string
  sandbox: boolean
  gateway_enabled: boolean
  api_base: string
  callback_url: string
  redact_logs: boolean
}

export default function ZarinpalSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null)
  const [coverage, setCoverage] = useState<any>(null)
  const base = window.webinoDashboard?.restUrl || '/wp-json/'
  const nonce = window.webinoDashboard?.nonce || ''

  useEffect(() => {
    fetch(`${base}webino-dashboard/v1/zarinpal/settings`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => r.json())
      .then((d) => setSettings(d.settings))
    fetch(`${base}webino-dashboard/v1/zarinpal/coverage/endpoints`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => r.json())
      .then((d) => setCoverage(d))
  }, [base, nonce])

  if (!settings) return <div>Loading...</div>

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <h2>Zarinpal</h2>
      <label>
        Merchant ID
        <input
          value={settings.merchant_id}
          onChange={(e) => setSettings({ ...settings, merchant_id: e.target.value })}
        />
      </label>
      <label>
        <input
          type="checkbox"
          checked={settings.sandbox}
          onChange={(e) => setSettings({ ...settings, sandbox: e.target.checked })}
        />
        Sandbox
      </label>
      <button
        onClick={async () => {
          const r = await fetch(`${base}webino-dashboard/v1/zarinpal/settings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
            body: JSON.stringify(settings),
          })
          const d = await r.json()
          setSettings(d.settings)
        }}
      >
        Save
      </button>
      <button
        onClick={async () => {
          await fetch(`${base}webino-dashboard/v1/zarinpal/reconcile`, {
            method: 'POST',
            headers: { 'X-WP-Nonce': nonce },
          })
        }}
      >
        Reconcile now
      </button>
      <pre>{JSON.stringify(coverage, null, 2)}</pre>
    </div>
  )
}
