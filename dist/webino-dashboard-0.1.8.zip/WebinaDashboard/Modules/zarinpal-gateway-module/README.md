# ماژول Zarinpal Gateway

## معرفی
ماژول Zarinpal Gateway یکپارچه‌سازی کامل درگاه زرین‌پال برای WooCommerce و پنل Dashboard را فراهم می‌کند.

## امکانات
- ایجاد درخواست پرداخت و ریدایرکت کاربر به درگاه
- callback و verify تراکنش پس از بازگشت
- پشتیبانی refund
- queue داخلی برای reconcile عملیات
- endpoint coverage registry برای پایش پیاده‌سازی API
- پنل تنظیمات و عملیات در داشبورد

## معماری و اجزای اصلی
- هسته: `includes/class-zarinpal-module.php`
- REST: `includes/class-webino-dashboard-rest-zarinpal.php`
- سرویس‌ها: `Zarinpal_Client`, `Zarinpal_Gateway_Service`, `Zarinpal_Jobs`
- gateway ووکامرس: `includes/woocommerce/class-wc-gateway-zarinpal.php`
- UI: `client/pages/zarinpal/ZarinpalSettingsPage.tsx`

## مسیرهای کلیدی
- `manifest.json`
- `bootstrap.php`
- `includes/`
- `client/module-entry.tsx`
- `docs/OPERATIONS_RUNBOOK.md`

## تنظیمات و پیش‌نیازها
- نیازمند WooCommerce
- نیازمند merchant id معتبر
- مسیرهای تنظیمات:
  - `/settings/shop/zarinpal`
  - `/settings/shop/zarinpal/payments`
  - `/settings/shop/zarinpal/operations`
  - `/settings/shop/zarinpal/coverage`

## مسیرهای REST مهم
- `GET|POST /wp-json/webino-dashboard/v1/zarinpal/settings`
- `GET /wp-json/webino-dashboard/v1/zarinpal/status`
- `GET /wp-json/webino-dashboard/v1/zarinpal/coverage/endpoints`
- `POST /wp-json/webino-dashboard/v1/zarinpal/reconcile`

## عیب‌یابی سریع
- اگر verify ناموفق است، authority/ref_id و log سفارش را بررسی کنید.
- اگر reconcile اجرا نمی‌شود، cron و job queue را بررسی کنید.
- اگر coverage قدیمی است، transient cache را پاک‌سازی کنید.

## نکات امنیتی
- merchant id و credentialها باید در خروجی API ماسک شوند.
- مسیر callback باید فقط با اعتبارسنجی تراکنش، سفارش را complete کند.
