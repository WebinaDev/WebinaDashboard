<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Zarinpal_Client {
	public static function request( $method, $path, array $body = array() ) {
		$s   = Zarinpal_Config::get();
		$url = rtrim( (string) $s['api_base'], '/' ) . '/' . ltrim( $path, '/' );
		$args = array(
			'method'  => strtoupper( (string) $method ),
			'timeout' => 30,
			'headers' => array( 'Content-Type' => 'application/json' ),
		);
		if ( ! empty( $body ) ) {
			$args['body'] = wp_json_encode( $body );
		}
		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'zarinpal_api_error', __( 'Zarinpal API request failed.', 'webino-dashboard' ), array( 'status' => 502, 'code' => $code, 'data' => $data ) );
		}
		return $data;
	}
}
