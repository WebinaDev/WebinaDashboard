<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Zarinpal_Jobs {
	const OPTION_QUEUE = 'webino_zarinpal_jobs';

	public static function enqueue( $type, array $payload = array(), $delay = 0 ) {
		$q = get_option( self::OPTION_QUEUE, array() );
		if ( ! is_array( $q ) ) {
			$q = array();
		}
		$q[] = array(
			'id'        => wp_generate_uuid4(),
			'type'      => sanitize_key( (string) $type ),
			'payload'   => $payload,
			'run_after' => time() + max( 0, (int) $delay ),
		);
		update_option( self::OPTION_QUEUE, $q, false );
	}

	public static function all() {
		$q = get_option( self::OPTION_QUEUE, array() );
		return is_array( $q ) ? $q : array();
	}

	public static function process_due() {
		$q = self::all();
		$out = array();
		$now = time();
		foreach ( $q as $job ) {
			if ( (int) ( $job['run_after'] ?? 0 ) > $now ) {
				$out[] = $job;
				continue;
			}
			if ( 'reconcile' === (string) ( $job['type'] ?? '' ) ) {
				do_action( 'webino_zarinpal_reconcile' );
			}
		}
		update_option( self::OPTION_QUEUE, $out, false );
	}
}
