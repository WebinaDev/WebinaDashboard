<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Dashboard_REST_Zarinpal {
	const NS = 'webino-dashboard/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route(
			self::NS,
			'/zarinpal/settings',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_get' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'callback'            => array( __CLASS__, 'settings_post' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/zarinpal/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'status_get' ),
			)
		);
		register_rest_route(
			self::NS,
			'/zarinpal/coverage/endpoints',
			array(
				'methods'             => 'GET',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'coverage_get' ),
			)
		);
		register_rest_route(
			self::NS,
			'/zarinpal/reconcile',
			array(
				'methods'             => 'POST',
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'callback'            => array( __CLASS__, 'reconcile_post' ),
			)
		);
	}

	public static function can_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_woocommerce' );
	}

	public static function settings_get() {
		return new WP_REST_Response( array( 'settings' => Zarinpal_Config::get() ) );
	}

	public static function settings_post( WP_REST_Request $request ) {
		$data = $request->get_json_params();
		$saved = Zarinpal_Config::save( is_array( $data ) ? $data : array() );
		do_action( 'webino_zarinpal_audit', 'settings_updated', array( 'merchant_id_masked' => self::mask( (string) $saved['merchant_id'] ) ) );
		return new WP_REST_Response( array( 'settings' => $saved ) );
	}

	public static function status_get() {
		return new WP_REST_Response(
			array(
				'jobs'       => Zarinpal_Jobs::all(),
				'checked_at' => gmdate( 'c' ),
			)
		);
	}

	public static function coverage_get() {
		return new WP_REST_Response( Zarinpal_Endpoint_Registry::report() );
	}

	public static function reconcile_post() {
		Zarinpal_Jobs::enqueue( 'reconcile', array(), 0 );
		do_action( 'webino_zarinpal_audit', 'manual_reconcile', array( 'user_id' => get_current_user_id() ) );
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	private static function mask( $value ) {
		$len = strlen( $value );
		if ( $len <= 6 ) {
			return str_repeat( '*', $len );
		}
		return substr( $value, 0, 3 ) . str_repeat( '*', max( 0, $len - 6 ) ) . substr( $value, -3 );
	}
}
