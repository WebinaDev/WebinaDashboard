<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Webino_Zarinpal_Module {
	public static function init() {
		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'register_gateway' ) );
		add_action( 'woocommerce_api_webino_zarinpal_gateway', array( __CLASS__, 'callback' ) );
		add_action( 'webino_zarinpal_process_jobs', array( 'Zarinpal_Jobs', 'process_due' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		if ( ! wp_next_scheduled( 'webino_zarinpal_process_jobs' ) ) {
			wp_schedule_event( time() + 60, 'zarinpal_minute', 'webino_zarinpal_process_jobs' );
		}
	}

	public static function register_gateway( $methods ) {
		if ( class_exists( 'WC_Gateway_Zarinpal', false ) ) {
			$methods[] = 'WC_Gateway_Zarinpal';
		}
		return $methods;
	}

	public static function callback() {
		$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$authority = isset( $_GET['Authority'] ) ? sanitize_text_field( wp_unslash( $_GET['Authority'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['Status'] ) ? sanitize_text_field( wp_unslash( $_GET['Status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'webino-dashboard' ) );
		}
		if ( 'OK' === strtoupper( $status ) ) {
			$res = Zarinpal_Gateway_Service::verify_payment( $order, $authority );
			if ( is_wp_error( $res ) ) {
				$order->update_status( 'failed', $res->get_error_message() );
			}
		} else {
			$order->update_status( 'failed', __( 'Zarinpal payment canceled or failed.', 'webino-dashboard' ) );
		}
		wp_safe_redirect( $order->get_checkout_order_received_url() );
		exit;
	}

	public static function schedules( $schedules ) {
		$schedules['zarinpal_minute'] = array(
			'interval' => 60,
			'display'  => 'Zarinpal every minute',
		);
		return $schedules;
	}
}
