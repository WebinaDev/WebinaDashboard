<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
	return;
}

class WC_Gateway_Zarinpal extends WC_Payment_Gateway {
	public function __construct() {
		$this->id                 = 'zarinpal_gateway';
		$this->method_title       = __( 'Zarinpal Gateway', 'webino-dashboard' );
		$this->method_description = __( 'Pay via Zarinpal gateway.', 'webino-dashboard' );
		$this->has_fields         = false;
		$this->supports           = array( 'products', 'refunds' );
		$this->init_form_fields();
		$this->init_settings();
		$this->title   = $this->get_option( 'title', __( 'Zarinpal', 'webino-dashboard' ) );
		$this->enabled = $this->get_option( 'enabled', 'no' );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'webino-dashboard' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Zarinpal Gateway', 'webino-dashboard' ),
				'default' => 'no',
			),
			'title' => array(
				'title'   => __( 'Title', 'webino-dashboard' ),
				'type'    => 'text',
				'default' => __( 'Zarinpal', 'webino-dashboard' ),
			),
		);
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return array( 'result' => 'failure' );
		}
		$res = Zarinpal_Gateway_Service::request_payment( $order );
		if ( is_wp_error( $res ) ) {
			wc_add_notice( $res->get_error_message(), 'error' );
			return array( 'result' => 'failure' );
		}
		return array( 'result' => 'success', 'redirect' => (string) $res['redirect_url'] );
	}

	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		$res = Zarinpal_Gateway_Service::refund( $order, (float) $amount );
		return ! is_wp_error( $res );
	}
}
