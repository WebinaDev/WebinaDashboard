<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Zarinpal_Config {
	const OPTION_KEY = 'webino_zarinpal_settings';

	public static function defaults() {
		return array(
			'merchant_id'      => '',
			'sandbox'          => true,
			'gateway_enabled'  => false,
			'api_base'         => 'https://api.zarinpal.com/pg/v4',
			'callback_url'     => home_url( '/wc-api/webino_zarinpal_gateway' ),
			'redact_logs'      => true,
		);
	}

	public static function get() {
		$stored = get_option( self::OPTION_KEY, array() );
		return wp_parse_args( is_array( $stored ) ? $stored : array(), self::defaults() );
	}

	public static function save( array $data ) {
		$old = self::get();
		$new = array(
			'merchant_id'     => sanitize_text_field( (string) ( $data['merchant_id'] ?? $old['merchant_id'] ) ),
			'sandbox'         => ! empty( $data['sandbox'] ),
			'gateway_enabled' => ! empty( $data['gateway_enabled'] ),
			'api_base'        => esc_url_raw( (string) ( $data['api_base'] ?? $old['api_base'] ) ),
			'callback_url'    => esc_url_raw( (string) ( $data['callback_url'] ?? $old['callback_url'] ) ),
			'redact_logs'     => ! empty( $data['redact_logs'] ),
		);
		update_option( self::OPTION_KEY, $new, false );
		return $new;
	}
}
