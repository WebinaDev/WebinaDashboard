<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Zarinpal_Endpoint_Registry {
	const CACHE_KEY = 'webino_zarinpal_endpoint_registry';
	const CACHE_TTL = 6 * HOUR_IN_SECONDS;

	public static function report() {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$items = array(
			array( 'method' => 'POST', 'path' => '/payment/request.json', 'status' => 'implemented', 'source' => 'includes/class-zarinpal-gateway-service.php' ),
			array( 'method' => 'POST', 'path' => '/payment/verify.json', 'status' => 'implemented', 'source' => 'includes/class-zarinpal-gateway-service.php' ),
			array( 'method' => 'POST', 'path' => '/payment/refund.json', 'status' => 'implemented', 'source' => 'includes/class-zarinpal-gateway-service.php' ),
		);
		$report = array(
			'summary' => array(
				'implemented' => count( $items ),
				'queued'      => 0,
				'pending'     => 0,
				'total'       => count( $items ),
			),
			'items'   => $items,
			'meta'    => array(
				'generated_at'   => gmdate( 'c' ),
				'schema_version' => '1.0.0',
			),
		);
		set_transient( self::CACHE_KEY, $report, self::CACHE_TTL );
		return $report;
	}
}
