<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Zarinpal_Gateway_Service {
	public static function request_payment( WC_Order $order ) {
		$s = Zarinpal_Config::get();
		$payload = array(
			'merchant_id'  => (string) $s['merchant_id'],
			'amount'       => (int) round( (float) $order->get_total() * 10 ),
			'description'  => sprintf( 'Order #%d', (int) $order->get_id() ),
			'callback_url' => (string) $s['callback_url'] . '?order_id=' . (int) $order->get_id(),
			'metadata'     => array(
				'mobile' => (string) $order->get_billing_phone(),
				'email'  => (string) $order->get_billing_email(),
			),
		);
		$res = Zarinpal_Client::request( 'POST', '/payment/request.json', $payload );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$authority = (string) ( $res['data']['authority'] ?? '' );
		if ( '' === $authority ) {
			return new WP_Error( 'zarinpal_authority_missing', __( 'Missing Zarinpal authority.', 'webino-dashboard' ) );
		}
		$order->update_meta_data( '_zarinpal_authority', $authority );
		$order->save();
		$host = ! empty( $s['sandbox'] ) ? 'https://sandbox.zarinpal.com/pg/StartPay/' : 'https://www.zarinpal.com/pg/StartPay/';
		return array(
			'authority'    => $authority,
			'redirect_url' => $host . $authority,
		);
	}

	public static function verify_payment( WC_Order $order, $authority ) {
		$s = Zarinpal_Config::get();
		$payload = array(
			'merchant_id' => (string) $s['merchant_id'],
			'amount'      => (int) round( (float) $order->get_total() * 10 ),
			'authority'   => sanitize_text_field( (string) $authority ),
		);
		$res = Zarinpal_Client::request( 'POST', '/payment/verify.json', $payload );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$ref_id = (string) ( $res['data']['ref_id'] ?? '' );
		$order->payment_complete( $ref_id );
		$order->update_meta_data( '_zarinpal_ref_id', $ref_id );
		$order->add_order_note( __( 'Zarinpal payment verified.', 'webino-dashboard' ) );
		$order->save();
		return $res;
	}

	public static function refund( WC_Order $order, $amount ) {
		$s = Zarinpal_Config::get();
		$ref_id = (string) $order->get_meta( '_zarinpal_ref_id' );
		if ( '' === $ref_id ) {
			return new WP_Error( 'zarinpal_refid_missing', __( 'No Zarinpal ref_id for refund.', 'webino-dashboard' ) );
		}
		$payload = array(
			'merchant_id' => (string) $s['merchant_id'],
			'amount'      => (int) round( (float) $amount * 10 ),
			'ref_id'      => $ref_id,
		);
		return Zarinpal_Client::request( 'POST', '/payment/refund.json', $payload );
	}
}
