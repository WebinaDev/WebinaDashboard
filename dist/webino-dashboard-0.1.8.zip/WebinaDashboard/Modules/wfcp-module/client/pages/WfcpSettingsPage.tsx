import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { generatePath, Link, useLocation, useParams } from 'react-router-dom'
import { toast } from 'sonner'
import { toastApiError } from '@/lib/apiError'

import { FormSettingsSkeleton } from '@/components/skeletons'
import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { translateEnum } from '@/lib/enumLabels'
import { apiFetch } from '@/lib/api'
import type { PaymentGatewayRow } from '@/components/settings/wc-settings-types'

type WfcpSettings = Record<string, Record<string, unknown>>

const TABS = [
  'dashboard',
  'currency',
  'exchange',
  'retail',
  'credit',
  'installment',
  'wholesale',
  'notifications',
  'style',
  'advanced',
] as const

type TabId = (typeof TABS)[number]

function isTab(s: string | undefined): s is TabId {
  return !!s && (TABS as readonly string[]).includes(s)
}

export default function WfcpSettingsPage() {
  const { tab: tabParam } = useParams()
  const tab = isTab(tabParam) ? tabParam : 'dashboard'
  const { t } = useTranslation()
  const qc = useQueryClient()
  const loc = useLocation()
  const embedded = loc.pathname.includes('/settings/shop/pricing')
  const tabBase = '/settings/shop/pricing'

  const q = useQuery({
    queryKey: ['wfcp', 'settings'],
    queryFn: () => apiFetch<WfcpSettings>('wfcp/settings'),
    enabled: true,
  })

  const [draft, setDraft] = useState<WfcpSettings>({})

  useEffect(() => {
    if (q.data) setDraft(JSON.parse(JSON.stringify(q.data)) as WfcpSettings)
  }, [q.data])

  const save = useMutation({
    mutationFn: async ({ section, data }: { section: string; data: Record<string, unknown> }) => {
      await apiFetch(`wfcp/settings/${section}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data }),
      })
    },
    onSuccess: async (_, v) => {
      await qc.invalidateQueries({ queryKey: ['wfcp', 'settings'] })
      toast.success(t('common.saved'))
      if (v.section === 'general' || v.section === 'exchange') {
        void qc.invalidateQueries({ queryKey: ['bootstrap'] })
      }
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const general = draft.general ?? {}
  const retail = draft.retail ?? {}
  const credit = draft.credit ?? {}
  const installment = draft.installment ?? {}
  const wholesale = draft.wholesale ?? {}
  const notifications = draft.notifications ?? {}
  const style = draft.style ?? {}

  const tabLinks = useMemo(
    () =>
      TABS.map((id) => (
        <Link
          key={id}
          to={generatePath(`${tabBase.replace(/^\//, '')}/:tab`, { tab: id })}
          className={`rounded-md px-2 py-1 text-sm ${tab === id ? 'bg-muted font-medium' : 'hover:bg-muted/60'}`}
        >
          {t(`wfcp.tab.${id}`)}
        </Link>
      )),
    [t, tab, tabBase],
  )

  const content = (
    <div className={embedded ? 'space-y-4' : 'flex flex-col gap-4 lg:flex-row'}>
      <nav className={embedded ? 'flex flex-wrap gap-1 border-b border-border pb-2' : 'flex flex-wrap gap-1 border-b border-border pb-2 lg:w-48 lg:flex-col lg:border-b-0 lg:border-e lg:pb-0 lg:pe-3'}>
          {tabLinks}
        </nav>
        <div className="min-w-0 flex-1 space-y-4">
          {q.isLoading ? <FormSettingsSkeleton cards={2} fieldsPerCard={4} /> : null}
          {q.isError && <p className="text-sm text-destructive">{(q.error as Error).message}</p>}

          {tab === 'dashboard' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="wfcp-dash-enabled"
                  checked={Boolean(general.enabled ?? true)}
                  onCheckedChange={(v) => setDraft((d) => ({ ...d, general: { ...general, enabled: v === true } }))}
                />
                <Label htmlFor="wfcp-dash-enabled" className="cursor-pointer font-normal">
                  {t('wfcp.generalEnabled')}
                </Label>
              </div>
              <Button
                type="button"
                onClick={() => void save.mutateAsync({ section: 'general', data: { ...(draft.general ?? {}) } as Record<string, unknown> })}
                disabled={save.isPending}
              >
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'currency' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="space-y-2">
                <Label>{t('wfcp.currencyCode')}</Label>
                <Input
                  className="max-w-xs"
                  value={String(general.currency ?? 'IRR')}
                  onChange={(e) => setDraft((d) => ({ ...d, general: { ...general, currency: e.target.value } }))}
                />
              </div>
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'currency', data: { currency: general.currency ?? 'IRR' } })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'exchange' && (
            <ExchangeTab
              general={general}
              setGeneral={(g) => setDraft((d) => ({ ...d, general: { ...d.general, ...g } }))}
              onSave={(data) => void save.mutateAsync({ section: 'exchange', data })}
              saving={save.isPending}
            />
          )}

          {tab === 'retail' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="space-y-2">
                <Label>{t('wfcp.profitPercent')}</Label>
                <Input
                  type="number"
                  className="max-w-xs"
                  value={Number(retail.profit_percent ?? 20)}
                  onChange={(e) => setDraft((d) => ({ ...d, retail: { ...retail, profit_percent: parseFloat(e.target.value) } }))}
                />
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="wfcp-retail-round"
                  checked={Boolean(retail.round_enabled)}
                  onCheckedChange={(v) => setDraft((d) => ({ ...d, retail: { ...retail, round_enabled: v === true } }))}
                />
                <Label htmlFor="wfcp-retail-round" className="cursor-pointer font-normal">
                  {t('wfcp.roundEnabled')}
                </Label>
              </div>
              <div className="space-y-2">
                <Label>{t('wfcp.roundTo')}</Label>
                <Input
                  type="number"
                  className="max-w-xs"
                  value={Number(retail.round_to ?? 1000)}
                  onChange={(e) => setDraft((d) => ({ ...d, retail: { ...retail, round_to: parseInt(e.target.value, 10) } }))}
                />
              </div>
              <WfcpGatewayPicker
                selected={Array.isArray(retail.gateways) ? (retail.gateways as string[]) : []}
                onChange={(gateways) => setDraft((d) => ({ ...d, retail: { ...retail, gateways } }))}
              />
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'retail', data: retail })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'credit' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="wfcp-credit-en"
                  checked={Boolean(credit.enabled)}
                  onCheckedChange={(v) => setDraft((d) => ({ ...d, credit: { ...credit, enabled: v === true } }))}
                />
                <Label htmlFor="wfcp-credit-en" className="cursor-pointer font-normal">
                  {t('wfcp.creditEnabled')}
                </Label>
              </div>
              <div className="space-y-2">
                <Label>{t('wfcp.increasePercent')}</Label>
                <Input
                  type="number"
                  className="max-w-xs"
                  value={Number(credit.increase_percent ?? 5)}
                  onChange={(e) => setDraft((d) => ({ ...d, credit: { ...credit, increase_percent: parseFloat(e.target.value) } }))}
                />
              </div>
              <WfcpGatewayPicker
                selected={Array.isArray(credit.gateways) ? (credit.gateways as string[]) : []}
                onChange={(gateways) => setDraft((d) => ({ ...d, credit: { ...credit, gateways } }))}
              />
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'credit', data: credit })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'installment' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="wfcp-inst-en"
                  checked={Boolean(installment.enabled)}
                  onCheckedChange={(v) => setDraft((d) => ({ ...d, installment: { ...installment, enabled: v === true } }))}
                />
                <Label htmlFor="wfcp-inst-en" className="cursor-pointer font-normal">
                  {t('wfcp.installmentEnabled')}
                </Label>
              </div>
              <p className="text-xs text-muted-foreground">{t('wfcp.installmentPlansHint')}</p>
              <WfcpGatewayPicker
                selected={Array.isArray(installment.gateways) ? (installment.gateways as string[]) : []}
                onChange={(gateways) => setDraft((d) => ({ ...d, installment: { ...installment, gateways } }))}
              />
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'installment', data: installment })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'wholesale' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="wfcp-wholesale-en"
                  checked={Boolean(wholesale.enabled)}
                  onCheckedChange={(v) => setDraft((d) => ({ ...d, wholesale: { ...wholesale, enabled: v === true } }))}
                />
                <Label htmlFor="wfcp-wholesale-en" className="cursor-pointer font-normal">
                  {t('wfcp.wholesaleEnabled')}
                </Label>
              </div>
              <div className="space-y-2">
                <Label>{t('wfcp.wholesaleStrategy')}</Label>
                <Select
                  value={String(wholesale.strategy ?? 'global')}
                  onValueChange={(v) => setDraft((d) => ({ ...d, wholesale: { ...wholesale, strategy: v } }))}
                >
                  <SelectTrigger className="max-w-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="global">{translateEnum(t, "wfcp.scope", "global")}</SelectItem>
                    <SelectItem value="category">{translateEnum(t, "wfcp.scope", "category")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t('wfcp.discountPercent')}</Label>
                <Input
                  type="number"
                  className="max-w-xs"
                  value={Number(wholesale.discount_percent ?? 10)}
                  onChange={(e) => setDraft((d) => ({ ...d, wholesale: { ...wholesale, discount_percent: parseFloat(e.target.value) } }))}
                />
              </div>
              <WfcpGatewayPicker
                selected={Array.isArray(wholesale.gateways) ? (wholesale.gateways as string[]) : []}
                onChange={(gateways) => setDraft((d) => ({ ...d, wholesale: { ...wholesale, gateways } }))}
              />
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'wholesale', data: wholesale })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'notifications' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              {(['installment_text', 'credit_text', 'need_review'] as const).map((k) => (
                <div key={k}>
                  <Label>{t(`wfcp.field.${k}`)}</Label>
                  <Input
                    value={String((notifications as Record<string, string>)[k] ?? '')}
                    onChange={(e) => setDraft((d) => ({ ...d, notifications: { ...notifications, [k]: e.target.value } }))}
                  />
                </div>
              ))}
              {(['cash_description', 'installment_description', 'credit_description', 'wholesale_description'] as const).map((k) => (
                <div key={k}>
                  <Label>{t(`wfcp.field.${k}`, k)}</Label>
                  <Textarea
                    value={String((notifications as Record<string, string>)[k] ?? '')}
                    onChange={(e) => setDraft((d) => ({ ...d, notifications: { ...notifications, [k]: e.target.value } }))}
                  />
                </div>
              ))}
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'notifications', data: notifications })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'style' && (
            <section className="space-y-3 rounded-lg border border-border p-4">
              {(['box_background', 'box_border_color', 'button_background', 'button_text_color', 'price_color'] as const).map((k) => (
                <div key={k}>
                  <Label>{t(`wfcp.field.${k}`)}</Label>
                  <Input
                    type="color"
                    className="h-9 w-20 cursor-pointer p-1"
                    value={String((style as Record<string, string>)[k] ?? '#2271b1')}
                    onChange={(e) => setDraft((d) => ({ ...d, style: { ...style, [k]: e.target.value } }))}
                  />
                </div>
              ))}
              <Button type="button" onClick={() => void save.mutateAsync({ section: 'style', data: style })} disabled={save.isPending}>
                {t('common.save')}
              </Button>
            </section>
          )}

          {tab === 'advanced' && <AdvancedTab />}
        </div>
    </div>
  )

  if (embedded) return content
  return (
    <PageShell title={t('wfcp.settingsTitle')} description={t('wfcp.settingsDescription')}>
      {content}
    </PageShell>
  )
}

function WfcpGatewayPicker({
  selected,
  onChange,
}: {
  selected: string[]
  onChange: (gateways: string[]) => void
}) {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['payment-gateways'],
    queryFn: () => apiFetch<{ gateways: PaymentGatewayRow[] }>('shop/payment-gateways'),
  })

  const gateways = q.data?.gateways ?? []

  const toggle = (id: string, checked: boolean) => {
    if (checked) {
      onChange(Array.from(new Set([...selected, id])))
      return
    }
    onChange(selected.filter((g) => g !== id))
  }

  return (
    <div className="space-y-2">
      <Label>{t('wfcp.paymentGateways', 'درگاه‌های پرداخت')}</Label>
      {q.isLoading ? <p className="text-sm text-muted-foreground">{t('common.loading')}</p> : null}
      {gateways.length === 0 && !q.isLoading ? (
        <p className="text-sm text-muted-foreground">{t('wfcp.noGateways', 'هیچ درگاه پرداختی یافت نشد')}</p>
      ) : (
        <div className="space-y-2 rounded-md border border-border p-3">
          {gateways.map((gateway) => (
            <div key={gateway.id} className="flex items-center gap-2">
              <Checkbox
                id={`wfcp-gw-${gateway.id}`}
                checked={selected.includes(gateway.id)}
                onCheckedChange={(v) => toggle(gateway.id, v === true)}
              />
              <Label htmlFor={`wfcp-gw-${gateway.id}`} className="cursor-pointer font-normal">
                {gateway.title}
                {!gateway.enabled ? ` (${t('common.disabled', 'غیرفعال')})` : ''}
              </Label>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function ExchangeTab({
  general,
  setGeneral,
  onSave,
  saving,
}: {
  general: Record<string, unknown>
  setGeneral: (p: Record<string, unknown>) => void
  onSave: (data: Record<string, unknown>) => void
  saving: boolean
}) {
  const { t } = useTranslation()
  const [testMsg, setTestMsg] = useState('')

  return (
    <section className="space-y-3 rounded-lg border border-border p-4">
      <div className="space-y-2">
        <Label>{t('wfcp.exchangeRate')}</Label>
        <Input
          type="number"
          className="max-w-xs"
          value={Number(general.exchange_rate ?? 42000)}
          onChange={(e) => setGeneral({ exchange_rate: parseFloat(e.target.value) })}
        />
      </div>
      <div className="flex items-center gap-2">
        <Checkbox
          id="wfcp-ex-rate-en"
          checked={Boolean(general.exchange_rate_enabled ?? true)}
          onCheckedChange={(v) => setGeneral({ exchange_rate_enabled: v === true })}
        />
        <Label htmlFor="wfcp-ex-rate-en" className="cursor-pointer font-normal">
          {t('wfcp.exchangeRateEnabled')}
        </Label>
      </div>
      <div className="space-y-2">
        <Label>{t('wfcp.apiKey')}</Label>
        <Input className="max-w-md" value={String(general.api_key ?? '')} onChange={(e) => setGeneral({ api_key: e.target.value })} />
      </div>
      <div className="space-y-2">
        <Label>{t('wfcp.apiSymbol')}</Label>
        <Input className="max-w-xs" value={String(general.api_symbol ?? 'USD')} onChange={(e) => setGeneral({ api_symbol: e.target.value })} />
      </div>
      <div className="flex items-center gap-2">
        <Checkbox id="wfcp-api-en" checked={Boolean(general.api_enabled)} onCheckedChange={(v) => setGeneral({ api_enabled: v === true })} />
        <Label htmlFor="wfcp-api-en" className="cursor-pointer font-normal">
          {t('wfcp.apiEnabled')}
        </Label>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="secondary"
          onClick={async () => {
            try {
              const r = await apiFetch<{ message?: string; price?: number }>('wfcp/exchange/test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ api_key: general.api_key ?? '', api_symbol: general.api_symbol ?? 'USD' }),
              })
              setTestMsg(r.message ? `${r.message}` : String(r.price ?? ''))
            } catch (e) {
              setTestMsg((e as Error).message)
            }
          }}
        >
          {t('wfcp.testApi')}
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={async () => {
            try {
              const r = await apiFetch<{ message?: string }>('wfcp/exchange/fetch', { method: 'POST', body: '{}' })
              setTestMsg(r.message ?? t('wfcp.fetchOk'))
            } catch (e) {
              setTestMsg((e as Error).message)
            }
          }}
        >
          {t('wfcp.fetchRate')}
        </Button>
        <Button type="button" onClick={() => onSave(general as Record<string, unknown>)} disabled={saving}>
          {t('common.save')}
        </Button>
      </div>
      {testMsg && <p className="text-sm text-muted-foreground">{testMsg}</p>}
    </section>
  )
}

function AdvancedTab() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [importJson, setImportJson] = useState('')
  const [dry, setDry] = useState(false)

  const recalc = useMutation({
    mutationFn: () =>
      apiFetch<{ success: number; failed: number }>('wfcp/advanced/recalculate-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dry_run: dry }),
      }),
    onSuccess: (r) => toast.success(t('wfcp.recalcDone', { ok: r.success, fail: r.failed })),
    onError: (e: Error) => toastApiError(t, e),
  })

  const delTrans = useMutation({
    mutationFn: () => apiFetch('wfcp/advanced/delete-transients', { method: 'POST', body: '{}' }),
    onSuccess: () => toast.success(t('wfcp.transientsCleared')),
    onError: (e: Error) => toastApiError(t, e),
  })

  const exportS = useMutation({
    mutationFn: () => apiFetch<{ json: string }>('wfcp/advanced/export-settings'),
    onSuccess: (r) => {
      void navigator.clipboard.writeText(r.json).catch(() => {})
      toast.success(t('wfcp.exportCopied'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const importS = useMutation({
    mutationFn: () =>
      apiFetch('wfcp/advanced/import-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ json: importJson }),
      }),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['wfcp', 'settings'] })
      toast.success(t('common.saved'))
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <section className="space-y-4 rounded-lg border border-border p-4">
      <div>
        <div className="flex items-center gap-2">
          <Checkbox id="wfcp-dry" checked={dry} onCheckedChange={(v) => setDry(v === true)} />
          <Label htmlFor="wfcp-dry" className="cursor-pointer font-normal">
            {t('wfcp.dryRun')}
          </Label>
        </div>
        <Button className="mt-2" type="button" variant="secondary" disabled={recalc.isPending} onClick={() => void recalc.mutateAsync()}>
          {t('wfcp.recalculateAll')}
        </Button>
      </div>
      <Button type="button" variant="secondary" disabled={delTrans.isPending} onClick={() => void delTrans.mutateAsync()}>
        {t('wfcp.deleteTransients')}
      </Button>
      <div>
        <Button type="button" variant="secondary" disabled={exportS.isPending} onClick={() => void exportS.mutateAsync()}>
          {t('wfcp.exportSettings')}
        </Button>
      </div>
      <div>
        <Label>{t('wfcp.importJson')}</Label>
        <Textarea className="min-h-24" value={importJson} onChange={(e) => setImportJson(e.target.value)} />
        <Button className="mt-2" type="button" disabled={importS.isPending} onClick={() => void importS.mutateAsync()}>
          {t('wfcp.importSettings')}
        </Button>
      </div>
    </section>
  )
}
