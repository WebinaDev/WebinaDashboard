<?php
/**
 * Cart Manager Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Cart Manager Service
 */
class WFCP_Cart_Manager {

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply_cart_prices' ), 20 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'save_order_line_item_meta' ), 10, 4 );
	}

	/**
	 * Validate cart item addition.
	 *
	 * @param bool $passed Validation result.
	 * @param int  $product_id Product ID.
	 * @param int  $quantity Quantity.
	 * @return bool|WP_Error
	 */
	public static function validate_add_to_cart( $passed, $product_id, $quantity ) {
		unset( $quantity );

		if ( ! $passed || ! WFCP_Helper::is_enabled() ) {
			return $passed;
		}

		$product = wc_get_product( $product_id );
		if ( $product && $product->is_type( 'variable' ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$variation_id = isset( $_REQUEST['variation_id'] ) ? (int) $_REQUEST['variation_id'] : 0;
			if ( $variation_id <= 0 ) {
				wc_add_notice( __( 'لطفاً متغیر محصول را انتخاب کنید.', 'webina-woo-core' ), 'error' );
				return false;
			}
		}

		$new_purchase_type = self::sanitize_purchase_type( isset( $_REQUEST['purchase_type'] ) ? wp_unslash( $_REQUEST['purchase_type'] ) : 'cash' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! self::is_purchase_type_enabled( $new_purchase_type ) ) {
			wc_add_notice( __( 'این روش خرید در حال حاضر فعال نیست.', 'webina-woo-core' ), 'error' );
			return false;
		}

		return $passed;
	}

	/**
	 * Add purchase type to cart item data.
	 *
	 * @param array $cart_item_data Cart item data.
	 * @param int   $product_id Product ID.
	 * @return array
	 */
	public static function add_cart_item_data( $cart_item_data, $product_id ) {
		unset( $product_id );

		$purchase_type = self::sanitize_purchase_type( isset( $_REQUEST['purchase_type'] ) ? wp_unslash( $_REQUEST['purchase_type'] ) : 'cash' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$cart_item_data['wfcp_purchase_type'] = $purchase_type;

		if ( 'installment' === $purchase_type && isset( $_REQUEST['installment_months'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$cart_item_data['wfcp_installment_months'] = max( 1, (int) $_REQUEST['installment_months'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		return $cart_item_data;
	}

	/**
	 * Display purchase type in cart.
	 *
	 * @param array $item_data Cart item data.
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public static function get_item_data( $item_data, $cart_item ) {
		if ( ! isset( $cart_item['wfcp_purchase_type'] ) ) {
			return $item_data;
		}

		$item_data[] = array(
			'name'  => __( 'نوع خرید', 'webina-woo-core' ),
			'value' => WFCP_Helper::get_purchase_type_label( $cart_item['wfcp_purchase_type'], $cart_item ),
		);

		$unit_price = self::get_cart_unit_price(
			WFCP_Helper::resolve_cart_pricing_product_id( $cart_item ),
			(string) $cart_item['wfcp_purchase_type'],
			isset( $cart_item['wfcp_installment_months'] ) ? (int) $cart_item['wfcp_installment_months'] : 0
		);

		if ( null !== $unit_price ) {
			$item_data[] = array(
				'name'  => __( 'قیمت واحد', 'webina-woo-core' ),
				'value' => wp_strip_all_tags( wc_price( $unit_price ) ),
			);
		}

		return $item_data;
	}

	/**
	 * Apply WFCP prices to cart line items.
	 *
	 * @param WC_Cart $cart Cart instance.
	 * @return void
	 */
	public static function apply_cart_prices( $cart ) {
		if ( ! $cart instanceof WC_Cart || ( is_admin() && ! wp_doing_ajax() ) || ! WFCP_Helper::is_enabled() ) {
			return;
		}

		foreach ( $cart->get_cart() as $item_key => $item ) {
			if ( empty( $item['data'] ) || ! is_object( $item['data'] ) || ! method_exists( $item['data'], 'set_price' ) ) {
				continue;
			}

			$pricing_id    = WFCP_Helper::resolve_cart_pricing_product_id( $item );
			$purchase_type = isset( $item['wfcp_purchase_type'] ) ? (string) $item['wfcp_purchase_type'] : 'cash';
			$months        = isset( $item['wfcp_installment_months'] ) ? (int) $item['wfcp_installment_months'] : 0;

			$unit_price = self::get_cart_unit_price( $pricing_id, $purchase_type, $months );
			if ( null === $unit_price ) {
				continue;
			}

			$cart->cart_contents[ $item_key ]['data']->set_price( $unit_price );
		}
	}

	/**
	 * Persist WFCP metadata on order line items.
	 *
	 * @param WC_Order_Item_Product $item Order item.
	 * @param string                $cart_item_key Cart item key.
	 * @param array                 $values Cart item values.
	 * @param WC_Order              $order Order.
	 * @return void
	 */
	public static function save_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
		unset( $cart_item_key, $order );

		if ( empty( $values['wfcp_purchase_type'] ) ) {
			return;
		}

		$purchase_type = (string) $values['wfcp_purchase_type'];
		$months        = isset( $values['wfcp_installment_months'] ) ? (int) $values['wfcp_installment_months'] : 0;
		$pricing_id    = WFCP_Helper::resolve_cart_pricing_product_id( $values );
		$unit_price    = self::get_cart_unit_price( $pricing_id, $purchase_type, $months );

		$item->add_meta_data( 'wfcp_purchase_type', $purchase_type, true );
		if ( $months > 0 ) {
			$item->add_meta_data( 'wfcp_installment_months', $months, true );
		}
		if ( null !== $unit_price ) {
			$item->add_meta_data( 'wfcp_unit_price', $unit_price, true );
		}
	}

	/**
	 * Resolve cart unit price for a purchase type.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $purchase_type Purchase type slug.
	 * @param int    $months Installment months.
	 * @return float|null
	 */
	public static function get_cart_unit_price( $product_id, $purchase_type, $months = 0 ) {
		$purchase_price = WFCP_Helper::get_product_purchase_price( $product_id );
		if ( null === $purchase_price ) {
			return null;
		}

		$purchase_type = self::sanitize_purchase_type( $purchase_type );

		switch ( $purchase_type ) {
			case 'credit':
				return WFCP_Calculator::calculate_price( $purchase_price, 'credit', $product_id );
			case 'wholesale':
				return WFCP_Calculator::calculate_price( $purchase_price, 'wholesale', $product_id );
			case 'installment':
				$months = max( 1, (int) $months );
				$monthly = WFCP_Calculator::calculate_price(
					$purchase_price,
					'installment',
					$product_id,
					array( 'months' => $months )
				);
				return $monthly * $months;
			case 'cash':
			default:
				return WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product_id );
		}
	}

	/**
	 * @param string $purchase_type Raw purchase type.
	 * @return string
	 */
	public static function sanitize_purchase_type( $purchase_type ) {
		$purchase_type = sanitize_key( (string) $purchase_type );
		$allowed       = array( 'cash', 'credit', 'installment', 'wholesale' );

		return in_array( $purchase_type, $allowed, true ) ? $purchase_type : 'cash';
	}

	/**
	 * @param string $purchase_type Purchase type slug.
	 * @return bool
	 */
	public static function is_purchase_type_enabled( $purchase_type ) {
		switch ( self::sanitize_purchase_type( $purchase_type ) ) {
			case 'credit':
				return (bool) WFCP_Helper::get_settings( 'credit', 'enabled' );
			case 'installment':
				return (bool) WFCP_Helper::get_settings( 'installment', 'enabled' );
			case 'wholesale':
				return (bool) WFCP_Helper::get_settings( 'wholesale', 'enabled' );
			case 'cash':
			default:
				return true;
		}
	}
}
