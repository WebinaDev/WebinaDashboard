<?php
/**
 * Fired during plugin activation
 *
 * @package    WFCP
 * @subpackage WFCP/includes
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Fired during plugin activation.
 */
class WFCP_Activator {

	/**
	 * Activate plugin
	 */
	public static function activate() {
		// Set default options
		$default_settings = self::get_default_settings();
		
		// Check if settings already exist
		$existing_settings = get_option( 'wfcp_settings', array() );
		
		// Merge with defaults (preserve existing settings)
		$settings = wp_parse_args( $existing_settings, $default_settings );
		
		update_option( 'wfcp_settings', $settings );
		
		// Set version
		update_option( 'wfcp_version', WFCP_VERSION );
		
		// Flush rewrite rules
		flush_rewrite_rules();
	}

	/**
	 * Get default settings
	 *
	 * @return array
	 */
	private static function get_default_settings() {
		return array(
			'general' => array(
				'enabled'                => true,
				'currency'               => 'IRR',
				'exchange_rate'          => 42000,
				'exchange_rate_enabled'  => true, // When false, never apply exchange rate.
				'purchase_currency'      => 'base', // 'base' = USD, 'display' = IRR/IRT
				'api_enabled'            => false,
				'api_key'          => '',
				'api_symbol'       => 'USD',
				'auto_update_enabled' => false,
				'auto_update_hour' => 0,
			),
			'retail' => array(
				'profit_percent' => 20,
				'round_enabled'  => true,
				'round_to'      => 1000,
				'gateways'      => array(),
			),
			'credit' => array(
				'enabled'        => false,
				'increase_percent' => 5,
				'gateways'       => array(),
				'texts'          => array(
					'title'       => 'خرید اعتباری',
					'button_text' => 'افزودن اعتباری',
				),
			),
			'installment' => array(
				'enabled' => false,
				'plans'   => array(
					array(
						'months'   => 3,
						'interest' => 5,
					),
					array(
						'months'   => 6,
						'interest' => 10,
					),
				),
				'gateways' => array(),
				'texts' => array(
					'title'       => 'خرید اقساطی',
					'button_text' => 'افزودن اقساطی',
				),
			),
			'wholesale' => array(
				'enabled'         => false,
				'strategy'        => 'global',
				'discount_percent' => 10,
				'gateways'        => array(),
				'category_rules'  => array(),
			),
			'notifications' => array(
				'installment_text'        => 'خرید اقساطی',
				'credit_text'             => 'خرید اعتباری',
				'cash_description'        => '',
				'installment_description' => '',
				'credit_description'      => '',
				'wholesale_description'   => '',
				'need_review'             => 'نیاز به بررسی',
			),
			'style' => array(
				'box_background'    => '#ffffff',
				'box_border_color'  => '#e0e0e0',
				'button_background' => '#2271b1',
				'button_text_color' => '#ffffff',
				'price_color'       => '#2271b1',
				'border_radius'     => 8,
			),
		);
	}
}

