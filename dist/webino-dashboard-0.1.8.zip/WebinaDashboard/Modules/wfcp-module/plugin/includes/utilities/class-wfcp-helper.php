<?php
/**
 * Helper functions
 *
 * @package    WFCP
 * @subpackage WFCP/includes/utilities
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Helper functions class
 */
class WFCP_Helper {

	/**
	 * Get plugin settings
	 *
	 * @param string $section Optional. Settings section.
	 * @param string $key     Optional. Settings key.
	 * @return mixed
	 */
	public static function get_settings( $section = null, $key = null ) {
		$settings = get_option( 'wfcp_settings', array() );

		if ( null === $section ) {
			return $settings;
		}

		if ( ! isset( $settings[ $section ] ) ) {
			return null;
		}

		if ( null === $key ) {
			return $settings[ $section ];
		}

		if ( ! isset( $settings[ $section ][ $key ] ) ) {
			return null;
		}

		return $settings[ $section ][ $key ];
	}

	/**
	 * Update plugin settings
	 *
	 * @param string $section Settings section.
	 * @param array  $data    Settings data.
	 * @return bool
	 */
	public static function update_settings( $section, $data ) {
		$settings = self::get_settings();
		
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$settings[ $section ] = $data;
		
		return update_option( 'wfcp_settings', $settings );
	}

	/**
	 * Sanitize price value
	 *
	 * @param mixed $price Price value.
	 * @return float
	 */
	public static function sanitize_price( $price ) {
		if ( is_array( $price ) ) {
			return 0.0;
		}
		$price = sanitize_text_field( (string) $price );
		$price = str_replace( array( ',', ' ' ), '', $price );
		return floatval( $price );
	}

	/**
	 * Format price for display
	 *
	 * @param float  $price    Price value.
	 * @param string $currency Optional. Currency code.
	 * @return string
	 */
	public static function format_price( $price, $currency = null ) {
		if ( null === $currency ) {
			$currency = self::get_settings( 'general', 'currency' );
		}

		$formatted = number_format( $price, 0, '.', ',' );

		if ( class_exists( 'Webino_Dashboard_Currency' ) && Webino_Dashboard_Currency::is_toman_currency( $currency, self::get_currency_symbol( $currency ) ) ) {
			return $formatted . ' ' . Webino_Dashboard_Currency::irt_icon_html();
		}

		$symbol = self::get_currency_symbol( $currency );

		return $formatted . ' ' . $symbol;
	}

	/**
	 * Get currency symbol
	 *
	 * @param string $currency Currency code.
	 * @return string
	 */
	public static function get_currency_symbol( $currency = null ) {
		if ( null === $currency ) {
			$currency = self::get_settings( 'general', 'currency' );
		}

		$symbols = array(
			'IRR' => 'ریال',
			'IRT' => 'تومان',
			'USD' => '$',
			'EUR' => '€',
			'GBP' => '£',
		);

		return isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : $currency;
	}

	/**
	 * Format price with IRT (Toman) symbol HTML for product display.
	 *
	 * @param float $price Price value.
	 * @return string HTML: formatted number + woocommerce-Price-currencySymbol span.
	 */
	public static function format_price_with_irt_symbol( $price ) {
		$formatted = number_format( (float) $price, 0, '.', ',' );
		if ( class_exists( 'Webino_Dashboard_Currency' ) ) {
			return $formatted . ' ' . Webino_Dashboard_Currency::irt_icon_html();
		}
		$symbol = '<span class="woocommerce-Price-currencySymbol"><span class="ishop-currency-symbol ishop-currency-irt">IRT</span></span>';
		return $formatted . ' ' . $symbol;
	}

	/**
	 * Round price
	 *
	 * @param float $price Price to round.
	 * @param int   $to    Round to this value.
	 * @return float
	 */
	public static function round_price( $price, $to = 1000 ) {
		return round( $price / $to ) * $to;
	}

	/**
	 * Check if plugin is enabled
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) self::get_settings( 'general', 'enabled' );
	}

	/**
	 * Get product purchase price
	 *
	 * @param int $product_id Product ID.
	 * @return float|null
	 */
	public static function get_product_purchase_price( $product_id ) {
		$price = get_post_meta( $product_id, '_wfcp_purchase_price', true );
		return $price ? floatval( $price ) : null;
	}

	/**
	 * Whether a product (simple or variable with priced variations) uses WFCP pricing.
	 *
	 * @param WC_Product|null $product Product object.
	 * @return bool
	 */
	public static function product_has_wfcp_pricing( $product ) {
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return false;
		}

		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				if ( null !== self::get_product_purchase_price( (int) $child_id ) ) {
					return true;
				}
			}
			return false;
		}

		return null !== self::get_product_purchase_price( $product->get_id() );
	}

	/**
	 * Resolve product ID used for WFCP price calculation (variation when applicable).
	 *
	 * @param int $product_id   Parent or simple product ID.
	 * @param int $variation_id Variation ID when set.
	 * @return int
	 */
	public static function resolve_pricing_product_id( $product_id, $variation_id = 0 ) {
		return $variation_id > 0 ? (int) $variation_id : (int) $product_id;
	}

	/**
	 * Check if product price is locked
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function is_product_price_locked( $product_id ) {
		return (bool) get_post_meta( $product_id, '_wfcp_lock_price', true );
	}

	/**
	 * Build computed tier prices for a simple product or variation.
	 *
	 * @param int $product_id Product or variation ID.
	 * @return array<string,mixed>|null
	 */
	public static function build_pricing_tiers( $product_id ) {
		$product_id     = (int) $product_id;
		$purchase_price = self::get_product_purchase_price( $product_id );
		if ( null === $purchase_price ) {
			return null;
		}

		$credit_enabled      = (bool) self::get_settings( 'credit', 'enabled' );
		$wholesale_enabled   = (bool) self::get_settings( 'wholesale', 'enabled' );
		$installment_enabled = (bool) self::get_settings( 'installment', 'enabled' );

		$retail    = WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product_id );
		$credit    = $credit_enabled ? WFCP_Calculator::calculate_price( $purchase_price, 'credit', $product_id ) : 0.0;
		$wholesale = $wholesale_enabled ? WFCP_Calculator::calculate_price( $purchase_price, 'wholesale', $product_id ) : 0.0;

		$installment_plans = array();
		if ( $installment_enabled ) {
			$plans_config = self::get_settings( 'installment', 'plans' );
			if ( is_array( $plans_config ) ) {
				foreach ( $plans_config as $plan ) {
					$months = isset( $plan['months'] ) ? (int) $plan['months'] : 0;
					if ( $months <= 0 ) {
						continue;
					}
					$monthly_price = WFCP_Calculator::calculate_price(
						$purchase_price,
						'installment',
						$product_id,
						array( 'months' => $months )
					);
					$installment_plans[] = array(
						'months'            => $months,
						'monthly_price'     => $monthly_price,
						'monthly_formatted' => self::format_price_with_irt_symbol( $monthly_price ),
						'total_price'       => $monthly_price * $months,
					);
				}
			}
		}

		return array(
			'retail'              => $retail,
			'retail_formatted'    => self::format_price_with_irt_symbol( $retail ),
			'credit'              => $credit,
			'credit_formatted'    => self::format_price_with_irt_symbol( $credit ),
			'wholesale'           => $wholesale,
			'wholesale_formatted' => self::format_price_with_irt_symbol( $wholesale ),
			'installment_plans'   => $installment_plans,
			'show_credit'         => $credit_enabled && $credit > 0,
			'show_wholesale'      => $wholesale_enabled && $wholesale > 0,
			'show_installment'    => $installment_enabled && ! empty( $installment_plans ),
		);
	}

	/**
	 * Pricing payload keyed by variation ID for variable products.
	 *
	 * @param WC_Product $product Variable product.
	 * @return array<string,array<string,mixed>>
	 */
	public static function build_variation_pricing_payload( $product ) {
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! $product->is_type( 'variable' ) ) {
			return array();
		}

		$payload = array();
		foreach ( $product->get_children() as $variation_id ) {
			$tiers = self::build_pricing_tiers( (int) $variation_id );
			if ( null !== $tiers ) {
				$payload[ (string) (int) $variation_id ] = $tiers;
			}
		}

		return $payload;
	}

	/**
	 * Resolve the product ID used for WFCP price lookup from a cart line.
	 *
	 * @param array $cart_item Cart line item.
	 * @return int
	 */
	public static function resolve_cart_pricing_product_id( $cart_item ) {
		if ( ! empty( $cart_item['variation_id'] ) ) {
			return (int) $cart_item['variation_id'];
		}

		return isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
	}

	/**
	 * Human-readable label for a purchase type.
	 *
	 * @param string     $purchase_type Purchase type slug.
	 * @param array|null $cart_item Optional cart item for installment months.
	 * @return string
	 */
	public static function get_purchase_type_label( $purchase_type, $cart_item = null ) {
		$credit_texts      = self::get_settings( 'credit', 'texts' );
		$installment_texts = self::get_settings( 'installment', 'texts' );

		$labels = array(
			'cash'        => __( 'نقدی', 'webina-woo-core' ),
			'credit'      => ( is_array( $credit_texts ) && ! empty( $credit_texts['title'] ) ) ? $credit_texts['title'] : __( 'اعتباری', 'webina-woo-core' ),
			'installment' => ( is_array( $installment_texts ) && ! empty( $installment_texts['title'] ) ) ? $installment_texts['title'] : __( 'اقساطی', 'webina-woo-core' ),
			'wholesale'   => __( 'عمده', 'webina-woo-core' ),
		);

		$label = isset( $labels[ $purchase_type ] ) ? $labels[ $purchase_type ] : (string) $purchase_type;

		if ( 'installment' === $purchase_type && is_array( $cart_item ) && ! empty( $cart_item['wfcp_installment_months'] ) ) {
			$label .= ' (' . sprintf( __( '%d ماهه', 'webina-woo-core' ), (int) $cart_item['wfcp_installment_months'] ) . ')';
		}

		return (string) $label;
	}

	/**
	 * Sync WooCommerce regular/active price from purchase price when not locked.
	 *
	 * @param int   $product_id Product ID.
	 * @param float $purchase_price Purchase price.
	 * @return void
	 */
	public static function sync_retail_price_from_purchase( $product_id, $purchase_price ) {
		if ( self::is_product_price_locked( $product_id ) || ! class_exists( 'WFCP_Calculator', false ) ) {
			return;
		}

		$retail = WFCP_Calculator::calculate_price( (float) $purchase_price, 'retail', $product_id );
		update_post_meta( $product_id, '_regular_price', $retail );
		update_post_meta( $product_id, '_price', $retail );

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$product->set_regular_price( (string) $retail );
				$product->set_price( (string) $retail );
				$product->save();
			}
		}
	}

	/**
	 * Reschedule or clear the exchange rate auto-update cron.
	 * Safe to call from AJAX (does not fire init hook).
	 */
	public static function reschedule_exchange_cron() {
		$general = self::get_settings( 'general' );
		if ( ! is_array( $general ) ) {
			$general = array();
		}

		if ( empty( $general['api_enabled'] ) || empty( $general['auto_update_enabled'] ) ) {
			wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );
			return;
		}

		$hour = isset( $general['auto_update_hour'] ) ? intval( $general['auto_update_hour'] ) : 0;
		wp_clear_scheduled_hook( 'wfcp_auto_update_exchange_rate' );

		$current_time = current_time( 'timestamp' );
		$today        = strtotime( date( 'Y-m-d', $current_time ) );
		$scheduled_time = $today + ( $hour * HOUR_IN_SECONDS );
		if ( $scheduled_time <= $current_time ) {
			$scheduled_time += DAY_IN_SECONDS;
		}
		wp_schedule_event( $scheduled_time, 'daily', 'wfcp_auto_update_exchange_rate' );
	}
}

