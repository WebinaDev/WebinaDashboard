<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package    WFCP
 * @subpackage WFCP/admin
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The admin-specific functionality of the plugin.
 */
class WFCP_Admin {

	/**
	 * Register the stylesheets for the admin area.
	 */
	public function enqueue_styles() {
		$screen = get_current_screen();
		$is_wfcp_page = false;
		
		// Check by screen ID
		if ( $screen && strpos( $screen->id, 'wfcp' ) !== false ) {
			$is_wfcp_page = true;
		}
		
		// Check by page parameter
		if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'wfcp' ) !== false ) {
			$is_wfcp_page = true;
		}
		
		if ( ! $is_wfcp_page ) {
			return;
		}

		wp_enqueue_style(
			'wfcp-admin-style',
			WFCP_PLUGIN_URL . 'admin/css/wfcp-admin-style.css',
			array(),
			WFCP_VERSION,
			'all'
		);
	}

	/**
	 * Register the JavaScript for the admin area.
	 */
	public function enqueue_scripts() {
		$screen = get_current_screen();
		$is_wfcp_page = false;
		
		// Check by screen ID
		if ( $screen && strpos( $screen->id, 'wfcp' ) !== false ) {
			$is_wfcp_page = true;
		}
		
		// Check by page parameter (important for custom pages)
		if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'wfcp' ) !== false ) {
			$is_wfcp_page = true;
		}
		
		if ( ! $is_wfcp_page ) {
			return;
		}

		// Quick add products page - enqueue media FIRST
		if ( isset( $_GET['page'] ) && 'wfcp-quick-add' === $_GET['page'] ) {
			// Enqueue WordPress Media Uploader FIRST - MUST be before any other scripts
			// This ensures all media scripts and styles are loaded
			wp_enqueue_media();
			
			// Also explicitly enqueue media scripts to ensure they're loaded
			wp_enqueue_script( 'media-upload' );
			wp_enqueue_script( 'media-views' );
			wp_enqueue_script( 'wp-util' );
		}

		wp_enqueue_script(
			'wfcp-admin-general',
			WFCP_PLUGIN_URL . 'admin/js/wfcp-admin-general.js',
			array( 'jquery' ),
			WFCP_VERSION,
			false
		);

		wp_enqueue_script(
			'wfcp-admin-bulk',
			WFCP_PLUGIN_URL . 'admin/js/wfcp-admin-bulk.js',
			array( 'jquery' ),
			WFCP_VERSION,
			false
		);

		// Quick add products script
		if ( isset( $_GET['page'] ) && 'wfcp-quick-add' === $_GET['page'] ) {
			// Enqueue our script with proper dependencies
			// Include all media-related dependencies to ensure wp.media is fully loaded
			wp_enqueue_script(
				'wfcp-admin-quick-add',
				WFCP_PLUGIN_URL . 'admin/js/wfcp-admin-quick-add.js',
				array( 'jquery', 'media-upload', 'media-views', 'wp-util' ),
				WFCP_VERSION,
				true // Load in footer to ensure wp.media is available
			);
		}

		// Select2 no longer needed - gateways are now toggle switches

		// Localize script
		wp_localize_script(
			'wfcp-admin-general',
			'wfcpAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wfcp_admin_nonce' ),
			)
		);

		// Localize quick add script if on quick add page
		if ( isset( $_GET['page'] ) && 'wfcp-quick-add' === $_GET['page'] ) {
			wp_localize_script(
				'wfcp-admin-quick-add',
				'wfcpAdmin',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'wfcp_admin_nonce' ),
				)
			);
		}

		wp_localize_script(
			'wfcp-admin-bulk',
			'wfcpBulk',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wfcp_bulk_nonce' ),
				'filterNonce' => wp_create_nonce( 'wfcp_pm_filter_nonce' ),
				'updateNonce' => wp_create_nonce( 'wfcp_pm_update_nonce' ),
			)
		);
	}

	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		// Use edit_products as it's the standard WooCommerce capability that always exists
		// manage_woocommerce might not exist in older WooCommerce versions
		$capability = 'edit_products';
		
		add_menu_page(
			__( 'مدیریت قیمت', 'webina-woo-core' ),
			__( 'مدیریت قیمت', 'webina-woo-core' ),
			$capability,
			'wfcp-settings',
			array( $this, 'display_settings_page' ),
			'dashicons-money-alt',
			56
		);

		add_submenu_page(
			'wfcp-settings',
			__( 'داشبورد و تنظیمات', 'webina-woo-core' ),
			__( 'داشبورد و تنظیمات', 'webina-woo-core' ),
			$capability,
			'wfcp-settings',
			array( $this, 'display_settings_page' )
		);

		add_submenu_page(
			'wfcp-settings',
			__( 'لیست قیمت', 'webina-woo-core' ),
			__( 'لیست قیمت', 'webina-woo-core' ),
			$capability,
			'wfcp-bulk-editor',
			array( $this, 'display_bulk_editor_page' )
		);

		add_submenu_page(
			'wfcp-settings',
			__( 'افزودن سریع محصولات', 'webina-woo-core' ),
			__( 'افزودن سریع محصولات', 'webina-woo-core' ),
			$capability,
			'wfcp-quick-add',
			array( $this, 'display_quick_add_page' )
		);

		add_submenu_page(
			'wfcp-settings',
			__( 'تغییر قیمت گروهی', 'webina-woo-core' ),
			__( 'تغییر قیمت گروهی', 'webina-woo-core' ),
			'manage_woocommerce',
			'wfcp-price-changer',
			array( $this, 'display_price_changer_page' )
		);
	}

	/**
	 * Display settings page
	 */
	public function display_settings_page() {
		require_once WFCP_PLUGIN_DIR . 'admin/partials/wfcp-admin-wrap.php';
	}

	/**
	 * Display bulk editor page
	 */
	public function display_bulk_editor_page() {
		require_once WFCP_PLUGIN_DIR . 'admin/partials/wfcp-page-bulk-editor.php';
	}

	/**
	 * Display quick add products page
	 */
	public function display_quick_add_page() {
		require_once WFCP_PLUGIN_DIR . 'admin/partials/wfcp-page-quick-add.php';
	}

	/**
	 * Display price changer page (bulk price bump + CSV import)
	 */
	public function display_price_changer_page() {
		if ( isset( $GLOBALS['wfcp_bulk_price_change'] ) && is_object( $GLOBALS['wfcp_bulk_price_change'] ) ) {
			$GLOBALS['wfcp_bulk_price_change']->page();
		} else {
			echo '<div class="wrap"><h1>تغییر قیمت گروهی</h1><p>خطا در بارگذاری ماژول تغییر قیمت گروهی</p></div>';
		}
	}

	/**
	 * AJAX handler for saving settings
	 */
	public function ajax_save_settings() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$section = isset( $_POST['section'] ) ? sanitize_text_field( $_POST['section'] ) : '';
		$data    = isset( $_POST['data'] ) && is_array( $_POST['data'] ) ? $_POST['data'] : array();

		if ( empty( $section ) ) {
			wp_send_json_error( array( 'message' => __( 'بخش تنظیمات مشخص نشده است', 'webina-woo-core' ) ) );
		}

		// Sanitize data based on section
		$sanitized_data = $this->sanitize_settings_data( $section, $data );

		// For 'exchange' section, we update 'general' section instead
		$update_section = ( 'exchange' === $section ) ? 'general' : $section;
		
		$result = WFCP_Helper::update_settings( $update_section, $sanitized_data );

		if ( $result ) {
			// Reschedule exchange cron after save when general settings were updated (e.g. from exchange tab).
			if ( 'general' === $update_section ) {
				WFCP_Helper::reschedule_exchange_cron();
			}
			wp_send_json_success( array( 'message' => __( 'تنظیمات با موفقیت ذخیره شد', 'webina-woo-core' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'خطا در ذخیره تنظیمات', 'webina-woo-core' ) ) );
		}
	}

	/**
	 * Sanitize settings data
	 *
	 * @param string $section Section name.
	 * @param array  $data    Data to sanitize.
	 * @return array
	 */
	private function sanitize_settings_data( $section, $data ) {
		$sanitized = array();

		switch ( $section ) {
			case 'general':
				$sanitized['enabled']       = isset( $data['enabled'] ) ? (bool) $data['enabled'] : false;
				$sanitized['currency']       = isset( $data['currency'] ) ? sanitize_text_field( $data['currency'] ) : 'IRR';
				$sanitized['exchange_rate'] = isset( $data['exchange_rate'] ) ? WFCP_Helper::sanitize_price( $data['exchange_rate'] ) : 42000;
				break;

			case 'retail':
				$sanitized['profit_percent'] = isset( $data['profit_percent'] ) ? floatval( $data['profit_percent'] ) : 20;
				$sanitized['round_enabled']  = isset( $data['round_enabled'] ) ? (bool) $data['round_enabled'] : false;
				$sanitized['round_to']       = isset( $data['round_to'] ) ? intval( $data['round_to'] ) : 1000;
				$sanitized['gateways']       = isset( $data['gateways'] ) && is_array( $data['gateways'] ) ? array_map( 'sanitize_text_field', $data['gateways'] ) : array();
				break;

			case 'credit':
				$sanitized['enabled']         = isset( $data['enabled'] ) ? (bool) $data['enabled'] : false;
				$sanitized['increase_percent'] = isset( $data['increase_percent'] ) ? floatval( $data['increase_percent'] ) : 5;
				$sanitized['gateways']         = isset( $data['gateways'] ) && is_array( $data['gateways'] ) ? array_map( 'sanitize_text_field', $data['gateways'] ) : array();
				$sanitized['texts']            = array(
					'title'       => isset( $data['texts']['title'] ) ? sanitize_text_field( $data['texts']['title'] ) : '',
					'button_text' => isset( $data['texts']['button_text'] ) ? sanitize_text_field( $data['texts']['button_text'] ) : '',
				);
				break;

			case 'installment':
				$sanitized['enabled'] = isset( $data['enabled'] ) ? (bool) $data['enabled'] : false;
				$sanitized['plans']   = array();
				
				if ( isset( $data['plans'] ) && is_array( $data['plans'] ) ) {
					foreach ( $data['plans'] as $plan ) {
						$sanitized['plans'][] = array(
							'months'   => isset( $plan['months'] ) ? intval( $plan['months'] ) : 0,
							'interest' => isset( $plan['interest'] ) ? floatval( $plan['interest'] ) : 0,
						);
					}
				}
				
				$sanitized['gateways'] = isset( $data['gateways'] ) && is_array( $data['gateways'] ) ? array_map( 'sanitize_text_field', $data['gateways'] ) : array();
				$sanitized['texts'] = array(
					'title'       => isset( $data['texts']['title'] ) ? sanitize_text_field( $data['texts']['title'] ) : '',
					'button_text' => isset( $data['texts']['button_text'] ) ? sanitize_text_field( $data['texts']['button_text'] ) : '',
				);
				break;

			case 'wholesale':
				$sanitized['enabled']          = isset( $data['enabled'] ) ? (bool) $data['enabled'] : false;
				$sanitized['strategy']          = isset( $data['strategy'] ) ? sanitize_text_field( $data['strategy'] ) : 'global';
				$sanitized['discount_percent']  = isset( $data['discount_percent'] ) ? floatval( $data['discount_percent'] ) : 10;
				$sanitized['gateways']          = isset( $data['gateways'] ) && is_array( $data['gateways'] ) ? array_map( 'sanitize_text_field', $data['gateways'] ) : array();
				$sanitized['category_rules']   = array();
				
				if ( isset( $data['category_rules'] ) && is_array( $data['category_rules'] ) ) {
					foreach ( $data['category_rules'] as $cat_id => $discount ) {
						$sanitized['category_rules'][ intval( $cat_id ) ] = floatval( $discount );
					}
				}
				break;

			case 'notifications':
				$sanitized['installment_text']        = isset( $data['installment_text'] ) ? sanitize_text_field( $data['installment_text'] ) : '';
				$sanitized['credit_text']             = isset( $data['credit_text'] ) ? sanitize_text_field( $data['credit_text'] ) : '';
				$sanitized['cash_description']        = isset( $data['cash_description'] ) ? wp_kses_post( $data['cash_description'] ) : '';
				$sanitized['installment_description'] = isset( $data['installment_description'] ) ? wp_kses_post( $data['installment_description'] ) : '';
				$sanitized['credit_description']      = isset( $data['credit_description'] ) ? wp_kses_post( $data['credit_description'] ) : '';
				$sanitized['wholesale_description']   = isset( $data['wholesale_description'] ) ? wp_kses_post( $data['wholesale_description'] ) : '';
				$sanitized['need_review']             = isset( $data['need_review'] ) ? sanitize_text_field( $data['need_review'] ) : '';
				break;

			case 'currency':
				// Update currency in general settings
				$current_general = WFCP_Helper::get_settings( 'general' );
				if ( ! is_array( $current_general ) ) {
					$current_general = array();
				}
				$current_general['currency'] = isset( $data['currency'] ) ? sanitize_text_field( $data['currency'] ) : 'IRR';
				// Preserve other settings
				if ( ! isset( $current_general['enabled'] ) ) {
					$current_general['enabled'] = true;
				}
				$sanitized = $current_general;
				break;

			case 'exchange':
				// Update exchange rate in general settings
				$current_general = WFCP_Helper::get_settings( 'general' );
				if ( ! is_array( $current_general ) ) {
					$current_general = array();
				}
				
				// Preserve existing settings
				$current_general['enabled'] = isset( $current_general['enabled'] ) ? $current_general['enabled'] : true;
				$current_general['currency'] = isset( $current_general['currency'] ) ? $current_general['currency'] : 'IRR';
				
				// Update exchange rate settings
				$current_general['exchange_rate'] = isset( $data['exchange_rate'] ) ? WFCP_Helper::sanitize_price( $data['exchange_rate'] ) : ( isset( $current_general['exchange_rate'] ) ? $current_general['exchange_rate'] : 42000 );
				// Checkbox: when unchecked, JS may send false or "false"; (bool) "false" is true in PHP, so normalize:
				$exchange_enabled_raw = isset( $data['exchange_rate_enabled'] ) ? $data['exchange_rate_enabled'] : null;
				if ( null !== $exchange_enabled_raw ) {
					$current_general['exchange_rate_enabled'] = in_array( $exchange_enabled_raw, array( true, '1', 1, 'true', 'on', 'yes' ), true );
				} else {
					$current_general['exchange_rate_enabled'] = isset( $current_general['exchange_rate_enabled'] ) ? (bool) $current_general['exchange_rate_enabled'] : true;
				}
				$current_general['purchase_currency'] = isset( $data['purchase_currency'] ) && in_array( $data['purchase_currency'], array( 'base', 'display' ), true ) ? sanitize_text_field( $data['purchase_currency'] ) : ( isset( $current_general['purchase_currency'] ) ? $current_general['purchase_currency'] : 'base' );
				$current_general['api_enabled'] = isset( $data['api_enabled'] ) ? (bool) $data['api_enabled'] : ( isset( $current_general['api_enabled'] ) ? $current_general['api_enabled'] : false );
				$current_general['api_key'] = isset( $data['api_key'] ) ? sanitize_text_field( $data['api_key'] ) : ( isset( $current_general['api_key'] ) ? $current_general['api_key'] : '' );
				$current_general['api_symbol'] = isset( $data['api_symbol'] ) ? sanitize_text_field( $data['api_symbol'] ) : ( isset( $current_general['api_symbol'] ) ? $current_general['api_symbol'] : 'USD' );
				$current_general['auto_update_enabled'] = isset( $data['auto_update_enabled'] ) ? (bool) $data['auto_update_enabled'] : ( isset( $current_general['auto_update_enabled'] ) ? $current_general['auto_update_enabled'] : false );
				$current_general['auto_update_hour'] = isset( $data['auto_update_hour'] ) ? intval( $data['auto_update_hour'] ) : ( isset( $current_general['auto_update_hour'] ) ? $current_general['auto_update_hour'] : 0 );
				
				// Do NOT call external API on save (causes timeout/errors). Rate is updated only via
				// "دریافت الان" / "تست اتصال به API" buttons or cron.
				
				// Update enabled status if provided
				if ( isset( $data['enabled'] ) ) {
					$current_general['enabled'] = (bool) $data['enabled'];
				}
				
				// Cron is rescheduled in ajax_save_settings after save (avoids do_action('init') which can cause 500 in AJAX).
				
				// Return sanitized data for response (will be saved by ajax_save_settings)
				$sanitized = $current_general;
				break;

			case 'style':
				$sanitized['box_background']    = isset( $data['box_background'] ) ? sanitize_hex_color( $data['box_background'] ) : '#ffffff';
				$sanitized['box_border_color']  = isset( $data['box_border_color'] ) ? sanitize_hex_color( $data['box_border_color'] ) : '#e0e0e0';
				$sanitized['button_background'] = isset( $data['button_background'] ) ? sanitize_hex_color( $data['button_background'] ) : '#2271b1';
				$sanitized['button_text_color']  = isset( $data['button_text_color'] ) ? sanitize_hex_color( $data['button_text_color'] ) : '#ffffff';
				$sanitized['price_color']        = isset( $data['price_color'] ) ? sanitize_hex_color( $data['price_color'] ) : '#2271b1';
				$sanitized['border_radius']      = isset( $data['border_radius'] ) ? intval( $data['border_radius'] ) : 8;
				break;
		}

		return $sanitized;
	}

	/**
	 * AJAX handler for updating product price
	 */
	public function ajax_update_product_price() {
		check_ajax_referer( 'wfcp_bulk_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_id    = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
		$purchase_price = isset( $_POST['purchase_price'] ) ? WFCP_Helper::sanitize_price( $_POST['purchase_price'] ) : 0;

		if ( ! $product_id || ! $purchase_price ) {
			wp_send_json_error( array( 'message' => __( 'اطلاعات ناقص است', 'webina-woo-core' ) ) );
		}

		// Update purchase price
		update_post_meta( $product_id, '_wfcp_purchase_price', $purchase_price );

		// Calculate prices
		$retail_price     = WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product_id );
		$credit_price     = WFCP_Calculator::calculate_price( $purchase_price, 'credit', $product_id );
		$wholesale_price  = WFCP_Calculator::calculate_price( $purchase_price, 'wholesale', $product_id );

		// Update WooCommerce price if not locked
		if ( ! WFCP_Helper::is_product_price_locked( $product_id ) ) {
			update_post_meta( $product_id, '_regular_price', $retail_price );
			update_post_meta( $product_id, '_price', $retail_price );
			wc_delete_product_transients( $product_id );
		}

		wp_send_json_success(
			array(
				'retail_price'    => WFCP_Helper::format_price( $retail_price ),
				'credit_price'    => WFCP_Helper::format_price( $credit_price ),
				'wholesale_price' => WFCP_Helper::format_price( $wholesale_price ),
			)
		);
	}

	/**
	 * AJAX handler for recalculating all prices
	 */
	public function ajax_recalculate_all() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$dry_run = isset( $_POST['dry_run'] ) && 'true' === $_POST['dry_run'];

		$results = WFCP_Batch_Process::recalculate_all( $dry_run );

		wp_send_json_success( $results );
	}

	/**
	 * AJAX handler for deleting transients
	 */
	public function ajax_delete_transients() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$deleted = WFCP_Batch_Process::delete_transients();

		wp_send_json_success(
			array(
				'message' => sprintf( __( '%d کش حذف شد', 'webina-woo-core' ), $deleted ),
			)
		);
	}

	/**
	 * AJAX handler for exporting settings
	 */
	public function ajax_export_settings() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$json = WFCP_Batch_Process::export_settings();

		wp_send_json_success( array( 'json' => $json ) );
	}

	/**
	 * AJAX handler for importing settings
	 */
	public function ajax_import_settings() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$json = isset( $_POST['json'] ) ? wp_unslash( $_POST['json'] ) : '';
		$json = sanitize_textarea_field( $json );

		if ( empty( $json ) ) {
			wp_send_json_error( array( 'message' => __( 'داده JSON ارسال نشده است', 'webina-woo-core' ) ) );
		}

		$result = WFCP_Batch_Process::import_settings( $json );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'تنظیمات با موفقیت وارد شد', 'webina-woo-core' ) ) );
	}

	/**
	 * AJAX handler for updating lock price
	 */
	public function ajax_update_lock_price() {
		check_ajax_referer( 'wfcp_bulk_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
		$is_locked  = isset( $_POST['is_locked'] ) && 1 === intval( $_POST['is_locked'] );

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'شناسه محصول نامعتبر است', 'webina-woo-core' ) ) );
		}

		update_post_meta( $product_id, '_wfcp_lock_price', $is_locked ? '1' : '0' );

		$message = $is_locked 
			? __( 'قیمت محصول قفل شد', 'webina-woo-core' )
			: __( 'قفل قیمت محصول باز شد', 'webina-woo-core' );

		wp_send_json_success( array( 'message' => $message ) );
	}

	/**
	 * AJAX handler for testing API connection
	 */
	public function ajax_test_api() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';
		$symbol  = isset( $_POST['api_symbol'] ) ? sanitize_text_field( $_POST['api_symbol'] ) : 'USD';

		if ( empty( $api_key ) ) {
			wp_send_json_error( array( 'message' => __( 'API Key وارد نشده است', 'webina-woo-core' ) ) );
		}

		$result = WFCP_Exchange_API::get_exchange_rate( $api_key, $symbol );

		if ( $result['success'] ) {
			wp_send_json_success( array(
				'message' => sprintf( __( 'اتصال موفق! نرخ ارز: %s', 'webina-woo-core' ), number_format_i18n( $result['price'], 0 ) ),
				'price'   => $result['price'],
			) );
		} else {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}
	}

	/**
	 * AJAX handler for updating exchange rate from API
	 */
	public function ajax_update_exchange_rate() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$result = WFCP_Exchange_API::update_exchange_rate();

		if ( $result['success'] ) {
			wp_send_json_success( array(
				'message' => $result['message'],
				'price'   => $result['price'],
			) );
		} else {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}
	}

	/**
	 * AJAX handler for updating all product prices
	 */
	public function ajax_update_all_prices() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		// Delete all price transients to force recalculation
		WFCP_Batch_Process::delete_transients();

		// Recalculate all products
		$results = WFCP_Batch_Process::recalculate_all( false );

		wp_send_json_success( array(
			'message' => sprintf( __( 'قیمت %d محصول با موفقیت به‌روزرسانی شد', 'webina-woo-core' ), $results['success'] ),
			'success' => $results['success'],
			'failed'  => $results['failed'],
		) );
	}

	/**
	 * AJAX handler for quick add product
	 */
	public function ajax_quick_add_product() {
		check_ajax_referer( 'wfcp_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_name = isset( $_POST['product_name'] ) ? sanitize_text_field( $_POST['product_name'] ) : '';
		$purchase_price = isset( $_POST['purchase_price'] ) ? WFCP_Helper::sanitize_price( $_POST['purchase_price'] ) : 0;
		$image_id = isset( $_POST['image_id'] ) ? intval( $_POST['image_id'] ) : 0;

		if ( empty( $product_name ) ) {
			wp_send_json_error( array( 'message' => __( 'نام محصول الزامی است', 'webina-woo-core' ) ) );
		}

		if ( strlen( $product_name ) > 5040 ) {
			wp_send_json_error( array( 'message' => __( 'نام محصول نمی‌تواند بیشتر از 5040 کاراکتر باشد', 'webina-woo-core' ) ) );
		}

		if ( $purchase_price <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'قیمت خرید باید بیشتر از صفر باشد', 'webina-woo-core' ) ) );
		}

		// Check if WooCommerce is active
		if ( ! class_exists( 'WC_Product_Simple' ) ) {
			wp_send_json_error( array( 'message' => __( 'ووکامرس فعال نیست', 'webina-woo-core' ) ) );
		}

		// Create WooCommerce product
		$product = new WC_Product_Simple();
		$product->set_name( $product_name );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'visible' );
		$product->set_manage_stock( false );
		$product->set_stock_status( 'instock' );

		// Set purchase price
		$product->update_meta_data( '_wfcp_purchase_price', $purchase_price );

		// Calculate and set retail price
		$retail_price = WFCP_Calculator::calculate_price( $purchase_price, 'retail' );
		$product->set_regular_price( $retail_price );
		$product->set_price( $retail_price );

		// Save product
		$product_id = $product->save();

		if ( ! $product_id || is_wp_error( $product_id ) ) {
			wp_send_json_error( array( 'message' => __( 'خطا در ایجاد محصول', 'webina-woo-core' ) ) );
		}

		// Handle image if provided (from media library)
		if ( $image_id > 0 ) {
			set_post_thumbnail( $product_id, $image_id );
		}

		wp_send_json_success( array(
			'message' => sprintf( __( 'محصول "%s" با موفقیت ایجاد شد', 'webina-woo-core' ), $product_name ),
			'product_id' => $product_id,
		) );
	}

	/* =================================================================
	 *  Price Manager AJAX handlers
	 * ================================================================= */

	/**
	 * AJAX: Get products list for price manager page.
	 */
	public function ajax_pm_get_products() {
		check_ajax_referer( 'wfcp_pm_filter_nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$paged          = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
		$search_term    = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$posts_per_page = 50;

		$brand_terms = get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => false ) );
		if ( is_wp_error( $brand_terms ) ) {
			$brand_terms = array();
		}

		// Sort
		$sort_option = isset( $_POST['sort'] ) ? sanitize_text_field( wp_unslash( $_POST['sort'] ) ) : 'date_desc';
		$orderby     = 'date';
		$order       = 'DESC';

		switch ( $sort_option ) {
			case 'date_asc':
				$orderby = 'date';
				$order   = 'ASC';
				break;
			case 'name_asc':
				$orderby = 'title';
				$order   = 'ASC';
				break;
			case 'name_desc':
				$orderby = 'title';
				$order   = 'DESC';
				break;
			case 'price_asc':
				$orderby = 'meta_value_num';
				$order   = 'ASC';
				break;
			case 'price_desc':
				$orderby = 'meta_value_num';
				$order   = 'DESC';
				break;
		}

		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $posts_per_page,
			'paged'          => $paged,
			's'              => $search_term,
			'orderby'        => $orderby,
			'order'          => $order,
		);

		if ( false !== strpos( $sort_option, 'price' ) ) {
			$args['meta_key'] = '_regular_price';
		}

		// Taxonomy filters.
		$tax_query = array();
		if ( ! empty( $_POST['category'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( wp_unslash( $_POST['category'] ) ),
			);
		}
		if ( ! empty( $_POST['brand'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_brand',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( wp_unslash( $_POST['brand'] ) ),
			);
		}
		if ( ! empty( $tax_query ) ) {
			$tax_query['relation'] = 'AND';
			$args['tax_query']     = $tax_query;
		}

		$stock_status_filter = ! empty( $_POST['stock_status'] ) ? sanitize_text_field( wp_unslash( $_POST['stock_status'] ) ) : '';

		$products_query = new WP_Query( $args );

		ob_start();

		if ( $products_query->have_posts() ) {
			while ( $products_query->have_posts() ) {
				$products_query->the_post();
				$product = wc_get_product( get_the_ID() );
				if ( ! $product ) {
					continue;
				}

				// Clear caches to ensure fresh data from DB.
				clean_post_cache( get_the_ID() );
				wc_delete_product_transients( get_the_ID() );
				$product = wc_get_product( get_the_ID() );

				if ( $product->is_type( 'variable' ) ) {
					$variations_data    = $product->get_available_variations();
					$parent_brand_id    = $this->pm_get_brand_term_id( $product->get_id() );
					$brand_html         = $this->pm_build_brand_select( $brand_terms, $parent_brand_id, $product->get_id() );
					$parent_purchase    = WFCP_Helper::get_product_purchase_price( $product->get_id() );
					$parent_locked      = WFCP_Helper::is_product_price_locked( $product->get_id() );

					foreach ( $variations_data as $i => $variation_data ) {
						$variation = wc_get_product( $variation_data['variation_id'] );
						if ( ! $variation ) {
							continue;
						}
						$stock_status = $variation->get_stock_status();
						if ( '' !== $stock_status_filter && $stock_status !== $stock_status_filter ) {
							continue;
						}

						$v_purchase  = WFCP_Helper::get_product_purchase_price( $variation->get_id() );
						if ( null === $v_purchase ) {
							$v_purchase = $parent_purchase;
						}
						$v_retail    = $v_purchase ? WFCP_Calculator::calculate_price( $v_purchase, 'retail', $product->get_id() ) : 0;
						$v_credit    = $v_purchase ? WFCP_Calculator::calculate_price( $v_purchase, 'credit', $product->get_id() ) : 0;
						$v_wholesale = $v_purchase ? WFCP_Calculator::calculate_price( $v_purchase, 'wholesale', $product->get_id() ) : 0;
						?>
						<tr class="<?php echo 0 === $i ? 'wfcp-pm-product-start' : ''; ?>" data-product-id="<?php echo esc_attr( $variation->get_id() ); ?>">
							<td data-column="image" class="wfcp-pm-image-cell"><?php echo $variation->get_image( 'thumbnail', array( 'class' => 'wfcp-pm-product-thumbnail' ) ); ?></td>
							<td data-column="name" data-label="نام"><strong><?php echo esc_html( $product->get_name() ); ?></strong></td>
							<td data-column="attrs" class="wfcp-pm-attrs-cell" data-label="ویژگی‌ها">
								<?php
								foreach ( $variation_data['attributes'] as $attr_key => $term_slug ) {
									$taxonomy = str_replace( 'attribute_', '', urldecode( $attr_key ) );
									$term     = get_term_by( 'slug', $term_slug, $taxonomy );
									echo '<span class="wfcp-pm-attr-tag">' . esc_html( wc_attribute_label( $taxonomy ) ) . ': <strong>' . ( $term ? esc_html( $term->name ) : esc_html( $term_slug ) ) . '</strong></span>';
								}
								?>
							</td>
							<td data-column="sku" data-label="SKU"><?php echo esc_html( $variation->get_sku() ?: '-' ); ?></td>
							<td data-column="brand" class="wfcp-pm-brand-col" data-label="برند"><?php echo $brand_html; ?></td>
							<td data-column="stock" data-label="موجودی">
								<div class="wfcp-pm-stock-wrapper">
									<select class="wfcp-stock-select" data-id="<?php echo esc_attr( $variation->get_id() ); ?>">
										<option value="instock" <?php selected( $stock_status, 'instock' ); ?>>موجود</option>
										<option value="outofstock" <?php selected( $stock_status, 'outofstock' ); ?>>ناموجود</option>
									</select>
									<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
								</div>
							</td>
							<td data-column="purchase_price" data-label="قیمت خرید">
								<input type="number" class="wfcp-purchase-price-input wfcp-form-control" value="<?php echo esc_attr( $v_purchase ?: '' ); ?>" step="0.01" min="0" <?php echo $parent_locked ? 'disabled' : ''; ?>>
								<label class="wfcp-checkbox" style="margin-top:5px;font-size:12px;">
									<input type="checkbox" class="wfcp-lock-price-checkbox" data-product-id="<?php echo esc_attr( $variation->get_id() ); ?>" <?php checked( $parent_locked ); ?>>
									<span>قفل</span>
								</label>
							</td>
							<td data-column="retail_price" class="wfcp-retail-price" data-label="قیمت تکی"><?php echo $v_retail ? esc_html( WFCP_Helper::format_price( $v_retail ) ) : '-'; ?></td>
							<td data-column="credit_price" class="wfcp-credit-price" data-label="قیمت اعتباری"><?php echo $v_credit ? esc_html( WFCP_Helper::format_price( $v_credit ) ) : '-'; ?></td>
							<td data-column="wholesale_price" class="wfcp-wholesale-price" data-label="قیمت عمده"><?php echo $v_wholesale ? esc_html( WFCP_Helper::format_price( $v_wholesale ) ) : '-'; ?></td>
							<td data-column="regular_price" data-label="قیمت ووکامرس">
								<div class="wfcp-pm-price-wrapper">
									<input type="text" class="wfcp-wc-price-input" value="<?php echo esc_attr( $variation->get_regular_price() ? number_format( (float) $variation->get_regular_price() ) : '' ); ?>" data-price-type="regular" data-id="<?php echo esc_attr( $variation->get_id() ); ?>">
									<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
								</div>
							</td>
							<td data-column="sale_price" data-label="تخفیف ووکامرس">
								<div class="wfcp-pm-price-wrapper">
									<input type="text" class="wfcp-wc-price-input" value="<?php echo esc_attr( $variation->get_sale_price() ? number_format( (float) $variation->get_sale_price() ) : '' ); ?>" data-price-type="sale" data-id="<?php echo esc_attr( $variation->get_id() ); ?>">
									<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
								</div>
							</td>
						</tr>
						<?php
					}
				} else {
					$stock_status        = $product->get_stock_status();
					$product_brand_id    = $this->pm_get_brand_term_id( $product->get_id() );
					$brand_html          = $this->pm_build_brand_select( $brand_terms, $product_brand_id, $product->get_id() );
					$purchase_price      = WFCP_Helper::get_product_purchase_price( $product->get_id() );
					$is_locked          = WFCP_Helper::is_product_price_locked( $product->get_id() );
					$retail_price       = $purchase_price ? WFCP_Calculator::calculate_price( $purchase_price, 'retail', $product->get_id() ) : 0;
					$credit_price       = $purchase_price ? WFCP_Calculator::calculate_price( $purchase_price, 'credit', $product->get_id() ) : 0;
					$wholesale_price    = $purchase_price ? WFCP_Calculator::calculate_price( $purchase_price, 'wholesale', $product->get_id() ) : 0;

					if ( '' !== $stock_status_filter && $stock_status !== $stock_status_filter ) {
						continue;
					}
					?>
					<tr class="wfcp-pm-product-start" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
						<td data-column="image" class="wfcp-pm-image-cell"><?php echo $product->get_image( 'thumbnail', array( 'class' => 'wfcp-pm-product-thumbnail' ) ); ?></td>
						<td data-column="name" data-label="نام"><strong><?php echo esc_html( $product->get_name() ); ?></strong></td>
						<td data-column="attrs" class="wfcp-pm-attrs-cell" data-label="ویژگی‌ها"><span class="wfcp-pm-attr-tag">محصول ساده</span></td>
						<td data-column="sku" data-label="SKU"><?php echo esc_html( $product->get_sku() ?: '-' ); ?></td>
						<td data-column="brand" class="wfcp-pm-brand-col" data-label="برند"><?php echo $brand_html; ?></td>
						<td data-column="stock" data-label="موجودی">
							<div class="wfcp-pm-stock-wrapper">
								<select class="wfcp-stock-select" data-id="<?php echo esc_attr( $product->get_id() ); ?>">
									<option value="instock" <?php selected( $stock_status, 'instock' ); ?>>موجود</option>
									<option value="outofstock" <?php selected( $stock_status, 'outofstock' ); ?>>ناموجود</option>
								</select>
								<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
							</div>
						</td>
						<td data-column="purchase_price" data-label="قیمت خرید">
							<input type="number" class="wfcp-purchase-price-input wfcp-form-control" value="<?php echo esc_attr( $purchase_price ?: '' ); ?>" step="0.01" min="0" <?php echo $is_locked ? 'disabled' : ''; ?>>
							<label class="wfcp-checkbox" style="margin-top:5px;font-size:12px;">
								<input type="checkbox" class="wfcp-lock-price-checkbox" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" <?php checked( $is_locked ); ?>>
								<span>قفل</span>
							</label>
						</td>
						<td data-column="retail_price" class="wfcp-retail-price" data-label="قیمت تکی"><?php echo $retail_price ? esc_html( WFCP_Helper::format_price( $retail_price ) ) : '-'; ?></td>
						<td data-column="credit_price" class="wfcp-credit-price" data-label="قیمت اعتباری"><?php echo $credit_price ? esc_html( WFCP_Helper::format_price( $credit_price ) ) : '-'; ?></td>
						<td data-column="wholesale_price" class="wfcp-wholesale-price" data-label="قیمت عمده"><?php echo $wholesale_price ? esc_html( WFCP_Helper::format_price( $wholesale_price ) ) : '-'; ?></td>
						<td data-column="regular_price" data-label="قیمت ووکامرس">
							<div class="wfcp-pm-price-wrapper">
								<input type="text" class="wfcp-wc-price-input" value="<?php echo esc_attr( $product->get_regular_price() ? number_format( (float) $product->get_regular_price() ) : '' ); ?>" data-price-type="regular" data-id="<?php echo esc_attr( $product->get_id() ); ?>">
								<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
							</div>
						</td>
						<td data-column="sale_price" data-label="تخفیف ووکامرس">
							<div class="wfcp-pm-price-wrapper">
								<input type="text" class="wfcp-wc-price-input" value="<?php echo esc_attr( $product->get_sale_price() ? number_format( (float) $product->get_sale_price() ) : '' ); ?>" data-price-type="sale" data-id="<?php echo esc_attr( $product->get_id() ); ?>">
								<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>
							</div>
						</td>
					</tr>
					<?php
				}
			}
			wp_reset_postdata();
		} else {
			echo '<tr><td colspan="12">هیچ محصولی با این مشخصات یافت نشد.</td></tr>';
		}

		$products_html = ob_get_clean();

		// Pagination.
		$pagination_html = '';
		if ( $products_query->max_num_pages > 1 ) {
			$pagination_html = '<div class="wfcp-pm-pagination">';

			if ( $paged > 1 ) {
				$pagination_html .= '<a href="#" data-page="' . ( $paged - 1 ) . '" class="page-numbers prev">« قبلی</a>';
			}

			$start_page = max( 1, $paged - 2 );
			$end_page   = min( $products_query->max_num_pages, $paged + 2 );

			if ( $start_page > 1 ) {
				$pagination_html .= '<a href="#" data-page="1" class="page-numbers">1</a>';
				if ( $start_page > 2 ) {
					$pagination_html .= '<span class="page-numbers dots">...</span>';
				}
			}

			for ( $i = $start_page; $i <= $end_page; $i++ ) {
				$current_class    = ( $i === $paged ) ? ' current' : '';
				$pagination_html .= '<a href="#" data-page="' . $i . '" class="page-numbers' . $current_class . '">' . $i . '</a>';
			}

			if ( $end_page < $products_query->max_num_pages ) {
				if ( $end_page < $products_query->max_num_pages - 1 ) {
					$pagination_html .= '<span class="page-numbers dots">...</span>';
				}
				$pagination_html .= '<a href="#" data-page="' . $products_query->max_num_pages . '" class="page-numbers">' . $products_query->max_num_pages . '</a>';
			}

			if ( $paged < $products_query->max_num_pages ) {
				$pagination_html .= '<a href="#" data-page="' . ( $paged + 1 ) . '" class="page-numbers next">بعدی »</a>';
			}

			$pagination_html .= '</div>';
		}

		wp_send_json_success( array(
			'products_html'   => $products_html,
			'pagination_html' => $pagination_html,
			'current_page'    => $paged,
			'total_pages'     => $products_query->max_num_pages,
			'total_products'  => $products_query->found_posts,
		) );
	}

	/**
	 * AJAX: Update product/variation price.
	 */
	public function ajax_pm_update_price() {
		check_ajax_referer( 'wfcp_pm_update_nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $product_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'شناسه نامعتبر است.', 'webina-woo-core' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => __( 'محصول یافت نشد.', 'webina-woo-core' ) ) );
		}

		$price      = isset( $_POST['price'] ) ? wc_clean( wp_unslash( $_POST['price'] ) ) : '';
		$price_type = isset( $_POST['price_type'] ) && 'sale' === $_POST['price_type'] ? 'sale' : 'regular';
		$price      = str_replace( ',', '', $price );

		if ( '' !== $price && ! is_numeric( $price ) ) {
			wp_send_json_error( array( 'message' => __( 'قیمت نامعتبر است.', 'webina-woo-core' ) ) );
		}

		if ( 'sale' === $price_type ) {
			$product->set_sale_price( $price );
		} else {
			$product->set_regular_price( $price );
		}

		$product->save();

		// Also update post meta directly as a safety net (in case WC object cache is stale).
		$meta_key = ( 'sale' === $price_type ) ? '_sale_price' : '_regular_price';
		update_post_meta( $product_id, $meta_key, $price );

		// If regular price changed, update _price meta too (WooCommerce uses _price for display).
		if ( 'regular' === $price_type ) {
			$current_sale = get_post_meta( $product_id, '_sale_price', true );
			if ( '' === $current_sale || (float) $current_sale <= 0 ) {
				update_post_meta( $product_id, '_price', $price );
			}
		}

		// Verify save: clear cache and re-read from DB.
		wc_delete_product_transients( $product_id );
		clean_post_cache( $product_id );
		$saved_price = get_post_meta( $product_id, $meta_key, true );
		$verified    = ( (string) $saved_price === (string) $price );

		if ( ! $verified ) {
			error_log( "WFCP price save FAILED: product_id={$product_id}, type={$price_type}, sent={$price}, saved={$saved_price}" );
		}

		wp_send_json_success( array(
			'message'     => __( 'قیمت ذخیره شد.', 'webina-woo-core' ),
			'product_id'  => $product_id,
			'price_type'  => $price_type,
			'sent_price'  => $price,
			'saved_price' => $saved_price,
			'verified'    => $verified,
		) );
	}

	/**
	 * AJAX: Update product/variation stock status.
	 */
	public function ajax_pm_update_stock() {
		check_ajax_referer( 'wfcp_pm_update_nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $product_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'شناسه نامعتبر است.', 'webina-woo-core' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			wp_send_json_error( array( 'message' => __( 'محصول یافت نشد.', 'webina-woo-core' ) ) );
		}

		$stock_status = isset( $_POST['stock_status'] ) && in_array( $_POST['stock_status'], array( 'instock', 'outofstock' ), true )
			? sanitize_text_field( wp_unslash( $_POST['stock_status'] ) )
			: 'instock';

		$product->set_stock_status( $stock_status );
		$product->save();

		// Also update post meta directly as a safety net.
		update_post_meta( $product_id, '_stock_status', $stock_status );

		// Verify save: clear cache and re-read from DB.
		wc_delete_product_transients( $product_id );
		clean_post_cache( $product_id );
		$saved_status = get_post_meta( $product_id, '_stock_status', true );
		$verified     = ( $saved_status === $stock_status );

		if ( ! $verified ) {
			error_log( "WFCP stock save FAILED: product_id={$product_id}, sent={$stock_status}, saved={$saved_status}" );
		}

		wp_send_json_success( array(
			'message'      => __( 'وضعیت موجودی ذخیره شد.', 'webina-woo-core' ),
			'product_id'   => $product_id,
			'sent_status'  => $stock_status,
			'saved_status' => $saved_status,
			'verified'     => $verified,
		) );
	}

	/**
	 * AJAX: Update product brand.
	 */
	public function ajax_pm_update_brand() {
		check_ajax_referer( 'wfcp_pm_update_nonce' );

		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز', 'webina-woo-core' ) ) );
		}

		$product_id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( $product_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'شناسه نامعتبر است.', 'webina-woo-core' ) ) );
		}

		$brand_id = isset( $_POST['brand_id'] ) ? absint( $_POST['brand_id'] ) : 0;

		if ( 0 === $brand_id ) {
			$result = wp_set_object_terms( $product_id, array(), 'product_brand', false );
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			}
			// Verify removal.
			clean_object_term_cache( $product_id, get_post_type( $product_id ) ?: 'product' );
			$verify = wp_get_post_terms( $product_id, 'product_brand', array( 'fields' => 'ids' ) );
			wp_send_json_success( array(
				'message'    => __( 'برند حذف شد.', 'webina-woo-core' ),
				'product_id' => $product_id,
				'verified'   => empty( $verify ),
			) );
		}

		$brand_term = get_term( $brand_id, 'product_brand' );
		if ( ! $brand_term || is_wp_error( $brand_term ) ) {
			wp_send_json_error( array(
				'message'         => __( 'برند انتخابی نامعتبر است.', 'webina-woo-core' ),
				'brand_id'        => $brand_id,
				'taxonomy_exists' => taxonomy_exists( 'product_brand' ),
			) );
		}

		$result = wp_set_object_terms( $product_id, (int) $brand_term->term_id, 'product_brand', false );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// Verify save: clear cache and re-read from DB.
		clean_object_term_cache( $product_id, get_post_type( $product_id ) ?: 'product' );
		$verify_terms = wp_get_post_terms( $product_id, 'product_brand', array( 'fields' => 'ids' ) );
		$verified     = is_array( $verify_terms ) && in_array( $brand_id, $verify_terms, false );

		if ( ! $verified ) {
			error_log( "WFCP brand save FAILED: product_id={$product_id}, sent_id={$brand_id}, saved=" . wp_json_encode( $verify_terms ) );
		}

		wp_send_json_success( array(
			'message'      => __( 'برند ذخیره شد.', 'webina-woo-core' ),
			'product_id'   => $product_id,
			'brand_id'     => $brand_id,
			'verified'     => $verified,
			'saved_brands' => $verify_terms,
		) );
	}

	/* =================================================================
	 *  Price Manager helper methods
	 * ================================================================= */

	/**
	 * Get primary brand slug for a product.
	 *
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private function pm_get_brand_term_id( $product_id ) {
		// Force fresh read — bypass any stale object cache.
		clean_object_term_cache( $product_id, get_post_type( $product_id ) ?: 'product' );
		$terms = wp_get_post_terms( $product_id, 'product_brand' );
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return 0;
		}
		return (int) $terms[0]->term_id;
	}

	/**
	 * Build brand dropdown HTML.
	 *
	 * @param array  $brand_terms   All brand terms.
	 * @param string $selected_slug Currently selected slug.
	 * @param int    $product_id    Product ID.
	 * @return string
	 */
	private function pm_build_brand_select( $brand_terms, $selected_term_id, $product_id ) {
		$options = '<option value="0">بدون برند</option>';
		if ( ! empty( $brand_terms ) ) {
			foreach ( $brand_terms as $bt ) {
				$options .= '<option value="' . esc_attr( $bt->term_id ) . '"' . selected( (int) $selected_term_id, (int) $bt->term_id, false ) . '>' . esc_html( $bt->name ) . '</option>';
			}
		}

		$html  = '<div class="wfcp-pm-brand-wrapper">';
		$html .= '<select class="wfcp-brand-select" data-product-id="' . esc_attr( $product_id ) . '" data-original-value="' . esc_attr( $selected_term_id ) . '">';
		$html .= $options;
		$html .= '</select>';
		$html .= '<span class="wfcp-pm-save-status"><span class="spinner"></span><span class="wfcp-pm-status-icon"></span></span>';
		$html .= '</div>';

		return $html;
	}
}

