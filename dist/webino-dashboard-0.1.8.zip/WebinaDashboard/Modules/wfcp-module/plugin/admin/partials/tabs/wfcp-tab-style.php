<?php
/**
 * Style settings tab
 *
 * @package    WFCP
 * @subpackage WFCP/admin/partials/tabs
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

$style_settings = WFCP_Helper::get_settings( 'style' );
?>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'تنظیمات استایل باکس قیمت', 'webina-woo-core' ); ?></h2>
	
	<form class="wfcp-settings-form" data-section="style">
		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="box_background">
				<?php esc_html_e( 'رنگ پس‌زمینه باکس', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="color" 
				name="box_background" 
				id="box_background" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['box_background'] ?? '#ffffff' ); ?>"
				style="width: 100px; height: 40px;"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="box_border_color">
				<?php esc_html_e( 'رنگ حاشیه باکس', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="color" 
				name="box_border_color" 
				id="box_border_color" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['box_border_color'] ?? '#e0e0e0' ); ?>"
				style="width: 100px; height: 40px;"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="button_background">
				<?php esc_html_e( 'رنگ پس‌زمینه دکمه‌ها', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="color" 
				name="button_background" 
				id="button_background" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['button_background'] ?? '#2271b1' ); ?>"
				style="width: 100px; height: 40px;"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="button_text_color">
				<?php esc_html_e( 'رنگ متن دکمه‌ها', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="color" 
				name="button_text_color" 
				id="button_text_color" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['button_text_color'] ?? '#ffffff' ); ?>"
				style="width: 100px; height: 40px;"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="price_color">
				<?php esc_html_e( 'رنگ نمایش قیمت', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="color" 
				name="price_color" 
				id="price_color" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['price_color'] ?? '#2271b1' ); ?>"
				style="width: 100px; height: 40px;"
			>
		</div>

		<div class="wfcp-form-group">
			<label class="wfcp-form-label" for="border_radius">
				<?php esc_html_e( 'گردی گوشه‌ها (px)', 'webina-woo-core' ); ?>
			</label>
			<input 
				type="number" 
				name="border_radius" 
				id="border_radius" 
				class="wfcp-form-control" 
				value="<?php echo esc_attr( $style_settings['border_radius'] ?? 8 ); ?>"
				min="0"
				max="50"
			>
		</div>

		<button type="submit" class="wfcp-btn wfcp-btn-primary">
			<?php esc_html_e( 'ذخیره تنظیمات', 'webina-woo-core' ); ?>
		</button>
	</form>
</div>

<div class="wfcp-card">
	<h2 class="wfcp-card-title"><?php esc_html_e( 'پیش‌نمایش', 'webina-woo-core' ); ?></h2>
	<div id="wfcp-style-preview" style="padding: 20px; background: #f8fafc; border-radius: 8px; margin-top: 20px;">
		<div class="wfcp-preview-box" style="background: <?php echo esc_attr( $style_settings['box_background'] ?? '#ffffff' ); ?>; border: 1px solid <?php echo esc_attr( $style_settings['box_border_color'] ?? '#e0e0e0' ); ?>; border-radius: <?php echo esc_attr( $style_settings['border_radius'] ?? 8 ); ?>px; padding: 20px;">
			<div style="margin-bottom: 15px;">
				<strong style="font-family: 'YekanBakh', 'Tahoma', sans-serif;">قیمت نقدی</strong>
				<div style="color: <?php echo esc_attr( $style_settings['price_color'] ?? '#2271b1' ); ?>; font-size: 18px; font-weight: bold; font-family: 'YekanBakh', 'Tahoma', sans-serif;">
					1,000,000 <?php echo class_exists( 'Webino_Dashboard_Currency' ) ? Webino_Dashboard_Currency::irt_icon_html() : 'تومان'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>
			<button style="background: <?php echo esc_attr( $style_settings['button_background'] ?? '#2271b1' ); ?>; color: <?php echo esc_attr( $style_settings['button_text_color'] ?? '#ffffff' ); ?>; border: none; padding: 10px 20px; border-radius: 6px; font-family: 'YekanBakh', 'Tahoma', sans-serif; cursor: pointer;">
				افزودن به سبد
			</button>
		</div>
	</div>
</div>

