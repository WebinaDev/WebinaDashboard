/**
 * Public JavaScript
 *
 * @package    WFCP
 * @subpackage WFCP/public/js
 */

(function($) {
	'use strict';

	var addToCartText = 'افزودن به سبد خرید';
	var addingText   = 'در حال افزودن...';
	var selectedVariationId = 0;

	$(document).ready(function() {
		initQuantityControls();
		initAddToCartButtons();
		initInstallmentPlanSelection();
		initVariableProductPricing();
	});

	function initQuantityControls() {
		$(document).on('click', '.wfcp-qty-minus', function() {
			var $input = $(this).closest('.wfcp-quantity-wrap').find('.wfcp-qty-input');
			var val = parseInt($input.val(), 10) || 1;
			if (val > 1) {
				$input.val(val - 1);
			}
		});

		$(document).on('click', '.wfcp-qty-plus', function() {
			var $input = $(this).closest('.wfcp-quantity-wrap').find('.wfcp-qty-input');
			var val = parseInt($input.val(), 10) || 1;
			$input.val(val + 1);
		});
	}

	function initAddToCartButtons() {
		$(document).on('click', '.wfcp-btn-add', function(e) {
			e.preventDefault();

			var $button = $(this);
			if ($button.prop('disabled')) {
				return;
			}

			var $row = $button.closest('.wfcp-pricing-row');
			var quantity = 1;
			var $qtyInput = $row.find('.wfcp-qty-input');
			if ($qtyInput.length) {
				quantity = parseInt($qtyInput.val(), 10) || 1;
				if (quantity < 1) {
					quantity = 1;
				}
			}

			var purchaseType = $button.data('purchase-type') || 'cash';
			var productId = $button.data('product-id');
			var variationId = parseInt($button.data('variation-id'), 10) || 0;
			var months = $button.data('months');

			if (typeof wfcpPublic !== 'undefined' && wfcpPublic.isVariable) {
				if (!variationId) {
					showMessage(wfcpPublic.selectVariationText || 'لطفاً متغیر را انتخاب کنید.', 'error');
					return;
				}
				productId = wfcpPublic.parentId || productId;
			}

			if (purchaseType === 'installment') {
				var $selectedPlan = $row.find('.wfcp-installment-plan-item.active');
				if ($selectedPlan.length) {
					months = $selectedPlan.data('months') || months;
				}
			}

			addToCartAjax(productId, purchaseType, $button, months, quantity, variationId);
		});
	}

	function initInstallmentPlanSelection() {
		$(document).on('click', '.wfcp-installment-plan-item', function() {
			var $item = $(this);
			var months = $item.data('months');
			var $row = $item.closest('.wfcp-pricing-row');
			$row.find('.wfcp-btn-add-installment').data('months', months);
			$row.find('.wfcp-installment-plan-item').removeClass('active');
			$item.addClass('active');
		});
	}

	function initVariableProductPricing() {
		if (typeof wfcpPublic === 'undefined' || !wfcpPublic.isVariable) {
			return;
		}

		var $form = $('form.variations_form');
		if (!$form.length) {
			return;
		}

		$form.on('found_variation.wfcp', function(event, variation) {
			if (!variation || !variation.variation_id) {
				return;
			}
			updatePricingBox(parseInt(variation.variation_id, 10));
		});

		$form.on('reset_data.wfcp hide_variation.wfcp', function() {
			resetPricingBox();
		});
	}

	function updatePricingBox(variationId) {
		var pricing = getVariationPricing(variationId);
		var $box = $('.wfcp-pricing-box');

		selectedVariationId = variationId;

		if (!pricing) {
			resetPricingBox();
			showMessage('برای این متغیر قیمت‌گذاری تعریف نشده است.', 'error');
			return;
		}

		$box.removeClass('wfcp-pricing-box--awaiting-variation');
		$box.find('.wfcp-variation-notice').hide();

		$box.find('.wfcp-pricing-row.cash .wfcp-pricing-amount-value').html(pricing.retail_formatted || '—');
		$box.find('.wfcp-pricing-row.credit .wfcp-pricing-amount-value').html(pricing.credit_formatted || '—');
		$box.find('.wfcp-pricing-row.wholesale .wfcp-pricing-amount-value').html(pricing.wholesale_formatted || '—');

		toggleRow($box.find('.wfcp-pricing-row.installment'), !!pricing.show_installment);
		toggleRow($box.find('.wfcp-pricing-row.credit'), !!pricing.show_credit);
		toggleRow($box.find('.wfcp-pricing-row.wholesale'), !!pricing.show_wholesale);

		renderInstallmentPlans($box, pricing.installment_plans || []);

		$box.find('.wfcp-btn-add').each(function() {
			$(this)
				.prop('disabled', false)
				.data('variation-id', variationId);
		});
	}

	function resetPricingBox() {
		var $box = $('.wfcp-pricing-box');
		selectedVariationId = 0;

		$box.addClass('wfcp-pricing-box--awaiting-variation');
		$box.find('.wfcp-variation-notice').show();
		$box.find('.wfcp-pricing-amount-value').text('—');
		$box.find('.wfcp-installment-plans-list').empty();
		$box.find('.wfcp-pricing-row.installment, .wfcp-pricing-row.credit, .wfcp-pricing-row.wholesale').addClass('wfcp-row-hidden');
		$box.find('.wfcp-btn-add').each(function() {
			$(this)
				.prop('disabled', true)
				.data('variation-id', '');
		});
	}

	function toggleRow($row, show) {
		if (!$row.length) {
			return;
		}
		if (show) {
			$row.removeClass('wfcp-row-hidden');
		} else {
			$row.addClass('wfcp-row-hidden');
		}
	}

	function renderInstallmentPlans($box, plans) {
		var $list = $box.find('.wfcp-installment-plans-list');
		$list.empty();

		if (!plans.length) {
			return;
		}

		var perMonthText = (typeof wfcpPublic !== 'undefined' && wfcpPublic.installmentPerMonthText) ? wfcpPublic.installmentPerMonthText : 'هر قسط %s';
		var monthsLabel = (typeof wfcpPublic !== 'undefined' && wfcpPublic.monthsLabel) ? wfcpPublic.monthsLabel : '%d ماهه';

		plans.forEach(function(plan, index) {
			var monthsText = monthsLabel.replace('%d', plan.months);
			var priceText = perMonthText.replace('%s', plan.monthly_formatted || '');
			var $item = $('<div class="wfcp-installment-plan-item"></div>')
				.attr('data-months', plan.months)
				.toggleClass('active', index === 0)
				.append($('<span class="wfcp-installment-plan-months"></span>').text(monthsText))
				.append($('<span class="wfcp-installment-plan-price"></span>').text(priceText));
			$list.append($item);
		});

		var firstMonths = plans[0].months;
		$box.find('.wfcp-btn-add-installment').data('months', firstMonths);
	}

	function getVariationPricing(variationId) {
		if (typeof wfcpPublic === 'undefined' || !wfcpPublic.variationsPricing) {
			return null;
		}
		return wfcpPublic.variationsPricing[String(variationId)] || null;
	}

	function collectVariationAttributes() {
		var attributes = {};
		var $form = $('form.variations_form');
		if (!$form.length) {
			return attributes;
		}

		$form.find('select[name^="attribute_"], input[name^="attribute_"]').each(function() {
			var name = $(this).attr('name');
			if (name) {
				attributes[name] = $(this).val();
			}
		});

		return attributes;
	}

	function addToCartAjax(productId, purchaseType, $button, months, quantity, variationId) {
		quantity = quantity || 1;
		var originalText = $button.data('original-text') || addToCartText;
		$button.prop('disabled', true).text(addingText);

		var ajaxUrl = typeof wc_add_to_cart_params !== 'undefined'
			? wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'add_to_cart')
			: wfcpPublic.ajaxUrl;

		var data = {
			product_id: productId,
			purchase_type: purchaseType,
			quantity: quantity
		};

		if (variationId) {
			data.variation_id = variationId;
			$.extend(data, collectVariationAttributes());
		}

		if (purchaseType === 'installment' && months) {
			data.installment_months = months;
		}

		$.ajax({
			url: ajaxUrl,
			type: 'POST',
			data: data,
			success: function(response) {
				if (response.error && response.product_url) {
					window.location = response.product_url;
					return;
				}
				if (typeof wc_add_to_cart_params !== 'undefined') {
					$(document.body).trigger('added_to_cart', [response.fragments || {}, response.cart_hash || '', $button]);
				}
				if (typeof wfcpPublic !== 'undefined' && wfcpPublic.isIshop) {
					openIshopAddedToCartModal();
				} else {
					showMessage(response.message || 'محصول با موفقیت به سبد خرید اضافه شد', 'success');
				}
				$button.prop('disabled', false).text(originalText);
			},
			error: function(xhr) {
				var message = 'خطا در افزودن به سبد خرید';
				var body = xhr && xhr.responseText ? String(xhr.responseText) : '';
				if (xhr && (xhr.status === 403 || body.indexOf('Forbidden') !== -1)) {
					message = (typeof wfcpPublic !== 'undefined' && wfcpPublic.forbiddenMessage)
						? wfcpPublic.forbiddenMessage
						: message;
				}
				showMessage(message, 'error');
				$button.prop('disabled', false).text(originalText);
			}
		});
	}

	function showMessage(message, type) {
		type = type || 'info';
		var $message = $('<div class="wfcp-message wfcp-message-' + type + '"></div>').text(message);
		$('.wfcp-pricing-box').first().before($message);
		setTimeout(function() {
			$message.fadeOut(function() {
				$(this).remove();
			});
		}, 3000);
	}

	function openIshopAddedToCartModal() {
		var $modal = $('[data-remodal-id=product-added-to-cart-notif]');
		if (!$modal.length || typeof $.fn.remodal !== 'function') {
			showMessage('محصول با موفقیت به سبد خرید اضافه شد', 'success');
			return;
		}

		var instance = $modal.remodal();
		if (instance && typeof instance.open === 'function') {
			instance.open();
		}
	}

})(jQuery);
