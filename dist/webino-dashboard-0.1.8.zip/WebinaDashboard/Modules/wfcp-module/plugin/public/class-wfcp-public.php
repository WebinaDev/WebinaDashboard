<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package    WFCP
 * @subpackage WFCP/public
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The public-facing functionality of the plugin.
 */
class WFCP_Public {

	/**
	 * Prevent duplicate pricing box output.
	 *
	 * @var bool
	 */
	private static $pricing_box_rendered = false;

	/**
	 * @return bool
	 */
	public static function is_pricing_box_rendered() {
		return self::$pricing_box_rendered;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 */
	public function enqueue_styles() {
		if ( ! is_product() && ! $this->is_pricing_shortcode_context() ) {
			return;
		}

		wp_enqueue_style(
			'wfcp-public-style',
			WFCP_PLUGIN_URL . 'public/css/wfcp-public-style.css',
			array(),
			WFCP_VERSION,
			'all'
		);

		$style = WFCP_Helper::get_settings( 'style' );
		if ( ! is_array( $style ) ) {
			$style = array();
		}
		$box_bg     = isset( $style['box_background'] ) && $style['box_background'] ? $style['box_background'] : '#ffffff';
		$box_border = isset( $style['box_border_color'] ) && $style['box_border_color'] ? $style['box_border_color'] : '#e0e0e0';
		$btn_bg     = isset( $style['button_background'] ) && $style['button_background'] ? $style['button_background'] : '#2271b1';
		$btn_text   = isset( $style['button_text_color'] ) && $style['button_text_color'] ? $style['button_text_color'] : '#ffffff';
		$price_color = isset( $style['price_color'] ) && $style['price_color'] ? $style['price_color'] : '#2271b1';
		$radius     = isset( $style['border_radius'] ) ? absint( $style['border_radius'] ) : 8;
		$radius     = $radius <= 50 ? $radius : 8;

		$css = sprintf(
			'.wfcp-pricing-box{--wfcp-box-bg:%s;--wfcp-box-border:%s;--wfcp-box-radius:%dpx;--wfcp-btn-bg:%s;--wfcp-btn-text:%s;--wfcp-price-color:%s;}',
			esc_attr( $box_bg ),
			esc_attr( $box_border ),
			$radius,
			esc_attr( $btn_bg ),
			esc_attr( $btn_text ),
			esc_attr( $price_color )
		);
		wp_add_inline_style( 'wfcp-public-style', $css );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 */
	public function enqueue_scripts() {
		if ( ! is_product() && ! $this->is_pricing_shortcode_context() ) {
			return;
		}

		global $product;

		$deps = array( 'jquery' );
		if ( $product && is_a( $product, 'WC_Product' ) && $product->is_type( 'variable' ) ) {
			$deps[] = 'wc-add-to-cart-variation';
		}

		wp_enqueue_script(
			'wfcp-public',
			WFCP_PLUGIN_URL . 'public/js/wfcp-public.js',
			$deps,
			WFCP_VERSION,
			true
		);

		$localize = array(
			'ajaxUrl'               => admin_url( 'admin-ajax.php' ),
			'nonce'                 => wp_create_nonce( 'wfcp_public_nonce' ),
			'isVariable'            => false,
			'isIshop'               => class_exists( 'WFCP_Ishop_Theme_Compat', false ) && WFCP_Ishop_Theme_Compat::is_active(),
			'parentId'              => 0,
			'variationsPricing'     => array(),
			'selectVariationText'   => __( 'لطفاً متغیر را انتخاب کنید.', 'webina-woo-core' ),
			'installmentPerMonthText' => __( 'هر قسط %s', 'webina-woo-core' ),
			'monthsLabel'           => __( '%d ماهه', 'webina-woo-core' ),
			'forbiddenMessage'      => __( 'درخواست رد شد (403). احتمالاً WAF یا امنیت تم — با پشتیبانی هاست تماس بگیرید.', 'webina-woo-core' ),
		);

		if ( $product && is_a( $product, 'WC_Product' ) && $product->is_type( 'variable' ) ) {
			$localize['isVariable']        = true;
			$localize['parentId']          = $product->get_id();
			$localize['variationsPricing'] = WFCP_Helper::build_variation_pricing_payload( $product );
		}

		wp_localize_script( 'wfcp-public', 'wfcpPublic', $localize );
	}

	/**
	 * @return void
	 */
	public function register_shortcodes() {
		add_shortcode( 'wfcp_pricing_box', array( $this, 'render_pricing_box_shortcode' ) );
	}

	/**
	 * @return string
	 */
	public function render_pricing_box_shortcode() {
		return $this->get_pricing_box_html();
	}

	/**
	 * Hide default WooCommerce add-to-cart when this product uses WFCP pricing box.
	 */
	public function maybe_hide_default_add_to_cart() {
		if ( class_exists( 'WFCP_Ishop_Theme_Compat', false ) && WFCP_Ishop_Theme_Compat::is_active() ) {
			return;
		}

		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! WFCP_Helper::is_enabled() ) {
			return;
		}
		if ( ! WFCP_Helper::product_has_wfcp_pricing( $product ) ) {
			return;
		}

		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );

		if ( $product->is_type( 'variable' ) ) {
			remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
		}
	}

	/**
	 * Display pricing box on single product page (simple products).
	 */
	public function display_pricing_box() {
		global $product;
		if ( $product && is_a( $product, 'WC_Product' ) && $product->is_type( 'variable' ) ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Display pricing box after variation form (variable products).
	 */
	public function display_pricing_box_variable() {
		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! $product->is_type( 'variable' ) ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * ishop: render pricing box inside buy card before add-to-cart form (simple products).
	 */
	public function display_pricing_box_ishop_before() {
		global $product;
		if ( $product && is_a( $product, 'WC_Product' ) && $product->is_type( 'variable' ) ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * ishop: render pricing box after variation form, outside form.cart (variable products).
	 */
	public function display_pricing_box_ishop_after() {
		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! $product->is_type( 'variable' ) ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * ishop fallback after theme add-to-cart hook (priority 46).
	 */
	public function display_pricing_box_ishop_fallback() {
		if ( self::$pricing_box_rendered || ! is_product() ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Fallback for block themes / templates without standard hooks.
	 */
	public function display_pricing_box_fallback() {
		if ( self::$pricing_box_rendered || ! is_product() ) {
			return;
		}
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Shared pricing box renderer.
	 */
	public function render_pricing_box() {
		echo $this->get_pricing_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Build pricing box HTML; sets rendered flag only on successful output.
	 *
	 * @return string
	 */
	public function get_pricing_box_html() {
		if ( self::$pricing_box_rendered ) {
			return '';
		}

		global $product;

		if ( ! $product || ! WFCP_Helper::is_enabled() ) {
			return '';
		}

		if ( ! WFCP_Helper::product_has_wfcp_pricing( $product ) ) {
			return '';
		}

		ob_start();
		require WFCP_PLUGIN_DIR . 'public/partials/wfcp-product-display.php';
		$html = ob_get_clean();

		if ( '' === trim( $html ) ) {
			return '';
		}

		self::$pricing_box_rendered = true;

		return $html;
	}

	/**
	 * @return bool
	 */
	private function is_pricing_shortcode_context() {
		global $post;

		return is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'wfcp_pricing_box' );
	}
}
