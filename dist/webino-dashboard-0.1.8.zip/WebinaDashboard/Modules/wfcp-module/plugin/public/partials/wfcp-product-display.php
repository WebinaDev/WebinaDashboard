<?php
/**
 * Product pricing display template
 *
 * @package    WFCP
 * @subpackage WFCP/public/partials
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

global $product;

if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
	return;
}

$is_variable         = $product->is_type( 'variable' );
$parent_id           = $product->get_id();
$settings            = WFCP_Helper::get_settings();
$notifications       = $settings['notifications'] ?? array();
$credit_enabled      = (bool) WFCP_Helper::get_settings( 'credit', 'enabled' );
$wholesale_enabled   = (bool) WFCP_Helper::get_settings( 'wholesale', 'enabled' );
$installment_enabled = (bool) WFCP_Helper::get_settings( 'installment', 'enabled' );
$credit_text         = $notifications['credit_text'] ?? 'خرید اعتباری';
$installment_text    = $notifications['installment_text'] ?? 'خرید اقساطی';
$add_to_cart_label   = __( 'افزودن به سبد خرید', 'webina-woo-core' );
$tiers               = null;

if ( $is_variable ) {
	if ( ! WFCP_Helper::product_has_wfcp_pricing( $product ) ) {
		return;
	}
} else {
	$tiers = WFCP_Helper::build_pricing_tiers( $parent_id );
	if ( null === $tiers ) {
		return;
	}
}

$available_gateways = array();
if ( function_exists( 'WC' ) && WC()->payment_gateways ) {
	$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
}
$retail_gateway_ids      = isset( $settings['retail']['gateways'] ) && is_array( $settings['retail']['gateways'] ) ? $settings['retail']['gateways'] : array();
$installment_gateway_ids = isset( $settings['installment']['gateways'] ) && is_array( $settings['installment']['gateways'] ) ? $settings['installment']['gateways'] : array();
$credit_gateway_ids      = isset( $settings['credit']['gateways'] ) && is_array( $settings['credit']['gateways'] ) ? $settings['credit']['gateways'] : array();
$wholesale_gateway_ids   = isset( $settings['wholesale']['gateways'] ) && is_array( $settings['wholesale']['gateways'] ) ? $settings['wholesale']['gateways'] : array();

$show_installment = $is_variable ? $installment_enabled : ( $installment_enabled && ! empty( $tiers['installment_plans'] ) );
$show_credit      = $is_variable ? $credit_enabled : ( ! empty( $tiers['show_credit'] ) );
$show_wholesale   = $is_variable ? $wholesale_enabled : ( ! empty( $tiers['show_wholesale'] ) );

$box_classes = array( 'wfcp-pricing-box' );
if ( $is_variable ) {
	$box_classes[] = 'wfcp-pricing-box--variable';
	$box_classes[] = 'wfcp-pricing-box--awaiting-variation';
}

/**
 * Output gateways logos only (no title/description), small, for next to button.
 *
 * @param array $gateway_ids Gateway IDs.
 * @param array $available   Available gateways from WC.
 */
if ( ! function_exists( 'wfcp_render_gateways_logos_only' ) ) {
	function wfcp_render_gateways_logos_only( $gateway_ids, $available ) {
		if ( empty( $gateway_ids ) || empty( $available ) ) {
			return;
		}
		echo '<ul class="wfcp-gateways-list wfcp-gateways-list--logos-only">';
		foreach ( $gateway_ids as $gid ) {
			if ( ! isset( $available[ $gid ] ) ) {
				continue;
			}
			$gateway = $available[ $gid ];
			$icon    = $gateway->get_icon();
			if ( ! $icon ) {
				continue;
			}
			echo '<li class="wfcp-gateway-item">';
			echo '<span class="wfcp-gateway-icon">' . wp_kses_post( $icon ) . '</span>';
			echo '</li>';
		}
		echo '</ul>';
	}
}

/**
 * Quantity selector markup (reused in each row)
 */
if ( ! function_exists( 'wfcp_quantity_markup' ) ) {
	function wfcp_quantity_markup() {
		?>
		<div class="wfcp-quantity-wrap">
			<button type="button" class="wfcp-qty-minus" aria-label="<?php esc_attr_e( 'کم کردن', 'webina-woo-core' ); ?>">−</button>
			<input type="number" class="wfcp-qty-input" value="1" min="1" step="1" aria-label="<?php esc_attr_e( 'تعداد', 'webina-woo-core' ); ?>">
			<button type="button" class="wfcp-qty-plus" aria-label="<?php esc_attr_e( 'افزودن', 'webina-woo-core' ); ?>">+</button>
		</div>
		<?php
	}
}
?>

<div class="<?php echo esc_attr( implode( ' ', $box_classes ) ); ?>" data-product-id="<?php echo esc_attr( $parent_id ); ?>" data-is-variable="<?php echo $is_variable ? '1' : '0'; ?>">
	<?php if ( $is_variable ) : ?>
		<p class="wfcp-variation-notice"><?php esc_html_e( 'لطفاً متغیر را انتخاب کنید.', 'webina-woo-core' ); ?></p>
	<?php endif; ?>

	<div class="wfcp-pricing-row cash">
		<div class="wfcp-pricing-info">
			<div class="wfcp-pricing-icon">💵</div>
			<div class="wfcp-pricing-details">
				<h3 class="wfcp-pricing-title"><?php esc_html_e( 'خرید نقدی', 'webina-woo-core' ); ?></h3>
				<p class="wfcp-pricing-amount">
					<span class="wfcp-pricing-amount-value">
						<?php
						if ( ! $is_variable && ! empty( $tiers['retail_formatted'] ) ) {
							echo wp_kses_post( $tiers['retail_formatted'] );
						} else {
							echo '—';
						}
						?>
					</span>
				</p>
				<?php if ( ! empty( $notifications['cash_description'] ) ) : ?>
					<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['cash_description'] ); ?></div>
				<?php endif; ?>
				<?php wfcp_render_gateways_logos_only( $retail_gateway_ids, $available_gateways ); ?>
			</div>
		</div>
		<div class="wfcp-pricing-action">
			<?php wfcp_render_gateways_logos_only( $retail_gateway_ids, $available_gateways ); ?>
			<?php wfcp_quantity_markup(); ?>
			<button type="button" class="wfcp-btn-add wfcp-btn-add-cash" data-product-id="<?php echo esc_attr( $parent_id ); ?>" data-variation-id="" data-purchase-type="cash" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>" <?php echo $is_variable ? 'disabled' : ''; ?>><?php echo esc_html( $add_to_cart_label ); ?></button>
		</div>
	</div>

	<?php if ( $show_installment ) : ?>
		<div class="wfcp-pricing-row installment<?php echo $is_variable ? ' wfcp-row-hidden' : ''; ?>">
			<div class="wfcp-pricing-info">
				<div class="wfcp-pricing-icon">📅</div>
				<div class="wfcp-pricing-details">
					<h3 class="wfcp-pricing-title"><?php echo esc_html( $installment_text ); ?></h3>
					<div class="wfcp-installment-plans-list">
						<?php if ( ! $is_variable && ! empty( $tiers['installment_plans'] ) ) : ?>
							<?php foreach ( $tiers['installment_plans'] as $index => $plan ) : ?>
								<div class="wfcp-installment-plan-item <?php echo 0 === $index ? 'active' : ''; ?>" data-months="<?php echo esc_attr( $plan['months'] ); ?>">
									<span class="wfcp-installment-plan-months"><?php printf( esc_html__( '%d ماهه', 'webina-woo-core' ), $plan['months'] ); ?></span>
									<span class="wfcp-installment-plan-price"><?php printf( esc_html__( 'هر قسط %s', 'webina-woo-core' ), wp_kses_post( $plan['monthly_formatted'] ) ); ?></span>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>
					<?php if ( ! empty( $notifications['installment_description'] ) ) : ?>
						<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['installment_description'] ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $installment_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<?php
				$first_plan_months = ( ! $is_variable && ! empty( $tiers['installment_plans'] ) ) ? (int) $tiers['installment_plans'][0]['months'] : 0;
				?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-installment" data-product-id="<?php echo esc_attr( $parent_id ); ?>" data-variation-id="" data-purchase-type="installment" data-months="<?php echo esc_attr( $first_plan_months ); ?>" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>" <?php echo $is_variable ? 'disabled' : ''; ?>><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $show_credit ) : ?>
		<div class="wfcp-pricing-row credit<?php echo $is_variable ? ' wfcp-row-hidden' : ''; ?>">
			<div class="wfcp-pricing-info">
				<div class="wfcp-pricing-icon">💳</div>
				<div class="wfcp-pricing-details">
					<h3 class="wfcp-pricing-title"><?php echo esc_html( $credit_text ); ?></h3>
					<p class="wfcp-pricing-amount">
						<span class="wfcp-pricing-amount-value">
							<?php
							if ( ! $is_variable && ! empty( $tiers['credit_formatted'] ) ) {
								echo wp_kses_post( $tiers['credit_formatted'] );
							} else {
								echo '—';
							}
							?>
						</span>
					</p>
					<?php if ( ! empty( $notifications['credit_description'] ) ) : ?>
						<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['credit_description'] ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $credit_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-credit" data-product-id="<?php echo esc_attr( $parent_id ); ?>" data-variation-id="" data-purchase-type="credit" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>" <?php echo $is_variable ? 'disabled' : ''; ?>><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $show_wholesale ) : ?>
		<div class="wfcp-pricing-row wholesale<?php echo $is_variable ? ' wfcp-row-hidden' : ''; ?>">
			<div class="wfcp-pricing-info">
				<div class="wfcp-pricing-icon">📦</div>
				<div class="wfcp-pricing-details">
					<h3 class="wfcp-pricing-title"><?php esc_html_e( 'خرید عمده', 'webina-woo-core' ); ?></h3>
					<p class="wfcp-pricing-amount">
						<span class="wfcp-pricing-amount-value">
							<?php
							if ( ! $is_variable && ! empty( $tiers['wholesale_formatted'] ) ) {
								echo wp_kses_post( $tiers['wholesale_formatted'] );
							} else {
								echo '—';
							}
							?>
						</span>
					</p>
					<?php if ( ! empty( $notifications['wholesale_description'] ) ) : ?>
						<div class="wfcp-pricing-description"><?php echo wp_kses_post( $notifications['wholesale_description'] ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="wfcp-pricing-action">
				<?php wfcp_render_gateways_logos_only( $wholesale_gateway_ids, $available_gateways ); ?>
				<?php wfcp_quantity_markup(); ?>
				<button type="button" class="wfcp-btn-add wfcp-btn-add-wholesale" data-product-id="<?php echo esc_attr( $parent_id ); ?>" data-variation-id="" data-purchase-type="wholesale" data-original-text="<?php echo esc_attr( $add_to_cart_label ); ?>" <?php echo $is_variable ? 'disabled' : ''; ?>><?php echo esc_html( $add_to_cart_label ); ?></button>
			</div>
		</div>
	<?php endif; ?>
</div>
