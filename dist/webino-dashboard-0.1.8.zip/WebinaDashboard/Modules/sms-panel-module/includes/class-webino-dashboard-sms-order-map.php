<?php
/**
 * WooCommerce order status → SMS event_key mapping.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maps WC statuses and custom hooks to CRM event keys.
 */
final class Webino_Dashboard_Sms_Order_Map {

	/**
	 * @return array<string,string> WC status slug => event_key (on status change).
	 */
	public static function status_to_event() {
		return array(
			'pending'    => 'pending_on_status',
			'processing' => 'processing',
			'on-hold'    => 'on-hold',
			'completed'  => 'completed',
			'cancelled'  => 'cancelled',
			'refunded'   => 'refunded',
			'failed'     => 'failed',
			'draft'      => 'checkout-draft',
		);
	}

	/**
	 * Custom statuses used by Webina shops (slug may vary; filterable).
	 *
	 * @return array<string,string>
	 */
	public static function custom_status_to_event() {
		$map = array(
			'sent-to-warehouse' => 'sent-to-warehouse',
			'packaged'          => 'packaged',
			'courier'           => 'courier',
			'post'              => 'post',
			'tipax'             => 'tipax',
			'wc-sent-to-warehouse' => 'sent-to-warehouse',
			'wc-packaged'       => 'packaged',
			'wc-courier'        => 'courier',
			'wc-post'           => 'post',
			'wc-tipax'          => 'tipax',
		);
		return apply_filters( 'webino_dashboard_sms_custom_status_map', $map );
	}

	/**
	 * @param string $status Order status slug.
	 * @return string|null Event key or null if not mapped.
	 */
	public static function event_for_status( $status ) {
		$status = sanitize_key( (string) $status );
		$all    = array_merge( self::status_to_event(), self::custom_status_to_event() );
		return $all[ $status ] ?? null;
	}

	/**
	 * @return array<int,string> All known event keys.
	 */
	public static function all_event_keys() {
		return array(
			'pending_on_create',
			'pending_on_status',
			'processing',
			'sent-to-warehouse',
			'packaged',
			'courier',
			'post',
			'tipax',
			'on-hold',
			'completed',
			'cancelled',
			'refunded',
			'failed',
			'checkout-draft',
			'post-barcode',
			'stock-low',
			'stock-out',
		);
	}
}
