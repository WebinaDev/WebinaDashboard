<?php
/**
 * ModirPayamak REST proxy to WebinoCRM.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers webino-dashboard/v1/modirpayamak/* routes.
 */
final class Webino_Dashboard_REST_ModirPayamak {

	const NS = 'webino-dashboard/v1';

	/** GET proxy cache lifetime (seconds). */
	const CACHE_TTL = 90;

	/** Fast CRM options for dashboard reads. */
	const CRM_FAST_OPTS = array(
		'timeout'  => 3,
		'wall_cap' => 5,
	);

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		$routes = array(
			array( 'GET', '/modirpayamak/dashboard', 'dashboard' ),
			array( 'GET', '/modirpayamak/account', 'account' ),
			array( 'GET', '/modirpayamak/packages', 'packages' ),
			array( 'POST', '/modirpayamak/topup/init', 'topup_init' ),
			array( 'POST', '/modirpayamak/topup/verify', 'topup_verify' ),
			array( 'POST', '/modirpayamak/send', 'send' ),
			array( 'POST', '/modirpayamak/send/peer-to-peer', 'send_p2p' ),
			array( 'POST', '/modirpayamak/send/calculate-price', 'calculate_price' ),
			array( 'POST', '/modirpayamak/send/cancel-scheduled', 'cancel_scheduled' ),
			array( 'GET', '/modirpayamak/reports/messages', 'reports_messages' ),
			array( 'GET', '/modirpayamak/reports/inbox', 'reports_inbox' ),
			array( 'GET', '/modirpayamak/reports/outbox', 'reports_outbox' ),
			array( 'GET', '/modirpayamak/patterns', 'patterns' ),
			array( 'GET', '/modirpayamak/patterns/registry', 'patterns_registry' ),
			array( 'POST', '/modirpayamak/patterns/sync', 'patterns_sync' ),
			array( 'GET', '/modirpayamak/numbers', 'numbers' ),
			array( 'GET', '/modirpayamak/phonebooks', 'phonebooks' ),
			array( 'POST', '/modirpayamak/phonebooks', 'create_phonebook' ),
			array( 'GET', '/modirpayamak/phonebooks/edge', 'phonebooks_edge' ),
			array( 'POST', '/modirpayamak/phonebooks/edge', 'create_phonebook_edge' ),
			array( 'GET', '/modirpayamak/settings/site', 'settings_site_get' ),
			array( 'POST', '/modirpayamak/settings/site', 'settings_site_post' ),
			array( 'GET', '/modirpayamak/settings/shop', 'settings_shop_get' ),
			array( 'POST', '/modirpayamak/settings/shop', 'settings_shop_post' ),
			array( 'GET', '/modirpayamak/templates', 'templates_get' ),
			array( 'POST', '/modirpayamak/templates', 'templates_post' ),
			array( 'GET', '/modirpayamak/templates/shortcodes', 'templates_shortcodes' ),
			array( 'POST', '/modirpayamak/orders/notify', 'orders_notify' ),
			array( 'POST', '/modirpayamak/auth/send-otp', 'auth_send_otp' ),
			array( 'POST', '/modirpayamak/auth/verify-otp', 'auth_verify_otp' ),
			array( 'POST', '/modirpayamak/newsletter/subscribe', 'newsletter_subscribe' ),
			array( 'GET', '/modirpayamak/newsletter/subscribers', 'newsletter_subscribers' ),
			array( 'POST', '/modirpayamak/newsletter/send', 'newsletter_send' ),
			array( 'GET', '/modirpayamak/drafts', 'drafts' ),
			array( 'GET', '/modirpayamak/tickets', 'tickets' ),
		);

		foreach ( $routes as $r ) {
			register_rest_route(
				self::NS,
				$r[1],
				array(
					'methods'             => $r[0],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => array( __CLASS__, 'perm_manage' ),
				)
			);
		}
	}

	/**
	 * @return bool
	 */
	public static function perm_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_options' );
	}

	/**
	 * @param string              $path CRM path.
	 * @param array<string,mixed> $body Body.
	 * @return WP_REST_Response|WP_Error
	 */
	/**
	 * @param string $message Error message.
	 * @return WP_REST_Response
	 */
	private static function crm_unavailable_response( $message ) {
		return new WP_REST_Response(
			array(
				'ok'          => false,
				'unavailable' => true,
				'message'     => $message,
			),
			200
		);
	}

	/**
	 * @param string              $path CRM path.
	 * @param array<string,mixed> $body Body.
	 * @return WP_REST_Response
	 */
	private static function crm_post( $path, array $body = array() ) {
		$license = Webino_Dashboard_License::instance();
		$res     = $license->crm_post( 'wp-json/webinocrm/v1/' . ltrim( $path, '/' ), $body );
		if ( empty( $res['ok'] ) ) {
			$msg = is_array( $res['data'] ?? null ) && ! empty( $res['data']['message'] )
				? (string) $res['data']['message']
				: ( $res['error'] ?? __( 'CRM request failed.', 'webino-dashboard' ) );
			return self::crm_unavailable_response( $msg );
		}
		return new WP_REST_Response( is_array( $res['data'] ) ? $res['data'] : array( 'ok' => true ), 200 );
	}

	/**
	 * @param string              $path CRM path.
	 * @param array<string,mixed> $query Query.
	 * @return WP_REST_Response
	 */
	/**
	 * @param string $cache_slug Cache key slug.
	 * @return string
	 */
	private static function cache_transient_key( $cache_slug ) {
		$domain = Webino_Dashboard_License::instance()->get_current_domain();
		return 'webino_mp_' . md5( $cache_slug . '|' . $domain );
	}

	/**
	 * @param string              $cache_slug Cache slug.
	 * @param string              $path       CRM path under modirpayamak/.
	 * @param array<string,mixed> $query      Query args.
	 * @return WP_REST_Response
	 */
	private static function crm_get_cached( $cache_slug, $path, array $query = array() ) {
		$key    = self::cache_transient_key( $cache_slug );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return new WP_REST_Response( $cached, 200 );
		}

		$response = self::crm_get( $path, $query );
		if ( $response instanceof WP_REST_Response ) {
			$data = $response->get_data();
			if ( is_array( $data ) && empty( $data['unavailable'] ) ) {
				set_transient( $key, $data, self::CACHE_TTL );
			}
		}
		return $response;
	}

	/**
	 * @param string              $path CRM path.
	 * @param array<string,mixed> $query Query.
	 * @return WP_REST_Response
	 */
	private static function crm_get( $path, array $query = array() ) {
		$license = Webino_Dashboard_License::instance();
		$res     = $license->crm_get( 'wp-json/webinocrm/v1/' . ltrim( $path, '/' ), $query, self::CRM_FAST_OPTS );
		if ( empty( $res['ok'] ) ) {
			$msg = $res['error'] ?? __( 'CRM request failed.', 'webino-dashboard' );
			return self::crm_unavailable_response( $msg );
		}
		return new WP_REST_Response( is_array( $res['data'] ) ? $res['data'] : array( 'ok' => true ), 200 );
	}

	/**
	 * Combined account + recent messages (single client round-trip).
	 *
	 * @return WP_REST_Response
	 */
	public static function dashboard() {
		$key    = self::cache_transient_key( 'dashboard' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return new WP_REST_Response( $cached, 200 );
		}

		$license = Webino_Dashboard_License::instance();
		$opts    = self::CRM_FAST_OPTS;

		$account_res = $license->crm_get( 'wp-json/webinocrm/v1/modirpayamak/account', array(), $opts );
		if ( empty( $account_res['ok'] ) ) {
			$msg = $account_res['error'] ?? __( 'CRM request failed.', 'webino-dashboard' );
			return self::crm_unavailable_response( $msg );
		}

		$account_data = is_array( $account_res['data'] ) ? $account_res['data'] : array();
		$messages_res = $license->crm_get(
			'wp-json/webinocrm/v1/modirpayamak/reports/messages',
			array(
				'page'  => 1,
				'limit' => 10,
			),
			$opts
		);
		$messages_data = ! empty( $messages_res['ok'] ) && is_array( $messages_res['data'] ) ? $messages_res['data'] : array();

		$payload = array_merge(
			$account_data,
			array(
				'ok'       => true,
				'messages' => isset( $messages_data['messages'] ) && is_array( $messages_data['messages'] )
					? $messages_data['messages']
					: array(),
			)
		);
		set_transient( $key, $payload, self::CACHE_TTL );

		return new WP_REST_Response( $payload, 200 );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function account() {
		return self::crm_get_cached( 'account', 'modirpayamak/account' );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function packages() {
		return self::crm_get_cached( 'packages', 'modirpayamak/packages' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function topup_init( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}
		if ( empty( $body['callback_url'] ) ) {
			$body['callback_url'] = home_url( '/dashboard/marketing/sms/payment-callback' );
		}
		return self::crm_post( 'modirpayamak/topup/init', $body );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function topup_verify( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/topup/verify', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function send( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/send', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function send_p2p( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/send/peer-to-peer', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function calculate_price( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/send/calculate-price', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function reports_messages( WP_REST_Request $request ) {
		$page  = max( 1, (int) $request->get_param( 'page' ) );
		$limit = min( 50, max( 1, (int) $request->get_param( 'limit' ) ) );
		$query = array(
			'page'  => $page,
			'limit' => $limit,
		);
		if ( 1 === $page && $limit <= 20 ) {
			return self::crm_get_cached( 'reports_messages_p1', 'modirpayamak/reports/messages', $query );
		}
		return self::crm_get( 'modirpayamak/reports/messages', $query );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function patterns( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/patterns',
			array(
				'page'     => max( 1, (int) $request->get_param( 'page' ) ),
				'per_page' => min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) ),
			)
		);
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function numbers() {
		return self::crm_get( 'modirpayamak/numbers' );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function phonebooks() {
		return self::crm_get( 'modirpayamak/phonebooks' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_phonebook( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/phonebooks', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function list_contacts( WP_REST_Request $request ) {
		$id = (int) $request['id'];
		return self::crm_get( 'modirpayamak/phonebooks/' . $id . '/contacts' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_contact( WP_REST_Request $request ) {
		$id   = (int) $request['id'];
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/phonebooks/' . $id . '/contacts', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function cancel_scheduled( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/send/cancel-scheduled', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function reports_inbox( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/reports/inbox',
			array(
				'page'  => max( 1, (int) $request->get_param( 'page' ) ),
				'limit' => min( 50, max( 1, (int) $request->get_param( 'limit' ) ) ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function reports_outbox( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/reports/outbox',
			array(
				'page'  => max( 1, (int) $request->get_param( 'page' ) ),
				'limit' => min( 50, max( 1, (int) $request->get_param( 'limit' ) ) ),
			)
		);
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function patterns_registry() {
		return self::crm_get( 'modirpayamak/patterns/registry' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function patterns_sync( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/patterns/sync', is_array( $body ) ? $body : array() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function phonebooks_edge() {
		return self::crm_get( 'modirpayamak/phonebooks/edge' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_phonebook_edge( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/phonebooks/edge', is_array( $body ) ? $body : array() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_site_get() {
		return self::crm_get( 'modirpayamak/settings/site' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_site_post( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/settings/site', is_array( $body ) ? $body : array() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_shop_get() {
		return self::crm_get( 'modirpayamak/settings/shop' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function settings_shop_post( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/settings/shop', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function templates_get( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/templates',
			array_filter(
				array(
					'scope'     => $request->get_param( 'scope' ),
					'event_key' => $request->get_param( 'event_key' ),
				)
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function templates_post( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/templates', is_array( $body ) ? $body : array() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public static function templates_shortcodes() {
		return self::crm_get( 'modirpayamak/templates/shortcodes' );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function orders_notify( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/orders/notify', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function auth_send_otp( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/auth/send-otp', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function auth_verify_otp( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/auth/verify-otp', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function newsletter_subscribe( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/newsletter/subscribe', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function newsletter_subscribers( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/newsletter/subscribers',
			array(
				'product_id' => (int) $request->get_param( 'product_id' ),
				'page'       => max( 1, (int) $request->get_param( 'page' ) ),
				'limit'      => min( 100, max( 1, (int) $request->get_param( 'limit' ) ) ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function newsletter_send( WP_REST_Request $request ) {
		$body = $request->get_json_params();
		return self::crm_post( 'modirpayamak/newsletter/send', is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function drafts( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/drafts',
			array(
				'page'     => max( 1, (int) $request->get_param( 'page' ) ),
				'per_page' => min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function tickets( WP_REST_Request $request ) {
		return self::crm_get(
			'modirpayamak/tickets',
			array(
				'page'     => max( 1, (int) $request->get_param( 'page' ) ),
				'per_page' => min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) ),
			)
		);
	}
}
