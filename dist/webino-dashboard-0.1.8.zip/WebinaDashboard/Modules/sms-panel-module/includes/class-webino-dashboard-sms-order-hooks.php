<?php
/**
 * WooCommerce hooks → CRM order SMS notify.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Forwards order events to webinocrm/v1/modirpayamak/orders/notify.
 */
final class Webino_Dashboard_Sms_Order_Hooks {

	/**
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'on_checkout_processed' ), 20, 1 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status_changed' ), 20, 4 );
		add_action( 'webino_dashboard_order_post_barcode_saved', array( __CLASS__, 'on_post_barcode' ), 10, 2 );
		add_action( 'woocommerce_low_stock', array( __CLASS__, 'on_wc_low_stock' ), 10, 1 );
		add_action( 'woocommerce_no_stock', array( __CLASS__, 'on_wc_no_stock' ), 10, 1 );
		add_action( 'webino_dashboard_product_stock_low', array( __CLASS__, 'on_stock_low' ), 10, 2 );
		add_action( 'webino_dashboard_product_stock_out', array( __CLASS__, 'on_stock_out' ), 10, 2 );
	}

	/**
	 * WooCommerce: product reached low stock threshold.
	 *
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public static function on_wc_low_stock( $product ) {
		$resolved = self::resolve_wc_product( $product );
		if ( ! $resolved ) {
			return;
		}
		self::notify_stock_event( 'stock-low', $resolved['id'], $resolved['qty'] );
	}

	/**
	 * WooCommerce: product is out of stock.
	 *
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public static function on_wc_no_stock( $product ) {
		$resolved = self::resolve_wc_product( $product );
		if ( ! $resolved ) {
			return;
		}
		self::notify_stock_event( 'stock-out', $resolved['id'], $resolved['qty'] );
	}

	/**
	 * @param WC_Product|int $product Product or id.
	 * @return array{id:int,qty:float|null}|null
	 */
	private static function resolve_wc_product( $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( (int) $product );
		}
		if ( ! $product instanceof WC_Product ) {
			return null;
		}
		$id = (int) $product->get_id();
		if ( $product->is_type( 'variation' ) ) {
			$id = (int) $product->get_parent_id();
			if ( $id < 1 ) {
				$id = (int) $product->get_id();
			}
		}
		$qty = $product->managing_stock() ? (float) $product->get_stock_quantity() : null;
		return array(
			'id'  => $id,
			'qty' => $qty,
		);
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function on_checkout_processed( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$status = $order->get_status();
		if ( 'pending' === $status ) {
			self::notify( 'pending_on_create', $order );
		}
	}

	/**
	 * @param int    $order_id Order id.
	 * @param string $from From status.
	 * @param string $to To status.
	 * @param object $order Order object.
	 * @return void
	 */
	public static function on_status_changed( $order_id, $from, $to, $order ) {
		unset( $from );
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return;
		}
		$event = Webino_Dashboard_Sms_Order_Map::event_for_status( $to );
		if ( null === $event ) {
			return;
		}
		if ( 'pending_on_status' === $event && 'pending' !== $to ) {
			// only pending uses pending_on_status when not on-create
		}
		self::notify( $event, $order );
	}

	/**
	 * @param int    $order_id Order id.
	 * @param string $barcode Barcode.
	 * @return void
	 */
	public static function on_post_barcode( $order_id, $barcode ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$snapshot = self::build_snapshot( $order );
		$snapshot['barcode'] = (string) $barcode;
		self::notify_snapshot( 'post-barcode', $snapshot );
	}

	/**
	 * @param int $product_id Product id.
	 * @param int $qty Quantity.
	 * @return void
	 */
	public static function on_stock_low( $product_id, $qty ) {
		self::notify_stock_event( 'stock-low', (int) $product_id, $qty );
	}

	/**
	 * @param int       $product_id Product id (WooCommerce product id when linked).
	 * @param int|float $qty Quantity.
	 * @return void
	 */
	public static function on_stock_out( $product_id, $qty ) {
		self::notify_stock_event( 'stock-out', (int) $product_id, $qty );
	}

	/**
	 * @param string  $event_key Event.
	 * @param WC_Order $order Order.
	 * @return void
	 */
	private static function notify( $event_key, $order ) {
		self::notify_snapshot( $event_key, self::build_snapshot( $order ) );
	}

	/**
	 * @param string              $event_key Event.
	 * @param array<string,mixed> $snapshot Snapshot.
	 * @return void
	 */
	private static function notify_snapshot( $event_key, array $snapshot ) {
		$order_id = (int) ( $snapshot['id'] ?? 0 );
		if ( $order_id <= 0 && 'stock-low' !== $event_key && 'stock-out' !== $event_key ) {
			return;
		}
		$product_id = (int) ( $snapshot['product_id'] ?? 0 );
		if ( $product_id > 0 && in_array( $event_key, array( 'stock-low', 'stock-out' ), true ) ) {
			$dedupe_key = 'webino_sms_' . $event_key . '_p' . $product_id . '_q' . (string) ( $snapshot['stock_quantity'] ?? '' );
		} else {
			$dedupe_key = 'webino_sms_' . $event_key . '_' . $order_id . '_' . ( $snapshot['status'] ?? '' ) . '_' . ( $snapshot['barcode'] ?? '' );
		}
		if ( get_transient( $dedupe_key ) ) {
			return;
		}
		set_transient( $dedupe_key, 1, 60 );

		$license = Webino_Dashboard_License::instance();
		if ( ! $license->is_license_active() ) {
			return;
		}
		$license->crm_post(
			'wp-json/webinocrm/v1/modirpayamak/orders/notify',
			array(
				'event_key' => $event_key,
				'order'     => $snapshot,
			)
		);
	}

	/**
	 * @param string $event_key Event.
	 * @param int    $product_id Product id.
	 * @return void
	 */
	/**
	 * @param string       $event_key Event key.
	 * @param int          $product_id WC product id.
	 * @param int|float|null $qty Stock qty if known.
	 * @return void
	 */
	public static function notify_stock_event( $event_key, $product_id, $qty = null ) {
		self::notify_snapshot( $event_key, self::build_stock_snapshot( $product_id, $qty ) );
	}

	/**
	 * @param int          $product_id Product id.
	 * @param int|float|null $qty Quantity.
	 * @return array<string,mixed>
	 */
	public static function build_stock_snapshot( $product_id, $qty = null ) {
		$product_id = (int) $product_id;
		$name       = '';
		$url        = '';
		$stock_qty  = $qty;
		$low_amount = '';

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( $product instanceof WC_Product ) {
			$name = $product->get_name();
			$url  = (string) get_permalink( $product_id );
			if ( null === $stock_qty && $product->managing_stock() ) {
				$stock_qty = (float) $product->get_stock_quantity();
			}
			$low = $product->get_low_stock_amount();
			if ( null !== $low && '' !== $low ) {
				$low_amount = (string) $low;
			}
		}

		return array(
			'id'               => 0,
			'product_id'       => $product_id,
			'product_name'     => $name ?: (string) $product_id,
			'product_url'      => $url,
			'stock_quantity'   => null !== $stock_qty ? (string) $stock_qty : '',
			'qty'              => null !== $stock_qty ? (string) $stock_qty : '',
			'low_stock_amount' => $low_amount,
			'site_name'        => get_bloginfo( 'name' ),
			'site_url'         => home_url(),
		);
	}

	/**
	 * @param WC_Order $order Order.
	 * @return array<string,mixed>
	 */
	public static function build_snapshot( $order ) {
		$status = $order->get_status();
		$phone  = $order->get_billing_phone();
		if ( '' === $phone ) {
			$phone = (string) get_user_meta( $order->get_customer_id(), 'billing_phone', true );
		}
		$tracking = (string) $order->get_meta( '_tracking_code' );
		if ( '' === $tracking ) {
			$tracking = (string) $order->get_meta( 'tracking_code' );
		}
		$barcode = (string) $order->get_meta( '_post_barcode' );
		if ( '' === $barcode ) {
			$barcode = (string) $order->get_meta( 'post_barcode' );
		}
		$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		$label    = $statuses[ 'wc-' . $status ] ?? $status;

		return array(
			'id'              => $order->get_id(),
			'number'          => $order->get_order_number(),
			'customer_name'   => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'customer_phone'  => $phone,
			'total'           => $order->get_formatted_order_total(),
			'status'          => $status,
			'status_label'    => $label,
			'tracking'        => $tracking,
			'barcode'         => $barcode,
			'site_name'       => get_bloginfo( 'name' ),
			'site_url'        => home_url(),
		);
	}
}
