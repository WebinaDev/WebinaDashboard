import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation } from 'react-router-dom'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type DigikalaSettings = {
  base_url: string
  client_code: string
  client_secret?: string
  has_client_secret?: boolean
  authorization_code: string
  webhook_secret: string
  auto_sync: boolean
  webhook_url?: string
}

type DigikalaRow = Record<string, unknown>
type DigikalaHealth = {
  status: string
  auth_ok: boolean
  queue_pending: number
  queue_running: number
  errors_24h: number
  checked_at: string
}
type EndpointCoverageSummary = {
  implemented: number
  queued: number
  pending: number
  total: number
}
type EndpointCoverageItem = {
  method: string
  path: string
  status: 'implemented' | 'queued' | 'pending'
  source?: string
  sources?: string[]
  job_types?: string[]
  dispatchers?: string[]
  confidence?: 'high' | 'medium' | 'low'
}
type EndpointCoverageMeta = {
  generated_at?: string
  source_scan_count?: number
  dispatcher_scan_count?: number
  parse_duration_ms?: number
  partial?: boolean
  parse_errors?: string[]
  total?: number
}

export default function DigikalaSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const location = useLocation()
  const isSync = location.pathname.endsWith('/sync')
  const isJobs = location.pathname.endsWith('/jobs')

  const settingsQ = useQuery({
    queryKey: ['digikala', 'settings'],
    queryFn: () => apiFetch<{ settings: DigikalaSettings }>('digikala/settings'),
  })

  const [draft, setDraft] = useState<DigikalaSettings | null>(null)
  const settings = useMemo(() => {
    if (!settingsQ.data?.settings) return draft
    if (!draft) setDraft(settingsQ.data.settings)
    return draft ?? settingsQ.data.settings
  }, [settingsQ.data?.settings, draft])

  const jobsQ = useQuery({
    queryKey: ['digikala', 'jobs'],
    queryFn: () => apiFetch<{ items: DigikalaRow[] }>('digikala/jobs'),
    enabled: isJobs,
    refetchInterval: 5000,
  })

  const logsQ = useQuery({
    queryKey: ['digikala', 'logs'],
    queryFn: () => apiFetch<{ items: DigikalaRow[] }>('digikala/logs'),
    enabled: isJobs,
    refetchInterval: 5000,
  })
  const healthQ = useQuery({
    queryKey: ['digikala', 'health'],
    queryFn: () => apiFetch<DigikalaHealth>('digikala/health'),
    enabled: isJobs,
    refetchInterval: 10000,
  })
  const alertsQ = useQuery({
    queryKey: ['digikala', 'alerts'],
    queryFn: () => apiFetch<{ status: string; items: DigikalaRow[] }>('digikala/alerts'),
    enabled: isJobs,
    refetchInterval: 10000,
  })
  const matrixQ = useQuery({
    queryKey: ['digikala', 'webhook-matrix'],
    queryFn: () => apiFetch<{ items: Record<string, unknown> }>('digikala/webhook-matrix'),
    enabled: isJobs,
  })
  const [coverageStatusFilter, setCoverageStatusFilter] = useState<'all' | 'implemented' | 'queued' | 'pending'>('all')
  const [coverageJobTypeFilter, setCoverageJobTypeFilter] = useState('')
  const [coverageDispatcherFilter, setCoverageDispatcherFilter] = useState('')
  const endpointCoverageQ = useQuery({
    queryKey: ['digikala', 'endpoint-coverage', coverageStatusFilter, coverageJobTypeFilter, coverageDispatcherFilter],
    queryFn: () =>
      apiFetch<{ summary: EndpointCoverageSummary; items: EndpointCoverageItem[]; meta: EndpointCoverageMeta }>(
        `digikala/coverage/endpoints?include_pending=true&per_page=400${
          coverageStatusFilter !== 'all' ? `&status=${encodeURIComponent(coverageStatusFilter)}` : ''
        }${coverageJobTypeFilter ? `&job_type=${encodeURIComponent(coverageJobTypeFilter)}` : ''}${
          coverageDispatcherFilter ? `&dispatcher=${encodeURIComponent(coverageDispatcherFilter)}` : ''
        }`,
      ),
    enabled: isJobs,
  })

  const save = useMutation({
    mutationFn: () =>
      apiFetch<{ settings: DigikalaSettings }>('digikala/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      }),
    onSuccess: async () => {
      toast.success(t('common.saved'))
      await qc.invalidateQueries({ queryKey: ['digikala', 'settings'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const test = useMutation({
    mutationFn: () => apiFetch('digikala/test-connection', { method: 'POST' }),
    onSuccess: () => toast.success(t('digikala.testOk')),
    onError: (e: Error) => toastApiError(t, e),
  })

  const enqueue = useMutation({
    mutationFn: (path: string) => apiFetch(path, { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('digikala.jobQueued'))
      await qc.invalidateQueries({ queryKey: ['digikala', 'jobs'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })
  const reconcile = useMutation({
    mutationFn: (type: 'all' | 'products' | 'orders' | 'inventory') =>
      apiFetch('digikala/reconcile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      }),
    onSuccess: () => toast.success(t('digikala.reconcileQueued')),
    onError: (e: Error) => toastApiError(t, e),
  })

  if (isJobs) {
    return (
      <PageShell title={t('digikala.jobsTitle')} subtitle={t('digikala.jobsSubtitle')}>
        <section className="space-y-3 rounded-lg border border-border p-4">
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => reconcile.mutate('all')}>
              {t('digikala.reconcileAll')}
            </Button>
            <Button variant="outline" onClick={() => reconcile.mutate('products')}>
              {t('digikala.reconcileProducts')}
            </Button>
            <Button variant="outline" onClick={() => reconcile.mutate('orders')}>
              {t('digikala.reconcileOrders')}
            </Button>
            <Button variant="outline" onClick={() => reconcile.mutate('inventory')}>
              {t('digikala.reconcileInventory')}
            </Button>
          </div>
          <h3 className="font-medium">{t('digikala.healthTitle')}</h3>
          <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(healthQ.data ?? {}, null, 2)}
          </pre>
          <h3 className="font-medium">{t('digikala.alertsTitle')}</h3>
          <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(alertsQ.data?.items ?? [], null, 2)}
          </pre>
          <h3 className="font-medium">{t('digikala.webhookMatrixTitle')}</h3>
          <pre className="bg-muted max-h-48 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(matrixQ.data?.items ?? {}, null, 2)}
          </pre>
          <h3 className="font-medium">{t('digikala.endpointCoverageTitle')}</h3>
          <div className="grid gap-2 md:grid-cols-3">
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={coverageStatusFilter}
              onChange={(e) =>
                setCoverageStatusFilter((e.target.value as 'all' | 'implemented' | 'queued' | 'pending') || 'all')
              }
            >
              <option value="all">{t('digikala.endpointFilterStatusAll')}</option>
              <option value="implemented">{t('digikala.endpointFilterStatusImplemented')}</option>
              <option value="queued">{t('digikala.endpointFilterStatusQueued')}</option>
              <option value="pending">{t('digikala.endpointFilterStatusPending')}</option>
            </select>
            <Input
              placeholder={t('digikala.endpointFilterJobType')}
              value={coverageJobTypeFilter}
              onChange={(e) => setCoverageJobTypeFilter(e.target.value)}
            />
            <Input
              placeholder={t('digikala.endpointFilterDispatcher')}
              value={coverageDispatcherFilter}
              onChange={(e) => setCoverageDispatcherFilter(e.target.value)}
            />
          </div>
          <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(endpointCoverageQ.data?.summary ?? {}, null, 2)}
          </pre>
          <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(endpointCoverageQ.data?.meta ?? {}, null, 2)}
          </pre>
          <div className="overflow-auto rounded-md border">
            <table className="w-full text-xs">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointMethod')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointPath')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointStatus')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointSource')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointSources')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointJobTypes')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointDispatchers')}</th>
                  <th className="px-2 py-2 text-start">{t('digikala.endpointConfidence')}</th>
                </tr>
              </thead>
              <tbody>
                {(endpointCoverageQ.data?.items ?? []).slice(0, 400).map((row, idx) => (
                  <tr key={`${row.method}-${row.path}-${idx}`} className="border-t">
                    <td className="px-2 py-1">{row.method}</td>
                    <td className="px-2 py-1 font-mono">{row.path}</td>
                    <td className="px-2 py-1">{row.status}</td>
                    <td className="px-2 py-1 font-mono">{row.source ?? '-'}</td>
                    <td className="px-2 py-1 font-mono">{(row.sources ?? []).join(', ') || '-'}</td>
                    <td className="px-2 py-1 font-mono">{(row.job_types ?? []).join(', ') || '-'}</td>
                    <td className="px-2 py-1 font-mono">{(row.dispatchers ?? []).join(', ') || '-'}</td>
                    <td className="px-2 py-1">{row.confidence ?? '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <h3 className="font-medium">{t('digikala.jobsTitle')}</h3>
          <pre className="bg-muted max-h-56 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(jobsQ.data?.items ?? [], null, 2)}
          </pre>
          <h3 className="font-medium">{t('digikala.logsTitle')}</h3>
          <pre className="bg-muted max-h-80 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
            {JSON.stringify(logsQ.data?.items ?? [], null, 2)}
          </pre>
        </section>
      </PageShell>
    )
  }

  if (isSync) {
    return (
      <PageShell title={t('digikala.syncTitle')} subtitle={t('digikala.syncSubtitle')}>
        <section className="flex flex-wrap gap-2 rounded-lg border border-border p-4">
          <Button onClick={() => enqueue.mutate('digikala/sync/products/import')}>{t('digikala.syncImport')}</Button>
          <Button onClick={() => enqueue.mutate('digikala/sync/products/export')}>{t('digikala.syncExport')}</Button>
          <Button onClick={() => enqueue.mutate('digikala/sync/inventory')}>{t('digikala.syncInventory')}</Button>
          <Button onClick={() => enqueue.mutate('digikala/sync/orders/pull')}>{t('digikala.syncOrdersPull')}</Button>
          <Button onClick={() => enqueue.mutate('digikala/sync/orders/push-status')}>{t('digikala.syncOrdersPush')}</Button>
          <Button variant="secondary" onClick={() => enqueue.mutate('digikala/sync/phase2/shipments')}>{t('digikala.syncPhase2Shipments')}</Button>
          <Button variant="secondary" onClick={() => enqueue.mutate('digikala/sync/phase2/finance')}>{t('digikala.syncPhase2Finance')}</Button>
          <Button variant="secondary" onClick={() => enqueue.mutate('digikala/sync/phase2/promotions')}>{t('digikala.syncPhase2Promotions')}</Button>
          <Button variant="secondary" onClick={() => enqueue.mutate('digikala/sync/phase2/sbs')}>{t('digikala.syncPhase2Sbs')}</Button>
        </section>
      </PageShell>
    )
  }

  return (
    <PageShell title={t('digikala.title')} subtitle={t('digikala.subtitle')}>
      <section className="space-y-4 rounded-lg border border-border p-4">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Base URL" value={settings?.base_url ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), base_url: v }))} />
          <Field label={t('digikala.clientCode')} value={settings?.client_code ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), client_code: v }))} />
          <Field label={t('digikala.clientSecret')} type="password" value={settings?.client_secret ?? ''} placeholder={settings?.has_client_secret ? '••••••••' : ''} onChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), client_secret: v }))} />
          <Field label={t('digikala.authorizationCode')} value={settings?.authorization_code ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), authorization_code: v }))} />
          <Field label={t('digikala.webhookSecret')} value={settings?.webhook_secret ?? ''} onChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), webhook_secret: v }))} />
          <div className="space-y-2">
            <Label>{t('digikala.webhookUrl')}</Label>
            <Input value={settings?.webhook_url ?? ''} readOnly />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox checked={Boolean(settings?.auto_sync)} onCheckedChange={(v) => setDraft((p) => ({ ...(p as DigikalaSettings), auto_sync: v === true }))} id="digikala-auto-sync" />
          <Label htmlFor="digikala-auto-sync">{t('digikala.autoSync')}</Label>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => save.mutate()} disabled={!settings || save.isPending}>
            {t('common.save')}
          </Button>
          <Button variant="outline" onClick={() => test.mutate()} disabled={test.isPending}>
            {t('digikala.testConnection')}
          </Button>
        </div>
      </section>
    </PageShell>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
  placeholder?: string
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} type={type} placeholder={placeholder} />
    </div>
  )
}
