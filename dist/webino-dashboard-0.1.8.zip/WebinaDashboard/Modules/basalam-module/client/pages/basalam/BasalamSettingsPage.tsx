import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

export default function BasalamSettingsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()

  const settingsQ = useQuery({
    queryKey: ['basalam', 'settings'],
    queryFn: () => apiFetch<{ settings: Record<string, unknown> }>('basalam/settings'),
  })
  const statusQ = useQuery({
    queryKey: ['basalam', 'status'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/status'),
  })
  const coverageQ = useQuery({
    queryKey: ['basalam', 'coverage'],
    queryFn: () => apiFetch<Record<string, unknown>>('basalam/coverage/endpoints'),
  })

  const reconcile = useMutation({
    mutationFn: () => apiFetch('basalam/reconcile', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.reconcileQueued'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'status'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <PageShell title={t('basalam.title')} subtitle={t('basalam.subtitle')}>
      <section className="space-y-4 rounded-lg border border-border p-4">
        <div className="flex gap-2">
          <Button onClick={() => reconcile.mutate()}>{t('basalam.reconcileNow')}</Button>
        </div>
        <h3 className="font-medium">{t('basalam.settingsTitle')}</h3>
        <pre className="bg-muted max-h-52 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
          {JSON.stringify(settingsQ.data?.settings ?? {}, null, 2)}
        </pre>
        <h3 className="font-medium">{t('basalam.statusTitle')}</h3>
        <pre className="bg-muted max-h-52 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
          {JSON.stringify(statusQ.data ?? {}, null, 2)}
        </pre>
        <h3 className="font-medium">{t('basalam.coverageTitle')}</h3>
        <pre className="bg-muted max-h-64 overflow-auto rounded-md p-3 text-xs whitespace-pre-wrap">
          {JSON.stringify(coverageQ.data ?? {}, null, 2)}
        </pre>
      </section>
    </PageShell>
  )
}
