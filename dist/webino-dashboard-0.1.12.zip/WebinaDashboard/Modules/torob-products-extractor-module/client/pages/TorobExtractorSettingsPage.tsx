import { useEffect, useState } from 'react'

declare global {
  interface Window {
    webinoDashboard?: { restUrl?: string; nonce?: string }
  }
}

type VendorStatus = {
  woocommerce_ready?: boolean
  plugin_loaded?: boolean
  plugin_source?: string
}

type Settings = {
  enabled: boolean
  feed_token: string
  public_key: string
  auto_sync: boolean
  sync_interval_hours: number
}

export default function TorobExtractorSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null)
  const [status, setStatus] = useState<VendorStatus | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const base = window.webinoDashboard?.restUrl || '/wp-json/'
  const nonce = window.webinoDashboard?.nonce || ''

  useEffect(() => {
    fetch(`${base}webino-dashboard/v1/torob-extractor/settings`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((d) => {
        setSettings(d.settings)
        setStatus(d.status)
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed'))
  }, [base, nonce])

  if (error) return <div>Torob Extractor: {error}</div>
  if (!settings) return <div>Loading Torob Extractor…</div>

  return (
    <div style={{ display: 'grid', gap: 16, maxWidth: 640 }}>
      <h2>Torob Products Extractor</h2>
      <section style={{ display: 'grid', gap: 8, padding: 12, border: '1px solid #ddd', borderRadius: 8 }}>
        <strong>Runtime status</strong>
        <p>WooCommerce: {status?.woocommerce_ready ? 'ready' : 'missing'}</p>
        <p>Extractor: {status?.plugin_loaded ? 'loaded' : 'not loaded'} ({status?.plugin_source ?? '—'})</p>
      </section>
      <label>
        <input
          type="checkbox"
          checked={settings.enabled}
          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
        />
        Enable extractor
      </label>
      <label>
        Feed token
        <input value={settings.feed_token} onChange={(e) => setSettings({ ...settings, feed_token: e.target.value })} />
      </label>
      <label>
        Public key
        <input value={settings.public_key} onChange={(e) => setSettings({ ...settings, public_key: e.target.value })} />
      </label>
      <label>
        <input
          type="checkbox"
          checked={settings.auto_sync}
          onChange={(e) => setSettings({ ...settings, auto_sync: e.target.checked })}
        />
        Auto sync
      </label>
      <label>
        Sync interval (hours)
        <input
          type="number"
          min={1}
          value={settings.sync_interval_hours}
          onChange={(e) => setSettings({ ...settings, sync_interval_hours: Number(e.target.value) })}
        />
      </label>
      <button
        disabled={saving}
        onClick={async () => {
          setSaving(true)
          try {
            const r = await fetch(`${base}webino-dashboard/v1/torob-extractor/settings`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
              body: JSON.stringify(settings),
            })
            const d = await r.json()
            setSettings(d.settings)
            setStatus(d.status)
          } finally {
            setSaving(false)
          }
        }}
      >
        {saving ? 'Saving…' : 'Save'}
      </button>
    </div>
  )
}
