<?php
/**
 * Fired during plugin activation
 *
 * @package    WFCP
 * @subpackage WFCP/includes
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Fired during plugin activation.
 */
class WFCP_Activator {

	/**
	 * Activate plugin
	 */
	public static function activate() {
		// Set default options
		$default_settings = self::get_default_settings();
		
		// Check if settings already exist
		$existing_settings = get_option( 'wfcp_settings', array() );
		
		// Merge with defaults (preserve existing settings)
		$settings = wp_parse_args( $existing_settings, $default_settings );
		
		update_option( 'wfcp_settings', $settings );
		
		// Set version
		update_option( 'wfcp_version', WFCP_VERSION );
		
		// Flush rewrite rules
		flush_rewrite_rules();
	}

	/**
	 * Ensure marketplace pricing sections exist for existing installs.
	 */
	public static function maybe_upgrade_settings() {
		$settings = get_option( 'wfcp_settings', array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$defaults = self::get_default_settings();
		$changed  = false;
		foreach ( array( 'digikala', 'basalam', 'technolife', 'snappshop', 'tapsishop', 'zarehbin', 'emalls', 'torob' ) as $section ) {
			if ( ! isset( $settings[ $section ] ) || ! is_array( $settings[ $section ] ) ) {
				$settings[ $section ] = $defaults[ $section ];
				$changed = true;
			} else {
				$merged = wp_parse_args( $settings[ $section ], $defaults[ $section ] );
				if ( $merged !== $settings[ $section ] ) {
					$settings[ $section ] = $merged;
					$changed = true;
				}
			}
		}
		if ( $changed ) {
			update_option( 'wfcp_settings', $settings );
		}
	}

	/**
	 * Get default settings
	 *
	 * @return array
	 */
	public static function get_default_settings() {
		return array(
			'general' => array(
				'enabled'                => true,
				'currency'               => 'IRR',
				'exchange_rate'          => 42000,
				'exchange_rate_enabled'  => true, // When false, never apply exchange rate.
				'purchase_currency'      => 'base', // 'base' = USD, 'display' = IRR/IRT
				'api_enabled'            => false,
				'api_key'          => '',
				'api_symbol'       => 'USD',
				'auto_update_enabled' => false,
				'auto_update_hour' => 0,
			),
			'retail' => array(
				'profit_percent' => 20,
				'round_enabled'  => true,
				'round_to'      => 1000,
				'gateways'      => array(),
			),
			'credit' => array(
				'enabled'        => false,
				'increase_percent' => 5,
				'gateways'       => array(),
				'texts'          => array(
					'title'       => 'خرید اعتباری',
					'button_text' => 'افزودن اعتباری',
				),
			),
			'installment' => array(
				'enabled'       => false,
				'round_enabled' => true,
				'round_to'      => 1000,
				'plans'         => array(
					array(
						'months'   => 3,
						'interest' => 5,
					),
					array(
						'months'   => 6,
						'interest' => 10,
					),
				),
				'gateways' => array(),
				'texts' => array(
					'title'       => 'خرید اقساطی',
					'button_text' => 'افزودن اقساطی',
				),
			),
			'wholesale' => array(
				'enabled'         => false,
				'strategy'        => 'global',
				'discount_percent' => 10,
				'gateways'        => array(),
				'category_rules'  => array(),
			),
			'digikala' => array(
				'enabled'        => false,
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'rial',
			),
			'basalam' => array(
				'enabled'        => false,
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'technolife' => array(
				'enabled'        => false,
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'snappshop' => array(
				'enabled'        => false,
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'tapsishop' => array(
				'enabled'        => false,
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'zarehbin' => array(
				'enabled'        => false,
				'price_mode'     => 'retail',
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'emalls' => array(
				'enabled'        => false,
				'price_mode'     => 'retail',
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'torob' => array(
				'enabled'        => false,
				'price_mode'     => 'retail',
				'profit_percent' => 20,
				'extra_percent'  => 0,
				'round_enabled'  => true,
				'round_to'       => 1000,
				'price_unit'     => 'toman',
			),
			'notifications' => array(
				'installment_text'        => 'خرید اقساطی',
				'credit_text'             => 'خرید اعتباری',
				'cash_description'        => '',
				'installment_description' => '',
				'credit_description'      => '',
				'wholesale_description'   => '',
				'need_review'             => 'نیاز به بررسی',
				'alert_product_enabled'   => true,
				'alert_cart_enabled'      => true,
				'alert_checkout_enabled'  => true,
				'alert_product_text'      => 'در صورت نیاز می‌توانید روش پرداخت اقساطی یا اعتباری را از باکس قیمت انتخاب کنید، سپس محصول را به سبد اضافه کنید.',
				'alert_cart_text'         => 'می‌توانید روش پرداخت همه محصولات سبد را از بخش زیر به نقدی، اقساطی یا اعتباری تغییر دهید.',
				'alert_checkout_text'     => 'روش پرداخت فعلی سبد: {type}. برای تغییر به اقساطی یا اعتباری به سبد خرید برگردید و روش را عوض کنید.',
			),
			'style' => array(
				'box_background'         => '#ffffff',
				'box_border_color'       => '#e0e0e0',
				'button_background'      => '#2271b1',
				'button_text_color'      => '#ffffff',
				'price_color'            => '#2271b1',
				'border_radius'          => 8,
				'alert_bg'               => '#ffffff',
				'alert_text_color'       => '#9A3412',
				'alert_border_color'     => '#FDBA74',
				'alert_accent'           => '#EA580C',
				'badge_cash_bg'          => '#ECFDF5',
				'badge_cash_text'        => '#047857',
				'badge_credit_bg'        => '#EFF6FF',
				'badge_credit_text'      => '#1D4ED8',
				'badge_installment_bg'   => '#FFFBEB',
				'badge_installment_text' => '#B45309',
			),
		);
	}
}

