<?php
/**
 * Price Calculator Service
 *
 * @package    WFCP
 * @subpackage WFCP/includes/services
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Price Calculator Service
 */
class WFCP_Calculator {

	/**
	 * Calculate price based on type
	 *
	 * @param float  $base_price Base purchase price.
	 * @param string $type       Price type: retail, credit, installment, wholesale.
	 * @param int    $product_id Optional. Product ID.
	 * @param array  $args       Optional. Additional arguments.
	 * @return float
	 */
	public static function calculate_price( $base_price, $type = 'retail', $product_id = null, $args = array() ) {
		// Check cache first
		$cache_key = self::get_cache_key( $base_price, $type, $product_id, $args );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return floatval( $cached );
		}

		$price = floatval( $base_price );

		// Get exchange rate (from API if enabled, otherwise manual)
		$general = WFCP_Helper::get_settings( 'general' );
		if ( ! is_array( $general ) ) {
			$general = array();
		}
		$api_enabled = WFCP_Helper::to_bool( isset( $general['api_enabled'] ) ? $general['api_enabled'] : false );

		$exchange_rate = isset( $general['exchange_rate'] ) ? $general['exchange_rate'] : 42000;

		// If API is enabled, try to get latest rate (but use cached if available)
		if ( $api_enabled && ! empty( $general['api_key'] ) ) {
			$exchange_rate = isset( $general['exchange_rate'] ) ? $general['exchange_rate'] : 42000;
		}

		$purchase_currency     = isset( $general['purchase_currency'] ) ? $general['purchase_currency'] : 'base';
		$exchange_rate_enabled = isset( $general['exchange_rate_enabled'] )
			? WFCP_Helper::to_bool( $general['exchange_rate_enabled'] )
			: true;

		// Apply exchange rate only when enabled and purchase_currency is 'base'
		if ( $exchange_rate_enabled && $exchange_rate && $exchange_rate > 0 ) {
			if ( ! $purchase_currency || 'base' === $purchase_currency ) {
				$price = $price * floatval( $exchange_rate );
			}
		}

		// Calculate based on type
		switch ( $type ) {
			case 'retail':
				$price = self::calculate_retail_price( $price );
				break;

			case 'credit':
				// Credit is markup on retail so it never undercuts cash.
				$retail = self::calculate_retail_price( $price );
				$price  = self::calculate_credit_price( $retail );
				break;

			case 'installment':
				// Installment interest is applied on retail base.
				$retail = self::calculate_retail_price( $price );
				$months = isset( $args['months'] ) ? intval( $args['months'] ) : 3;
				$price  = self::calculate_installment_price( $retail, $months );
				break;

			case 'wholesale':
				// Wholesale discount is applied on FX-converted purchase (not retail).
				$price = self::calculate_wholesale_price( $price, $product_id );
				break;

			case 'digikala':
			case 'basalam':
			case 'technolife':
			case 'snappshop':
			case 'tapsishop':
			case 'zarehbin':
			case 'emalls':
			case 'torob':
				// Platform markup is applied on retail (نقدی), not purchase.
				$retail = self::calculate_retail_price( $price );
				$price  = self::calculate_marketplace_price( $retail, $type, $product_id );
				break;
		}

		// Round price if enabled (retail and installment monthly).
		if ( 'retail' === $type ) {
			$round_enabled = WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'retail', 'round_enabled' ) );
			if ( $round_enabled ) {
				$round_to = WFCP_Helper::get_settings( 'retail', 'round_to' );
				if ( $round_to ) {
					$price = WFCP_Helper::round_price( $price, intval( $round_to ) );
				}
			}
		} elseif ( 'installment' === $type ) {
			$round_enabled = WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'installment', 'round_enabled' ) );
			if ( $round_enabled ) {
				$round_to = WFCP_Helper::get_settings( 'installment', 'round_to' );
				$round_to = $round_to ? intval( $round_to ) : 1000;
				$price    = WFCP_Helper::round_price( $price, max( 1, $round_to ) );
			}
		} elseif ( in_array( $type, array( 'digikala', 'basalam', 'technolife', 'snappshop', 'tapsishop', 'zarehbin', 'emalls', 'torob' ), true ) ) {
			$skip_platform_round = in_array( $type, array( 'torob', 'zarehbin', 'emalls' ), true )
				&& 'markup' !== (string) WFCP_Helper::get_settings( $type, 'price_mode' );
			if ( ! $skip_platform_round ) {
				$round_enabled = WFCP_Helper::to_bool( WFCP_Helper::get_settings( $type, 'round_enabled' ) );
				if ( $round_enabled ) {
					$round_to = WFCP_Helper::get_settings( $type, 'round_to' );
					$round_to = $round_to ? intval( $round_to ) : 1000;
					$price    = WFCP_Helper::round_price( $price, max( 1, $round_to ) );
				}
			}
		}

		// Cache the result (1 hour)
		set_transient( $cache_key, $price, HOUR_IN_SECONDS );

		return floatval( $price );
	}

	/**
	 * Calculate retail price
	 *
	 * @param float $base_price Base price.
	 * @return float
	 */
	private static function calculate_retail_price( $base_price ) {
		$profit_percent = WFCP_Helper::get_settings( 'retail', 'profit_percent' );

		if ( ! $profit_percent || $profit_percent <= 0 ) {
			return $base_price;
		}

		$profit = ( $base_price * floatval( $profit_percent ) ) / 100;
		return $base_price + $profit;
	}

	/**
	 * Calculate credit price (expects retail base).
	 *
	 * @param float $base_price Retail-level price.
	 * @return float
	 */
	private static function calculate_credit_price( $base_price ) {
		if ( ! WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'credit', 'enabled' ) ) ) {
			return $base_price;
		}

		$increase_percent = WFCP_Helper::get_settings( 'credit', 'increase_percent' );

		if ( ! $increase_percent || $increase_percent <= 0 ) {
			return $base_price;
		}

		$increase = ( $base_price * floatval( $increase_percent ) ) / 100;
		return $base_price + $increase;
	}

	/**
	 * Calculate installment monthly payment (expects retail base).
	 *
	 * @param float $base_price Retail-level price.
	 * @param int   $months     Number of months.
	 * @return float
	 */
	private static function calculate_installment_price( $base_price, $months ) {
		if ( ! WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'installment', 'enabled' ) ) ) {
			return $base_price;
		}

		$plans = WFCP_Helper::get_settings( 'installment', 'plans' );

		if ( ! is_array( $plans ) || empty( $plans ) ) {
			return $base_price;
		}

		// Find matching plan
		$plan = null;
		foreach ( $plans as $p ) {
			if ( isset( $p['months'] ) && intval( $p['months'] ) === $months ) {
				$plan = $p;
				break;
			}
		}

		if ( ! $plan || ! isset( $plan['interest'] ) ) {
			return $base_price;
		}

		$interest_percent = floatval( $plan['interest'] );
		$total_interest   = ( $base_price * $interest_percent ) / 100;
		$total_price      = $base_price + $total_interest;

		// Prevent division by zero
		if ( $months <= 0 ) {
			return $base_price;
		}

		return $total_price / $months;
	}

	/**
	 * Calculate wholesale price
	 *
	 * Discount is applied on FX-converted purchase price (not retail/نقدی).
	 *
	 * @param float $base_price Purchase after FX.
	 * @param int   $product_id Product ID.
	 * @return float
	 */
	private static function calculate_wholesale_price( $base_price, $product_id = null ) {
		if ( ! WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'wholesale', 'enabled' ) ) ) {
			return $base_price;
		}

		$strategy         = WFCP_Helper::get_settings( 'wholesale', 'strategy' );
		$discount_percent = 0;

		switch ( $strategy ) {
			case 'global':
				$discount_percent = WFCP_Helper::get_settings( 'wholesale', 'discount_percent' );
				break;

			case 'category':
				if ( $product_id ) {
					$terms = wp_get_post_terms( $product_id, 'product_cat' );
					if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
						$category_rules = WFCP_Helper::get_settings( 'wholesale', 'category_rules' );
						foreach ( $terms as $term ) {
							if ( isset( $category_rules[ $term->term_id ] ) ) {
								$discount_percent = floatval( $category_rules[ $term->term_id ] );
								break;
							}
						}
					}
				}
				break;

			case 'product':
				if ( $product_id ) {
					$custom_rule = get_post_meta( $product_id, '_wfcp_wholesale_custom_rule', true );
					if ( $custom_rule && isset( $custom_rule['discount_percent'] ) ) {
						$discount_percent = floatval( $custom_rule['discount_percent'] );
					}
				}
				break;
		}

		if ( ! $discount_percent || $discount_percent <= 0 ) {
			return $base_price;
		}

		// Prevent discount from being more than 100%
		if ( $discount_percent >= 100 ) {
			$discount_percent = 99.99;
		}

		$discount = ( $base_price * $discount_percent ) / 100;
		return max( 0, $base_price - $discount ); // Prevent negative prices
	}

	/**
	 * Marketplace channel price.
	 * Formula (on retail/نقدی): retail * (1 + profit/100) * (1 + extra/100)
	 * Respects per-product lock + manual price meta.
	 *
	 * @param float  $retail_price Retail (نقدی) base.
	 * @param string $platform     Platform slug.
	 * @param int    $product_id   Product ID.
	 * @return float
	 */
	private static function calculate_marketplace_price( $retail_price, $platform, $product_id = null ) {
		if ( $product_id ) {
			$locked = get_post_meta( $product_id, '_wfcp_' . $platform . '_lock', true );
			if ( '1' === (string) $locked ) {
				$manual = get_post_meta( $product_id, '_wfcp_' . $platform . '_price', true );
				if ( '' !== $manual && null !== $manual ) {
					return floatval( $manual );
				}
			}
		}

		if ( ! WFCP_Helper::to_bool( WFCP_Helper::get_settings( $platform, 'enabled' ) ) ) {
			return floatval( $retail_price );
		}

		// Comparison engines: optional "use retail as-is" mode (same as cash / نقدی).
		if ( in_array( $platform, array( 'torob', 'zarehbin', 'emalls' ), true ) ) {
			$mode = (string) WFCP_Helper::get_settings( $platform, 'price_mode' );
			if ( 'markup' !== $mode ) {
				$price = floatval( $retail_price );
				$round_enabled = WFCP_Helper::to_bool( WFCP_Helper::get_settings( 'retail', 'round_enabled' ) );
				if ( $round_enabled ) {
					$round_to = WFCP_Helper::get_settings( 'retail', 'round_to' );
					if ( $round_to ) {
						$price = WFCP_Helper::round_price( $price, intval( $round_to ) );
					}
				}
				return $price;
			}
		}

		$profit = floatval( WFCP_Helper::get_settings( $platform, 'profit_percent' ) );
		$extra  = floatval( WFCP_Helper::get_settings( $platform, 'extra_percent' ) );
		$price  = floatval( $retail_price );

		if ( $profit > 0 ) {
			$price = $price * ( 1 + ( $profit / 100 ) );
		}
		if ( $extra > 0 ) {
			$price = $price * ( 1 + ( $extra / 100 ) );
		}

		return max( 0, $price );
	}

	/**
	 * Hash of pricing-related settings for cache invalidation.
	 *
	 * @return string
	 */
	private static function settings_hash() {
		$parts = array(
			WFCP_Helper::get_settings( 'general' ),
			WFCP_Helper::get_settings( 'retail' ),
			WFCP_Helper::get_settings( 'credit' ),
			WFCP_Helper::get_settings( 'installment' ),
			WFCP_Helper::get_settings( 'wholesale' ),
			WFCP_Helper::get_settings( 'digikala' ),
			WFCP_Helper::get_settings( 'basalam' ),
			WFCP_Helper::get_settings( 'technolife' ),
			WFCP_Helper::get_settings( 'snappshop' ),
			WFCP_Helper::get_settings( 'tapsishop' ),
			WFCP_Helper::get_settings( 'zarehbin' ),
			WFCP_Helper::get_settings( 'emalls' ),
			WFCP_Helper::get_settings( 'torob' ),
		);
		return md5( wp_json_encode( $parts ) );
	}

	/**
	 * Get cache key
	 *
	 * @param float  $base_price Base price.
	 * @param string $type       Price type.
	 * @param int    $product_id Product ID.
	 * @param array  $args       Additional arguments.
	 * @return string
	 */
	private static function get_cache_key( $base_price, $type, $product_id, $args ) {
		$key = 'wfcp_price_' . md5( $base_price . $type . $product_id . serialize( $args ) . self::settings_hash() );
		return $key;
	}
}
