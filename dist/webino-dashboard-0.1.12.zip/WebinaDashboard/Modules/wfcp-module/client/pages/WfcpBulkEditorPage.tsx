import { Navigate } from 'react-router-dom'

export default function WfcpBulkEditorPage() {
  return <Navigate to="/shop/products" replace />
}
