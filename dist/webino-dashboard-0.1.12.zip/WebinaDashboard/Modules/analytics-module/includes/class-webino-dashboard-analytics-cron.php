<?php
/**
 * Daily rollup and retention purge.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cron jobs for analytics aggregates.
 */
class Webino_Dashboard_Analytics_Cron {

	/**
	 * @return void
	 */
	public static function init() {
		add_action( self::hook(), array( __CLASS__, 'run_daily' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/**
	 * @return string
	 */
	public static function hook() {
		return Webino_Dashboard_Analytics::CRON_HOOK;
	}

	/**
	 * @return void
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::hook() ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::hook() );
		}
	}

	/**
	 * @return void
	 */
	public static function run_daily() {
		self::rollup_day( gmdate( 'Y-m-d', strtotime( '-1 day' ) ) );
		self::purge_old_events();
	}

	/**
	 * Rebuild aggregates for a day from raw events.
	 *
	 * @param string $day Y-m-d.
	 * @return void
	 */
	public static function rollup_day( $day ) {
		global $wpdb;

		$events = Webino_Dashboard_Analytics_Db::table( 'events' );
		$totals = Webino_Dashboard_Analytics_Db::table( 'daily_totals' );
		$page_d = Webino_Dashboard_Analytics_Db::table( 'page_daily' );
		$ref_d  = Webino_Dashboard_Analytics_Db::table( 'referrer_daily' );
		$dev_d  = Webino_Dashboard_Analytics_Db::table( 'device_daily' );
		$geo_d  = Webino_Dashboard_Analytics_Db::table( 'geo_daily' );

		$start = $day . ' 00:00:00';
		$end   = $day . ' 23:59:59';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$views = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$events} WHERE created_at >= %s AND created_at <= %s",
				$start,
				$end
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$visitors = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT visitor_hash) FROM {$events} WHERE created_at >= %s AND created_at <= %s",
				$start,
				$end
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->replace(
			$totals,
			array(
				'day'      => $day,
				'visitors' => $visitors,
				'views'    => $views,
			),
			array( '%s', '%d', '%d' )
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$page_d} WHERE day = %s", $day ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$page_d} (day, post_id, uri, views)
				SELECT %s, post_id, uri, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s
				GROUP BY post_id, uri",
				$day,
				$start,
				$end
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$ref_d} WHERE day = %s", $day ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$ref_d} (day, ref_category, ref_source, visits)
				SELECT %s, ref_category, ref_source, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s
				GROUP BY ref_category, ref_source",
				$day,
				$start,
				$end
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$dev_d} WHERE day = %s", $day ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$dev_d} (day, dim_type, dim_value, views)
				SELECT %s, 'browser', browser, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s GROUP BY browser",
				$day,
				$start,
				$end
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$dev_d} (day, dim_type, dim_value, views)
				SELECT %s, 'os', os, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s GROUP BY os",
				$day,
				$start,
				$end
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$dev_d} (day, dim_type, dim_value, views)
				SELECT %s, 'device', device, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s GROUP BY device",
				$day,
				$start,
				$end
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$geo_d} WHERE day = %s", $day ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$geo_d} (day, dim_type, dim_value, views)
				SELECT %s, 'country', country, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s AND country != '' GROUP BY country",
				$day,
				$start,
				$end
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$geo_d} (day, dim_type, dim_value, views)
				SELECT %s, 'city', city, COUNT(*) FROM {$events}
				WHERE created_at >= %s AND created_at <= %s AND city != '' GROUP BY city",
				$day,
				$start,
				$end
			)
		);
	}

	/**
	 * @return void
	 */
	public static function purge_old_events() {
		global $wpdb;
		$settings = Webino_Dashboard_Analytics::get_settings();
		$days     = max( 7, (int) ( $settings['retention_days'] ?? 90 ) );
		$cutoff   = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$events   = Webino_Dashboard_Analytics_Db::table( 'events' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$events} WHERE created_at < %s", $cutoff ) );
	}

	/**
	 * Rebuild all daily aggregates from events (optimization action).
	 *
	 * @return int Days processed.
	 */
	public static function rebuild_all() {
		global $wpdb;
		$events = Webino_Dashboard_Analytics_Db::table( 'events' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$days = $wpdb->get_col( "SELECT DISTINCT DATE(created_at) AS d FROM {$events} ORDER BY d ASC" );
		if ( ! is_array( $days ) ) {
			return 0;
		}
		foreach ( $days as $day ) {
			self::rollup_day( (string) $day );
		}
		return count( $days );
	}
}
