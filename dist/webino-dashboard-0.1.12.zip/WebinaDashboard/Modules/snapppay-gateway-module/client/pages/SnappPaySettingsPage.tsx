import { useEffect, useState } from 'react'

declare global {
  interface Window {
    webinoDashboard?: { restUrl?: string; nonce?: string }
  }
}

type VendorStatus = {
  woocommerce_ready?: boolean
  gateway_loaded?: boolean
  searchwise_loaded?: boolean
  gateway_source?: string
  searchwise_source?: string
}

type Settings = {
  enabled: boolean
  title: string
  description: string
  merchant_id: string
  client_id: string
  client_secret: string
  sandbox: boolean
}

export default function SnappPaySettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null)
  const [status, setStatus] = useState<VendorStatus | null>(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const base = window.webinoDashboard?.restUrl || '/wp-json/'
  const nonce = window.webinoDashboard?.nonce || ''

  useEffect(() => {
    fetch(`${base}webino-dashboard/v1/snapppay/settings`, { headers: { 'X-WP-Nonce': nonce } })
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((d) => {
        setSettings(d.settings)
        setStatus(d.status)
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed'))
  }, [base, nonce])

  if (error) return <div>SnappPay: {error}</div>
  if (!settings) return <div>Loading SnappPay…</div>

  return (
    <div style={{ display: 'grid', gap: 16, maxWidth: 640 }}>
      <h2>SnappPay Gateway</h2>
      <section style={{ display: 'grid', gap: 8, padding: 12, border: '1px solid #ddd', borderRadius: 8 }}>
        <strong>Runtime status</strong>
        <p>WooCommerce: {status?.woocommerce_ready ? 'ready' : 'missing'}</p>
        <p>Gateway: {status?.gateway_loaded ? 'loaded' : 'not loaded'} ({status?.gateway_source ?? '—'})</p>
        <p>Searchwise: {status?.searchwise_loaded ? 'loaded' : 'not loaded'} ({status?.searchwise_source ?? '—'})</p>
      </section>
      <label>
        <input
          type="checkbox"
          checked={settings.enabled}
          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
        />
        Enable gateway
      </label>
      <label>
        Title
        <input value={settings.title} onChange={(e) => setSettings({ ...settings, title: e.target.value })} />
      </label>
      <label>
        Description
        <input value={settings.description} onChange={(e) => setSettings({ ...settings, description: e.target.value })} />
      </label>
      <label>
        Merchant ID
        <input value={settings.merchant_id} onChange={(e) => setSettings({ ...settings, merchant_id: e.target.value })} />
      </label>
      <label>
        Client ID
        <input value={settings.client_id} onChange={(e) => setSettings({ ...settings, client_id: e.target.value })} />
      </label>
      <label>
        Client secret
        <input
          type="password"
          value={settings.client_secret}
          onChange={(e) => setSettings({ ...settings, client_secret: e.target.value })}
        />
      </label>
      <label>
        <input
          type="checkbox"
          checked={settings.sandbox}
          onChange={(e) => setSettings({ ...settings, sandbox: e.target.checked })}
        />
        Sandbox
      </label>
      <button
        disabled={saving}
        onClick={async () => {
          setSaving(true)
          try {
            const r = await fetch(`${base}webino-dashboard/v1/snapppay/settings`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
              body: JSON.stringify(settings),
            })
            const d = await r.json()
            setSettings(d.settings)
            setStatus(d.status)
          } finally {
            setSaving(false)
          }
        }}
      >
        {saving ? 'Saving…' : 'Save'}
      </button>
    </div>
  )
}
