<?php

namespace WebinoBasalam\Migrations;

defined('ABSPATH') || exit;

interface MigrationInterface
{
    public function up();
}
