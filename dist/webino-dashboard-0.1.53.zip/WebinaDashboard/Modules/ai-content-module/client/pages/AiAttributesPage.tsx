import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import {
  confirmAttrTemplate,
  deleteAttrTemplate,
  fetchAttrDraft,
  fetchAttrTemplates,
  suggestAttrTemplate,
} from '../lib/ai-content-api'

export default function AiAttributesPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [catId, setCatId] = useState('')

  const listQ = useQuery({
    queryKey: ['ai-content', 'attr-templates'],
    queryFn: fetchAttrTemplates,
  })
  useQueryErrorToast(listQ)

  const draftQ = useQuery({
    queryKey: ['ai-content', 'attr-draft', catId],
    queryFn: () => fetchAttrDraft(Number(catId)),
    enabled: Number(catId) > 0,
  })

  const suggest = useMutation({
    mutationFn: () => suggestAttrTemplate(Number(catId)),
    onSuccess: () => {
      toast.success(t('aiContent.jobQueued'))
      setTimeout(() => void draftQ.refetch(), 3000)
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const confirm = useMutation({
    mutationFn: () => confirmAttrTemplate(Number(catId), draftQ.data?.draft),
    onSuccess: () => {
      toast.success(t('common.saved'))
      void qc.invalidateQueries({ queryKey: ['ai-content'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const remove = useMutation({
    mutationFn: (id: number) => deleteAttrTemplate(id),
    onSuccess: () => {
      toast.success(t('common.deleted'))
      void qc.invalidateQueries({ queryKey: ['ai-content'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const draftAttrs = draftQ.data?.draft?.attributes ?? []

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.attrSuggestTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1 max-w-xs">
            <Label>{t('aiContent.productCatId')}</Label>
            <Input value={catId} onChange={(e) => setCatId(e.target.value)} placeholder="e.g. 12" />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" disabled={!Number(catId) || suggest.isPending} onClick={() => void suggest.mutateAsync()}>
              {t('aiContent.suggest')}
            </Button>
            <Button size="sm" variant="outline" disabled={!draftAttrs.length || confirm.isPending} onClick={() => void confirm.mutateAsync()}>
              {t('aiContent.confirmTemplate')}
            </Button>
            <Button size="sm" variant="ghost" disabled={!Number(catId)} onClick={() => void draftQ.refetch()}>
              {t('common.refresh')}
            </Button>
          </div>
          <div className="space-y-2">
            {draftAttrs.map((a, i) => (
              <div key={`${a.label}-${i}`} className="rounded-md border p-2 text-sm">
                <div className="font-medium">
                  {a.label} <span className="text-muted-foreground">({a.slug})</span>
                </div>
                <div className="text-xs text-muted-foreground">{(a.options ?? []).join(' · ')}</div>
              </div>
            ))}
            {!draftAttrs.length ? (
              <p className="text-sm text-muted-foreground">{t('aiContent.noAttrDraft')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.attrTemplates')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {(listQ.data?.items ?? []).map((row) => (
            <div key={row.id} className="flex flex-wrap items-center justify-between gap-2 border-b py-2 text-sm last:border-0">
              <div>
                <div className="font-medium">
                  {row.category_name || `#${row.product_cat_id}`}
                </div>
                <div className="text-muted-foreground">
                  {(row.labels ?? []).map((l) => l.label).join(' · ') || row.attribute_ids.join(', ')}
                </div>
              </div>
              <Button size="sm" variant="destructive" onClick={() => void remove.mutateAsync(row.product_cat_id)}>
                {t('common.delete')}
              </Button>
            </div>
          ))}
          {!listQ.data?.items?.length ? (
            <p className="text-sm text-muted-foreground">{t('aiContent.noTemplates')}</p>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
