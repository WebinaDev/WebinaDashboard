import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { fetchAiJobs, fetchAiOverview, retryAiJob } from '../lib/ai-content-api'

export default function AiOverviewPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()

  const overviewQ = useQuery({
    queryKey: ['ai-content', 'overview'],
    queryFn: fetchAiOverview,
  })
  useQueryErrorToast(overviewQ)

  const jobsQ = useQuery({
    queryKey: ['ai-content', 'jobs'],
    queryFn: () => fetchAiJobs({ limit: 20 }),
  })
  useQueryErrorToast(jobsQ)

  const retry = useMutation({
    mutationFn: (id: number) => retryAiJob(id),
    onSuccess: () => {
      toast.success(t('aiContent.jobRetried'))
      void qc.invalidateQueries({ queryKey: ['ai-content'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const o = overviewQ.data

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Button asChild variant="outline" size="sm">
          <Link to="/ai-content/calendar">{t('aiContent.navCalendar')}</Link>
        </Button>
        <Button asChild variant="outline" size="sm">
          <Link to="/ai-content/products">{t('aiContent.navProducts')}</Link>
        </Button>
        <Button asChild variant="outline" size="sm">
          <Link to="/ai-content/taxonomies">{t('aiContent.navTaxonomies')}</Link>
        </Button>
        <Button asChild variant="outline" size="sm">
          <Link to="/ai-content/attributes">{t('aiContent.navAttributes')}</Link>
        </Button>
        <Button asChild variant="outline" size="sm">
          <Link to="/ai-content/settings">{t('aiContent.navSettings')}</Link>
        </Button>
      </div>

      {overviewQ.isPending ? (
        <Skeleton className="h-32 w-full rounded-xl" />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ['pending', o?.jobs_pending ?? 0],
            ['failed', o?.jobs_failed ?? 0],
            ['done', o?.jobs_done ?? 0],
            ['calendar', o?.calendar_upcoming ?? 0],
          ].map(([key, val]) => (
            <Card key={String(key)}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {t(`aiContent.stat.${key}`)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">{val}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.incompleteTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm text-muted-foreground">
            {t('aiContent.incompleteCount', { count: o?.incomplete_products ?? 0 })}
          </p>
          {(o?.sample_incomplete ?? []).map((row) => (
            <div key={row.id} className="flex items-center justify-between gap-2 text-sm">
              <span>{row.name}</span>
              <span className="text-muted-foreground">{row.missing.join(', ')}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.jobsTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {(jobsQ.data?.items ?? []).map((job) => (
            <div key={job.id} className="flex flex-wrap items-center justify-between gap-2 border-b py-2 text-sm last:border-0">
              <div>
                <div className="font-medium">
                  #{job.id} · {job.job_type} · {job.status}
                </div>
                <div className="text-muted-foreground">
                  {job.result_summary || job.error_message || job.provider}
                </div>
              </div>
              {job.status === 'failed' ? (
                <Button size="sm" variant="outline" disabled={retry.isPending} onClick={() => void retry.mutateAsync(job.id)}>
                  {t('aiContent.retry')}
                </Button>
              ) : null}
            </div>
          ))}
          {!jobsQ.data?.items?.length ? (
            <p className="text-sm text-muted-foreground">{t('aiContent.noJobs')}</p>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
