import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useMutation, useQuery } from '@tanstack/react-query'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { type AiSettings, fetchAiSettings, saveAiSettings } from '../lib/ai-content-api'

export default function AiSettingsPage() {
  const { t } = useTranslation()
  const [draft, setDraft] = useState<Partial<AiSettings> | null>(null)

  const q = useQuery({
    queryKey: ['ai-content', 'settings'],
    queryFn: fetchAiSettings,
  })
  useQueryErrorToast(q)

  useEffect(() => {
    if (q.data) setDraft({ ...q.data, grok_api_key: '', gemini_api_key: '', openai_api_key: '' })
  }, [q.data])

  const save = useMutation({
    mutationFn: () => saveAiSettings(draft ?? {}),
    onSuccess: (res) => {
      toast.success(t('common.saved'))
      setDraft({ ...res, grok_api_key: '', gemini_api_key: '', openai_api_key: '' })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  if (!draft) {
    return <div className="text-sm text-muted-foreground">{t('common.loading')}</div>
  }

  const set = <K extends keyof AiSettings>(key: K, value: AiSettings[K]) => {
    setDraft((d) => ({ ...(d ?? {}), [key]: value }))
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProviders')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <Label>{t('aiContent.defaultProvider')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.default_provider ?? 'grok'}
              onChange={(e) => set('default_provider', e.target.value)}
            >
              <option value="grok">Grok</option>
              <option value="gemini">Gemini</option>
              <option value="openai">ChatGPT</option>
            </select>
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Grok API key {draft.has_grok_key ? `(${draft.grok_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.grok_api_key ?? ''}
              onChange={(e) => set('grok_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>Gemini API key {draft.has_gemini_key ? `(${draft.gemini_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.gemini_api_key ?? ''}
              onChange={(e) => set('gemini_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1 md:col-span-2">
            <Label>OpenAI API key {draft.has_openai_key ? `(${draft.openai_api_key_masked})` : ''}</Label>
            <Input
              type="password"
              value={draft.openai_api_key ?? ''}
              onChange={(e) => set('openai_api_key', e.target.value)}
              placeholder={t('aiContent.leaveBlankKeep')}
            />
          </div>
          <div className="space-y-1">
            <Label>Grok model</Label>
            <Input value={draft.grok_model ?? ''} onChange={(e) => set('grok_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Gemini model</Label>
            <Input value={draft.gemini_model ?? ''} onChange={(e) => set('gemini_model', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>OpenAI model</Label>
            <Input value={draft.openai_model ?? ''} onChange={(e) => set('openai_model', e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('aiContent.settingsProfile')}</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1 md:col-span-2">
            <Label>{t('aiContent.siteTopic')}</Label>
            <Textarea rows={2} value={draft.site_topic ?? ''} onChange={(e) => set('site_topic', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.tone')}</Label>
            <Input value={draft.tone ?? ''} onChange={(e) => set('tone', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.language')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.language ?? 'fa'}
              onChange={(e) => set('language', e.target.value)}
            >
              <option value="fa">{t('aiContent.lang.fa')}</option>
              <option value="en">{t('aiContent.lang.en')}</option>
            </select>
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.dailyBlogQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_blog_quota ?? 1}
              onChange={(e) => set('daily_blog_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.dailyProductQuota')}</Label>
            <Input
              type="number"
              value={draft.daily_product_quota ?? 5}
              onChange={(e) => set('daily_product_quota', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label>{t('aiContent.publishStatus')}</Label>
            <select
              className="flex h-9 w-full rounded-md border bg-background px-3 text-sm"
              value={draft.publish_status ?? 'draft'}
              onChange={(e) => set('publish_status', e.target.value)}
            >
              <option value="draft">draft</option>
              <option value="pending">pending</option>
              <option value="publish">publish</option>
            </select>
          </div>
          <div className="flex items-center gap-2 pt-6">
            <Checkbox
              checked={!!draft.auto_publish}
              onCheckedChange={(v) => set('auto_publish', Boolean(v))}
              id="auto_publish"
            />
            <Label htmlFor="auto_publish">{t('aiContent.autoPublish')}</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox checked={!!draft.enabled} onCheckedChange={(v) => set('enabled', Boolean(v))} id="enabled" />
            <Label htmlFor="enabled">{t('aiContent.enabled')}</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              checked={!!draft.require_site_name}
              onCheckedChange={(v) => set('require_site_name', Boolean(v))}
              id="require_site_name"
            />
            <Label htmlFor="require_site_name">{t('aiContent.requireSiteName')}</Label>
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => void save.mutateAsync()} disabled={save.isPending}>
        {t('common.save')}
      </Button>
    </div>
  )
}
