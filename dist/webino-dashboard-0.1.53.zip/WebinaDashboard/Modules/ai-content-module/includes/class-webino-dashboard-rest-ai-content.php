<?php
/**
 * REST API for AI Content module.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Routes under webino-dashboard/v1/ai-content/*.
 */
final class Webino_Dashboard_REST_AI_Content {

	const NS = 'webino-dashboard/v1';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * @return void
	 */
	public static function register_routes() {
		$edit = array( 'permission_callback' => array( __CLASS__, 'perm_edit' ) );
		$manage = array( 'permission_callback' => array( __CLASS__, 'perm_manage' ) );
		$products = array( 'permission_callback' => array( __CLASS__, 'perm_products' ) );
		$terms = array( 'permission_callback' => array( __CLASS__, 'perm_terms' ) );

		register_rest_route(
			self::NS,
			'/ai-content/overview',
			array_merge( $edit, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'overview' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/settings',
			array(
				array_merge( $manage, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'settings_get' ) ) ),
				array_merge( $manage, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'settings_post' ) ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/ai-content/jobs',
			array(
				array_merge( $edit, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'jobs_list' ) ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/ai-content/jobs/(?P<id>\d+)/retry',
			array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'jobs_retry' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/generate',
			array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'generate' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/products/incomplete',
			array_merge( $products, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'products_incomplete' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/products/fill-batch',
			array_merge( $products, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'products_fill_batch' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/calendar',
			array(
				array_merge( $edit, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'calendar_list' ) ) ),
				array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'calendar_create' ) ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/ai-content/calendar/bulk',
			array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'calendar_bulk' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/calendar/(?P<id>\d+)',
			array(
				array_merge( $edit, array( 'methods' => 'PATCH', 'callback' => array( __CLASS__, 'calendar_patch' ) ) ),
				array_merge( $edit, array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'calendar_delete' ) ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/ai-content/calendar/run-due',
			array_merge( $manage, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'calendar_run_due' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/attribute-templates',
			array(
				array_merge( $terms, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'attr_list' ) ) ),
				array_merge( $terms, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'attr_confirm' ) ) ),
			)
		);

		register_rest_route(
			self::NS,
			'/ai-content/attribute-templates/(?P<cat_id>\d+)/suggest',
			array_merge( $terms, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'attr_suggest' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/attribute-templates/(?P<cat_id>\d+)/draft',
			array_merge( $terms, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'attr_draft' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/attribute-templates/(?P<cat_id>\d+)',
			array_merge( $terms, array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'attr_delete' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/suggest-categories',
			array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'suggest_categories' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/suggest-categories/(?P<kind>blog|product)',
			array_merge( $edit, array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'suggest_categories_get' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/suggest-categories/(?P<kind>blog|product)/apply',
			array_merge( $edit, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'suggest_categories_apply' ) ) )
		);

		register_rest_route(
			self::NS,
			'/ai-content/terms/fill-batch',
			array_merge( $terms, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'terms_fill_batch' ) ) )
		);
	}

	/** @return bool */
	public static function perm_edit() {
		return Webino_Dashboard_Rest_Base::can( 'edit_posts' );
	}

	/** @return bool */
	public static function perm_manage() {
		return Webino_Dashboard_Rest_Base::can( 'manage_options' );
	}

	/** @return bool */
	public static function perm_products() {
		return Webino_Dashboard_Rest_Base::can( 'edit_products' );
	}

	/** @return bool */
	public static function perm_terms() {
		return Webino_Dashboard_Rest_Base::can( 'manage_product_terms' );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function overview() {
		return new WP_REST_Response( Webino_Dashboard_AI_Content::overview() );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function settings_get() {
		return new WP_REST_Response( Webino_Dashboard_AI_Content_Settings::get_public() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function settings_post( $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = $request->get_params();
		}
		return new WP_REST_Response( Webino_Dashboard_AI_Content_Settings::save( is_array( $body ) ? $body : array() ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function jobs_list( $request ) {
		return new WP_REST_Response(
			Webino_Dashboard_AI_Queue::list_jobs(
				array(
					'status' => (string) $request->get_param( 'status' ),
					'limit'  => (int) $request->get_param( 'limit' ),
					'offset' => (int) $request->get_param( 'offset' ),
				)
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function jobs_retry( $request ) {
		global $wpdb;
		$id    = (int) $request['id'];
		$table = Webino_Dashboard_AI_Content_Db::table( 'jobs' );
		$wpdb->update(
			$table,
			array(
				'status'        => 'pending',
				'error_message' => '',
				'updated_at'    => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		Webino_Dashboard_AI_Queue::schedule( $id );
		return new WP_REST_Response( array( 'ok' => true, 'id' => $id ) );
	}

	/**
	 * Immediate or queued generate for a single entity.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function generate( $request ) {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}
		$type   = sanitize_key( (string) ( $body['type'] ?? '' ) );
		$id     = (int) ( $body['id'] ?? 0 );
		$sync   = ! empty( $body['sync'] );
		$payload = isset( $body['payload'] ) && is_array( $body['payload'] ) ? $body['payload'] : array();

		$map = array(
			'product'      => array( 'product_fill', 'product' ),
			'post'         => array( 'blog_write', 'post' ),
			'product_cat'  => array( 'term_fill', 'product_cat' ),
			'product_brand'=> array( 'term_fill', 'product_brand' ),
			'blog'         => array( 'blog_write', 'calendar' ),
		);

		if ( ! isset( $map[ $type ] ) ) {
			return new WP_Error( 'invalid_type', __( 'Invalid generate type.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}

		if ( 'post' === $type ) {
			$payload['post_id'] = $id;
		}
		if ( 'blog' === $type ) {
			$payload = array_merge( $payload, array(
				'topic'         => (string) ( $body['topic'] ?? '' ),
				'focus_keyword' => (string) ( $body['focus_keyword'] ?? '' ),
			) );
		}

		$job_type    = $map[ $type ][0];
		$target_type = $map[ $type ][1];
		$job_id      = Webino_Dashboard_AI_Queue::enqueue( $job_type, $target_type, $id, $payload );

		if ( $sync ) {
			Webino_Dashboard_AI_Queue::process_job( $job_id );
			$listed = Webino_Dashboard_AI_Queue::list_jobs( array( 'limit' => 1 ) );
			$job    = null;
			foreach ( $listed['items'] as $row ) {
				if ( (int) $row['id'] === $job_id ) {
					$job = $row;
					break;
				}
			}
			return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job_id, 'job' => $job ) );
		}

		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job_id, 'queued' => true ), 202 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function products_incomplete( $request ) {
		$limit = (int) $request->get_param( 'limit' );
		return new WP_REST_Response( Webino_Dashboard_AI_Content::incomplete_products( $limit > 0 ? $limit : 50 ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function products_fill_batch( $request ) {
		$body = $request->get_json_params();
		$ids  = isset( $body['ids'] ) && is_array( $body['ids'] ) ? array_map( 'intval', $body['ids'] ) : array();
		if ( ! $ids ) {
			$incomplete = Webino_Dashboard_AI_Content::incomplete_products( (int) ( $body['limit'] ?? 10 ) );
			$ids        = array_map(
				static function ( $row ) {
					return (int) $row['id'];
				},
				$incomplete['items']
			);
		}
		$job_ids = array();
		foreach ( $ids as $pid ) {
			if ( $pid <= 0 ) {
				continue;
			}
			$job_ids[] = Webino_Dashboard_AI_Queue::enqueue( 'product_fill', 'product', $pid, array() );
		}
		return new WP_REST_Response( array( 'ok' => true, 'job_ids' => $job_ids, 'count' => count( $job_ids ) ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function calendar_list( $request ) {
		return new WP_REST_Response(
			Webino_Dashboard_AI_Calendar::list_slots(
				array(
					'from' => (string) $request->get_param( 'from' ),
					'to'   => (string) $request->get_param( 'to' ),
				)
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function calendar_create( $request ) {
		$body = $request->get_json_params();
		$slot = Webino_Dashboard_AI_Calendar::create_slot( is_array( $body ) ? $body : array() );
		if ( is_wp_error( $slot ) ) {
			return $slot;
		}
		return new WP_REST_Response( $slot, 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function calendar_bulk( $request ) {
		$body = $request->get_json_params();
		return new WP_REST_Response( Webino_Dashboard_AI_Calendar::bulk_from_topics( is_array( $body ) ? $body : array() ), 201 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function calendar_patch( $request ) {
		$body = $request->get_json_params();
		$slot = Webino_Dashboard_AI_Calendar::update_slot( (int) $request['id'], is_array( $body ) ? $body : array() );
		if ( is_wp_error( $slot ) ) {
			return $slot;
		}
		return new WP_REST_Response( $slot );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function calendar_delete( $request ) {
		Webino_Dashboard_AI_Calendar::delete_slot( (int) $request['id'] );
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function calendar_run_due() {
		Webino_Dashboard_AI_Calendar::run_daily();
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @return WP_REST_Response
	 */
	public static function attr_list() {
		return new WP_REST_Response( Webino_Dashboard_AI_Attributes::list_templates() );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function attr_suggest( $request ) {
		$cat_id = (int) $request['cat_id'];
		$job_id = Webino_Dashboard_AI_Queue::enqueue( 'attr_template', 'product_cat', $cat_id, array() );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job_id ), 202 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function attr_draft( $request ) {
		$cat_id = (int) $request['cat_id'];
		$draft  = get_transient( 'webino_ai_attr_draft_' . $cat_id );
		return new WP_REST_Response(
			array(
				'product_cat_id' => $cat_id,
				'draft'          => is_array( $draft ) ? $draft : null,
				'template'       => Webino_Dashboard_AI_Attributes::get_template( $cat_id ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function attr_confirm( $request ) {
		$body   = $request->get_json_params();
		$cat_id = (int) ( $body['product_cat_id'] ?? 0 );
		$draft  = isset( $body['draft'] ) && is_array( $body['draft'] ) ? $body['draft'] : get_transient( 'webino_ai_attr_draft_' . $cat_id );
		if ( ! is_array( $draft ) ) {
			return new WP_Error( 'no_draft', __( 'No attribute draft to confirm.', 'webino-dashboard' ), array( 'status' => 400 ) );
		}
		$saved = Webino_Dashboard_AI_Attributes::confirm_template( $cat_id, $draft );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return new WP_REST_Response( $saved );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function attr_delete( $request ) {
		Webino_Dashboard_AI_Attributes::delete_template( (int) $request['cat_id'] );
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function suggest_categories( $request ) {
		$body = $request->get_json_params();
		$kind = sanitize_key( (string) ( $body['kind'] ?? 'blog' ) );
		if ( ! in_array( $kind, array( 'blog', 'product' ), true ) ) {
			$kind = 'blog';
		}
		$job_type = 'blog' === $kind ? 'suggest_blog_categories' : 'suggest_product_categories';
		$payload  = array();
		if ( 'product' === $kind && function_exists( 'wc_get_products' ) ) {
			$ids = wc_get_products( array( 'limit' => 15, 'status' => 'publish', 'return' => 'ids' ) );
			$samples = array();
			foreach ( (array) $ids as $id ) {
				$p = wc_get_product( (int) $id );
				if ( $p ) {
					$samples[] = $p->get_name();
				}
			}
			$payload['product_samples'] = $samples;
		}
		$job_id = Webino_Dashboard_AI_Queue::enqueue( $job_type, 'suggest', 0, $payload );
		return new WP_REST_Response( array( 'ok' => true, 'job_id' => $job_id ), 202 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function suggest_categories_get( $request ) {
		$kind = sanitize_key( (string) $request['kind'] );
		$data = get_transient( 'webino_ai_suggest_cats_' . $kind );
		return new WP_REST_Response(
			array(
				'kind'        => $kind,
				'suggestions' => is_array( $data ) ? $data : null,
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function suggest_categories_apply( $request ) {
		$kind = sanitize_key( (string) $request['kind'] );
		$body = $request->get_json_params();
		$data = isset( $body['categories'] ) && is_array( $body['categories'] ) ? $body['categories'] : null;
		if ( ! $data ) {
			$stored = get_transient( 'webino_ai_suggest_cats_' . $kind );
			$data   = is_array( $stored ) && isset( $stored['categories'] ) ? $stored['categories'] : array();
		}
		$tax     = 'blog' === $kind ? 'category' : 'product_cat';
		$created = array();
		foreach ( (array) $data as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name = sanitize_text_field( (string) ( $row['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$parent = 0;
			if ( ! empty( $row['parent'] ) ) {
				$pterm = term_exists( sanitize_text_field( (string) $row['parent'] ), $tax );
				if ( $pterm && ! is_wp_error( $pterm ) ) {
					$parent = (int) ( is_array( $pterm ) ? $pterm['term_id'] : $pterm );
				}
			}
			$exists = term_exists( $name, $tax );
			if ( $exists && ! is_wp_error( $exists ) ) {
				$tid = (int) ( is_array( $exists ) ? $exists['term_id'] : $exists );
			} else {
				$ins = wp_insert_term(
					$name,
					$tax,
					array(
						'slug'        => sanitize_title( (string) ( $row['slug'] ?? $name ) ),
						'description' => sanitize_textarea_field( (string) ( $row['description'] ?? '' ) ),
						'parent'      => $parent,
					)
				);
				if ( is_wp_error( $ins ) ) {
					continue;
				}
				$tid = (int) $ins['term_id'];
			}
			$created[] = $tid;
			if ( ! empty( $row['children'] ) && is_array( $row['children'] ) ) {
				foreach ( $row['children'] as $child ) {
					$cname = is_string( $child ) ? $child : (string) ( $child['name'] ?? '' );
					$cname = sanitize_text_field( $cname );
					if ( '' === $cname || term_exists( $cname, $tax ) ) {
						continue;
					}
					$cins = wp_insert_term( $cname, $tax, array( 'parent' => $tid ) );
					if ( ! is_wp_error( $cins ) ) {
						$created[] = (int) $cins['term_id'];
					}
				}
			}
		}
		return new WP_REST_Response( array( 'ok' => true, 'created_ids' => $created, 'count' => count( $created ) ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function terms_fill_batch( $request ) {
		$body     = $request->get_json_params();
		$taxonomy = sanitize_key( (string) ( $body['taxonomy'] ?? 'product_cat' ) );
		if ( ! in_array( $taxonomy, array( 'product_cat', 'product_brand' ), true ) ) {
			$taxonomy = 'product_cat';
		}
		$ids = isset( $body['ids'] ) && is_array( $body['ids'] ) ? array_map( 'intval', $body['ids'] ) : array();
		if ( ! $ids ) {
			$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'number' => 30 ) );
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$desc = trim( wp_strip_all_tags( $t->description ) );
					$seo  = (string) get_term_meta( (int) $t->term_id, 'rank_math_focus_keyword', true );
					if ( mb_strlen( $desc ) < 80 || '' === $seo ) {
						$ids[] = (int) $t->term_id;
					}
				}
			}
		}
		$job_ids = array();
		foreach ( $ids as $tid ) {
			if ( $tid <= 0 ) {
				continue;
			}
			$job_ids[] = Webino_Dashboard_AI_Queue::enqueue( 'term_fill', $taxonomy, $tid, array() );
		}
		return new WP_REST_Response( array( 'ok' => true, 'job_ids' => $job_ids, 'count' => count( $job_ids ) ) );
	}
}
