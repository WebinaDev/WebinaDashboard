<?php
/**
 * Prompt builders for AI content jobs.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * System + user prompts and JSON schemas.
 */
final class Webino_Dashboard_AI_Prompts {

	/**
	 * @return string
	 */
	public static function system_rules() {
		$s         = Webino_Dashboard_AI_Content_Settings::get();
		$site_name = (string) get_bloginfo( 'name' );
		$lang      = 'fa' === ( $s['language'] ?? 'fa' ) ? 'Persian (Farsi)' : 'English';
		$topic     = (string) ( $s['site_topic'] ?? '' );
		$tone      = (string) ( $s['tone'] ?? 'professional_friendly' );
		$sep       = (string) ( $s['seo_sep'] ?? ' - ' );

		return <<<PROMPT
You are an expert SEO content writer for an e-commerce WordPress/WooCommerce site.
Write in {$lang}. Tone: {$tone}.
Site name: "{$site_name}". Site topic/niche: "{$topic}".
Always mention the site name naturally at least once near the introduction and once in the conclusion.
Follow Rank Math and Google helpful-content best practices:
- Primary focus keyword in title, slug, first ~100 words, at least one H2, SEO title, meta description.
- Keyword density roughly 0.5%–1.5%; never stuff.
- SEO title length ~10–60 chars; meta description ~70–160 chars.
- Prefer SEO title pattern: %title%{$sep}%sitename% or a crafted title that includes the site name when natural.
- Use clear H2/H3 hierarchy. No medical/legal claims without sources. No fluff.
- Add 2–4 internal link placeholders as HTML anchors with paths like /product/... or /magazine/... when related items are provided.
- Return ONLY valid JSON. No markdown fences.
PROMPT;
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function product_schema() {
		return array(
			'name'              => 'string',
			'slug'              => 'string-kebab',
			'short_description' => 'html-short',
			'description'       => 'html-long-with-h2-h3',
			'english_name'      => 'string',
			'tags'              => array( 'string' ),
			'focus_keyword'     => 'string',
			'seo'               => array(
				'title'             => 'string',
				'description'       => 'string',
				'focus_keyword'     => 'string',
				'breadcrumb_title'  => 'string',
				'facebook_title'    => 'string',
				'facebook_description' => 'string',
				'twitter_title'     => 'string',
				'twitter_description' => 'string',
				'schema_type'       => 'product',
				'brand'             => 'string',
			),
			'faqs'              => array(
				array( 'question' => 'string', 'answer' => 'string' ),
			),
			'ai_review_summary' => 'string',
			'attributes'        => array(
				array( 'name' => 'string', 'options' => array( 'string' ) ),
			),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function blog_schema() {
		return array(
			'title'          => 'string',
			'slug'           => 'string-kebab',
			'excerpt'        => 'string',
			'content'        => 'html-long-with-h2-h3',
			'focus_keyword'  => 'string',
			'tags'           => array( 'string' ),
			'category_names' => array( 'string' ),
			'seo'            => array(
				'title'            => 'string',
				'description'      => 'string',
				'focus_keyword'    => 'string',
				'breadcrumb_title' => 'string',
				'schema_type'      => 'article',
			),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function term_schema() {
		return array(
			'description'   => 'html-long',
			'focus_keyword' => 'string',
			'seo'           => array(
				'title'         => 'string',
				'description'   => 'string',
				'focus_keyword' => 'string',
				'schema_type'   => 'collectionpage',
			),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function categories_schema() {
		return array(
			'categories' => array(
				array(
					'name'        => 'string',
					'slug'        => 'string',
					'description' => 'string',
					'parent'      => 'string-or-empty',
					'children'    => array( 'string' ),
				),
			),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function attribute_template_schema() {
		return array(
			'attributes' => array(
				array(
					'label'   => 'string',
					'slug'    => 'string',
					'options' => array( 'string' ),
				),
			),
		);
	}

	/**
	 * @param array<string,mixed> $ctx Context.
	 * @return string
	 */
	public static function product_user( $ctx ) {
		$s = Webino_Dashboard_AI_Content_Settings::get();
		return wp_json_encode(
			array(
				'task'                 => 'Complete WooCommerce product content for all SEO and marketing fields.',
				'product'              => $ctx,
				'min_description_words'=> (int) $s['min_product_words'],
				'include_faqs'         => 4,
				'attribute_template'   => $ctx['attribute_template'] ?? array(),
				'related_products'     => $ctx['related'] ?? array(),
				'instructions'         => 'Keep existing factual data (SKU, brand, price cues). Fill empty fields. If attribute_template is set, only fill those attribute names with values; do not invent new attribute names.',
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);
	}

	/**
	 * @param array<string,mixed> $ctx Context.
	 * @return string
	 */
	public static function blog_user( $ctx ) {
		$s = Webino_Dashboard_AI_Content_Settings::get();
		return wp_json_encode(
			array(
				'task'            => 'Write a helpful blog post.',
				'topic'           => $ctx['topic'] ?? '',
				'focus_keyword'   => $ctx['focus_keyword'] ?? '',
				'secondary'       => $ctx['secondary_keywords'] ?? array(),
				'category'        => $ctx['category'] ?? '',
				'related'         => $ctx['related'] ?? array(),
				'min_words'       => (int) $s['min_blog_words'],
				'publish_as'      => $s['auto_publish'] ? $s['publish_status'] : 'draft',
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);
	}

	/**
	 * @param array<string,mixed> $ctx Context.
	 * @return string
	 */
	public static function term_user( $ctx ) {
		$s = Webino_Dashboard_AI_Content_Settings::get();
		return wp_json_encode(
			array(
				'task'          => 'Write archive/landing content for a WooCommerce taxonomy term.',
				'term'          => $ctx,
				'min_words'     => (int) $s['min_term_words'],
				'focus_keyword' => $ctx['focus_keyword'] ?? ( $ctx['name'] ?? '' ),
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);
	}
}
