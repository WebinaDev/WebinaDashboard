<?php
/**
 * AI Content settings.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site profile, providers, quotas, SEO rules toggles.
 */
final class Webino_Dashboard_AI_Content_Settings {

	const OPTION = 'webino_dashboard_ai_content_settings';

	/**
	 * @return array<string,mixed>
	 */
	public static function defaults() {
		$lang = get_locale();
		if ( 0 === strpos( (string) $lang, 'fa' ) ) {
			$lang = 'fa';
		} else {
			$lang = 'en';
		}

		return array(
			'default_provider'       => 'grok',
			'fallback_order'         => array( 'grok', 'gemini', 'openai' ),
			'grok_api_key'           => '',
			'gemini_api_key'         => '',
			'openai_api_key'         => '',
			'grok_model'             => 'grok-2-latest',
			'gemini_model'           => 'gemini-2.0-flash',
			'openai_model'           => 'gpt-4o-mini',
			'site_topic'             => (string) get_option( 'blogdescription', '' ),
			'tone'                   => 'professional_friendly',
			'language'               => $lang,
			'seo_sep'                => ' - ',
			'daily_blog_quota'       => 1,
			'daily_product_quota'    => 5,
			'auto_publish'           => false,
			'publish_status'         => 'draft',
			'min_blog_words'         => 900,
			'min_product_words'      => 400,
			'min_term_words'         => 250,
			'require_site_name'      => true,
			'internal_links_min'     => 2,
			'internal_links_max'     => 4,
			'max_regenerate'         => 2,
			'similarity_threshold'   => 0.72,
			'enabled'                => true,
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function get() {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$merged = array_merge( self::defaults(), $stored );

		foreach ( array( 'grok_api_key', 'gemini_api_key', 'openai_api_key' ) as $k ) {
			if ( ! empty( $merged[ $k ] ) && 0 === strpos( (string) $merged[ $k ], 'enc:' ) ) {
				$merged[ $k ] = Webino_Dashboard_AI_Content_Crypto::decrypt( substr( (string) $merged[ $k ], 4 ) );
			}
		}

		return $merged;
	}

	/**
	 * Settings safe for REST (masked keys).
	 *
	 * @return array<string,mixed>
	 */
	public static function get_public() {
		$s = self::get();
		$s['grok_api_key_masked']   = Webino_Dashboard_AI_Content_Crypto::mask( (string) $s['grok_api_key'] );
		$s['gemini_api_key_masked'] = Webino_Dashboard_AI_Content_Crypto::mask( (string) $s['gemini_api_key'] );
		$s['openai_api_key_masked'] = Webino_Dashboard_AI_Content_Crypto::mask( (string) $s['openai_api_key'] );
		$s['has_grok_key']          = '' !== trim( (string) $s['grok_api_key'] );
		$s['has_gemini_key']        = '' !== trim( (string) $s['gemini_api_key'] );
		$s['has_openai_key']        = '' !== trim( (string) $s['openai_api_key'] );
		unset( $s['grok_api_key'], $s['gemini_api_key'], $s['openai_api_key'] );
		$s['site_name'] = (string) get_bloginfo( 'name' );
		return $s;
	}

	/**
	 * @param array<string,mixed> $input Raw.
	 * @return array<string,mixed>
	 */
	public static function sanitize( $input ) {
		$cur  = self::get();
		$raw  = is_array( $input ) ? $input : array();
		$out  = $cur;

		$providers = array( 'grok', 'gemini', 'openai' );
		if ( isset( $raw['default_provider'] ) ) {
			$p = sanitize_key( (string) $raw['default_provider'] );
			$out['default_provider'] = in_array( $p, $providers, true ) ? $p : 'grok';
		}

		if ( isset( $raw['fallback_order'] ) && is_array( $raw['fallback_order'] ) ) {
			$order = array();
			foreach ( $raw['fallback_order'] as $item ) {
				$k = sanitize_key( (string) $item );
				if ( in_array( $k, $providers, true ) && ! in_array( $k, $order, true ) ) {
					$order[] = $k;
				}
			}
			if ( $order ) {
				$out['fallback_order'] = $order;
			}
		}

		foreach ( array( 'grok_model', 'gemini_model', 'openai_model', 'site_topic', 'tone', 'seo_sep' ) as $key ) {
			if ( array_key_exists( $key, $raw ) ) {
				$out[ $key ] = sanitize_text_field( (string) $raw[ $key ] );
			}
		}

		if ( isset( $raw['language'] ) ) {
			$lang = sanitize_key( (string) $raw['language'] );
			$out['language'] = in_array( $lang, array( 'fa', 'en' ), true ) ? $lang : 'fa';
		}

		foreach ( array( 'daily_blog_quota', 'daily_product_quota', 'min_blog_words', 'min_product_words', 'min_term_words', 'internal_links_min', 'internal_links_max', 'max_regenerate' ) as $ikey ) {
			if ( array_key_exists( $ikey, $raw ) ) {
				$out[ $ikey ] = max( 0, (int) $raw[ $ikey ] );
			}
		}

		if ( array_key_exists( 'similarity_threshold', $raw ) ) {
			$out['similarity_threshold'] = min( 0.99, max( 0.3, (float) $raw['similarity_threshold'] ) );
		}

		foreach ( array( 'auto_publish', 'require_site_name', 'enabled' ) as $bkey ) {
			if ( array_key_exists( $bkey, $raw ) ) {
				$out[ $bkey ] = (bool) $raw[ $bkey ];
			}
		}

		if ( isset( $raw['publish_status'] ) ) {
			$st = sanitize_key( (string) $raw['publish_status'] );
			$out['publish_status'] = in_array( $st, array( 'draft', 'publish', 'pending' ), true ) ? $st : 'draft';
		}

		foreach ( array( 'grok_api_key', 'gemini_api_key', 'openai_api_key' ) as $kkey ) {
			if ( ! array_key_exists( $kkey, $raw ) ) {
				continue;
			}
			$val = trim( (string) $raw[ $kkey ] );
			if ( '' === $val || false !== strpos( $val, '*' ) ) {
				continue;
			}
			$out[ $kkey ] = $val;
		}

		return $out;
	}

	/**
	 * @param array<string,mixed> $input Raw.
	 * @return array<string,mixed>
	 */
	public static function save( $input ) {
		$sanitized = self::sanitize( $input );
		$store     = $sanitized;

		foreach ( array( 'grok_api_key', 'gemini_api_key', 'openai_api_key' ) as $k ) {
			$plain = (string) ( $store[ $k ] ?? '' );
			$store[ $k ] = '' === $plain ? '' : ( 'enc:' . Webino_Dashboard_AI_Content_Crypto::encrypt( $plain ) );
		}

		update_option( self::OPTION, $store, false );
		return self::get_public();
	}
}
