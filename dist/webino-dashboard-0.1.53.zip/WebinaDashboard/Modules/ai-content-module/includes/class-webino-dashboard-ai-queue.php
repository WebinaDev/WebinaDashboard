<?php
/**
 * AI Content job queue (Action Scheduler / WP-Cron).
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue and process generation jobs.
 */
final class Webino_Dashboard_AI_Queue {

	const HOOK       = 'webino_dashboard_ai_content_process_job';
	const CRON_DAILY = 'webino_dashboard_ai_content_daily';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'process_job' ), 10, 1 );
		add_action( self::CRON_DAILY, array( 'Webino_Dashboard_AI_Calendar', 'run_daily' ) );
		if ( ! wp_next_scheduled( self::CRON_DAILY ) ) {
			wp_schedule_event( time() + 300, 'daily', self::CRON_DAILY );
		}
	}

	/**
	 * @param string               $job_type Type.
	 * @param string               $target_type Target type.
	 * @param int                  $target_id Target ID.
	 * @param array<string,mixed>  $payload Payload.
	 * @return int Job ID.
	 */
	public static function enqueue( $job_type, $target_type, $target_id, $payload = array() ) {
		global $wpdb;
		$table = Webino_Dashboard_AI_Content_Db::table( 'jobs' );
		$now   = current_time( 'mysql', true );

		$wpdb->insert(
			$table,
			array(
				'job_type'    => sanitize_key( $job_type ),
				'target_type' => sanitize_key( $target_type ),
				'target_id'   => (int) $target_id,
				'payload'     => wp_json_encode( $payload ),
				'status'      => 'pending',
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		$job_id = (int) $wpdb->insert_id;
		self::schedule( $job_id );
		return $job_id;
	}

	/**
	 * @param int $job_id Job ID.
	 * @return void
	 */
	public static function schedule( $job_id ) {
		$job_id = (int) $job_id;
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::HOOK, array( $job_id ), 'webino-ai-content' );
			return;
		}
		if ( ! wp_next_scheduled( self::HOOK, array( $job_id ) ) ) {
			wp_schedule_single_event( time() + 5, self::HOOK, array( $job_id ) );
		}
		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	/**
	 * @param int $job_id Job ID.
	 * @return void
	 */
	public static function process_job( $job_id ) {
		global $wpdb;
		$job_id = (int) $job_id;
		$table  = Webino_Dashboard_AI_Content_Db::table( 'jobs' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );
		if ( ! $job || 'pending' !== $job['status'] && 'running' !== $job['status'] ) {
			return;
		}

		$wpdb->update(
			$table,
			array(
				'status'     => 'running',
				'started_at' => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
				'attempts'   => (int) $job['attempts'] + 1,
			),
			array( 'id' => $job_id ),
			array( '%s', '%s', '%s', '%d' ),
			array( '%d' )
		);

		$payload = json_decode( (string) $job['payload'], true );
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		try {
			$result = self::run_job_logic( (string) $job['job_type'], (string) $job['target_type'], (int) $job['target_id'], $payload );
			if ( is_wp_error( $result ) ) {
				self::fail_job( $job_id, $result->get_error_message() );
				return;
			}
			$wpdb->update(
				$table,
				array(
					'status'         => 'done',
					'provider'       => (string) ( $result['provider'] ?? '' ),
					'tokens_in'      => (int) ( $result['tokens_in'] ?? 0 ),
					'tokens_out'     => (int) ( $result['tokens_out'] ?? 0 ),
					'result_summary' => sanitize_text_field( (string) ( $result['summary'] ?? 'OK' ) ),
					'finished_at'    => current_time( 'mysql', true ),
					'updated_at'     => current_time( 'mysql', true ),
					'error_message'  => '',
				),
				array( 'id' => $job_id ),
				array( '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);
		} catch ( Exception $e ) {
			self::fail_job( $job_id, $e->getMessage() );
		}
	}

	/**
	 * @param int    $job_id Job.
	 * @param string $message Error.
	 * @return void
	 */
	private static function fail_job( $job_id, $message ) {
		global $wpdb;
		$table = Webino_Dashboard_AI_Content_Db::table( 'jobs' );
		$wpdb->update(
			$table,
			array(
				'status'        => 'failed',
				'error_message' => sanitize_text_field( $message ),
				'finished_at'   => current_time( 'mysql', true ),
				'updated_at'    => current_time( 'mysql', true ),
			),
			array( 'id' => (int) $job_id ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * @param string              $job_type Type.
	 * @param string              $target_type Target.
	 * @param int                 $target_id ID.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function run_job_logic( $job_type, $target_type, $target_id, $payload ) {
		$settings = Webino_Dashboard_AI_Content_Settings::get();
		$max_try  = max( 1, (int) $settings['max_regenerate'] + 1 );
		$last_err = '';

		for ( $i = 0; $i < $max_try; $i++ ) {
			if ( 'product_fill' === $job_type ) {
				$out = self::job_product_fill( $target_id, $payload );
			} elseif ( 'blog_write' === $job_type ) {
				$out = self::job_blog_write( $target_id, $payload );
			} elseif ( 'term_fill' === $job_type ) {
				$out = self::job_term_fill( $target_type, $target_id, $payload );
			} elseif ( 'suggest_blog_categories' === $job_type ) {
				$out = self::job_suggest_categories( 'blog', $payload );
			} elseif ( 'suggest_product_categories' === $job_type ) {
				$out = self::job_suggest_categories( 'product', $payload );
			} elseif ( 'attr_template' === $job_type ) {
				$out = self::job_attr_template( $target_id, $payload );
			} else {
				return new WP_Error( 'ai_job', __( 'Unknown job type.', 'webino-dashboard' ) );
			}

			if ( ! is_wp_error( $out ) ) {
				return $out;
			}
			$last_err = $out->get_error_message();
			$payload['regenerate_hint'] = $last_err;
		}

		return new WP_Error( 'ai_job', $last_err ?: __( 'Generation failed.', 'webino-dashboard' ) );
	}

	/**
	 * @param int                 $product_id Product.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_product_fill( $product_id, $payload ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return new WP_Error( 'no_wc', 'WooCommerce required' );
		}
		$p = wc_get_product( (int) $product_id );
		if ( ! $p ) {
			return new WP_Error( 'not_found', 'Product not found' );
		}

		$cats = array();
		foreach ( $p->get_category_ids() as $cid ) {
			$t = get_term( (int) $cid, 'product_cat' );
			if ( $t && ! is_wp_error( $t ) ) {
				$cats[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
			}
		}

		$attr_template = array();
		$attr_ids      = array();
		if ( $cats ) {
			$tpl = Webino_Dashboard_AI_Attributes::get_template( (int) $cats[0]['id'] );
			if ( $tpl ) {
				$attr_ids      = $tpl['attribute_ids'];
				$attr_template = $tpl['labels'];
			}
		}

		$ctx = array(
			'id'                 => (int) $product_id,
			'name'               => $p->get_name(),
			'sku'                => $p->get_sku(),
			'short_description'  => $p->get_short_description(),
			'description'        => $p->get_description(),
			'categories'         => $cats,
			'focus_keyword'      => (string) ( $payload['focus_keyword'] ?? '' ),
			'attribute_template' => $attr_template,
			'related'            => self::related_products( (int) $product_id ),
			'regenerate_hint'    => (string) ( $payload['regenerate_hint'] ?? '' ),
		);

		$result = Webino_Dashboard_AI_Providers::complete(
			Webino_Dashboard_AI_Prompts::system_rules(),
			Webino_Dashboard_AI_Prompts::product_user( $ctx ),
			Webino_Dashboard_AI_Prompts::product_schema()
		);
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'ai_provider', (string) ( $result['error'] ?? 'fail' ) );
		}

		$data = $result['data'];
		$gate = Webino_Dashboard_AI_Seo_Gate::validate(
			$data,
			'product',
			array(
				'focus_keyword' => (string) ( $data['focus_keyword'] ?? $data['seo']['focus_keyword'] ?? $p->get_name() ),
				'exclude_type'  => 'product',
				'exclude_id'    => (int) $product_id,
			)
		);
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$settings = Webino_Dashboard_AI_Content_Settings::get();
		$applied  = Webino_Dashboard_AI_Writer::apply_product(
			(int) $product_id,
			$data,
			array(
				'attribute_ids' => $attr_ids,
				'set_status'    => ! empty( $payload['set_status'] ),
				'publish'       => ! empty( $settings['auto_publish'] ),
				'status'        => $settings['publish_status'],
			)
		);
		if ( is_wp_error( $applied ) ) {
			return $applied;
		}

		return array(
			'provider'   => $result['provider'] ?? '',
			'tokens_in'  => $result['tokens_in'] ?? 0,
			'tokens_out' => $result['tokens_out'] ?? 0,
			'summary'    => 'Product #' . $product_id . ' updated',
		);
	}

	/**
	 * @param int                 $calendar_or_post_id Calendar slot or post id.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_blog_write( $calendar_or_post_id, $payload ) {
		$ctx = array(
			'topic'               => (string) ( $payload['topic'] ?? '' ),
			'focus_keyword'       => (string) ( $payload['focus_keyword'] ?? '' ),
			'secondary_keywords'  => $payload['secondary_keywords'] ?? array(),
			'category'            => (string) ( $payload['category'] ?? '' ),
			'related'             => self::related_posts(),
			'regenerate_hint'     => (string) ( $payload['regenerate_hint'] ?? '' ),
		);

		$result = Webino_Dashboard_AI_Providers::complete(
			Webino_Dashboard_AI_Prompts::system_rules(),
			Webino_Dashboard_AI_Prompts::blog_user( $ctx ),
			Webino_Dashboard_AI_Prompts::blog_schema()
		);
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'ai_provider', (string) ( $result['error'] ?? 'fail' ) );
		}

		$data = $result['data'];
		$gate = Webino_Dashboard_AI_Seo_Gate::validate(
			$data,
			'blog',
			array(
				'focus_keyword' => (string) ( $data['focus_keyword'] ?? $ctx['focus_keyword'] ),
				'exclude_type'  => 'post',
				'exclude_id'    => (int) ( $payload['post_id'] ?? 0 ),
			)
		);
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$post_id = Webino_Dashboard_AI_Writer::create_or_update_post(
			$data,
			array(
				'post_id'     => (int) ( $payload['post_id'] ?? 0 ),
				'category_id' => (int) ( $payload['category_id'] ?? 0 ),
				'publish'     => ! empty( $payload['publish'] ),
			)
		);
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( ! empty( $payload['calendar_id'] ) ) {
			Webino_Dashboard_AI_Calendar::mark_done( (int) $payload['calendar_id'], (int) $post_id );
		}

		return array(
			'provider'   => $result['provider'] ?? '',
			'tokens_in'  => $result['tokens_in'] ?? 0,
			'tokens_out' => $result['tokens_out'] ?? 0,
			'summary'    => 'Post #' . $post_id . ' created',
			'post_id'    => (int) $post_id,
		);
	}

	/**
	 * @param string              $taxonomy Taxonomy.
	 * @param int                 $term_id Term.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_term_fill( $taxonomy, $term_id, $payload ) {
		$term = get_term( (int) $term_id, sanitize_key( $taxonomy ) );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'not_found', 'Term not found' );
		}

		$ctx = array(
			'id'              => (int) $term_id,
			'name'            => $term->name,
			'slug'            => $term->slug,
			'taxonomy'        => $taxonomy,
			'description'     => $term->description,
			'focus_keyword'   => (string) ( $payload['focus_keyword'] ?? $term->name ),
			'regenerate_hint' => (string) ( $payload['regenerate_hint'] ?? '' ),
		);

		$result = Webino_Dashboard_AI_Providers::complete(
			Webino_Dashboard_AI_Prompts::system_rules(),
			Webino_Dashboard_AI_Prompts::term_user( $ctx ),
			Webino_Dashboard_AI_Prompts::term_schema()
		);
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'ai_provider', (string) ( $result['error'] ?? 'fail' ) );
		}

		$data = $result['data'];
		$gate = Webino_Dashboard_AI_Seo_Gate::validate(
			array_merge( $data, array( 'title' => $term->name ) ),
			'term',
			array(
				'focus_keyword' => (string) ( $data['focus_keyword'] ?? $term->name ),
				'exclude_type'  => $taxonomy,
				'exclude_id'    => (int) $term_id,
			)
		);
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$applied = Webino_Dashboard_AI_Writer::apply_term( (int) $term_id, $taxonomy, $data );
		if ( is_wp_error( $applied ) ) {
			return $applied;
		}

		return array(
			'provider'   => $result['provider'] ?? '',
			'tokens_in'  => $result['tokens_in'] ?? 0,
			'tokens_out' => $result['tokens_out'] ?? 0,
			'summary'    => $taxonomy . ' #' . $term_id . ' updated',
		);
	}

	/**
	 * @param string              $kind blog|product.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_suggest_categories( $kind, $payload ) {
		$settings = Webino_Dashboard_AI_Content_Settings::get();
		$existing = array();
		$tax      = 'blog' === $kind ? 'category' : 'product_cat';
		$terms    = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'number' => 100 ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$existing[] = $t->name;
			}
		}

		$user = wp_json_encode(
			array(
				'task'              => 'blog' === $kind ? 'Suggest blog category tree for this site niche.' : 'Suggest product categories for uncategorized products.',
				'site_topic'        => $settings['site_topic'],
				'existing'          => $existing,
				'product_samples'   => $payload['product_samples'] ?? array(),
				'regenerate_hint'   => (string) ( $payload['regenerate_hint'] ?? '' ),
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);

		$result = Webino_Dashboard_AI_Providers::complete(
			Webino_Dashboard_AI_Prompts::system_rules(),
			$user,
			Webino_Dashboard_AI_Prompts::categories_schema()
		);
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'ai_provider', (string) ( $result['error'] ?? 'fail' ) );
		}

		set_transient( 'webino_ai_suggest_cats_' . $kind, $result['data'], DAY_IN_SECONDS );

		return array(
			'provider'   => $result['provider'] ?? '',
			'tokens_in'  => $result['tokens_in'] ?? 0,
			'tokens_out' => $result['tokens_out'] ?? 0,
			'summary'    => 'Category suggestions ready',
			'suggestions'=> $result['data'],
		);
	}

	/**
	 * @param int                 $cat_id Category.
	 * @param array<string,mixed> $payload Payload.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function job_attr_template( $cat_id, $payload ) {
		$term = get_term( (int) $cat_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'not_found', 'Category not found' );
		}

		$user = wp_json_encode(
			array(
				'task'            => 'Propose WooCommerce global attributes for this product category. Fixed attribute set for all products in the category.',
				'category'        => array( 'id' => (int) $cat_id, 'name' => $term->name ),
				'sample_products' => $payload['samples'] ?? array(),
				'regenerate_hint' => (string) ( $payload['regenerate_hint'] ?? '' ),
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);

		$result = Webino_Dashboard_AI_Providers::complete(
			Webino_Dashboard_AI_Prompts::system_rules(),
			$user,
			Webino_Dashboard_AI_Prompts::attribute_template_schema()
		);
		if ( empty( $result['ok'] ) ) {
			return new WP_Error( 'ai_provider', (string) ( $result['error'] ?? 'fail' ) );
		}

		$draft = $result['data'];
		set_transient( 'webino_ai_attr_draft_' . (int) $cat_id, $draft, DAY_IN_SECONDS );

		return array(
			'provider'   => $result['provider'] ?? '',
			'tokens_in'  => $result['tokens_in'] ?? 0,
			'tokens_out' => $result['tokens_out'] ?? 0,
			'summary'    => 'Attribute template draft ready',
			'draft'      => $draft,
		);
	}

	/**
	 * @param int $product_id Product.
	 * @return array<int,array<string,string>>
	 */
	private static function related_products( $product_id ) {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return array();
		}
		$ids = wc_get_products(
			array(
				'limit'   => 5,
				'status'  => 'publish',
				'exclude' => array( (int) $product_id ),
				'return'  => 'ids',
			)
		);
		$out = array();
		foreach ( (array) $ids as $id ) {
			$p = wc_get_product( (int) $id );
			if ( $p ) {
				$out[] = array(
					'name' => $p->get_name(),
					'url'  => get_permalink( (int) $id ) ?: '',
				);
			}
		}
		return $out;
	}

	/**
	 * @return array<int,array<string,string>>
	 */
	private static function related_posts() {
		$q = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 5,
				'fields'         => 'ids',
			)
		);
		$out = array();
		foreach ( $q->posts as $id ) {
			$out[] = array(
				'name' => get_the_title( (int) $id ),
				'url'  => get_permalink( (int) $id ) ?: '',
			);
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $args Query args.
	 * @return array{items:array,total:int}
	 */
	public static function list_jobs( $args = array() ) {
		global $wpdb;
		$table  = Webino_Dashboard_AI_Content_Db::table( 'jobs' );
		$status = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';
		$limit  = min( 100, max( 1, (int) ( $args['limit'] ?? 30 ) ) );
		$offset = max( 0, (int) ( $args['offset'] ?? 0 ) );

		$where = '1=1';
		$params = array();
		if ( $status ) {
			$where   .= ' AND status = %s';
			$params[] = $status;
		}

		$sql_count = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
		$sql_list  = "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d";

		if ( $params ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$total = (int) $wpdb->get_var( $wpdb->prepare( $sql_count, $params ) );
			$params2 = array_merge( $params, array( $limit, $offset ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( $sql_list, $params2 ), ARRAY_A );
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );
		}

		return array(
			'items' => is_array( $rows ) ? $rows : array(),
			'total' => $total,
		);
	}
}
