<?php
/**
 * Checkout GEO notice: warn non-Iran visitors to disable VPN before paying.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site-level toggle + footer modal on WooCommerce checkout / pay-order.
 */
final class Webino_Dashboard_Checkout_Geo {

	const OPTION = 'webino_dashboard_checkout_geo_notice';

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'maybe_print_checkout_modal' ), 50 );
	}

	/**
	 * Enabled by default when option is missing.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$raw = get_option( self::OPTION, null );
		if ( null === $raw ) {
			return true;
		}
		return ! empty( $raw );
	}

	/**
	 * @param bool $enabled Enabled.
	 * @return void
	 */
	public static function set_enabled( $enabled ) {
		update_option( self::OPTION, $enabled ? '1' : '0', false );
	}

	/**
	 * ISO country code or empty when unknown.
	 *
	 * @return string
	 */
	public static function visitor_country() {
		if ( ! empty( $_SERVER['HTTP_CF_IPCOUNTRY'] ) ) {
			$c = strtoupper( sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_CF_IPCOUNTRY'] ) ) );
			if ( preg_match( '/^[A-Z]{2}$/', $c ) && 'XX' !== $c && 'T1' !== $c ) {
				return $c;
			}
		}

		$ip = self::client_ip();
		if ( class_exists( 'WC_Geolocation', false ) ) {
			$data = WC_Geolocation::geolocate_ip( $ip, true, false );
			if ( is_array( $data ) && ! empty( $data['country'] ) ) {
				$code = strtoupper( sanitize_text_field( (string) $data['country'] ) );
				if ( preg_match( '/^[A-Z]{2}$/', $code ) ) {
					return $code;
				}
			}
		}

		if ( class_exists( 'Webino_Dashboard_Analytics_Geo', false ) && '' !== $ip ) {
			$geo = Webino_Dashboard_Analytics_Geo::lookup( $ip );
			if ( is_array( $geo ) && ! empty( $geo['country'] ) ) {
				$code = strtoupper( sanitize_text_field( (string) $geo['country'] ) );
				if ( preg_match( '/^[A-Z]{2}$/', $code ) ) {
					return $code;
				}
			}
		}

		return '';
	}

	/**
	 * True when country is known and not Iran.
	 *
	 * @return bool
	 */
	public static function should_show_notice() {
		if ( ! self::is_enabled() ) {
			return false;
		}
		$code = self::visitor_country();
		if ( '' === $code ) {
			return false;
		}
		return 'IR' !== $code;
	}

	/**
	 * @return string
	 */
	private static function client_ip() {
		if ( class_exists( 'WC_Geolocation', false ) ) {
			$ip = WC_Geolocation::get_ip_address();
			if ( is_string( $ip ) && '' !== $ip ) {
				return $ip;
			}
		}
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			return sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		}
		if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			return sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) );
		}
		return '';
	}

	/**
	 * WooCommerce checkout / order-pay footer.
	 *
	 * @return void
	 */
	public static function maybe_print_checkout_modal() {
		if ( is_admin() ) {
			return;
		}
		$on_checkout = function_exists( 'is_checkout' ) && is_checkout();
		$on_order_pay = function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' );
		if ( ! $on_checkout && ! $on_order_pay ) {
			return;
		}
		if ( ! self::should_show_notice() ) {
			return;
		}
		self::print_modal_markup();
	}

	/**
	 * Shared modal HTML/CSS/JS (also used by pay-order template).
	 *
	 * @return void
	 */
	public static function print_modal_markup() {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$is_fa  = is_string( $locale ) && ( 0 === strpos( strtolower( $locale ), 'fa' ) );
		$title  = $is_fa ? 'نکتهٔ پرداخت' : __( 'Payment tip', 'webino-dashboard' );
		$body   = $is_fa
			? 'اگر فیلترشکن روشن است، لطفاً خاموشش کنید تا اختلالی در روند پرداخت پیش نیاید.'
			: __( 'If you have a VPN enabled, please turn it off so your payment is not interrupted.', 'webino-dashboard' );
		$ok     = $is_fa ? 'متوجه شدم' : __( 'Got it', 'webino-dashboard' );
		$dir    = $is_fa || ( function_exists( 'is_rtl' ) && is_rtl() ) ? 'rtl' : 'ltr';
		?>
		<style id="wd-geo-notice-css">
			.wd-geo-notice-overlay{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:1rem;background:rgba(15,23,42,.55);backdrop-filter:blur(4px)}
			.wd-geo-notice-dialog{max-width:26rem;width:100%;background:#fff;color:#111;border-radius:14px;padding:1.25rem 1.35rem;box-shadow:0 18px 48px rgba(0,0,0,.22);font-family:system-ui,-apple-system,sans-serif}
			.wd-geo-notice-dialog h2{margin:0 0 .65rem;font-size:1.1rem;line-height:1.35}
			.wd-geo-notice-dialog p{margin:0 0 1.1rem;font-size:.95rem;line-height:1.55;color:#334155}
			.wd-geo-notice-dialog button{appearance:none;border:0;border-radius:10px;background:#0f172a;color:#fff;padding:.7rem 1.1rem;font-size:.95rem;cursor:pointer;width:100%}
			.wd-geo-notice-dialog button:hover{background:#1e293b}
			[dir=rtl] .wd-geo-notice-dialog{text-align:right}
		</style>
		<div class="wd-geo-notice-overlay" id="wd-geo-notice" role="dialog" aria-modal="true" aria-labelledby="wd-geo-notice-title" dir="<?php echo esc_attr( $dir ); ?>">
			<div class="wd-geo-notice-dialog">
				<h2 id="wd-geo-notice-title"><?php echo esc_html( $title ); ?></h2>
				<p><?php echo esc_html( $body ); ?></p>
				<button type="button" id="wd-geo-notice-ok"><?php echo esc_html( $ok ); ?></button>
			</div>
		</div>
		<script>
		(function () {
			var overlay = document.getElementById('wd-geo-notice');
			if (!overlay) return;
			function close() {
				overlay.style.display = 'none';
				overlay.setAttribute('aria-hidden', 'true');
			}
			var btn = document.getElementById('wd-geo-notice-ok');
			if (btn) btn.addEventListener('click', close);
			overlay.addEventListener('click', function (e) {
				if (e.target === overlay) close();
			});
			document.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') close();
			});
		})();
		</script>
		<?php
	}
}
