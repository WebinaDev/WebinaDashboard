<?php

namespace WebinoBasalam\Actions\Controller\ProductActions;

use WebinoBasalam\Admin\Product\ProductOperations;
use WebinoBasalam\Actions\Controller\ActionController;

defined('ABSPATH') || exit;
class ArchiveProduct extends ActionController
{
    public function __invoke()
    {
        $productOperations = webinoBasalamContainer()->get(ProductOperations::class);

        $productId = isset($_POST['product_id']) ? sanitize_text_field(wp_unslash($_POST['product_id'])) : null;

        if (!$productId) {
            wp_send_json_error(['message' => 'آیدی محصول الزامی است.'], 400);
        }

        try {
            $result = $productOperations->archiveExistProduct($productId);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()], 500);
        }

        if (!$result['success']) {
            wp_send_json_error(['message' => $result['message']], $result['status_code'] ?? 500);
        }

        wp_send_json_success(['message' => $result['message']], $result['status_code'] ?? 200);
    }
}
