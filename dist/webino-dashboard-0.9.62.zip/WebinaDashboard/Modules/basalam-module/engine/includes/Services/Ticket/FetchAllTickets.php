<?php

namespace WebinoBasalam\Services\Ticket;

use WebinoBasalam\Config\Endpoints;
use WebinoBasalam\Services\ApiServiceManager;

class FetchAllTickets
{
    private $url;

    public function __construct()
    {
        $this->url  = Endpoints::TICKET_LIST;
    }
    public function execute($hamsalamToken, $page = 1)
    {
        $apiService = webinoBasalamContainer()->get(ApiServiceManager::class);
        $url = $this->url . "?page=$page";
        $header = ['Authorization' => 'Bearer ' . $hamsalamToken];

        try {
            return $apiService->get($url, $header);
        } catch (\Exception $e) {
            return [
                'status_code' => $e->getCode() ?? 500,
                'body' => null,
                'error' => 'خطا در دریافت لیست تیکت‌ها: ' . $e->getMessage(),
            ];
        }
    }
}
