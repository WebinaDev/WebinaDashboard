import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { BasalamNav } from '../../components/BasalamNav'
import { PageShell } from '@/components/PageShell'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { formatDisplayDateTime } from '@/lib/date'

type JobLike = {
  id?: number
  job_type?: string
  type?: string
  status?: string
  error_message?: string
  created_at?: string
  updated_at?: string
}

const JOB_TYPE_KEYS: Record<string, string> = {
  sync_basalam_fetch_orders: 'basalam.job.fetchOrders',
  sync_basalam_create_product: 'basalam.job.createProduct',
  sync_basalam_update_product: 'basalam.job.updateProduct',
  sync_basalam_update_all: 'basalam.job.updateAll',
  sync_basalam_auto_connect: 'basalam.job.autoConnect',
  webino_basalam_discount_tasks: 'basalam.job.discounts',
  sync_basalam_quick_update: 'basalam.job.quickUpdate',
}

const STATUS_KEYS: Record<string, string> = {
  pending: 'basalam.jobStatus.pending',
  processing: 'basalam.jobStatus.processing',
  completed: 'basalam.jobStatus.completed',
  failed: 'basalam.jobStatus.failed',
  success: 'basalam.jobStatus.completed',
}

function jobTypeLabel(raw: string | undefined, t: (k: string, o?: { defaultValue?: string }) => string) {
  if (!raw) return '—'
  const key = JOB_TYPE_KEYS[raw]
  return key ? t(key) : t(`basalam.job.${raw}`, { defaultValue: raw.replace(/^sync_basalam_/, '').replace(/_/g, ' ') })
}

function statusLabel(raw: string | undefined, t: (k: string, o?: { defaultValue?: string }) => string) {
  if (!raw) return '—'
  const key = STATUS_KEYS[raw]
  return key ? t(key) : t(`basalam.jobStatus.${raw}`, { defaultValue: raw })
}

export default function BasalamLogsPage() {
  const { t, i18n } = useTranslation()
  const jobsQ = useQuery({
    queryKey: ['basalam', 'jobs', 'all'],
    queryFn: () => apiFetch<{ jobs: JobLike[] }>('basalam/jobs'),
    refetchInterval: 8000,
  })

  const jobs = jobsQ.data?.jobs ?? []
  const pending = jobs.filter((j) => j.status === 'pending' || j.status === 'processing').length
  const failed = jobs.filter((j) => j.status === 'failed').length
  const done = jobs.filter((j) => j.status === 'completed' || j.status === 'success').length

  return (
    <PageShell title={t('basalam.logsTitle')} description={t('basalam.logsSubtitle')}>
      <BasalamNav />
      <div className="mb-4 grid max-w-3xl gap-3 sm:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">{t('basalam.syncStatus.pending')}</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{pending}</CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">{t('basalam.syncStatus.done')}</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{done}</CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">{t('basalam.syncStatus.failed')}</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{failed}</CardContent>
        </Card>
      </div>

      <Card className="max-w-4xl">
        <CardHeader>
          <CardTitle>{t('basalam.recentJobs')}</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-start">
                <th className="py-2 pe-2">{t('basalam.col.type')}</th>
                <th className="py-2 pe-2">{t('basalam.col.status')}</th>
                <th className="py-2 pe-2">{t('basalam.col.time')}</th>
                <th className="py-2">{t('basalam.col.error')}</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={String(j.id)} className="border-b align-top">
                  <td className="py-2 pe-2">{jobTypeLabel(j.job_type || j.type, t)}</td>
                  <td className="py-2 pe-2">{statusLabel(j.status, t)}</td>
                  <td className="text-muted-foreground py-2 pe-2 text-xs">
                    {formatDisplayDateTime(j.updated_at || j.created_at, i18n.language)}
                  </td>
                  <td className="text-muted-foreground py-2 text-xs">
                    {j.error_message && j.error_message !== 'null' ? String(j.error_message) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!jobs.length ? <p className="text-muted-foreground mt-3 text-sm">{t('common.empty')}</p> : null}
        </CardContent>
      </Card>
    </PageShell>
  )
}
