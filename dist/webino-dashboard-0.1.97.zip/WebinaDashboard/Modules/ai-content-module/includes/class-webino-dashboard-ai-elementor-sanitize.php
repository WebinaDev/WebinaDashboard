<?php
/**
 * Strip font/typography font-family from Elementor trees.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ensures AI-built Elementor trees never override site fonts.
 */
final class Webino_Dashboard_AI_Elementor_Sanitize {

	/**
	 * Keys that force a custom font (must be removed).
	 *
	 * @var list<string>
	 */
	private static $font_keys = array(
		'font_family',
		'typography_font_family',
		'title_typography_font_family',
		'description_typography_font_family',
		'button_typography_font_family',
		'text_typography_font_family',
		'heading_typography_font_family',
		'name_typography_font_family',
		'job_typography_font_family',
		'tab_title_typography_font_family',
		'number_typography_font_family',
		'title_text_typography_font_family',
	);

	/**
	 * @param array<int,mixed> $elements Elementor elements tree.
	 * @return array<int,mixed>
	 */
	public static function strip_fonts( $elements ) {
		if ( ! is_array( $elements ) ) {
			return array();
		}
		$out = array();
		foreach ( $elements as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			$out[] = self::strip_element( $el );
		}
		return $out;
	}

	/**
	 * @param array<string,mixed> $el Element.
	 * @return array<string,mixed>
	 */
	private static function strip_element( $el ) {
		if ( isset( $el['settings'] ) && is_array( $el['settings'] ) ) {
			$el['settings'] = self::strip_settings( $el['settings'] );
		}
		if ( isset( $el['elements'] ) && is_array( $el['elements'] ) ) {
			$children = array();
			foreach ( $el['elements'] as $child ) {
				if ( is_array( $child ) ) {
					$children[] = self::strip_element( $child );
				}
			}
			$el['elements'] = $children;
		}
		return $el;
	}

	/**
	 * @param array<string,mixed> $settings Settings.
	 * @return array<string,mixed>
	 */
	private static function strip_settings( $settings ) {
		foreach ( self::$font_keys as $key ) {
			unset( $settings[ $key ] );
		}
		foreach ( array_keys( $settings ) as $key ) {
			$k = (string) $key;
			if ( false !== strpos( $k, 'font_family' ) || false !== strpos( $k, 'typography_font_family' ) ) {
				unset( $settings[ $key ] );
			}
			// Drop typography globals that only set font family.
			if ( '__globals__' === $k && is_array( $settings[ $key ] ) ) {
				foreach ( array_keys( $settings[ $key ] ) as $gk ) {
					if ( false !== strpos( (string) $gk, 'font_family' ) ) {
						unset( $settings[ $key ][ $gk ] );
					}
				}
			}
		}
		return $settings;
	}
}
