<?php
/**
 * Compile PageBlueprint sections into Elementor element trees.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Archetype library → native Elementor widgets (no custom fonts).
 */
final class Webino_Dashboard_AI_Elementor_Compiler {

	/**
	 * @param array<string,mixed> $blueprint Page blueprint from LLM.
	 * @return array<int,mixed>
	 */
	public static function compile( $blueprint ) {
		$memory   = Webino_Dashboard_AI_Design_Memory::get();
		$sections = isset( $blueprint['sections'] ) && is_array( $blueprint['sections'] ) ? $blueprint['sections'] : array();
		$tree     = array();

		if ( ! $sections ) {
			$sections = array(
				array(
					'archetype' => 'hero_cinematic',
					'variant'   => 'default',
					'content'   => array(
						'eyebrow'    => '',
						'heading'    => (string) ( $blueprint['h1'] ?? $blueprint['title'] ?? '' ),
						'subheading' => (string) ( $blueprint['excerpt'] ?? '' ),
						'cta_text'   => '',
						'cta_url'    => '',
					),
				),
			);
		}

		foreach ( $sections as $i => $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}
			$arch = sanitize_key( (string) ( $section['archetype'] ?? 'image_text_split' ) );
			if ( ! in_array( $arch, Webino_Dashboard_AI_Design_Memory::all_archetypes(), true ) ) {
				$arch = 'image_text_split';
			}
			$content = isset( $section['content'] ) && is_array( $section['content'] ) ? $section['content'] : array();
			$built   = self::build_section( $arch, $content, $memory, (int) $i );
			if ( $built ) {
				$tree[] = $built;
			}
		}

		return Webino_Dashboard_AI_Elementor_Sanitize::strip_fonts( $tree );
	}

	/**
	 * @param string              $archetype Archetype.
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Design memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>|null
	 */
	private static function build_section( $archetype, $content, $memory, $index ) {
		switch ( $archetype ) {
			case 'hero_cinematic':
				return self::section_hero( $content, $memory, $index );
			case 'bento_features':
				return self::section_bento( $content, $memory, $index );
			case 'stats_strip':
				return self::section_stats( $content, $memory, $index );
			case 'timeline':
				return self::section_timeline( $content, $memory, $index );
			case 'faq_accordion':
				return self::section_faq( $content, $memory, $index );
			case 'cta_fullbleed':
				return self::section_cta( $content, $memory, $index );
			case 'testimonials':
				return self::section_testimonials( $content, $memory, $index );
			case 'icon_grid':
				return self::section_icon_grid( $content, $memory, $index );
			case 'logo_strip':
				return self::section_logo_strip( $content, $memory, $index );
			case 'image_text_split':
			default:
				return self::section_split( $content, $memory, $index );
		}
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_hero( $content, $memory, $index ) {
		$pad_y   = (int) ( $memory['spacing']['section_y'] ?? 80 );
		$primary = self::color_settings( 'primary' );
		$accent  = self::color_settings( 'accent' );
		$text    = self::color_settings( 'text' );
		$bg      = self::color_settings( 'bg' );

		$heading = (string) ( $content['heading'] ?? $content['h1'] ?? '' );
		$sub     = (string) ( $content['subheading'] ?? $content['text'] ?? '' );
		$eyebrow = (string) ( $content['eyebrow'] ?? '' );
		$cta     = (string) ( $content['cta_text'] ?? '' );
		$url     = (string) ( $content['cta_url'] ?? '#' );
		$img_id  = self::resolve_image_id( $content );

		$left_widgets = array();
		if ( '' !== $eyebrow ) {
			$left_widgets[] = self::widget_heading( $eyebrow, 'h6', $accent, 14 );
		}
		$left_widgets[] = self::widget_heading( $heading, 'h1', $text, 48 );
		if ( '' !== $sub ) {
			$left_widgets[] = self::widget_text( '<p>' . esc_html( $sub ) . '</p>', $memory['spacing']['gap'] ?? 24 );
		}
		if ( '' !== $cta ) {
			$left_widgets[] = self::widget_button( $cta, $url, $primary, $memory );
		}

		$cols = array(
			self::column( 50, $left_widgets, array( 'content_position' => 'center' ) ),
		);

		$right = array();
		if ( $img_id > 0 ) {
			$right[] = self::widget_image( $img_id, (string) ( $content['image_alt'] ?? $heading ) );
		} else {
			$right[] = self::widget_heading( '★', 'h2', $accent, 72 );
			$right[] = self::widget_text( '<p style="opacity:.7">' . esc_html__( 'Visual focal point', 'webino-dashboard' ) . '</p>', 8 );
		}
		$cols[] = self::column( 50, $right, array( 'content_position' => 'center' ) );

		return self::section(
			$cols,
			array_merge(
				array(
					'layout'                     => 'full_width',
					'gap'                        => 'extended',
					'content_width'              => 'boxed',
					'content_width_custom'       => array( 'unit' => 'px', 'size' => 1200 ),
					'padding'                    => self::padding( $pad_y + 40, 24, $pad_y + 40, 24 ),
					'background_background'      => 'classic',
					'background_color'           => $bg['color'],
					'background_overlay_background' => 'gradient',
					'background_overlay_color'   => $primary['color'],
					'background_overlay_color_b' => $accent['color'],
					'background_overlay_opacity' => array( 'unit' => 'px', 'size' => 0.08 ),
					'background_overlay_gradient_angle' => array( 'unit' => 'deg', 'size' => 135 ),
				),
				self::maybe_globals( $bg, 'background_color' )
			),
			'hero-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_bento( $content, $memory, $index ) {
		$items = isset( $content['items'] ) && is_array( $content['items'] ) ? $content['items'] : array();
		if ( count( $items ) < 2 ) {
			$items = array(
				array( 'title' => (string) ( $content['heading'] ?? 'Feature' ), 'text' => (string) ( $content['text'] ?? '' ), 'icon' => 'fas fa-star' ),
				array( 'title' => 'Quality', 'text' => '', 'icon' => 'fas fa-gem' ),
				array( 'title' => 'Support', 'text' => '', 'icon' => 'fas fa-headset' ),
			);
		}
		$surface = self::color_settings( 'surface' );
		$text    = self::color_settings( 'text' );
		$accent  = self::color_settings( 'accent' );
		$pad_y   = (int) ( $memory['spacing']['section_y'] ?? 80 );
		$radius  = (int) ( $memory['radius']['card'] ?? 16 );

		$title_widgets = array();
		if ( ! empty( $content['heading'] ) ) {
			$title_widgets[] = self::widget_heading( (string) $content['heading'], 'h2', $text, 36 );
		}
		if ( ! empty( $content['subheading'] ) ) {
			$title_widgets[] = self::widget_text( '<p>' . esc_html( (string) $content['subheading'] ) . '</p>', 12 );
		}

		$rows = array();
		if ( $title_widgets ) {
			$rows[] = self::inner_section( array( self::column( 100, $title_widgets ) ), array( 'gap' => 'no' ) );
		}

		$chunk = array_chunk( array_slice( $items, 0, 6 ), 3 );
		foreach ( $chunk as $row_items ) {
			$cols = array();
			$w    = (int) floor( 100 / max( 1, count( $row_items ) ) );
			foreach ( $row_items as $ri => $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$box = self::widget_icon_box(
					(string) ( $item['title'] ?? '' ),
					(string) ( $item['text'] ?? $item['description'] ?? '' ),
					(string) ( $item['icon'] ?? 'fas fa-check' ),
					$accent,
					$text
				);
				$col_settings = array(
					'background_background' => 'classic',
					'background_color'      => $surface['color'],
					'border_radius'         => self::sides( $radius ),
					'padding'               => self::padding( 28, 24, 28, 24 ),
					'box_shadow_box_shadow' => array(
						'horizontal' => 0,
						'vertical'   => 12,
						'blur'       => 40,
						'spread'     => 0,
						'color'      => 'rgba(15,23,42,0.08)',
					),
					'box_shadow_box_shadow_type' => 'yes',
				);
				if ( 0 === $ri && count( $row_items ) >= 3 ) {
					// Asymmetric first card slightly taller feel via extra padding.
					$col_settings['padding'] = self::padding( 36, 28, 36, 28 );
				}
				$cols[] = self::column( $w, array( $box ), $col_settings );
			}
			$rows[] = self::inner_section( $cols, array( 'gap' => 'extended' ) );
		}

		return self::section(
			array( self::column( 100, $rows ) ),
			array(
				'layout'                => 'full_width',
				'content_width'         => 'boxed',
				'content_width_custom'  => array( 'unit' => 'px', 'size' => 1200 ),
				'padding'               => self::padding( $pad_y, 24, $pad_y, 24 ),
				'background_background' => 'classic',
				'background_color'      => self::color_settings( 'bg' )['color'],
			),
			'bento-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_stats( $content, $memory, $index ) {
		$items = isset( $content['items'] ) && is_array( $content['items'] ) ? $content['items'] : array();
		if ( ! $items ) {
			$items = array(
				array( 'number' => '100', 'title' => 'Projects' ),
				array( 'number' => '50', 'title' => 'Clients' ),
				array( 'number' => '10', 'title' => 'Years' ),
				array( 'number' => '24', 'title' => 'Support' ),
			);
		}
		$primary = self::color_settings( 'primary' );
		$text    = self::color_settings( 'text' );
		$accent  = self::color_settings( 'accent' );
		$cols    = array();
		$w       = (int) floor( 100 / min( 4, max( 1, count( $items ) ) ) );
		foreach ( array_slice( $items, 0, 4 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$num = preg_replace( '/[^0-9.]/', '', (string) ( $item['number'] ?? $item['value'] ?? '0' ) );
			$cols[] = self::column(
				$w,
				array(
					self::widget_counter( (float) $num, (string) ( $item['title'] ?? $item['label'] ?? '' ), $accent, $text ),
				),
				array( 'align' => 'center' )
			);
		}
		return self::section(
			$cols,
			array(
				'layout'                => 'full_width',
				'content_width'         => 'boxed',
				'gap'                   => 'extended',
				'padding'               => self::padding( 56, 24, 56, 24 ),
				'background_background' => 'classic',
				'background_color'      => $primary['color'],
			),
			'stats-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_timeline( $content, $memory, $index ) {
		$items = isset( $content['items'] ) && is_array( $content['items'] ) ? $content['items'] : array();
		$text  = self::color_settings( 'text' );
		$accent = self::color_settings( 'accent' );
		$list  = array();
		foreach ( array_slice( $items, 0, 6 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$list[] = array(
				'text' => '<strong>' . esc_html( (string) ( $item['title'] ?? '' ) ) . '</strong> — ' . esc_html( (string) ( $item['text'] ?? $item['description'] ?? '' ) ),
				'selected_icon' => array( 'value' => 'fas fa-circle', 'library' => 'fa-solid' ),
			);
		}
		if ( ! $list ) {
			$list[] = array(
				'text' => (string) ( $content['text'] ?? $content['heading'] ?? 'Step' ),
				'selected_icon' => array( 'value' => 'fas fa-circle', 'library' => 'fa-solid' ),
			);
		}
		$widgets = array();
		if ( ! empty( $content['heading'] ) ) {
			$widgets[] = self::widget_heading( (string) $content['heading'], 'h2', $text, 32 );
		}
		$widgets[] = array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'icon-list',
			'settings'   => array(
				'icon_list'     => $list,
				'icon_color'    => $accent['color'],
				'text_color'    => $text['color'],
				'space_between' => array( 'unit' => 'px', 'size' => 18 ),
			),
			'elements'   => array(),
		);
		return self::section(
			array( self::column( 100, $widgets ) ),
			array(
				'layout'               => 'full_width',
				'content_width'        => 'boxed',
				'content_width_custom' => array( 'unit' => 'px', 'size' => 900 ),
				'padding'              => self::padding( (int) ( $memory['spacing']['section_y'] ?? 80 ), 24, (int) ( $memory['spacing']['section_y'] ?? 80 ), 24 ),
			),
			'timeline-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_faq( $content, $memory, $index ) {
		$items = isset( $content['items'] ) && is_array( $content['items'] ) ? $content['items'] : array();
		if ( isset( $content['faqs'] ) && is_array( $content['faqs'] ) ) {
			$items = $content['faqs'];
		}
		$tabs = array();
		foreach ( array_slice( $items, 0, 8 ) as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$tabs[] = array(
				'tab_title'   => (string) ( $item['question'] ?? $item['title'] ?? '' ),
				'tab_content' => wp_kses_post( (string) ( $item['answer'] ?? $item['text'] ?? '' ) ),
			);
		}
		if ( ! $tabs ) {
			$tabs[] = array(
				'tab_title'   => (string) ( $content['heading'] ?? 'FAQ' ),
				'tab_content' => wp_kses_post( (string) ( $content['text'] ?? '' ) ),
			);
		}
		$text    = self::color_settings( 'text' );
		$widgets = array();
		if ( ! empty( $content['heading'] ) ) {
			$widgets[] = self::widget_heading( (string) $content['heading'], 'h2', $text, 32 );
		}
		$widgets[] = array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'accordion',
			'settings'   => array(
				'tabs'             => $tabs,
				'title_color'      => $text['color'],
				'content_color'    => self::color_settings( 'muted' )['color'],
				'border_color'     => self::color_settings( 'surface' )['color'],
			),
			'elements'   => array(),
		);
		return self::section(
			array( self::column( 100, $widgets ) ),
			array(
				'layout'               => 'full_width',
				'content_width'        => 'boxed',
				'content_width_custom' => array( 'unit' => 'px', 'size' => 900 ),
				'padding'              => self::padding( (int) ( $memory['spacing']['section_y'] ?? 80 ), 24, (int) ( $memory['spacing']['section_y'] ?? 80 ), 24 ),
				'background_background'=> 'classic',
				'background_color'     => self::color_settings( 'surface' )['color'],
			),
			'faq-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_cta( $content, $memory, $index ) {
		$primary = self::color_settings( 'primary' );
		$accent  = self::color_settings( 'accent' );
		$text    = array( 'color' => '#ffffff', 'globals' => array() );
		$widgets = array(
			self::widget_heading( (string) ( $content['heading'] ?? '' ), 'h2', $text, 40 ),
		);
		if ( ! empty( $content['subheading'] ) || ! empty( $content['text'] ) ) {
			$widgets[] = self::widget_text( '<p>' . esc_html( (string) ( $content['subheading'] ?? $content['text'] ?? '' ) ) . '</p>', 16 );
		}
		if ( ! empty( $content['cta_text'] ) ) {
			$widgets[] = self::widget_button(
				(string) $content['cta_text'],
				(string) ( $content['cta_url'] ?? '#' ),
				$accent,
				$memory
			);
		}
		return self::section(
			array( self::column( 100, $widgets, array( 'align' => 'center' ) ) ),
			array(
				'layout'                => 'full_width',
				'content_width'         => 'boxed',
				'padding'               => self::padding( 96, 24, 96, 24 ),
				'background_background' => 'gradient',
				'background_color'      => $primary['color'],
				'background_color_b'    => $accent['color'],
				'background_gradient_angle' => array( 'unit' => 'deg', 'size' => 120 ),
			),
			'cta-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_testimonials( $content, $memory, $index ) {
		$items = isset( $content['items'] ) && is_array( $content['items'] ) ? $content['items'] : array();
		$text  = self::color_settings( 'text' );
		$muted = self::color_settings( 'muted' );
		$cols  = array();
		$slice = array_slice( $items ? $items : array( array( 'name' => 'Client', 'text' => (string) ( $content['text'] ?? '' ), 'title' => '' ) ), 0, 3 );
		$w     = (int) floor( 100 / max( 1, count( $slice ) ) );
		foreach ( $slice as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$cols[] = self::column(
				$w,
				array(
					array(
						'id'         => self::uid(),
						'elType'     => 'widget',
						'widgetType' => 'testimonial',
						'settings'   => array(
							'testimonial_content' => (string) ( $item['text'] ?? $item['content'] ?? '' ),
							'testimonial_name'    => (string) ( $item['name'] ?? '' ),
							'testimonial_job'     => (string) ( $item['title'] ?? $item['role'] ?? '' ),
							'content_color'       => $text['color'],
							'name_text_color'     => $text['color'],
							'job_text_color'      => $muted['color'],
						),
						'elements'   => array(),
					),
				),
				array(
					'background_background' => 'classic',
					'background_color'      => self::color_settings( 'surface' )['color'],
					'padding'               => self::padding( 28, 24, 28, 24 ),
					'border_radius'         => self::sides( (int) ( $memory['radius']['card'] ?? 16 ) ),
				)
			);
		}
		$widgets_title = array();
		if ( ! empty( $content['heading'] ) ) {
			$head = self::section(
				array( self::column( 100, array( self::widget_heading( (string) $content['heading'], 'h2', $text, 32 ) ) ) ),
				array( 'padding' => self::padding( 0, 0, 16, 0 ) ),
				'test-h-' . $index
			);
			// Flatten: wrap title + cards in one section.
			return self::section(
				array_merge(
					array( self::column( 100, array( self::widget_heading( (string) $content['heading'], 'h2', $text, 32 ) ) ) ),
					$cols
				),
				array(
					'layout'               => 'full_width',
					'content_width'        => 'boxed',
					'gap'                  => 'extended',
					'padding'              => self::padding( (int) ( $memory['spacing']['section_y'] ?? 80 ), 24, (int) ( $memory['spacing']['section_y'] ?? 80 ), 24 ),
				),
				'testi-' . $index
			);
		}
		return self::section(
			$cols,
			array(
				'layout'        => 'full_width',
				'content_width' => 'boxed',
				'gap'           => 'extended',
				'padding'       => self::padding( (int) ( $memory['spacing']['section_y'] ?? 80 ), 24, (int) ( $memory['spacing']['section_y'] ?? 80 ), 24 ),
			),
			'testi-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_icon_grid( $content, $memory, $index ) {
		$content['items'] = isset( $content['items'] ) ? $content['items'] : array();
		return self::section_bento( $content, $memory, $index );
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_logo_strip( $content, $memory, $index ) {
		$text    = self::color_settings( 'muted' );
		$widgets = array();
		if ( ! empty( $content['heading'] ) ) {
			$widgets[] = self::widget_heading( (string) $content['heading'], 'h3', $text, 18 );
		}
		$widgets[] = self::widget_divider();
		$widgets[] = self::widget_text(
			'<p style="letter-spacing:.08em;text-transform:uppercase;opacity:.7">' . esc_html( (string) ( $content['text'] ?? $content['subheading'] ?? '' ) ) . '</p>',
			8
		);
		return self::section(
			array( self::column( 100, $widgets, array( 'align' => 'center' ) ) ),
			array(
				'layout'        => 'full_width',
				'content_width' => 'boxed',
				'padding'       => self::padding( 40, 24, 40, 24 ),
			),
			'logos-' . $index
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @param array<string,mixed> $memory Memory.
	 * @param int                 $index Index.
	 * @return array<string,mixed>
	 */
	private static function section_split( $content, $memory, $index ) {
		$text   = self::color_settings( 'text' );
		$primary = self::color_settings( 'primary' );
		$flip   = ! empty( $content['flip'] ) || ( 1 === ( $index % 2 ) );
		$img_id = self::resolve_image_id( $content );
		$left   = array();
		$right  = array();

		$text_col = array();
		if ( ! empty( $content['eyebrow'] ) ) {
			$text_col[] = self::widget_heading( (string) $content['eyebrow'], 'h6', self::color_settings( 'accent' ), 13 );
		}
		$text_col[] = self::widget_heading( (string) ( $content['heading'] ?? '' ), 'h2', $text, 34 );
		if ( ! empty( $content['text'] ) || ! empty( $content['subheading'] ) || ! empty( $content['html'] ) ) {
			$html = (string) ( $content['html'] ?? '' );
			if ( '' === $html ) {
				$html = '<p>' . esc_html( (string) ( $content['text'] ?? $content['subheading'] ?? '' ) ) . '</p>';
			}
			$text_col[] = self::widget_text( $html, 16 );
		}
		if ( ! empty( $content['cta_text'] ) ) {
			$text_col[] = self::widget_button( (string) $content['cta_text'], (string) ( $content['cta_url'] ?? '#' ), $primary, $memory );
		}

		$media_col = array();
		if ( $img_id > 0 ) {
			$media_col[] = self::widget_image( $img_id, (string) ( $content['image_alt'] ?? $content['heading'] ?? '' ) );
		} else {
			$media_col[] = self::widget_heading( '◆', 'h2', self::color_settings( 'accent' ), 64 );
		}

		$cols = $flip
			? array( self::column( 48, $media_col ), self::column( 52, $text_col, array( 'content_position' => 'center' ) ) )
			: array( self::column( 52, $text_col, array( 'content_position' => 'center' ) ), self::column( 48, $media_col ) );

		return self::section(
			$cols,
			array(
				'layout'               => 'full_width',
				'content_width'        => 'boxed',
				'content_width_custom' => array( 'unit' => 'px', 'size' => 1200 ),
				'gap'                  => 'extended',
				'padding'              => self::padding( (int) ( $memory['spacing']['section_y'] ?? 80 ), 24, (int) ( $memory['spacing']['section_y'] ?? 80 ), 24 ),
			),
			'split-' . $index
		);
	}

	/**
	 * @param array<int,mixed>    $columns Columns.
	 * @param array<string,mixed> $settings Settings.
	 * @param string              $css_id CSS id.
	 * @return array<string,mixed>
	 */
	private static function section( $columns, $settings, $css_id = '' ) {
		if ( '' !== $css_id ) {
			$settings['css_id'] = sanitize_html_class( $css_id );
		}
		return array(
			'id'       => self::uid(),
			'elType'   => 'section',
			'isInner'  => false,
			'settings' => $settings,
			'elements' => array_values( $columns ),
		);
	}

	/**
	 * @param array<int,mixed>    $columns Columns.
	 * @param array<string,mixed> $settings Settings.
	 * @return array<string,mixed>
	 */
	private static function inner_section( $columns, $settings = array() ) {
		return array(
			'id'       => self::uid(),
			'elType'   => 'section',
			'isInner'  => true,
			'settings' => $settings,
			'elements' => array_values( $columns ),
		);
	}

	/**
	 * @param int                 $width Width percent.
	 * @param array<int,mixed>    $widgets Widgets.
	 * @param array<string,mixed> $extra Extra settings.
	 * @return array<string,mixed>
	 */
	private static function column( $width, $widgets, $extra = array() ) {
		$settings = array_merge(
			array(
				'_column_size' => (int) $width,
				'_inline_size' => null,
			),
			$extra
		);
		return array(
			'id'       => self::uid(),
			'elType'   => 'column',
			'settings' => $settings,
			'elements' => array_values( $widgets ),
		);
	}

	/**
	 * @param string              $title Title.
	 * @param string              $tag Tag.
	 * @param array<string,mixed> $color Color binding.
	 * @param int                 $size Size.
	 * @return array<string,mixed>
	 */
	private static function widget_heading( $title, $tag, $color, $size ) {
		$settings = array(
			'title'            => $title,
			'header_size'      => $tag,
			'align'            => 'inherit',
			'title_color'      => $color['color'],
			'typography_typography' => 'custom',
			'typography_font_size'  => array( 'unit' => 'px', 'size' => (int) $size ),
			'typography_font_weight'=> '700',
		);
		if ( ! empty( $color['globals']['color'] ) ) {
			$settings['__globals__'] = array( 'title_color' => $color['globals']['color'] );
		}
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'heading',
			'settings'   => $settings,
			'elements'   => array(),
		);
	}

	/**
	 * @param string $html HTML.
	 * @param int    $gap Gap.
	 * @return array<string,mixed>
	 */
	private static function widget_text( $html, $gap = 0 ) {
		$settings = array(
			'editor' => wp_kses_post( $html ),
		);
		if ( $gap > 0 ) {
			$settings['_margin'] = self::padding( $gap, 0, 0, 0 );
		}
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'text-editor',
			'settings'   => $settings,
			'elements'   => array(),
		);
	}

	/**
	 * @param string              $text Text.
	 * @param string              $url URL.
	 * @param array<string,mixed> $color Color.
	 * @param array<string,mixed> $memory Memory.
	 * @return array<string,mixed>
	 */
	private static function widget_button( $text, $url, $color, $memory ) {
		$radius = (int) ( $memory['radius']['button'] ?? 8 );
		$style  = (string) ( $memory['button_style'] ?? 'solid' );
		$settings = array(
			'text'            => $text,
			'link'            => array( 'url' => esc_url_raw( $url ), 'is_external' => '', 'nofollow' => '' ),
			'size'            => 'md',
			'background_color'=> $color['color'],
			'button_text_color'=> '#ffffff',
			'border_radius'   => self::sides( $radius ),
			'button_type'     => 'default',
		);
		if ( 'outline' === $style ) {
			$settings['background_color']   = 'rgba(0,0,0,0)';
			$settings['button_text_color']  = $color['color'];
			$settings['border_border']      = 'solid';
			$settings['border_width']       = self::sides( 2 );
			$settings['border_color']       = $color['color'];
		} elseif ( 'soft' === $style ) {
			$settings['background_color']  = self::color_settings( 'surface' )['color'];
			$settings['button_text_color'] = $color['color'];
		}
		if ( ! empty( $color['globals']['color'] ) && 'outline' !== $style && 'soft' !== $style ) {
			$settings['__globals__'] = array( 'background_color' => $color['globals']['color'] );
		}
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'button',
			'settings'   => $settings,
			'elements'   => array(),
		);
	}

	/**
	 * @param int    $id Attachment.
	 * @param string $alt Alt.
	 * @return array<string,mixed>
	 */
	private static function widget_image( $id, $alt ) {
		$url = wp_get_attachment_image_url( (int) $id, 'large' );
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'image',
			'settings'   => array(
				'image'      => array(
					'url' => $url ? $url : '',
					'id'  => (int) $id,
					'alt' => $alt,
					'source' => 'library',
				),
				'image_size' => 'large',
				'align'      => 'center',
				'border_radius' => self::sides( 16 ),
			),
			'elements'   => array(),
		);
	}

	/**
	 * @param string              $title Title.
	 * @param string              $desc Desc.
	 * @param string              $icon Icon.
	 * @param array<string,mixed> $accent Accent.
	 * @param array<string,mixed> $text Text color.
	 * @return array<string,mixed>
	 */
	private static function widget_icon_box( $title, $desc, $icon, $accent, $text ) {
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'icon-box',
			'settings'   => array(
				'selected_icon'       => array( 'value' => $icon ? $icon : 'fas fa-check', 'library' => 'fa-solid' ),
				'title_text'          => $title,
				'description_text'    => $desc,
				'position'            => 'top',
				'primary_color'       => $accent['color'],
				'title_color'         => $text['color'],
				'description_color'   => self::color_settings( 'muted' )['color'],
			),
			'elements'   => array(),
		);
	}

	/**
	 * @param float               $number Number.
	 * @param string              $title Title.
	 * @param array<string,mixed> $accent Accent.
	 * @param array<string,mixed> $text Text.
	 * @return array<string,mixed>
	 */
	private static function widget_counter( $number, $title, $accent, $text ) {
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'counter',
			'settings'   => array(
				'starting_number' => 0,
				'ending_number'   => $number,
				'title'           => $title,
				'number_color'    => '#ffffff',
				'title_color'     => '#ffffff',
			),
			'elements'   => array(),
		);
	}

	/**
	 * @return array<string,mixed>
	 */
	private static function widget_divider() {
		return array(
			'id'         => self::uid(),
			'elType'     => 'widget',
			'widgetType' => 'divider',
			'settings'   => array(
				'style' => 'solid',
				'weight'=> array( 'unit' => 'px', 'size' => 1 ),
				'color' => self::color_settings( 'surface' )['color'],
				'width' => array( 'unit' => '%', 'size' => 40 ),
				'align' => 'center',
			),
			'elements'   => array(),
		);
	}

	/**
	 * @param string $slot Slot.
	 * @return array{color:string,globals:array<string,string>}
	 */
	private static function color_settings( $slot ) {
		return Webino_Dashboard_AI_Design_Memory::color_binding( $slot );
	}

	/**
	 * @param array<string,mixed> $binding Binding.
	 * @param string              $key Settings key.
	 * @return array<string,mixed>
	 */
	private static function maybe_globals( $binding, $key ) {
		if ( empty( $binding['globals']['color'] ) ) {
			return array();
		}
		return array(
			'__globals__' => array( $key => $binding['globals']['color'] ),
		);
	}

	/**
	 * @param int $t Top.
	 * @param int $r Right.
	 * @param int $b Bottom.
	 * @param int $l Left.
	 * @return array<string,mixed>
	 */
	private static function padding( $t, $r, $b, $l ) {
		return array(
			'unit'     => 'px',
			'top'      => (string) $t,
			'right'    => (string) $r,
			'bottom'   => (string) $b,
			'left'     => (string) $l,
			'isLinked' => false,
		);
	}

	/**
	 * @param int $n Size.
	 * @return array<string,mixed>
	 */
	private static function sides( $n ) {
		$v = (string) (int) $n;
		return array(
			'unit'     => 'px',
			'top'      => $v,
			'right'    => $v,
			'bottom'   => $v,
			'left'     => $v,
			'isLinked' => true,
		);
	}

	/**
	 * @param array<string,mixed> $content Content.
	 * @return int
	 */
	private static function resolve_image_id( $content ) {
		if ( ! empty( $content['image_id'] ) ) {
			return (int) $content['image_id'];
		}
		// Prefer a recent media image from the library.
		$q = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);
		return $q ? (int) $q[0] : 0;
	}

	/**
	 * @return string
	 */
	private static function uid() {
		return substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 7 );
	}
}
