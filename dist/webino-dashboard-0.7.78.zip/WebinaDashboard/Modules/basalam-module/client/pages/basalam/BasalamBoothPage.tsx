import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type Vendor = {
  id?: number
  title?: string
  summary?: string
  status?: string | number
  [key: string]: unknown
}

export default function BasalamBoothPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [title, setTitle] = useState('')
  const [summary, setSummary] = useState('')
  const [profileTitle, setProfileTitle] = useState('')
  const [discountPayload, setDiscountPayload] = useState('{\n  "product_id": 0,\n  "discount": 10\n}')

  const vendorQ = useQuery({
    queryKey: ['basalam', 'vendor'],
    queryFn: () => apiFetch<{ vendor: Vendor | null }>('basalam/vendor'),
  })

  const shippingQ = useQuery({
    queryKey: ['basalam', 'shipping'],
    queryFn: () =>
      apiFetch<{
        profiles?: unknown
        carriers?: unknown
        vendor_carriers?: unknown
        strategy?: unknown
        shipping?: unknown
      }>('basalam/shipping'),
  })

  const webhooksQ = useQuery({
    queryKey: ['basalam', 'webhooks'],
    queryFn: () =>
      apiFetch<{ webhooks: Array<Record<string, unknown>>; webhook_url?: string }>('basalam/webhooks'),
  })

  const discountsQ = useQuery({
    queryKey: ['basalam', 'discounts'],
    queryFn: () => apiFetch<{ discounts?: unknown }>('basalam/discounts'),
  })

  const chatQ = useQuery({
    queryKey: ['basalam', 'chat'],
    queryFn: () =>
      apiFetch<{ enabled?: boolean; token?: string | null; script_url?: string; admin_url?: string }>(
        'basalam/chat/token',
      ),
  })

  useEffect(() => {
    const v = vendorQ.data?.vendor
    if (v) {
      setTitle(String(v.title ?? ''))
      setSummary(String(v.summary ?? ''))
    }
  }, [vendorQ.data])

  useEffect(() => {
    const token = chatQ.data?.token
    const src = chatQ.data?.script_url
    if (!token || !src) return
    const existing = document.getElementById('basalam-chat-widget-script')
    if (existing) return
    const s = document.createElement('script')
    s.id = 'basalam-chat-widget-script'
    s.src = src
    s.setAttribute('token', token)
    s.async = true
    document.body.appendChild(s)
    return () => {
      s.remove()
    }
  }, [chatQ.data])

  const saveVendor = useMutation({
    mutationFn: () =>
      apiFetch('basalam/vendor', {
        method: 'POST',
        body: JSON.stringify({ title, summary }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.boothSaved'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'vendor'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const createShippingProfile = useMutation({
    mutationFn: () =>
      apiFetch('basalam/shipping', {
        method: 'POST',
        body: JSON.stringify({ title: profileTitle.trim() }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.shippingSaved'))
      setProfileTitle('')
      await qc.invalidateQueries({ queryKey: ['basalam', 'shipping'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const deleteShippingProfile = useMutation({
    mutationFn: (id: number) =>
      apiFetch('basalam/shipping', {
        method: 'POST',
        body: JSON.stringify({ action: 'delete_profile', profile_id: id }),
      }),
    onSuccess: async () => {
      toast.success(t('basalam.shippingProfileDeleted'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'shipping'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const setupWebhook = useMutation({
    mutationFn: () => apiFetch('basalam/webhook/setup', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.webhookConfigured'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'webhooks'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const rotateWebhook = useMutation({
    mutationFn: () => apiFetch('basalam/webhooks/rotate', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.webhookRotated'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'webhooks'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const deleteWebhook = useMutation({
    mutationFn: (id: number) =>
      apiFetch('basalam/webhooks/delete', { method: 'POST', body: JSON.stringify({ webhook_id: id }) }),
    onSuccess: async () => {
      toast.success(t('basalam.webhookDeleted'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'webhooks'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const createDiscount = useMutation({
    mutationFn: () => {
      let body: Record<string, unknown> = {}
      try {
        body = JSON.parse(discountPayload) as Record<string, unknown>
      } catch {
        throw new Error(t('basalam.invalidJson'))
      }
      return apiFetch('basalam/discounts', { method: 'POST', body: JSON.stringify(body) })
    },
    onSuccess: async () => {
      toast.success(t('basalam.discountCreated'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'discounts'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const webhooks = Array.isArray(webhooksQ.data?.webhooks) ? webhooksQ.data.webhooks : []
  const profilesRaw = shippingQ.data?.profiles ?? shippingQ.data?.shipping
  const profilesList: Array<Record<string, unknown>> = (() => {
    if (Array.isArray(profilesRaw)) return profilesRaw as Array<Record<string, unknown>>
    if (profilesRaw && typeof profilesRaw === 'object') {
      const data = (profilesRaw as { data?: unknown }).data
      if (Array.isArray(data)) return data as Array<Record<string, unknown>>
    }
    return []
  })()

  return (
    <PageShell title={t('basalam.boothTitle')} description={t('basalam.boothSubtitle')}>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.boothProfile')}</CardTitle>
            <CardDescription>{t('basalam.boothProfileHint')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="title" />
            <Textarea value={summary} onChange={(e) => setSummary(e.target.value)} placeholder="summary" rows={4} />
            <Button onClick={() => saveVendor.mutate()} disabled={saveVendor.isPending}>
              {t('basalam.saveBooth')}
            </Button>
            {vendorQ.data?.vendor?.id ? (
              <p className="text-muted-foreground text-xs">vendor #{String(vendorQ.data.vendor.id)}</p>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.shippingTitle')}</CardTitle>
            <CardDescription>{t('basalam.shippingHint')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Input
                className="min-w-[12rem] flex-1"
                value={profileTitle}
                onChange={(e) => setProfileTitle(e.target.value)}
                placeholder={t('basalam.shippingProfileTitle')}
              />
              <Button
                onClick={() => createShippingProfile.mutate()}
                disabled={createShippingProfile.isPending || !profileTitle.trim()}
              >
                {t('basalam.createShippingProfile')}
              </Button>
            </div>
            <ul className="space-y-2 text-sm">
              {profilesList.map((p) => (
                <li key={String(p.id)} className="flex items-center justify-between gap-2 border-b py-2">
                  <span>
                    #{String(p.id)} {String(p.title ?? '')}
                  </span>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deleteShippingProfile.mutate(Number(p.id))}
                    disabled={deleteShippingProfile.isPending}
                  >
                    {t('basalam.delete')}
                  </Button>
                </li>
              ))}
            </ul>
            <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs">
              {JSON.stringify(
                {
                  carriers: shippingQ.data?.carriers ?? null,
                  vendor_carriers: shippingQ.data?.vendor_carriers ?? null,
                  strategy: shippingQ.data?.strategy ?? null,
                },
                null,
                2,
              )}
            </pre>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.webhookManage')}</CardTitle>
            <CardDescription>{webhooksQ.data?.webhook_url ?? '—'}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setupWebhook.mutate()} disabled={setupWebhook.isPending}>
                {t('basalam.setupWebhook')}
              </Button>
              <Button variant="secondary" onClick={() => rotateWebhook.mutate()} disabled={rotateWebhook.isPending}>
                {t('basalam.rotateWebhook')}
              </Button>
            </div>
            <ul className="space-y-2 text-sm">
              {webhooks.map((w) => (
                <li key={String(w.id)} className="flex items-center justify-between gap-2 border-b py-2">
                  <span>
                    #{String(w.id)} {String(w.url ?? '')}
                  </span>
                  <Button size="sm" variant="destructive" onClick={() => deleteWebhook.mutate(Number(w.id))}>
                    {t('basalam.delete')}
                  </Button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('basalam.discountsTitle')}</CardTitle>
            <CardDescription>{t('basalam.discountsHint')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <pre className="bg-muted max-h-40 overflow-auto rounded-md p-3 text-xs">
              {JSON.stringify(discountsQ.data?.discounts ?? {}, null, 2)}
            </pre>
            <Textarea
              className="font-mono text-xs"
              rows={5}
              value={discountPayload}
              onChange={(e) => setDiscountPayload(e.target.value)}
            />
            <Button onClick={() => createDiscount.mutate()} disabled={createDiscount.isPending}>
              {t('basalam.createDiscount')}
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>{t('basalam.chatTitle')}</CardTitle>
            <CardDescription>{t('basalam.chatHint')}</CardDescription>
          </CardHeader>
          <CardContent>
            {chatQ.data?.enabled ? (
              <p className="text-sm">{t('basalam.chatLoaded')}</p>
            ) : (
              <p className="text-muted-foreground text-sm">{t('basalam.chatDisabled')}</p>
            )}
            {chatQ.data?.admin_url ? (
              <a className="text-primary text-sm underline" href={chatQ.data.admin_url} target="_blank" rel="noreferrer">
                {t('basalam.openAdminChat')}
              </a>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </PageShell>
  )
}
