import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { PageShell } from '@/components/PageShell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { apiFetch } from '@/lib/api'
import { toastApiError } from '@/lib/apiError'

type OrderRow = {
  id: number
  invoice_id?: number
  status?: string | null
  total?: string | number | null
  customer?: string | null
  tracking?: string
  date?: string | null
}

export default function BasalamOrdersPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [trackingById, setTrackingById] = useState<Record<number, string>>({})
  const [delayDays, setDelayDays] = useState<Record<number, string>>({})
  const [delayDesc, setDelayDesc] = useState<Record<number, string>>({})
  const [cancelDesc, setCancelDesc] = useState<Record<number, string>>({})

  const ordersQ = useQuery({
    queryKey: ['basalam', 'orders'],
    queryFn: () => apiFetch<{ orders: OrderRow[]; total: number }>('basalam/orders?per_page=50'),
    refetchInterval: 15000,
  })

  const pull = useMutation({
    mutationFn: () => apiFetch('basalam/sync/orders/pull', { method: 'POST' }),
    onSuccess: async () => {
      toast.success(t('basalam.ordersPullQueued'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'orders'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const action = useMutation({
    mutationFn: (body: { path: string; payload: Record<string, unknown> }) =>
      apiFetch(body.path, { method: 'POST', body: JSON.stringify(body.payload) }),
    onSuccess: async () => {
      toast.success(t('basalam.orderActionOk'))
      await qc.invalidateQueries({ queryKey: ['basalam', 'orders'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <PageShell title={t('basalam.ordersTitle')} description={t('basalam.ordersSubtitle')}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>{t('basalam.pullOrders')}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-3">
          <Button onClick={() => pull.mutate()} disabled={pull.isPending}>
            {t('basalam.pullOrders')}
          </Button>
          <span className="text-muted-foreground text-xs">
            {t('basalam.total')}: {ordersQ.data?.total ?? 0}
          </span>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('basalam.connectedOrders')}</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-start">
                <th className="py-2 pe-2">WC</th>
                <th className="py-2 pe-2">{t('basalam.col.invoice')}</th>
                <th className="py-2 pe-2">{t('basalam.col.customer')}</th>
                <th className="py-2 pe-2">{t('basalam.col.status')}</th>
                <th className="py-2 pe-2">{t('basalam.col.total')}</th>
                <th className="py-2">{t('basalam.col.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {(ordersQ.data?.orders ?? []).map((o) => {
                const tracking = trackingById[o.id] ?? o.tracking ?? ''
                return (
                  <tr key={o.id} className="border-b align-top">
                    <td className="py-2 pe-2">#{o.id}</td>
                    <td className="py-2 pe-2">{o.invoice_id ?? '—'}</td>
                    <td className="py-2 pe-2">{o.customer || '—'}</td>
                    <td className="py-2 pe-2">{o.status || '—'}</td>
                    <td className="py-2 pe-2">{o.total ?? '—'}</td>
                    <td className="space-y-2 py-2">
                      <div className="flex flex-wrap gap-1">
                        <Button
                          size="sm"
                          onClick={() =>
                            action.mutate({ path: 'basalam/orders/confirm', payload: { order_id: o.id } })
                          }
                        >
                          {t('basalam.confirmOrder')}
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() =>
                            action.mutate({
                              path: 'basalam/orders/cancel',
                              payload: { order_id: o.id, reason_id: 3481, description: '' },
                            })
                          }
                        >
                          {t('basalam.cancelOrder')}
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <Input
                          className="h-8 max-w-[10rem]"
                          placeholder={t('basalam.trackingCode')}
                          value={tracking}
                          onChange={(e) =>
                            setTrackingById((prev) => ({ ...prev, [o.id]: e.target.value }))
                          }
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!tracking}
                          onClick={() =>
                            action.mutate({
                              path: 'basalam/orders/tracking',
                              payload: {
                                order_id: o.id,
                                tracking_code: tracking,
                                shipping_method: 3197,
                                phone: '',
                              },
                            })
                          }
                        >
                          {t('basalam.shipOrder')}
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <Input
                          className="h-8 max-w-[6rem]"
                          placeholder={t('basalam.delayDays')}
                          value={delayDays[o.id] ?? ''}
                          onChange={(e) => setDelayDays((p) => ({ ...p, [o.id]: e.target.value }))}
                        />
                        <Input
                          className="h-8 max-w-[12rem]"
                          placeholder={t('basalam.delayDesc')}
                          value={delayDesc[o.id] ?? ''}
                          onChange={(e) => setDelayDesc((p) => ({ ...p, [o.id]: e.target.value }))}
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!delayDays[o.id] || !delayDesc[o.id]}
                          onClick={() =>
                            action.mutate({
                              path: 'basalam/orders/delay',
                              payload: {
                                order_id: o.id,
                                postpone_days: Number(delayDays[o.id]) || 0,
                                description: delayDesc[o.id] || '',
                              },
                            })
                          }
                        >
                          {t('basalam.delayOrder')}
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <Input
                          className="h-8 max-w-[14rem]"
                          placeholder={t('basalam.cancelRequestDesc')}
                          value={cancelDesc[o.id] ?? ''}
                          onChange={(e) => setCancelDesc((p) => ({ ...p, [o.id]: e.target.value }))}
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!cancelDesc[o.id]}
                          onClick={() =>
                            action.mutate({
                              path: 'basalam/orders/cancel-request',
                              payload: { order_id: o.id, description: cancelDesc[o.id] || '' },
                            })
                          }
                        >
                          {t('basalam.cancelRequest')}
                        </Button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          {!ordersQ.data?.orders?.length ? (
            <p className="text-muted-foreground mt-3 text-sm">{t('basalam.noOrders')}</p>
          ) : null}
        </CardContent>
      </Card>
    </PageShell>
  )
}
