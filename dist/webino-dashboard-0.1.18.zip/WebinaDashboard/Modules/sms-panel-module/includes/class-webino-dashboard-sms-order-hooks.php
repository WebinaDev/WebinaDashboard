<?php
/**
 * WooCommerce hooks → CRM order SMS notify.
 *
 * @package WebinoDashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Forwards order events to webinocrm/v1/modirpayamak/orders/notify (realtime, non-blocking).
 */
final class Webino_Dashboard_Sms_Order_Hooks {

	/** @var array<int,array{event_key:string,order:array<string,mixed>}> */
	private static $pending = array();

	/** @var bool */
	private static $shutdown_registered = false;

	/**
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'on_checkout_processed' ), 20, 1 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status_changed' ), 20, 4 );
		add_action( 'webino_dashboard_order_post_barcode_saved', array( __CLASS__, 'on_post_barcode' ), 10, 2 );
		add_action( 'woocommerce_low_stock', array( __CLASS__, 'on_wc_low_stock' ), 10, 1 );
		add_action( 'woocommerce_no_stock', array( __CLASS__, 'on_wc_no_stock' ), 10, 1 );
		add_action( 'webino_dashboard_product_stock_low', array( __CLASS__, 'on_stock_low' ), 10, 2 );
		add_action( 'webino_dashboard_product_stock_out', array( __CLASS__, 'on_stock_out' ), 10, 2 );
	}

	/**
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public static function on_wc_low_stock( $product ) {
		$resolved = self::resolve_wc_product( $product );
		if ( ! $resolved ) {
			return;
		}
		self::notify_stock_event( 'stock-low', $resolved['id'], $resolved['qty'] );
	}

	/**
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public static function on_wc_no_stock( $product ) {
		$resolved = self::resolve_wc_product( $product );
		if ( ! $resolved ) {
			return;
		}
		self::notify_stock_event( 'stock-out', $resolved['id'], $resolved['qty'] );
	}

	/**
	 * @param WC_Product|int $product Product or id.
	 * @return array{id:int,qty:float|null}|null
	 */
	private static function resolve_wc_product( $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( (int) $product );
		}
		if ( ! $product instanceof WC_Product ) {
			return null;
		}
		$id = (int) $product->get_id();
		if ( $product->is_type( 'variation' ) ) {
			$id = (int) $product->get_parent_id();
			if ( $id < 1 ) {
				$id = (int) $product->get_id();
			}
		}
		$qty = $product->managing_stock() ? (float) $product->get_stock_quantity() : null;
		return array(
			'id'  => $id,
			'qty' => $qty,
		);
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function on_checkout_processed( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$status = $order->get_status();
		if ( 'pending' === $status ) {
			self::notify( 'pending_on_create', $order );
		}
	}

	/**
	 * @param int      $order_id Order id.
	 * @param string   $from From status.
	 * @param string   $to To status.
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public static function on_status_changed( $order_id, $from, $to, $order ) {
		unset( $from );
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return;
		}
		$event = Webino_Dashboard_Sms_Order_Map::event_for_status( $to );
		if ( '' === $event ) {
			return;
		}
		self::notify( $event, $order );
	}

	/**
	 * @param int    $order_id Order id.
	 * @param string $barcode Barcode.
	 * @return void
	 */
	public static function on_post_barcode( $order_id, $barcode ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$snapshot            = self::build_snapshot( $order );
		$snapshot['barcode'] = (string) $barcode;
		self::notify_snapshot( 'post-barcode', $snapshot );
	}

	/**
	 * @param int $product_id Product id.
	 * @param int $qty Quantity.
	 * @return void
	 */
	public static function on_stock_low( $product_id, $qty ) {
		self::notify_stock_event( 'stock-low', (int) $product_id, $qty );
	}

	/**
	 * @param int       $product_id Product id.
	 * @param int|float $qty Quantity.
	 * @return void
	 */
	public static function on_stock_out( $product_id, $qty ) {
		self::notify_stock_event( 'stock-out', (int) $product_id, $qty );
	}

	/**
	 * @param string   $event_key Event.
	 * @param WC_Order $order Order.
	 * @return void
	 */
	private static function notify( $event_key, $order ) {
		self::notify_snapshot( $event_key, self::build_snapshot( $order ) );
	}

	/**
	 * Queue realtime CRM notify (fires on shutdown, non-blocking HTTP).
	 *
	 * @param string               $event_key Event.
	 * @param array<string,mixed>  $snapshot Snapshot.
	 * @param bool                 $sync When true, send immediately and wait (manual UI).
	 * @return array{ok:bool,error?:string}|null Sync result or null when queued.
	 */
	public static function notify_snapshot( $event_key, array $snapshot, $sync = false ) {
		$order_id = (int) ( $snapshot['id'] ?? 0 );
		if ( $order_id <= 0 && 'stock-low' !== $event_key && 'stock-out' !== $event_key ) {
			return array( 'ok' => false, 'error' => 'invalid_order' );
		}
		$product_id = (int) ( $snapshot['product_id'] ?? 0 );
		if ( $product_id > 0 && in_array( $event_key, array( 'stock-low', 'stock-out' ), true ) ) {
			$dedupe_key = 'webino_sms_' . $event_key . '_p' . $product_id . '_q' . (string) ( $snapshot['stock_quantity'] ?? '' );
		} else {
			$dedupe_key = 'webino_sms_' . $event_key . '_' . $order_id . '_' . ( $snapshot['status'] ?? '' ) . '_' . ( $snapshot['barcode'] ?? '' );
		}
		if ( ! $sync && get_transient( $dedupe_key ) ) {
			return array( 'ok' => true, 'skipped' => true, 'reason' => 'dedupe' );
		}
		if ( ! $sync ) {
			set_transient( $dedupe_key, 1, 60 );
		}

		$license = Webino_Dashboard_License::instance();
		if ( ! $license->is_license_active() ) {
			return array( 'ok' => false, 'error' => 'license_inactive' );
		}

		$payload = array(
			'event_key' => sanitize_key( $event_key ),
			'order'     => $snapshot,
		);

		if ( $sync ) {
			$res = $license->crm_post(
				'wp-json/webinocrm/v1/modirpayamak/orders/notify',
				$payload,
				'install'
			);
			return array(
				'ok'    => ! empty( $res['ok'] ),
				'data'  => $res['data'] ?? null,
				'error' => $res['error'] ?? '',
			);
		}

		self::$pending[] = $payload;
		if ( ! self::$shutdown_registered ) {
			self::$shutdown_registered = true;
			add_action( 'shutdown', array( __CLASS__, 'flush_pending' ), 5 );
		}
		return null;
	}

	/**
	 * Fire queued notifies with non-blocking HTTP so checkout/status UI is not delayed.
	 *
	 * @return void
	 */
	public static function flush_pending() {
		if ( ! self::$pending ) {
			return;
		}
		$queue         = self::$pending;
		self::$pending = array();
		$license       = Webino_Dashboard_License::instance();
		foreach ( $queue as $payload ) {
			$license->crm_post_async(
				'wp-json/webinocrm/v1/modirpayamak/orders/notify',
				$payload
			);
		}
	}

	/**
	 * @param string       $event_key Event key.
	 * @param int          $product_id WC product id.
	 * @param int|float|null $qty Stock qty if known.
	 * @return void
	 */
	public static function notify_stock_event( $event_key, $product_id, $qty = null ) {
		self::notify_snapshot( $event_key, self::build_stock_snapshot( $product_id, $qty ) );
	}

	/**
	 * @param int            $product_id Product id.
	 * @param int|float|null $qty Quantity.
	 * @return array<string,mixed>
	 */
	public static function build_stock_snapshot( $product_id, $qty = null ) {
		$product_id = (int) $product_id;
		$name       = '';
		$url        = '';
		$stock_qty  = $qty;
		$low_amount = '';

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( $product instanceof WC_Product ) {
			$name = $product->get_name();
			$url  = (string) get_permalink( $product_id );
			if ( null === $stock_qty && $product->managing_stock() ) {
				$stock_qty = (float) $product->get_stock_quantity();
			}
			$low = $product->get_low_stock_amount();
			if ( null !== $low && '' !== $low ) {
				$low_amount = (string) $low;
			}
		}

		return array(
			'id'               => 0,
			'product_id'       => $product_id,
			'product_name'     => $name ?: (string) $product_id,
			'product_url'      => $url,
			'stock_quantity'   => null !== $stock_qty ? (string) $stock_qty : '',
			'qty'              => null !== $stock_qty ? (string) $stock_qty : '',
			'low_stock_amount' => $low_amount,
			'site_name'        => get_bloginfo( 'name' ),
			'site_url'         => home_url(),
		);
	}

	/**
	 * @param WC_Order $order Order.
	 * @return array<string,mixed>
	 */
	public static function build_snapshot( $order ) {
		$status = $order->get_status();
		$phone  = $order->get_billing_phone();
		if ( '' === $phone ) {
			$phone = (string) get_user_meta( $order->get_customer_id(), 'billing_phone', true );
		}
		$tracking = (string) $order->get_meta( '_tracking_code' );
		if ( '' === $tracking ) {
			$tracking = (string) $order->get_meta( 'tracking_code' );
		}
		$barcode = (string) $order->get_meta( '_post_barcode' );
		if ( '' === $barcode ) {
			$barcode = (string) $order->get_meta( 'post_barcode' );
		}
		$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		$label    = $statuses[ 'wc-' . $status ] ?? $status;

		$item_names = array();
		$item_full  = array();
		$items_qty  = 0;
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$qty          = (int) $item->get_quantity();
			$items_qty   += $qty;
			$item_names[] = $item->get_name() . ( $qty > 1 ? ' ×' . $qty : '' );
			$item_full[]  = $item->get_name() . ' ×' . $qty;
		}

		$shipping_methods = array();
		foreach ( $order->get_shipping_methods() as $ship ) {
			$shipping_methods[] = $ship->get_name();
		}

		$billing  = self::format_address( $order, 'billing' );
		$shipping = self::format_address( $order, 'shipping' );
		$created  = $order->get_date_created();
		$items_str = implode( ', ', $item_names );
		$payment_url = '';
		if ( method_exists( $order, 'get_checkout_payment_url' ) ) {
			$payment_url = (string) $order->get_checkout_payment_url();
		}

		return array(
			'id'               => $order->get_id(),
			'number'           => $order->get_order_number(),
			'customer_name'    => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'customer_phone'   => $phone,
			'mobile'           => $phone,
			'customer_email'   => (string) $order->get_billing_email(),
			'total'            => $order->get_formatted_order_total(),
			'price'            => $order->get_formatted_order_total(),
			'status'           => $status,
			'status_label'     => wp_strip_all_tags( (string) $label ),
			'tracking'         => $tracking,
			'barcode'          => $barcode,
			'items'            => $items_str,
			'all_items'        => $items_str,
			'all_items_full'   => implode( ', ', $item_full ),
			'items_qty'        => (string) $items_qty,
			'count_items'      => (string) $items_qty,
			'payment_method'   => (string) ( $order->get_payment_method_title() ?: $order->get_payment_method() ),
			'payment_url'      => $payment_url,
			'shipping_method'  => implode( ', ', $shipping_methods ),
			'transaction_id'   => (string) $order->get_transaction_id(),
			'description'      => (string) $order->get_customer_note(),
			'billing_address'  => $billing,
			'shipping_address' => $shipping,
			'b_first_name'     => (string) $order->get_billing_first_name(),
			'b_last_name'      => (string) $order->get_billing_last_name(),
			'b_company'        => (string) $order->get_billing_company(),
			'b_country'        => (string) $order->get_billing_country(),
			'b_state'          => (string) $order->get_billing_state(),
			'b_city'           => (string) $order->get_billing_city(),
			'b_address_1'      => (string) $order->get_billing_address_1(),
			'b_address_2'      => (string) $order->get_billing_address_2(),
			'b_postcode'       => (string) $order->get_billing_postcode(),
			'sh_first_name'    => (string) $order->get_shipping_first_name(),
			'sh_last_name'     => (string) $order->get_shipping_last_name(),
			'sh_company'       => (string) $order->get_shipping_company(),
			'sh_country'       => (string) $order->get_shipping_country(),
			'sh_state'         => (string) $order->get_shipping_state(),
			'sh_city'          => (string) $order->get_shipping_city(),
			'sh_address_1'     => (string) $order->get_shipping_address_1(),
			'sh_address_2'     => (string) $order->get_shipping_address_2(),
			'sh_postcode'      => (string) $order->get_shipping_postcode(),
			'order_date'       => $created ? $created->date_i18n( 'Y-m-d H:i' ) : '',
			'site_name'        => get_bloginfo( 'name' ),
			'site_url'         => home_url(),
		);
	}

	/**
	 * @param WC_Order $order Order.
	 * @param string   $type billing|shipping.
	 * @return string
	 */
	private static function format_address( $order, $type ) {
		$parts = array();
		if ( 'billing' === $type ) {
			$parts = array_filter(
				array(
					$order->get_billing_address_1(),
					$order->get_billing_address_2(),
					$order->get_billing_city(),
					$order->get_billing_state(),
					$order->get_billing_postcode(),
				)
			);
		} else {
			$parts = array_filter(
				array(
					$order->get_shipping_address_1(),
					$order->get_shipping_address_2(),
					$order->get_shipping_city(),
					$order->get_shipping_state(),
					$order->get_shipping_postcode(),
				)
			);
		}
		return implode( '، ', $parts );
	}
}
