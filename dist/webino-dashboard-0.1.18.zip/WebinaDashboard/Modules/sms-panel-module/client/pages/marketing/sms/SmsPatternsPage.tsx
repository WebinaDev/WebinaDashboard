import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { createSmsPattern, fetchSmsPatternRegistry, fetchSmsPatterns } from '@/lib/modirpayamak-api'
import { ChevronDown, Plus, Trash2 } from 'lucide-react'

type VarRow = { name: string; type: 'string' | 'integer' }

export default function SmsPatternsPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const patternsQ = useQuery({ queryKey: ['sms-patterns'], queryFn: () => fetchSmsPatterns() })
  const registryQ = useQuery({ queryKey: ['sms-pattern-registry'], queryFn: fetchSmsPatternRegistry })
  useQueryErrorToast(patternsQ)
  useQueryErrorToast(registryQ)

  const [open, setOpen] = useState(false)
  const [rulesOpen, setRulesOpen] = useState(true)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [website, setWebsite] = useState('')
  const [message, setMessage] = useState('')
  const [brandName, setBrandName] = useState('')
  const [isShare, setIsShare] = useState(false)
  const [vars, setVars] = useState<VarRow[]>([])
  const [checkBrand, setCheckBrand] = useState(false)
  const [checkNonPromo, setCheckNonPromo] = useState(false)
  const [checkEnamad, setCheckEnamad] = useState(false)
  const [checkTest, setCheckTest] = useState(false)

  const edgeData = patternsQ.data?.data
  type RegistryRow = {
    scope?: string
    event_key?: string
    ippanel_code?: string
    sync_status?: string
    last_error?: string
  }
  const registry = (registryQ.data?.registry ?? []) as RegistryRow[]

  const rules = useMemo(
    () => [
      t('marketing.sms.patternRule1'),
      t('marketing.sms.patternRule2'),
      t('marketing.sms.patternRule3'),
      t('marketing.sms.patternRule4'),
      t('marketing.sms.patternRule5'),
      t('marketing.sms.patternRule6'),
    ],
    [t],
  )

  const createMut = useMutation({
    mutationFn: createSmsPattern,
    onSuccess: (res) => {
      if (res.ok) {
        toast.success(t('common.saved'))
        setOpen(false)
        void qc.invalidateQueries({ queryKey: ['sms-patterns'] })
        void qc.invalidateQueries({ queryKey: ['sms-pattern-registry'] })
      } else {
        toast.error(res.message || t('marketing.sms.sendFailed'))
      }
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const submit = () => {
    if (!title.trim() || !description.trim() || !message.trim()) {
      toast.error(t('marketing.sms.patternRequiredFields'))
      return
    }
    if (website && !/^https:\/\//i.test(website.trim())) {
      toast.error(t('marketing.sms.patternWebsiteHttps'))
      return
    }
    if (brandName.trim() && !message.includes(brandName.trim())) {
      toast.error(t('marketing.sms.patternBrandMissing'))
      return
    }
    if (!checkBrand || !checkNonPromo) {
      toast.error(t('marketing.sms.patternChecklistRequired'))
      return
    }
    createMut.mutate({
      title: title.trim(),
      description: description.trim(),
      message: message.trim(),
      website: website.trim() || undefined,
      is_share: isShare,
      variable: vars.filter((v) => v.name.trim()).map((v) => ({ name: v.name.trim(), type: v.type })),
    })
  }

  return (
    <div className="space-y-6 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-semibold">{t('marketing.sms.patternsTitle')}</h1>
        <Button type="button" size="sm" onClick={() => setOpen(true)}>
          <Plus className="me-1 h-4 w-4" />
          {t('marketing.sms.addPattern')}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.registryTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          {registry.length === 0 ? (
            <p className="text-muted-foreground text-sm">{t('marketing.sms.noRegistry')}</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {registry.map((row, i) => (
                <li key={i} className="rounded border px-3 py-2">
                  <span className="font-mono">{row.scope}</span> / {row.event_key} — {row.ippanel_code} (
                  {row.sync_status})
                  {row.last_error ? <span className="text-destructive block text-xs">{row.last_error}</span> : null}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.ippanelPatterns')}</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="max-h-96 overflow-auto rounded bg-muted p-3 text-xs">
            {JSON.stringify(edgeData ?? {}, null, 2)}
          </pre>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('marketing.sms.addPattern')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Collapsible open={rulesOpen} onOpenChange={setRulesOpen}>
              <CollapsibleTrigger asChild>
                <Button type="button" variant="outline" size="sm" className="w-full justify-between">
                  {t('marketing.sms.patternRulesTitle')}
                  <ChevronDown className={`h-4 w-4 transition ${rulesOpen ? 'rotate-180' : ''}`} />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <ul className="text-muted-foreground mt-2 list-disc space-y-1 rounded-md border px-5 py-3 text-sm">
                  {rules.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </CollapsibleContent>
            </Collapsible>
            <div>
              <Label>{t('marketing.sms.patternTitle')}</Label>
              <Input className="mt-1" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div>
              <Label>{t('marketing.sms.patternDescription')}</Label>
              <Textarea className="mt-1" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div>
              <Label>{t('marketing.sms.patternWebsite')}</Label>
              <Input className="mt-1" dir="ltr" value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://" />
            </div>
            <div>
              <Label>{t('marketing.sms.brandName')}</Label>
              <Input className="mt-1" value={brandName} onChange={(e) => setBrandName(e.target.value)} />
            </div>
            <div>
              <Label>{t('marketing.sms.patternMessage')}</Label>
              <Textarea className="mt-1 font-mono text-sm" rows={4} value={message} onChange={(e) => setMessage(e.target.value)} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>{t('marketing.sms.patternVariables')}</Label>
                <Button type="button" size="sm" variant="outline" onClick={() => setVars([...vars, { name: '', type: 'string' }])}>
                  <Plus className="me-1 h-3 w-3" />
                  {t('marketing.sms.addVariable')}
                </Button>
              </div>
              {vars.map((v, idx) => (
                <div key={idx} className="flex gap-2">
                  <Input
                    className="font-mono"
                    dir="ltr"
                    value={v.name}
                    onChange={(e) => {
                      const next = [...vars]
                      next[idx] = { ...next[idx], name: e.target.value }
                      setVars(next)
                    }}
                  />
                  <Select
                    value={v.type}
                    onValueChange={(type) => {
                      const next = [...vars]
                      next[idx] = { ...next[idx], type: type as 'string' | 'integer' }
                      setVars(next)
                    }}
                  >
                    <SelectTrigger className="w-28">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="string">string</SelectItem>
                      <SelectItem value="integer">integer</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="ghost" size="icon" onClick={() => setVars(vars.filter((_, i) => i !== idx))}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <div className="space-y-2 rounded border p-3 text-sm">
              <label className="flex gap-2">
                <Checkbox checked={checkBrand} onCheckedChange={(c) => setCheckBrand(c === true)} />
                {t('marketing.sms.checkBrandInMessage')}
              </label>
              <label className="flex gap-2">
                <Checkbox checked={checkNonPromo} onCheckedChange={(c) => setCheckNonPromo(c === true)} />
                {t('marketing.sms.checkNonPromotional')}
              </label>
              <label className="flex gap-2">
                <Checkbox checked={checkEnamad} onCheckedChange={(c) => setCheckEnamad(c === true)} />
                {t('marketing.sms.checkEnamad')}
              </label>
              <label className="flex gap-2">
                <Checkbox checked={checkTest} onCheckedChange={(c) => setCheckTest(c === true)} />
                {t('marketing.sms.checkTestWord')}
              </label>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={isShare} onCheckedChange={(c) => setIsShare(c === true)} />
              {t('marketing.sms.patternIsShare')}
            </label>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="button" disabled={createMut.isPending} onClick={submit}>
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
