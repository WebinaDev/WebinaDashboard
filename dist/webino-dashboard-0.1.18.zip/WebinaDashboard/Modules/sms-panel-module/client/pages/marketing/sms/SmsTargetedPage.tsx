import { useQuery } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsBulkRecipients, fetchSmsBulkStats, fetchSmsOutbox, smsQueryOptions } from '@/lib/modirpayamak-api'

function asRows(data: unknown): Array<Record<string, unknown>> {
  if (!data) return []
  if (Array.isArray(data)) return data as Array<Record<string, unknown>>
  if (typeof data === 'object' && data !== null) {
    const obj = data as Record<string, unknown>
    if (Array.isArray(obj.data)) return obj.data as Array<Record<string, unknown>>
  }
  return []
}

export default function SmsTargetedPage() {
  const { t } = useTranslation()
  const [selected, setSelected] = useState('')
  const outboxQ = useQuery({
    queryKey: ['sms', 'outbox', 'targeted'],
    queryFn: () => fetchSmsOutbox(1, 40),
    ...smsQueryOptions,
  })
  useQueryErrorToast(outboxQ)
  const unavailable = isSmsUnavailable(outboxQ.data)
  const rows = useMemo(() => (unavailable ? [] : asRows(outboxQ.data?.data)), [unavailable, outboxQ.data])

  const statsQ = useQuery({
    queryKey: ['sms', 'bulk-stats', selected],
    queryFn: () => fetchSmsBulkStats(selected),
    enabled: !!selected,
    ...smsQueryOptions,
  })
  const recipientsQ = useQuery({
    queryKey: ['sms', 'bulk-recipients', selected],
    queryFn: () => fetchSmsBulkRecipients(selected, 1),
    enabled: !!selected,
    ...smsQueryOptions,
  })

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.targetedTitle')}</h1>
      {unavailable ? (
        <SmsServiceBanner message={outboxQ.data?.message} onRetry={() => void outboxQ.refetch()} />
      ) : null}
      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.pickCampaign')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Input
              className="max-w-xs font-mono"
              dir="ltr"
              placeholder="outbox id"
              value={selected}
              onChange={(e) => setSelected(e.target.value)}
            />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">ID</th>
                  <th className="p-2 text-start">{t('marketing.sms.status')}</th>
                  <th className="p-2 text-start" />
                </tr>
              </thead>
              <tbody>
                {outboxQ.isPending
                  ? Array.from({ length: 4 }, (_, i) => (
                      <tr key={i}>
                        <td className="p-2" colSpan={3}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : rows.map((r, i) => {
                      const id = String(r.id ?? r.messages_outbox_id ?? r.outbox_id ?? '')
                      return (
                        <tr key={id || i} className="border-b">
                          <td className="p-2 font-mono" dir="ltr">
                            {id || '—'}
                          </td>
                          <td className="p-2">{String(r.status ?? r.state ?? '')}</td>
                          <td className="p-2 text-end">
                            {id ? (
                              <Button type="button" size="sm" variant="outline" onClick={() => setSelected(id)}>
                                {t('marketing.sms.viewStats')}
                              </Button>
                            ) : null}
                          </td>
                        </tr>
                      )
                    })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      {selected ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>{t('marketing.sms.bulkStats')}</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="overflow-auto rounded bg-muted p-3 text-xs" dir="ltr">
                {JSON.stringify(statsQ.data?.data ?? statsQ.data ?? {}, null, 2)}
              </pre>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>{t('marketing.sms.recipients')}</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="overflow-auto rounded bg-muted p-3 text-xs" dir="ltr">
                {JSON.stringify(recipientsQ.data?.data ?? recipientsQ.data ?? {}, null, 2)}
              </pre>
            </CardContent>
          </Card>
        </div>
      ) : null}
    </div>
  )
}
