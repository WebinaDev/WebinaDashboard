import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { cancelScheduledSms, fetchSmsOutbox, smsQueryOptions } from '@/lib/modirpayamak-api'

function unwrapList(data: unknown): Record<string, unknown>[] {
  if (!data) return []
  if (Array.isArray(data)) return data as Record<string, unknown>[]
  const d = data as Record<string, unknown>
  for (const key of ['messages', 'data', 'items', 'list', 'outbox']) {
    if (Array.isArray(d[key])) return d[key] as Record<string, unknown>[]
  }
  return []
}

function isFuture(sendTime: unknown): boolean {
  if (!sendTime) return false
  const t = new Date(String(sendTime)).getTime()
  return !isNaN(t) && t > Date.now()
}

export default function SmsScheduledPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [page, setPage] = useState(1)
  const [cancellingId, setCancellingId] = useState<string | null>(null)

  const outboxQ = useQuery({
    queryKey: ['sms', 'outbox', page],
    queryFn: () => fetchSmsOutbox(page, 50),
    ...smsQueryOptions,
  })
  useQueryErrorToast(outboxQ)

  const allItems = unwrapList(outboxQ.data?.data)
  const scheduled = allItems.filter((m) =>
    isFuture(m.send_time ?? m.scheduled_at ?? m.scheduled_time)
  )
  const loading = outboxQ.isPending

  const cancel = async (id: string) => {
    setCancellingId(id)
    try {
      const res = await cancelScheduledSms(id)
      if (res.ok) {
        toast.success(t('marketing.sms.cancelled'))
        void qc.invalidateQueries({ queryKey: ['sms', 'outbox'] })
      } else {
        toast.error(t('marketing.sms.cancelFailed'))
      }
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setCancellingId(null)
  }

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.scheduledTitle')}</h1>
      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.scheduledTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">{t('marketing.sms.outboxId')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.message')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.scheduledFor')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.status')}</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {loading
                  ? Array.from({ length: 5 }, (_, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2" colSpan={5}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : scheduled.map((m, i) => {
                      const id = String(m.id ?? m.bulk_id ?? m.outbox_id ?? i)
                      const sendTime = String(m.send_time ?? m.scheduled_at ?? m.scheduled_time ?? '—')
                      return (
                        <tr key={id} className="border-b">
                          <td className="p-2 font-mono text-xs">{id}</td>
                          <td className="max-w-xs truncate p-2">
                            {String(m.message ?? m.body ?? m.text ?? '—')}
                          </td>
                          <td className="p-2">{sendTime}</td>
                          <td className="p-2">{String(m.status ?? '—')}</td>
                          <td className="p-2">
                            <Button
                              variant="destructive"
                              size="sm"
                              disabled={cancellingId === id}
                              onClick={() => void cancel(id)}
                            >
                              {cancellingId === id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                t('marketing.sms.cancelSend')
                              )}
                            </Button>
                          </td>
                        </tr>
                      )
                    })}
              </tbody>
            </table>
            {!loading && !scheduled.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
            ) : null}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1 || loading}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">{page}</span>
            <Button
              variant="outline"
              size="sm"
              disabled={loading || allItems.length < 50}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
