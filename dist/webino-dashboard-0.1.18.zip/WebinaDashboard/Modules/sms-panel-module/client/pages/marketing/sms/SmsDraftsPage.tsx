import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import { createSmsDraft, deleteSmsDraft, fetchSmsDrafts, smsQueryOptions } from '@/lib/modirpayamak-api'

function asRows(data: unknown): Array<Record<string, unknown>> {
  if (!data) return []
  if (Array.isArray(data)) return data as Array<Record<string, unknown>>
  if (typeof data === 'object' && data !== null) {
    const obj = data as Record<string, unknown>
    if (Array.isArray(obj.data)) return obj.data as Array<Record<string, unknown>>
  }
  return []
}

export default function SmsDraftsPage() {
  const { t, i18n } = useTranslation()
  const qc = useQueryClient()
  const [title, setTitle] = useState('')
  const [message, setMessage] = useState('')

  const q = useQuery({
    queryKey: ['sms', 'drafts'],
    queryFn: () => fetchSmsDrafts(1),
    ...smsQueryOptions,
  })
  useQueryErrorToast(q)
  const unavailable = isSmsUnavailable(q.data)
  const rows = useMemo(() => (unavailable ? [] : asRows(q.data?.data)), [unavailable, q.data])

  const createM = useMutation({
    mutationFn: () => createSmsDraft({ title, message, text: message }),
    onSuccess: async () => {
      toast.success(t('common.saved'))
      setTitle('')
      setMessage('')
      await qc.invalidateQueries({ queryKey: ['sms', 'drafts'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  const deleteM = useMutation({
    mutationFn: (id: number) => deleteSmsDraft(id),
    onSuccess: async () => {
      toast.success(t('common.deleted'))
      await qc.invalidateQueries({ queryKey: ['sms', 'drafts'] })
    },
    onError: (e: Error) => toastApiError(t, e),
  })

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.draftsTitle')}</h1>
      {unavailable ? <SmsServiceBanner message={q.data?.message} onRetry={() => void q.refetch()} /> : null}
      <Card className="max-w-lg">
        <CardHeader>
          <CardTitle>{t('marketing.sms.newDraft')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>{t('marketing.sms.name')}</Label>
            <Input className="mt-1" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <Label>{t('marketing.sms.message')}</Label>
            <Textarea className="mt-1" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <Button type="button" disabled={createM.isPending || !message.trim()} onClick={() => createM.mutate()}>
            {t('common.save')}
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-0">
          <ul className="divide-y">
            {rows.map((r, i) => {
              const id = Number(r.id ?? 0)
              return (
                <li key={id || i} className="flex items-start justify-between gap-3 p-3 text-sm">
                  <div>
                    <p className="font-medium">{String(r.title ?? r.name ?? `#${id || i + 1}`)}</p>
                    <p className="text-muted-foreground mt-1 whitespace-pre-wrap">
                      {String(r.message ?? r.text ?? r.body ?? '')}
                    </p>
                  </div>
                  {id ? (
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={deleteM.isPending}
                      onClick={() => deleteM.mutate(id)}
                    >
                      {t('common.delete')}
                    </Button>
                  ) : null}
                </li>
              )
            })}
          </ul>
          {!q.isPending && !rows.length ? (
            <p className="text-muted-foreground p-4 text-sm">{t('marketing.sms.noDrafts')}</p>
          ) : null}
        </CardContent>
      </Card>
      {/* keep i18n used */}
      <span className="sr-only">{i18n.language}</span>
    </div>
  )
}
