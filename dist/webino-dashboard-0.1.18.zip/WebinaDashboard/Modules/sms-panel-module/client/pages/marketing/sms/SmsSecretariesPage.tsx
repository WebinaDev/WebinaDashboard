import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { Loader2, Plus, Trash2 } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import {
  deleteSmsSecretary,
  fetchSmsSecretaries,
  saveSmsSecretary,
  smsQueryOptions,
} from '@/lib/modirpayamak-api'

type SecretaryType = 'auto_reply' | 'inbox_forward' | 'code_reader' | 'membership' | 'all'

const SECRETARY_TYPES: SecretaryType[] = ['auto_reply', 'inbox_forward', 'code_reader', 'membership']

export default function SmsSecretariesPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [filter, setFilter] = useState<SecretaryType>('all')
  const [formType, setFormType] = useState<Omit<SecretaryType, 'all'>>('auto_reply')
  const [keyword, setKeyword] = useState('')
  const [response, setResponse] = useState('')
  const [saving, setSaving] = useState(false)
  const [deletingId, setDeletingId] = useState<number | null>(null)

  const secretariesQ = useQuery({
    queryKey: ['sms', 'secretaries'],
    queryFn: fetchSmsSecretaries,
    ...smsQueryOptions,
  })
  useQueryErrorToast(secretariesQ)

  const allSecretaries = secretariesQ.data?.secretaries ?? []
  const secretaries =
    filter === 'all'
      ? allSecretaries
      : allSecretaries.filter((s) => s.type === filter)
  const loading = secretariesQ.isPending

  const save = async () => {
    if (!keyword.trim()) return
    setSaving(true)
    try {
      await saveSmsSecretary({
        type: formType,
        keyword: keyword.trim(),
        response: response.trim() || undefined,
      })
      toast.success(t('marketing.sms.secretarySaved'))
      setKeyword('')
      setResponse('')
      void qc.invalidateQueries({ queryKey: ['sms', 'secretaries'] })
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setSaving(false)
  }

  const remove = async (id: number) => {
    setDeletingId(id)
    try {
      await deleteSmsSecretary(id)
      toast.success(t('marketing.sms.secretaryDeleted'))
      void qc.invalidateQueries({ queryKey: ['sms', 'secretaries'] })
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setDeletingId(null)
  }

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.secretariesTitle')}</h1>

      <Card className="max-w-lg">
        <CardHeader>
          <CardTitle>{t('marketing.sms.addSecretary')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>{t('marketing.sms.secretaryType')}</Label>
            <Select
              value={String(formType)}
              onValueChange={(v) => setFormType(v as Omit<SecretaryType, 'all'>)}
            >
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SECRETARY_TYPES.map((tp) => (
                  <SelectItem key={tp} value={tp}>
                    {t(`marketing.sms.secretary_${tp}`)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>{t('marketing.sms.secretaryKeyword')}</Label>
            <Input
              className="mt-1"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
            />
          </div>
          <div>
            <Label>{t('marketing.sms.secretaryResponse')}</Label>
            <Textarea
              className="mt-1"
              rows={3}
              value={response}
              onChange={(e) => setResponse(e.target.value)}
              placeholder={t('marketing.sms.secretaryResponseHint')}
            />
          </div>
          <Button type="button" disabled={saving || !keyword.trim()} onClick={() => void save()}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
            {t('marketing.sms.addSecretary')}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle>{t('marketing.sms.secretariesTitle')}</CardTitle>
          <Select value={filter} onValueChange={(v) => setFilter(v as SecretaryType)}>
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('marketing.sms.secretaryAll')}</SelectItem>
              {SECRETARY_TYPES.map((tp) => (
                <SelectItem key={tp} value={tp}>
                  {t(`marketing.sms.secretary_${tp}`)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">#</th>
                  <th className="p-2 text-start">{t('marketing.sms.secretaryType')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.secretaryKeyword')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.secretaryResponse')}</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {loading
                  ? Array.from({ length: 4 }, (_, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2" colSpan={5}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : secretaries.map((s, i) => {
                      const id = typeof s.id === 'number' ? s.id : Number(s.id)
                      return (
                        <tr key={String(s.id ?? i)} className="border-b">
                          <td className="p-2">{String(s.id ?? i + 1)}</td>
                          <td className="p-2">{String(s.type ?? '—')}</td>
                          <td className="p-2">{String(s.keyword ?? s.trigger ?? '—')}</td>
                          <td className="max-w-xs truncate p-2">
                            {String(s.response ?? s.reply ?? s.action ?? '—')}
                          </td>
                          <td className="p-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              disabled={deletingId === id}
                              onClick={() => void remove(id)}
                            >
                              {deletingId === id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Trash2 className="h-4 w-4 text-destructive" />
                              )}
                            </Button>
                          </td>
                        </tr>
                      )
                    })}
              </tbody>
            </table>
            {!loading && !secretaries.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
