import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsInbox, smsQueryOptions } from '@/lib/modirpayamak-api'

function asRows(data: unknown): Array<Record<string, unknown>> {
  if (!data) return []
  if (Array.isArray(data)) return data as Array<Record<string, unknown>>
  if (typeof data === 'object' && data !== null) {
    const obj = data as Record<string, unknown>
    if (Array.isArray(obj.data)) return obj.data as Array<Record<string, unknown>>
    if (Array.isArray(obj.items)) return obj.items as Array<Record<string, unknown>>
  }
  return []
}

export default function SmsInboxPage() {
  const { t } = useTranslation()
  const q = useQuery({
    queryKey: ['sms', 'inbox', 1],
    queryFn: () => fetchSmsInbox(1, 30),
    ...smsQueryOptions,
  })
  useQueryErrorToast(q)
  const unavailable = isSmsUnavailable(q.data)
  const rows = unavailable ? [] : asRows(q.data?.data)

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.inboxTitle')}</h1>
      {unavailable ? <SmsServiceBanner message={q.data?.message} onRetry={() => void q.refetch()} /> : null}
      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.inboxTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">{t('marketing.sms.from')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.message')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.date')}</th>
                </tr>
              </thead>
              <tbody>
                {q.isPending
                  ? Array.from({ length: 4 }, (_, i) => (
                      <tr key={i}>
                        <td className="p-2" colSpan={3}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : rows.map((r, i) => (
                      <tr key={String(r.id ?? i)} className="border-b">
                        <td className="p-2 font-mono" dir="ltr">
                          {String(r.from ?? r.sender ?? r.number ?? '—')}
                        </td>
                        <td className="p-2 max-w-md truncate">{String(r.message ?? r.text ?? r.body ?? '')}</td>
                        <td className="p-2 text-muted-foreground">{String(r.created_at ?? r.time ?? '')}</td>
                      </tr>
                    ))}
              </tbody>
            </table>
            {!q.isPending && !rows.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
