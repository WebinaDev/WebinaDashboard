import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { ChevronLeft, ChevronRight } from 'lucide-react'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsAccount, fetchSmsLedger, smsQueryOptions } from '@/lib/modirpayamak-api'

export default function SmsWalletPage() {
  const { t } = useTranslation()
  const [page, setPage] = useState(1)

  const accountQ = useQuery({
    queryKey: ['sms', 'account'],
    queryFn: fetchSmsAccount,
    ...smsQueryOptions,
  })
  useQueryErrorToast(accountQ)

  const ledgerQ = useQuery({
    queryKey: ['sms', 'ledger', page],
    queryFn: () => fetchSmsLedger(page, 30),
    ...smsQueryOptions,
  })
  useQueryErrorToast(ledgerQ)

  const unavailable = isSmsUnavailable(accountQ.data)
  const account = unavailable ? null : (accountQ.data?.account ?? null)
  const ledger = ledgerQ.data?.ledger ?? []
  const balanceLoading = accountQ.isPending

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.walletTitle')}</h1>

      {unavailable ? (
        <SmsServiceBanner
          message={accountQ.data?.message}
          onRetry={() => void accountQ.refetch()}
        />
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t('marketing.sms.balance')}</CardTitle>
          </CardHeader>
          <CardContent>
            {balanceLoading ? (
              <Skeleton className="h-9 w-40" />
            ) : (
              <p className="text-3xl font-bold">
                {(account?.balance ?? 0).toLocaleString()}{' '}
                <span className="text-base font-normal">{t('marketing.sms.toman')}</span>
              </p>
            )}
            <Button asChild className="mt-4" variant="outline" disabled={unavailable}>
              <Link to="/marketing/sms/topup">{t('marketing.sms.topup')}</Link>
            </Button>
          </CardContent>
        </Card>

        {account ? (
          <Card>
            <CardHeader>
              <CardTitle>{t('marketing.sms.walletAccount')}</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-1 text-sm">
                {account.domain ? (
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">{t('marketing.sms.walletDomain')}</dt>
                    <dd>{account.domain}</dd>
                  </div>
                ) : null}
                {account.default_from ? (
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">{t('marketing.sms.fromNumber')}</dt>
                    <dd>{account.default_from}</dd>
                  </div>
                ) : null}
                {account.status ? (
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">{t('marketing.sms.status')}</dt>
                    <dd>{account.status}</dd>
                  </div>
                ) : null}
                {account.price_per_unit != null ? (
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">{t('home.panels.smsUnitPrice')}</dt>
                    <dd>{account.price_per_unit}</dd>
                  </div>
                ) : null}
              </dl>
            </CardContent>
          </Card>
        ) : null}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.ledger')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">#</th>
                  <th className="p-2 text-start">{t('marketing.sms.ledgerDate')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.ledgerDescription')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.ledgerAmount')}</th>
                </tr>
              </thead>
              <tbody>
                {ledgerQ.isPending
                  ? Array.from({ length: 6 }, (_, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2" colSpan={4}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : ledger.map((row, i) => (
                      <tr key={String(row.id ?? i)} className="border-b">
                        <td className="p-2">{String(row.id ?? i + 1)}</td>
                        <td className="p-2">{String(row.date ?? row.created_at ?? '—')}</td>
                        <td className="max-w-xs truncate p-2">
                          {String(row.description ?? row.title ?? row.type ?? '—')}
                        </td>
                        <td className="p-2">
                          {typeof row.amount === 'number'
                            ? row.amount.toLocaleString()
                            : String(row.amount ?? '—')}
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
            {!ledgerQ.isPending && !ledger.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
            ) : null}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1 || ledgerQ.isPending}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">{page}</span>
            <Button
              variant="outline"
              size="sm"
              disabled={ledgerQ.isPending || ledger.length < 30}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
