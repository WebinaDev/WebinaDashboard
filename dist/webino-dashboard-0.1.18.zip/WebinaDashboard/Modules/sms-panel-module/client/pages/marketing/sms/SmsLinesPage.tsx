import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { fetchSmsNumbers, smsQueryOptions, type SmsAttachedNumber } from '@/lib/modirpayamak-api'

function unwrapNumbers(
  payload: { data?: SmsAttachedNumber[]; numbers?: SmsAttachedNumber[] } | undefined
): SmsAttachedNumber[] {
  const list = payload?.numbers ?? payload?.data
  return Array.isArray(list) ? list : []
}

export default function SmsLinesPage() {
  const { t } = useTranslation()

  const numbersQ = useQuery({
    queryKey: ['sms-numbers'],
    queryFn: fetchSmsNumbers,
    ...smsQueryOptions,
  })
  useQueryErrorToast(numbersQ)

  const unavailable = isSmsUnavailable(numbersQ.data)
  const numbers = unwrapNumbers(numbersQ.data)
  const loading = numbersQ.isPending

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.linesTitle')}</h1>

      {unavailable ? (
        <SmsServiceBanner
          message={(numbersQ.data as { message?: string } | undefined)?.message}
          onRetry={() => void numbersQ.refetch()}
        />
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>{t('marketing.sms.linesTitle')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-start">{t('marketing.sms.lineNumber')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.lineRole')}</th>
                  <th className="p-2 text-start">{t('marketing.sms.lineLabel')}</th>
                </tr>
              </thead>
              <tbody>
                {loading
                  ? Array.from({ length: 3 }, (_, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2" colSpan={3}>
                          <Skeleton className="h-6 w-full" />
                        </td>
                      </tr>
                    ))
                  : numbers.map((n) => (
                      <tr key={`${n.role}-${n.number}`} className="border-b">
                        <td className="p-2 font-mono">{n.number}</td>
                        <td className="p-2">{n.role}</td>
                        <td className="p-2">{n.label ?? '—'}</td>
                      </tr>
                    ))}
              </tbody>
            </table>
            {!loading && !numbers.length ? (
              <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noLines')}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
