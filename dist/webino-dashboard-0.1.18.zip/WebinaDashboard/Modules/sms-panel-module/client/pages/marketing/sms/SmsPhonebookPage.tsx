import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { Loader2, Trash2, UserPlus } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import { toastApiError } from '@/lib/apiError'
import {
  createSmsPhonebook,
  createSmsPhonebookContact,
  fetchSmsPhonebookContacts,
  fetchSmsPhonebooks,
  smsQueryOptions,
} from '@/lib/modirpayamak-api'

interface Phonebook {
  id: number
  name: string
}

export default function SmsPhonebookPage() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const [newName, setNewName] = useState('')
  const [creatingBook, setCreatingBook] = useState(false)
  const [selectedBook, setSelectedBook] = useState<Phonebook | null>(null)
  const [contactPhone, setContactPhone] = useState('')
  const [contactName, setContactName] = useState('')
  const [addingContact, setAddingContact] = useState(false)

  const booksQ = useQuery({
    queryKey: ['sms', 'phonebooks'],
    queryFn: fetchSmsPhonebooks,
    ...smsQueryOptions,
  })
  useQueryErrorToast(booksQ)

  const contactsQ = useQuery({
    queryKey: ['sms', 'phonebook-contacts', selectedBook?.id],
    queryFn: () => fetchSmsPhonebookContacts(selectedBook!.id),
    enabled: !!selectedBook,
    ...smsQueryOptions,
  })

  const books: Phonebook[] = booksQ.data?.phonebooks ?? []
  const contacts = contactsQ.data?.contacts ?? []

  const addBook = async () => {
    if (!newName.trim()) return
    setCreatingBook(true)
    try {
      await createSmsPhonebook(newName.trim())
      setNewName('')
      void qc.invalidateQueries({ queryKey: ['sms', 'phonebooks'] })
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setCreatingBook(false)
  }

  const addContact = async () => {
    if (!selectedBook || !contactPhone.trim()) return
    setAddingContact(true)
    try {
      await createSmsPhonebookContact(selectedBook.id, {
        phone: contactPhone.trim(),
        name: contactName.trim() || undefined,
      })
      toast.success(t('marketing.sms.contactAdded'))
      setContactPhone('')
      setContactName('')
      void qc.invalidateQueries({ queryKey: ['sms', 'phonebook-contacts', selectedBook.id] })
    } catch (e) {
      toastApiError(t, e as Error)
    }
    setAddingContact(false)
  }

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.phonebookTitle')}</h1>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <Card className="max-w-md">
            <CardHeader>
              <CardTitle>{t('marketing.sms.newPhonebook')}</CardTitle>
            </CardHeader>
            <CardContent className="flex gap-2">
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') void addBook() }}
              />
              <Button
                type="button"
                disabled={creatingBook || !newName.trim()}
                onClick={() => void addBook()}
              >
                {creatingBook ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {t('common.save')}
              </Button>
            </CardContent>
          </Card>

          {booksQ.isPending ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }, (_, i) => (
                <Skeleton key={i} className="h-12 w-full rounded-md" />
              ))}
            </div>
          ) : (
            <ul className="space-y-2">
              {books.map((b) => (
                <li
                  key={b.id}
                  className={`flex cursor-pointer items-center justify-between rounded border p-3 transition-colors hover:bg-muted/50 ${
                    selectedBook?.id === b.id ? 'border-primary bg-muted' : ''
                  }`}
                  onClick={() => setSelectedBook(b)}
                >
                  <span className="font-medium">{b.name}</span>
                  <span className="text-muted-foreground text-xs">#{b.id}</span>
                </li>
              ))}
              {!books.length ? (
                <p className="text-muted-foreground text-sm">{t('common.empty')}</p>
              ) : null}
            </ul>
          )}
        </div>

        <div className="space-y-4">
          {!selectedBook ? (
            <p className="text-muted-foreground text-sm">{t('marketing.sms.selectPhonebook')}</p>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>
                    {t('marketing.sms.contacts')} — {selectedBook.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>{t('marketing.sms.contactPhone')}</Label>
                      <Input
                        className="mt-1"
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        placeholder="09..."
                      />
                    </div>
                    <div>
                      <Label>{t('marketing.sms.contactName')}</Label>
                      <Input
                        className="mt-1"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    disabled={addingContact || !contactPhone.trim()}
                    onClick={() => void addContact()}
                  >
                    {addingContact ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <UserPlus className="mr-2 h-4 w-4" />
                    )}
                    {t('marketing.sms.addContact')}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{t('marketing.sms.contacts')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="p-2 text-start">{t('marketing.sms.contactPhone')}</th>
                          <th className="p-2 text-start">{t('marketing.sms.contactName')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {contactsQ.isPending
                          ? Array.from({ length: 4 }, (_, i) => (
                              <tr key={i} className="border-b">
                                <td className="p-2" colSpan={2}>
                                  <Skeleton className="h-5 w-full" />
                                </td>
                              </tr>
                            ))
                          : contacts.map((c) => (
                              <tr key={c.id} className="border-b">
                                <td className="p-2 font-mono">{c.phone}</td>
                                <td className="p-2">{c.name ?? '—'}</td>
                              </tr>
                            ))}
                      </tbody>
                    </table>
                    {!contactsQ.isPending && !contacts.length ? (
                      <p className="text-muted-foreground mt-3 text-sm">{t('common.empty')}</p>
                    ) : null}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
