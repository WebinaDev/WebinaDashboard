import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import { ChevronLeft, ChevronRight } from 'lucide-react'

import { SmsServiceBanner, isSmsUnavailable } from '@/components/marketing/SmsServiceBanner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useQueryErrorToast } from '@/hooks/useQueryErrorToast'
import {
  fetchSmsMessages,
  fetchSmsOutbox,
  smsQueryOptions,
  type SmsMessage,
} from '@/lib/modirpayamak-api'

function unwrapList(data: unknown): Record<string, unknown>[] {
  if (!data) return []
  if (Array.isArray(data)) return data as Record<string, unknown>[]
  const d = data as Record<string, unknown>
  for (const key of ['messages', 'data', 'items', 'list', 'outbox']) {
    if (Array.isArray(d[key])) return d[key] as Record<string, unknown>[]
  }
  return []
}

export default function SmsReportsPage() {
  const { t } = useTranslation()
  const [outboxPage, setOutboxPage] = useState(1)

  const messagesQ = useQuery({
    queryKey: ['sms', 'messages', 1],
    queryFn: () => fetchSmsMessages(1),
    ...smsQueryOptions,
  })
  useQueryErrorToast(messagesQ)

  const outboxQ = useQuery({
    queryKey: ['sms', 'outbox', outboxPage],
    queryFn: () => fetchSmsOutbox(outboxPage, 20),
    ...smsQueryOptions,
  })
  useQueryErrorToast(outboxQ)

  const unavailable = isSmsUnavailable(messagesQ.data)
  const messages: SmsMessage[] = unavailable ? [] : (messagesQ.data?.messages ?? [])
  const outboxItems = unwrapList(outboxQ.data?.data)
  const messagesLoading = messagesQ.isPending
  const outboxLoading = outboxQ.isPending

  return (
    <div className="space-y-6 p-4">
      <h1 className="text-2xl font-semibold">{t('marketing.sms.reportsTitle')}</h1>

      {unavailable ? (
        <SmsServiceBanner message={messagesQ.data?.message} onRetry={() => void messagesQ.refetch()} />
      ) : null}

      <Tabs defaultValue="local">
        <TabsList>
          <TabsTrigger value="local">{t('marketing.sms.localMessages')}</TabsTrigger>
          <TabsTrigger value="outbox">{t('marketing.sms.outbox')}</TabsTrigger>
        </TabsList>

        <TabsContent value="local">
          <Card>
            <CardHeader>
              <CardTitle>{t('marketing.sms.localMessages')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="p-2 text-start">#</th>
                      <th className="p-2 text-start">{t('marketing.sms.type')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.status')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.cost')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.sentAt')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {messagesLoading
                      ? Array.from({ length: 5 }, (_, i) => (
                          <tr key={i} className="border-b">
                            <td className="p-2" colSpan={5}>
                              <Skeleton className="h-6 w-full" />
                            </td>
                          </tr>
                        ))
                      : messages.map((m) => (
                          <tr key={m.id} className="border-b">
                            <td className="p-2">{m.id}</td>
                            <td className="p-2">{m.sending_type}</td>
                            <td className="p-2">{m.status}</td>
                            <td className="p-2">{m.cost?.toLocaleString()}</td>
                            <td className="p-2">{m.created_at ?? '—'}</td>
                          </tr>
                        ))}
                  </tbody>
                </table>
                {!messagesLoading && !messages.length ? (
                  <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="outbox">
          <Card>
            <CardHeader>
              <CardTitle>{t('marketing.sms.outbox')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="p-2 text-start">{t('marketing.sms.outboxId')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.recipient')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.status')}</th>
                      <th className="p-2 text-start">{t('marketing.sms.sentAt')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {outboxLoading
                      ? Array.from({ length: 5 }, (_, i) => (
                          <tr key={i} className="border-b">
                            <td className="p-2" colSpan={4}>
                              <Skeleton className="h-6 w-full" />
                            </td>
                          </tr>
                        ))
                      : outboxItems.map((m, i) => (
                          <tr key={String(m.id ?? i)} className="border-b">
                            <td className="p-2 font-mono text-xs">{String(m.id ?? i + 1)}</td>
                            <td className="p-2">
                              {String(m.recipient ?? m.phone ?? m.to ?? '—')}
                            </td>
                            <td className="p-2">{String(m.status ?? '—')}</td>
                            <td className="p-2">
                              {String(m.send_time ?? m.created_at ?? '—')}
                            </td>
                          </tr>
                        ))}
                  </tbody>
                </table>
                {!outboxLoading && !outboxItems.length ? (
                  <p className="text-muted-foreground mt-4 text-sm">{t('marketing.sms.noMessages')}</p>
                ) : null}
              </div>
              <div className="mt-4 flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={outboxPage <= 1 || outboxLoading}
                  onClick={() => setOutboxPage((p) => p - 1)}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm">{outboxPage}</span>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={outboxLoading || outboxItems.length < 20}
                  onClick={() => setOutboxPage((p) => p + 1)}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
